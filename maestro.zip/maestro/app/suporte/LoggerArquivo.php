<?php

declare(strict_types=1);

namespace App\suporte;

/**
 * Registra logs tecnicos em arquivo local sem derrubar a aplicacao em caso de falha.
 */
class LoggerArquivo
{
    public function __construct(
        private readonly string $caminhoArquivo,
        private readonly string $ambiente
    ) {
    }

    /**
     * Grava uma linha de log estruturada em JSON.
     *
     * @param array<string, mixed> $contexto Contexto tecnico nao sensivel.
     */
    public function registrar(string $nivel, string $mensagem, array $contexto = []): void
    {
        $diretorio = dirname($this->caminhoArquivo);

        if (!is_dir($diretorio)) {
            @mkdir($diretorio, 0775, true);
        }

        $linha = json_encode([
            'data_hora' => date(DATE_ATOM),
            'ambiente' => $this->ambiente,
            'nivel' => $nivel,
            'mensagem' => $mensagem,
            'contexto' => $contexto,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($linha === false) {
            return;
        }

        @file_put_contents($this->caminhoArquivo, $linha . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
