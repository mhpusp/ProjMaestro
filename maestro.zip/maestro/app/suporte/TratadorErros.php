<?php

declare(strict_types=1);

namespace App\suporte;

use App\repositories\ErroRepository;
use App\services\VersaoCodigoService;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Throwable;

/**
 * Trata erros inesperados de forma centralizada, sem expor detalhes internos ao usuario.
 */
class TratadorErros
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     */
    public function __construct(
        private readonly ResponseFactoryInterface $responseFactory,
        private readonly Template $template,
        private readonly ErroRepository $erros,
        private readonly SanitizadorContextoErro $sanitizador,
        private readonly array $configuracao,
        private readonly VersaoCodigoService $versaoCodigo
    ) {
    }

    /**
     * Retorna resposta amigavel e registra detalhes tecnicos sem expor stack trace.
     */
    public function __invoke(
        ServerRequestInterface $request,
        Throwable $exception,
        bool $displayErrorDetails,
        bool $logErrors,
        bool $logErrorDetails
    ): ResponseInterface {
        $codigo = $this->gerarCodigoPublico();
        $this->erros->registrar($this->montarRegistro($codigo, $request, $exception));

        if ($this->prefereJson($request)) {
            return $this->responderJson($codigo);
        }

        return $this->responderHtml($codigo, $request);
    }

    private function gerarCodigoPublico(): string
    {
        $prefixo = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $this->configuracao['erros']['prefixo'])) ?? '';
        $prefixo = $prefixo !== '' ? $prefixo : 'REQ';

        return sprintf('%s-%s-%s', $prefixo, date('Y'), strtoupper(bin2hex(random_bytes(3))));
    }

    /**
     * @return array<string, mixed>
     */
    private function montarRegistro(
        string $codigo,
        ServerRequestInterface $request,
        Throwable $exception
    ): array {
        $contexto = [
            'rota' => (string) $request->getUri()->getPath(),
            'metodo' => $request->getMethod(),
            'query' => $request->getQueryParams(),
            'body' => (array) ($request->getParsedBody() ?? []),
            'headers' => $request->getHeaders(),
        ];
        $workplace = $request->getAttribute('workplace');

        if ($workplace instanceof WorkplaceSession) {
            $contexto['workplace'] = [
                'usuario_id' => $workplace->usuario->id,
                'usuario_nome' => $workplace->usuario->nome,
                'papel_ativo' => $workplace->papelAtivo->codigo,
                'origem' => $workplace->origem,
            ];
        }

        return [
            'codigo' => $codigo,
            'registrado_em' => date(DATE_ATOM),
            'ambiente' => (string) $this->configuracao['app']['ambiente'],
            'versao_codigo' => $this->versaoCodigo->resumo(),
            'erro' => $exception::class,
            'mensagem_tecnica' => $exception->getMessage(),
            'arquivo' => $exception->getFile(),
            'linha' => $exception->getLine(),
            'contexto' => $this->sanitizador->sanitizar($contexto),
        ];
    }

    private function responderJson(string $codigo): ResponseInterface
    {
        $versao = $this->versaoCodigo->assinatura();
        $response = $this->responseFactory->createResponse(500);
        $response->getBody()->write((string) json_encode([
            'status' => 'erro',
            'mensagem' => 'Nao foi possivel concluir a operacao.',
            'codigo' => $codigo,
            'assinatura' => $versao,
        ], JSON_UNESCAPED_UNICODE));

        return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
    }

    private function responderHtml(string $codigo, ServerRequestInterface $request): ResponseInterface
    {
        $response = $this->responseFactory->createResponse(500);
        $html = $this->renderizarPaginaErro($codigo, $request);
        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function renderizarPaginaErro(string $codigo, ServerRequestInterface $request): string
    {
        try {
            return $this->template->renderizar('erro.php', [
                'titulo' => 'Erro inesperado',
                'codigoErro' => $codigo,
                'assinaturaErro' => $this->versaoCodigo->assinatura(),
                'suporteUrl' => (string) $this->configuracao['erros']['suporte_url'],
                'layout' => [
                    'nomeSistema' => $this->configuracao['app']['nome'],
                    'workplaceSession' => $request->getAttribute('workplace'),
                    'versao' => $this->versaoCodigo->assinatura(),
                    'versaoCodigo' => $this->versaoCodigo->resumo(),
                    'basePath' => $this->configuracao['app']['base_path'],
                ],
            ]);
        } catch (Throwable) {
            return '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Erro inesperado</title>'
                . '<body><h1>Nao foi possivel concluir a operacao.</h1>'
                . '<p>Informe o codigo ' . htmlspecialchars($codigo) . ' ao suporte.</p>'
                . '<p>Assinatura: ' . htmlspecialchars($this->versaoCodigo->assinatura()) . '</p></body></html>';
        }
    }

    private function prefereJson(ServerRequestInterface $request): bool
    {
        $accept = implode(',', $request->getHeader('Accept'));
        $path = (string) $request->getUri()->getPath();

        return str_starts_with($path, '/api/') || str_contains($accept, 'application/json');
    }
}
