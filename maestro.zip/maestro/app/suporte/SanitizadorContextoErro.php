<?php

declare(strict_types=1);

namespace App\suporte;

/**
 * Remove ou mascara dados sensiveis antes de registrar contexto tecnico de erro.
 */
class SanitizadorContextoErro
{
    /** @var array<int, string> */
    private const CAMPOS_SENSIVEIS = [
        'senha',
        'password',
        'token',
        'authorization',
        'cookie',
        'csrf',
        'secret',
        'cpf',
        'rg',
        'arquivo',
        'conteudo',
        'parecer',
        'observacao',
    ];

    /**
     * Sanitiza arrays de qualquer profundidade.
     *
     * @param array<string, mixed> $contexto
     * @return array<string, mixed>
     */
    public function sanitizar(array $contexto): array
    {
        $sanitizado = [];

        foreach ($contexto as $chave => $valor) {
            if ($this->chaveSensivel((string) $chave)) {
                $sanitizado[$chave] = '[removido]';
                continue;
            }

            if (is_array($valor)) {
                $sanitizado[$chave] = $this->sanitizar($valor);
                continue;
            }

            $sanitizado[$chave] = $valor;
        }

        return $sanitizado;
    }

    private function chaveSensivel(string $chave): bool
    {
        $chave = strtolower($chave);

        foreach (self::CAMPOS_SENSIVEIS as $campo) {
            if (str_contains($chave, $campo)) {
                return true;
            }
        }

        return false;
    }
}
