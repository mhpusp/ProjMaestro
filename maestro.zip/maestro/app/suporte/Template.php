<?php

declare(strict_types=1);

namespace App\suporte;

use RuntimeException;

/**
 * Renderizador simples de templates PHP.
 *
 * Evita dependencias extras nesta primeira versao do scaffold e mantem a ideia
 * de layout base com views parciais, familiar aos projetos Fat-Free.
 */
class Template
{
    public function __construct(private readonly string $caminhoViews)
    {
    }

    /**
     * Renderiza um arquivo de template dentro de `app/views`.
     *
     * @param array<string, mixed> $variaveis Dados disponiveis para o template.
     */
    public function renderizar(string $arquivo, array $variaveis = []): string
    {
        $caminho = $this->caminhoViews . '/' . ltrim($arquivo, '/');

        if (!file_exists($caminho)) {
            throw new RuntimeException("Template nao encontrado: {$arquivo}");
        }

        extract($variaveis, EXTR_SKIP);

        ob_start();
        require $caminho;

        return (string) ob_get_clean();
    }
}
