<?php

declare(strict_types=1);

use App\workplace\WorkplaceSession;

/**
 * Exibe usuario logado e papel ativo da sessao Workplace.
 *
 * Parametros:
 * - WorkplaceSession|null $workplaceSession Contexto institucional atual.
 * - string $basePath Base path da aplicacao.
 */

$basePath = rtrim((string) ($basePath ?? ''), '/');
?>
<div class="ms-md-auto poli-user-panel">
    <?php if (($workplaceSession ?? null) instanceof WorkplaceSession): ?>
        <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-2 gap-lg-3">
            <div>
                <div class="fw-semibold"><?= htmlspecialchars($workplaceSession->usuario->nome) ?></div>
                <div class="small text-secondary">
                    Papel ativo: <?= htmlspecialchars($workplaceSession->papelAtivo->nome) ?>
                </div>
            </div>

            <form method="post" action="<?= htmlspecialchars($basePath) ?>/workplace/papel" class="d-flex gap-2">
                <label class="visually-hidden" for="workplace-papel">Papel ativo</label>
                <select class="form-select form-select-sm" id="workplace-papel" name="papel">
                    <?php foreach ($workplaceSession->usuario->papeis() as $papel): ?>
                        <option value="<?= htmlspecialchars($papel->codigo) ?>" <?= $papel->codigo === $workplaceSession->papelAtivo->codigo ? 'selected' : '' ?>>
                            <?= htmlspecialchars($papel->nome) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-light btn-sm">Trocar</button>
            </form>

            <a href="<?= htmlspecialchars($basePath) ?>/logout" class="btn btn-outline-light btn-sm">Sair</a>
        </div>
    <?php else: ?>
        <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
            <div>
                <div class="fw-semibold">Acesso publico</div>
                <div class="small text-secondary">Sem sessao autenticada</div>
            </div>
        </div>
    <?php endif; ?>
</div>
