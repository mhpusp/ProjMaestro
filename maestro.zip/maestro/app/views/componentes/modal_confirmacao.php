<?php

declare(strict_types=1);

/**
 * Modal Bootstrap para confirmar acoes simples.
 *
 * Parametros:
 * - string $id Identificador HTML unico do modal.
 * - string $titulo Titulo do modal.
 * - string $mensagem Texto explicativo.
 * - string $acaoUrl URL do formulario de confirmacao.
 * - string $metodo Metodo HTTP do formulario.
 * - string $rotuloConfirmar Texto do botao principal.
 * - string $classeConfirmar Classe CSS do botao principal.
 *
 * Exemplo:
 * $id = 'modal-remover';
 * $titulo = 'Remover item';
 * $mensagem = 'Deseja continuar?';
 * $acaoUrl = '/itens/1/remover';
 * require __DIR__ . '/modal_confirmacao.php';
 */

$id = (string) ($id ?? 'modal-confirmacao');
$titulo = (string) ($titulo ?? 'Confirmar acao');
$mensagem = (string) ($mensagem ?? 'Deseja continuar?');
$acaoUrl = (string) ($acaoUrl ?? '#');
$metodo = strtoupper((string) ($metodo ?? 'POST'));
$rotuloConfirmar = (string) ($rotuloConfirmar ?? 'Confirmar');
$classeConfirmar = (string) ($classeConfirmar ?? 'btn btn-primary');
?>
<div class="modal modal-blur fade" id="<?= htmlspecialchars($id) ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <form class="modal-content" method="<?= htmlspecialchars($metodo) ?>" action="<?= htmlspecialchars($acaoUrl) ?>">
            <div class="modal-header">
                <h5 class="modal-title"><?= htmlspecialchars($titulo) ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <?= htmlspecialchars($mensagem) ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                    Cancelar
                </button>
                <button type="submit" class="<?= htmlspecialchars($classeConfirmar) ?>">
                    <?= htmlspecialchars($rotuloConfirmar) ?>
                </button>
            </div>
        </form>
    </div>
</div>
