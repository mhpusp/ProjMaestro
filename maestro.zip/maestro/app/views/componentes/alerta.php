<?php

declare(strict_types=1);

/**
 * Alerta Bootstrap/Tabler para mensagens de usuario.
 *
 * Parametros:
 * - string $tipo Um de: sucesso, aviso, erro, info.
 * - string $titulo Titulo opcional.
 * - string $mensagem Mensagem principal.
 * - array<int, string> $itens Lista opcional de detalhes.
 * - bool $dispensavel Exibe botao de fechar.
 *
 * Exemplo:
 * $tipo = 'aviso';
 * $titulo = 'Atencao';
 * $mensagem = 'Revise os campos destacados.';
 * require __DIR__ . '/alerta.php';
 */

$tipo = (string) ($tipo ?? 'info');
$titulo = (string) ($titulo ?? '');
$mensagem = (string) ($mensagem ?? '');
$itens = is_array($itens ?? null) ? $itens : [];
$dispensavel = (bool) ($dispensavel ?? false);

$classesPorTipo = [
    'sucesso' => 'alert-success',
    'aviso' => 'alert-warning',
    'erro' => 'alert-danger',
    'info' => 'alert-info',
];

$classeTipo = $classesPorTipo[$tipo] ?? $classesPorTipo['info'];
?>
<div class="alert <?= htmlspecialchars($classeTipo) ?> <?= $dispensavel ? 'alert-dismissible' : '' ?>" role="alert">
    <?php if ($titulo !== ''): ?>
        <h4 class="alert-title"><?= htmlspecialchars($titulo) ?></h4>
    <?php endif; ?>

    <?php if ($mensagem !== ''): ?>
        <div><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <?php if ($itens !== []): ?>
        <ul class="mb-0 mt-2">
            <?php foreach ($itens as $item): ?>
                <li><?= htmlspecialchars((string) $item) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if ($dispensavel): ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    <?php endif; ?>
</div>
