<?php

declare(strict_types=1);

/**
 * Barra de acoes com botoes empilhados no celular e alinhados no desktop.
 *
 * Parametros:
 * - array<int, array{rotulo:string,url:string,classe?:string,htmx?:array<string,string>}> $acoes
 *
 * Exemplo:
 * $acoes = [
 *     ['rotulo' => 'Salvar', 'url' => '/salvar', 'classe' => 'btn btn-primary'],
 *     ['rotulo' => 'Cancelar', 'url' => '/', 'classe' => 'btn btn-outline-secondary'],
 * ];
 * require __DIR__ . '/barra_acoes_mobile.php';
 */

$acoes = is_array($acoes ?? null) ? $acoes : [];
?>
<?php if ($acoes !== []): ?>
    <div class="poli-barra-acoes-mobile d-grid gap-2 d-md-none">
        <?php foreach ($acoes as $acao): ?>
            <?php
            $rotulo = (string) ($acao['rotulo'] ?? 'Acao');
            $url = (string) ($acao['url'] ?? '#');
            $classe = (string) ($acao['classe'] ?? 'btn btn-primary');
            $htmx = is_array($acao['htmx'] ?? null) ? $acao['htmx'] : [];
            ?>
            <a href="<?= htmlspecialchars($url) ?>" class="<?= htmlspecialchars($classe) ?>"
                <?php foreach ($htmx as $atributo => $valor): ?>
                    <?= htmlspecialchars((string) $atributo) ?>="<?= htmlspecialchars((string) $valor) ?>"
                <?php endforeach; ?>
            ><?= htmlspecialchars($rotulo) ?></a>
        <?php endforeach; ?>
    </div>

    <div class="d-none d-md-flex justify-content-end gap-2">
        <?php foreach ($acoes as $acao): ?>
            <?php
            $rotulo = (string) ($acao['rotulo'] ?? 'Acao');
            $url = (string) ($acao['url'] ?? '#');
            $classe = (string) ($acao['classe'] ?? 'btn btn-primary');
            $htmx = is_array($acao['htmx'] ?? null) ? $acao['htmx'] : [];
            ?>
            <a href="<?= htmlspecialchars($url) ?>" class="<?= htmlspecialchars($classe) ?>"
                <?php foreach ($htmx as $atributo => $valor): ?>
                    <?= htmlspecialchars((string) $atributo) ?>="<?= htmlspecialchars((string) $valor) ?>"
                <?php endforeach; ?>
            ><?= htmlspecialchars($rotulo) ?></a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
