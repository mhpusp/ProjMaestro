<?php

declare(strict_types=1);

/**
 * Badge de status para listas, cards e cabecalhos.
 *
 * Parametros:
 * - string $texto Texto exibido no badge.
 * - string $tipo Um de: sucesso, aviso, erro, info, neutro.
 * - string $classeExtra Classes CSS adicionais opcionais.
 *
 * Exemplo:
 * $texto = 'Ativo';
 * $tipo = 'sucesso';
 * require __DIR__ . '/badge_status.php';
 */

$texto = (string) ($texto ?? 'Status');
$tipo = (string) ($tipo ?? 'info');
$classeExtra = (string) ($classeExtra ?? '');

$classesPorTipo = [
    'sucesso' => 'poli-status-sucesso',
    'aviso' => 'poli-status-aviso',
    'erro' => 'poli-status-erro',
    'info' => 'poli-status-info',
    'neutro' => 'poli-status-neutro',
];

$classeTipo = $classesPorTipo[$tipo] ?? $classesPorTipo['info'];
?>
<span class="poli-status <?= htmlspecialchars($classeTipo) ?> <?= htmlspecialchars($classeExtra) ?>">
    <?= htmlspecialchars($texto) ?>
</span>
