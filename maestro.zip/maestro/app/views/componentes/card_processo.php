<?php

declare(strict_types=1);

/**
 * Card para representar processos, solicitacoes ou registros principais.
 *
 * Parametros:
 * - string $titulo Titulo do processo.
 * - string $descricao Texto resumido.
 * - array{texto:string,tipo:string} $status Badge opcional.
 * - array<string, string> $detalhes Pares rotulo => valor.
 * - array<int, array{rotulo:string,url:string,classe?:string}> $acoes Links de acao.
 *
 * Exemplo:
 * $titulo = 'Solicitacao 123';
 * $descricao = 'Atualizacao cadastral';
 * $status = ['texto' => 'Em analise', 'tipo' => 'aviso'];
 * $detalhes = ['Unidade' => 'Poli', 'Responsavel' => 'Maria Silva'];
 * $acoes = [['rotulo' => 'Abrir', 'url' => '/processos/123']];
 * require __DIR__ . '/card_processo.php';
 */

$titulo = (string) ($titulo ?? 'Processo');
$descricao = (string) ($descricao ?? '');
$status = is_array($status ?? null) ? $status : [];
$detalhes = is_array($detalhes ?? null) ? $detalhes : [];
$acoes = is_array($acoes ?? null) ? $acoes : [];
?>
<article class="card poli-card h-100">
    <div class="card-body">
        <div class="d-flex flex-column flex-sm-row justify-content-between gap-3 mb-3">
            <div>
                <h3 class="card-title mb-1"><?= htmlspecialchars($titulo) ?></h3>
                <?php if ($descricao !== ''): ?>
                    <p class="text-secondary mb-0"><?= htmlspecialchars($descricao) ?></p>
                <?php endif; ?>
            </div>

            <?php if ($status !== []): ?>
                <?php
                $texto = (string) ($status['texto'] ?? 'Status');
                $tipo = (string) ($status['tipo'] ?? 'info');
                require __DIR__ . '/badge_status.php';
                ?>
            <?php endif; ?>
        </div>

        <?php if ($detalhes !== []): ?>
            <dl class="row g-2 mb-3">
                <?php foreach ($detalhes as $rotulo => $valor): ?>
                    <dt class="col-5 text-secondary fw-normal"><?= htmlspecialchars((string) $rotulo) ?></dt>
                    <dd class="col-7 mb-0 fw-semibold"><?= htmlspecialchars((string) $valor) ?></dd>
                <?php endforeach; ?>
            </dl>
        <?php endif; ?>

        <?php if ($acoes !== []): ?>
            <div class="d-flex flex-column flex-sm-row gap-2">
                <?php foreach ($acoes as $acao): ?>
                    <?php
                    $rotuloAcao = (string) ($acao['rotulo'] ?? 'Abrir');
                    $urlAcao = (string) ($acao['url'] ?? '#');
                    $classeAcao = (string) ($acao['classe'] ?? 'btn btn-primary');
                    ?>
                    <a href="<?= htmlspecialchars($urlAcao) ?>" class="<?= htmlspecialchars($classeAcao) ?>">
                        <?= htmlspecialchars($rotuloAcao) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</article>
