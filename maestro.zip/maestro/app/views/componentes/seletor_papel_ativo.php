<?php

declare(strict_types=1);

/**
 * Seletor de papel ativo do usuario.
 *
 * Parametros:
 * - array<string, string> $papeis Valor => rotulo.
 * - string $papelAtivo Valor atualmente selecionado.
 * - string $acaoUrl URL para troca de papel.
 * - string $nomeCampo Nome do campo enviado.
 *
 * Exemplo:
 * $papeis = ['admin' => 'Administrador', 'leitor' => 'Leitor'];
 * $papelAtivo = 'admin';
 * $acaoUrl = '/perfil/papel';
 * require __DIR__ . '/seletor_papel_ativo.php';
 */

$papeis = is_array($papeis ?? null) ? $papeis : [];
$papelAtivo = (string) ($papelAtivo ?? '');
$acaoUrl = (string) ($acaoUrl ?? '#');
$nomeCampo = (string) ($nomeCampo ?? 'papel');
?>
<form method="post" action="<?= htmlspecialchars($acaoUrl) ?>" class="card">
    <div class="card-body">
        <label class="form-label" for="<?= htmlspecialchars($nomeCampo) ?>">Papel ativo</label>
        <div class="d-flex flex-column flex-sm-row gap-2">
            <select class="form-select" id="<?= htmlspecialchars($nomeCampo) ?>" name="<?= htmlspecialchars($nomeCampo) ?>">
                <?php foreach ($papeis as $valor => $rotulo): ?>
                    <option value="<?= htmlspecialchars((string) $valor) ?>" <?= (string) $valor === $papelAtivo ? 'selected' : '' ?>>
                        <?= htmlspecialchars((string) $rotulo) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary">Trocar</button>
        </div>
    </div>
</form>
