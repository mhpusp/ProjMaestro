<?php

declare(strict_types=1);

/**
 * Campo de busca com atributos htmx opcionais.
 *
 * Parametros:
 * - string $id Identificador do campo.
 * - string $nome Nome enviado na requisicao.
 * - string $valor Valor atual.
 * - string $rotulo Rotulo exibido.
 * - string $placeholder Texto de apoio.
 * - string $hxGet URL htmx para buscar resultados.
 * - string $hxTarget Seletor que recebera a resposta.
 * - string $hxIndicator Seletor do indicador de carregamento.
 * - string $hxTrigger Evento htmx.
 *
 * Exemplo:
 * $hxGet = '/usuarios/buscar';
 * $hxTarget = '#resultado-busca';
 * require __DIR__ . '/campo_busca_htmx.php';
 */

$id = (string) ($id ?? 'busca');
$nome = (string) ($nome ?? 'busca');
$valor = (string) ($valor ?? '');
$rotulo = (string) ($rotulo ?? 'Buscar');
$placeholder = (string) ($placeholder ?? 'Digite para buscar');
$hxGet = (string) ($hxGet ?? '');
$hxTarget = (string) ($hxTarget ?? '');
$hxIndicator = (string) ($hxIndicator ?? '');
$hxTrigger = (string) ($hxTrigger ?? 'keyup changed delay:500ms, search');
?>
<div class="mb-3">
    <label class="form-label" for="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($rotulo) ?></label>
    <div class="input-icon">
        <span class="input-icon-addon" aria-hidden="true">
            <span class="ti ti-search"></span>
        </span>
        <input
            type="search"
            class="form-control"
            id="<?= htmlspecialchars($id) ?>"
            name="<?= htmlspecialchars($nome) ?>"
            value="<?= htmlspecialchars($valor) ?>"
            placeholder="<?= htmlspecialchars($placeholder) ?>"
            <?php if ($hxGet !== ''): ?>
                hx-get="<?= htmlspecialchars($hxGet) ?>"
                hx-trigger="<?= htmlspecialchars($hxTrigger) ?>"
            <?php endif; ?>
            <?php if ($hxTarget !== ''): ?>
                hx-target="<?= htmlspecialchars($hxTarget) ?>"
            <?php endif; ?>
            <?php if ($hxIndicator !== ''): ?>
                hx-indicator="<?= htmlspecialchars($hxIndicator) ?>"
            <?php endif; ?>
        >
    </div>
</div>
