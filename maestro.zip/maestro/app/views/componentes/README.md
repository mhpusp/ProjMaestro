# Componentes Reutilizaveis

Componentes PHP simples para views do scaffold. Cada arquivo recebe variaveis claras antes do `require` e usa Bootstrap/Tabler.

Exemplo geral:

```php
$texto = 'Ativo';
$tipo = 'sucesso';
require __DIR__ . '/componentes/badge_status.php';
```

Componentes disponiveis:

- `badge_status.php`: badge visual para status.
- `card_processo.php`: card para processos, solicitacoes ou registros.
- `tabela_responsiva.php`: tabela desktop que vira cards no celular.
- `barra_acoes_mobile.php`: acoes empilhadas no celular e alinhadas no desktop.
- `alerta.php`: mensagens de usuario com estilos Bootstrap.
- `modal_confirmacao.php`: modal simples de confirmacao.
- `seletor_papel_ativo.php`: formulario para troca de papel ativo.
- `campo_busca_htmx.php`: busca com atributos htmx opcionais.
- `workplace_usuario.php`: exibe usuario logado, papel ativo e seletor de papel da sessao Workplace.

Os parametros aceitos e exemplos especificos ficam comentados no topo de cada componente.
