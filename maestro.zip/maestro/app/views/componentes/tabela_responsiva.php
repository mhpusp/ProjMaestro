<?php

declare(strict_types=1);

/**
 * Tabela que vira lista de cards no celular.
 *
 * Parametros:
 * - array<string, string> $colunas Chave da linha => rotulo.
 * - array<int, array<string, mixed>> $linhas Dados da tabela.
 * - string $vazio Mensagem para lista vazia.
 *
 * Exemplo:
 * $colunas = ['nome' => 'Nome', 'status' => 'Status'];
 * $linhas = [['nome' => 'Cadastro', 'status' => 'Ativo']];
 * require __DIR__ . '/tabela_responsiva.php';
 */

$colunas = is_array($colunas ?? null) ? $colunas : [];
$linhas = is_array($linhas ?? null) ? $linhas : [];
$vazio = (string) ($vazio ?? 'Nenhum registro encontrado.');
?>
<?php if ($linhas === []): ?>
    <div class="alert alert-info mb-0" role="alert">
        <?= htmlspecialchars($vazio) ?>
    </div>
<?php else: ?>
    <div class="d-none d-md-block table-responsive">
        <table class="table table-vcenter card-table">
            <thead>
                <tr>
                    <?php foreach ($colunas as $rotulo): ?>
                        <th><?= htmlspecialchars((string) $rotulo) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($linhas as $linha): ?>
                    <tr>
                        <?php foreach ($colunas as $chave => $rotulo): ?>
                            <td><?= htmlspecialchars((string) ($linha[$chave] ?? '')) ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="d-grid gap-3 d-md-none">
        <?php foreach ($linhas as $linha): ?>
            <article class="card">
                <div class="card-body">
                    <?php foreach ($colunas as $chave => $rotulo): ?>
                        <div class="d-flex justify-content-between gap-3 py-1">
                            <span class="text-secondary"><?= htmlspecialchars((string) $rotulo) ?></span>
                            <strong class="text-end"><?= htmlspecialchars((string) ($linha[$chave] ?? '')) ?></strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
