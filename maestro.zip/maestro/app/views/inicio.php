<?php

declare(strict_types=1);

$nomeAplicacao = $dados['nomeAplicacao'] ?? 'Siicusp - Apresentações';
$ambiente = $dados['ambiente'] ?? 'desenvolvimento';
$versao = $dados['versao'] ?? '0.1.0';
$componentes = __DIR__ . '/componentes';
?>
<div class="row g-3 g-md-4">
    <div class="col-12">
        <div class="card poli-card poli-card-destaque">
            <div class="card-body">
                <div class="row align-items-center gy-3">
                    <div class="col-12 col-lg">
                        <p class="text-secondary mb-2">Scaffold PHP Slim</p>
                        <h2 class="card-title mb-2">Bem-vindo ao <?= htmlspecialchars((string) $nomeAplicacao) ?></h2>
                        <p class="mb-0">
                            Base visual sobria para sistemas administrativos da Informatica Poli,
                            usando Tabler, Bootstrap 5 e componentes simples.
                        </p>
                    </div>
                    <div class="col-12 col-lg-auto">
                        <?php
                        $texto = 'Ambiente ' . $ambiente;
                        $tipo = 'info';
                        require $componentes . '/badge_status.php';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-6 col-xl-4">
        <?php
        $titulo = 'Fluxo inicial';
        $descricao = 'Estrutura pronta para rotas, controllers, models e views sem exigir arquitetura complexa.';
        $status = ['texto' => 'Aplicacao pronta', 'tipo' => 'sucesso'];
        $detalhes = ['Camada' => 'MVC simples', 'Base' => 'Slim'];
        $acoes = [
            ['rotulo' => 'Abrir modulo exemplo', 'url' => '/solicitacoes', 'classe' => 'btn btn-primary'],
        ];
        require $componentes . '/card_processo.php';
        ?>
    </div>

    <div class="col-12 col-md-6 col-xl-4">
        <?php
        $titulo = 'Interface responsiva';
        $descricao = 'Cards e blocos de conteudo se reorganizam para celular antes de crescer para desktop.';
        $status = ['texto' => 'Mobile-first', 'tipo' => 'aviso'];
        $detalhes = ['Desktop' => 'Grid fluido', 'Celular' => 'Cards'];
        $acoes = [];
        require $componentes . '/card_processo.php';
        ?>
    </div>

    <div class="col-12 col-md-6 col-xl-4">
        <?php
        $titulo = 'Identidade institucional';
        $descricao = 'Cores e espacamentos discretos priorizam consistencia, legibilidade e confianca.';
        $status = ['texto' => 'Versao ' . $versao, 'tipo' => 'info'];
        $detalhes = ['Layout' => 'Sistemas Poli', 'Tema' => 'Tabler'];
        $acoes = [];
        require $componentes . '/card_processo.php';
        ?>
    </div>

    <div class="col-12">
        <div class="card poli-card">
            <div class="card-header">
                <h3 class="card-title">Exemplo de tabela responsiva</h3>
            </div>
            <div class="card-body">
                <?php
                $colunas = [
                    'area' => 'Area',
                    'descricao' => 'Descricao',
                    'status' => 'Status',
                ];
                $linhas = [
                    ['area' => 'Cadastros', 'descricao' => 'Formularios simples', 'status' => 'Ativo'],
                    ['area' => 'Relatorios', 'descricao' => 'HTML, PDF ou Excel', 'status' => 'Exemplo'],
                    ['area' => 'Integracoes', 'descricao' => 'APIs e servicos externos', 'status' => 'Previsto'],
                ];
                require $componentes . '/tabela_responsiva.php';
                ?>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-7">
        <?php
        $tipo = 'info';
        $titulo = 'Componentes reutilizaveis';
        $mensagem = 'Os exemplos abaixo usam partials PHP simples em app/views/componentes.';
        $itens = ['Sem JavaScript complexo', 'Compatíveis com Bootstrap/Tabler', 'Parametros claros por variavel'];
        require $componentes . '/alerta.php';
        ?>

        <div class="card poli-card">
            <div class="card-body">
                <?php
                $id = 'busca-exemplo';
                $nome = 'busca';
                $rotulo = 'Busca com htmx';
                $placeholder = 'Buscar exemplo';
                $hxGet = '/exemplo/busca';
                $hxTarget = '#resultado-busca';
                require $componentes . '/campo_busca_htmx.php';
                ?>
                <div id="resultado-busca" class="text-secondary">
                    Resultado carregado por htmx apareceria aqui.
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-5">
        <?php
        $papeis = ['admin' => 'Administrador', 'leitor' => 'Leitor', 'operador' => 'Operador'];
        $papelAtivo = 'admin';
        $acaoUrl = '#';
        require $componentes . '/seletor_papel_ativo.php';
        ?>
    </div>

    <div class="col-12">
        <?php
        $acoes = [
            ['rotulo' => 'Acao principal', 'url' => '#', 'classe' => 'btn btn-primary'],
            ['rotulo' => 'Confirmar exemplo', 'url' => '#modal-confirmacao-exemplo', 'classe' => 'btn btn-outline-danger', 'htmx' => ['data-bs-toggle' => 'modal']],
        ];
        require $componentes . '/barra_acoes_mobile.php';

        $id = 'modal-confirmacao-exemplo';
        $titulo = 'Confirmar exemplo';
        $mensagem = 'Este modal demonstra o componente de confirmacao.';
        $acaoUrl = '#';
        $rotuloConfirmar = 'Entendi';
        require $componentes . '/modal_confirmacao.php';
        ?>
    </div>
</div>
