<?php

declare(strict_types=1);

$titulo = $titulo ?? 'Projeto Base';
$view = $view ?? '';
$dados = $dados ?? [];
$layout = $layout ?? [];
$nomeSistema = $layout['nomeSistema'] ?? $titulo;
$workplaceSession = $layout['workplaceSession'] ?? null;
$versao = $layout['versao'] ?? '0.1.0';
$versaoCodigo = is_array($layout['versaoCodigo'] ?? null) ? $layout['versaoCodigo'] : [];
$versaoApp = (string) ($versaoCodigo['app'] ?? $versao);
$statusVersaoCodigo = (string) ($versaoCodigo['status'] ?? 'indisponivel');
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
$homeUrl = ($basePath !== '' ? $basePath : '') . '/';
$logoUrl = ($basePath !== '' ? $basePath : '') . '/assets/images/minerva.png';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars((string) $titulo) ?></title>
    <link rel="icon" type="image/png" href="<?= htmlspecialchars($logoUrl) ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/core@1.0.0-beta20/dist/css/tabler.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/poli-theme.css">
</head>
<body>
    <div class="page">
        <header class="navbar navbar-expand-md d-print-none poli-topbar">
            <div class="container-xl flex-column flex-md-row">
                <a href="<?= htmlspecialchars($homeUrl) ?>" class="poli-header-brand text-decoration-none">
                    <img
                        src="<?= htmlspecialchars($logoUrl) ?>"
                        alt="Logo Poli"
                        class="poli-header-logo"
                    >
                    <span class="d-flex flex-column">
                        <span class="navbar-brand mb-1">Sistemas Poli</span>
                        <span class="poli-sistema-nome"><?= htmlspecialchars((string) $nomeSistema) ?></span>
                    </span>
                </a>

                <?php require __DIR__ . '/componentes/workplace_usuario.php'; ?>
            </div>
        </header>

        <main class="page-wrapper">
            <section class="poli-page-header py-4">
                <div class="container-xl">
                    <p class="text-secondary mb-1">Ambiente institucional</p>
                    <h1 class="page-title mb-0"><?= htmlspecialchars((string) $nomeSistema) ?></h1>
                </div>
            </section>

            <div class="page-body">
                <div class="container-xl">
                    <?php if ($view !== ''): ?>
                        <?php require __DIR__ . '/' . $view; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>

        <footer class="poli-footer py-4">
            <div class="container-xl">
                <div class="row gy-2 align-items-center">
                    <div class="col-12 col-md">
                        <strong>Servico Tecnico de Informatica</strong><br>
                        Escola Politecnica da USP
                    </div>
                    <div class="col-12 col-md-auto">
                        App <?= htmlspecialchars($versaoApp) ?> |
                        Codigo <?= htmlspecialchars((string) $versao) ?>
                        <?php if ($statusVersaoCodigo !== 'disponivel'): ?>
                            <span class="text-warning">(indisponivel)</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@tabler/core@1.0.0-beta20/dist/js/tabler.min.js"></script>
    <script src="https://unpkg.com/htmx.org@1.9.12"></script>
</body>
</html>
