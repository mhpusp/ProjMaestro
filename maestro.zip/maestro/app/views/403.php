<?php

declare(strict_types=1);

$titulo = $titulo ?? 'Acesso negado';
$sistema = (string) ($sistema ?? '');
$acao = (string) ($acao ?? '');
$escopo = $escopo ?? null;
$layout = $layout ?? [];
$nomeSistema = (string) ($layout['nomeSistema'] ?? 'Projeto Base');
$workplaceSession = $layout['workplaceSession'] ?? null;
$versao = (string) ($layout['versao'] ?? '0.1.0');
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars((string) $titulo) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/core@1.0.0-beta20/dist/css/tabler.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/poli-theme.css">
</head>
<body>
    <div class="page">
        <header class="navbar navbar-expand-md d-print-none poli-topbar">
            <div class="container-xl flex-column flex-md-row">
                <div class="d-flex flex-column">
                    <span class="navbar-brand mb-1">Sistemas Poli</span>
                    <span class="poli-sistema-nome"><?= htmlspecialchars($nomeSistema) ?></span>
                </div>
                <?php require __DIR__ . '/componentes/workplace_usuario.php'; ?>
            </div>
        </header>

        <main class="page-wrapper">
            <div class="page-body">
                <div class="container-tight">
                    <div class="card poli-card">
                        <div class="card-body text-center">
                            <p class="text-secondary mb-2">Permissao insuficiente</p>
                            <h1 class="h2">Voce nao tem permissao para executar esta acao.</h1>
                            <p class="text-secondary">
                                Se voce acredita que deveria ter acesso, altere o papel ativo quando disponivel
                                ou entre em contato com o suporte do sistema.
                            </p>
                            <div class="alert alert-warning text-start" role="alert">
                                <strong>Acao:</strong> <?= htmlspecialchars($acao) ?><br>
                                <strong>Sistema:</strong> <?= htmlspecialchars($sistema) ?>
                                <?php if ($escopo !== null): ?>
                                    <br><strong>Escopo:</strong> <?= htmlspecialchars((string) $escopo) ?>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex flex-column flex-sm-row justify-content-center gap-2">
                                <a href="<?= htmlspecialchars($basePath) ?>/" class="btn btn-primary">Voltar ao inicio</a>
                                <a href="javascript:history.back()" class="btn btn-outline-secondary">Voltar</a>
                            </div>
                        </div>
                        <div class="card-footer text-center text-secondary">
                            Versao <?= htmlspecialchars($versao) ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
