<?php
$dadosFormulario = $dados['dadosFormulario'] ?? [];
$erro = $dados['erro'] ?? null;
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Novo processo</h3>
    </div>
    <div class="card-body">
        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" action="<?= htmlspecialchars($basePath) ?>/admin/processos">
            <div class="mb-3">
            <label class="form-label">Identificador definido pela App</label>
            <input class="form-control" value="Definido ao criar o processo" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label">Nome</label>
                <input name="nome" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['nome'] ?? '')) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Descricao</label>
                <textarea name="descricao" class="form-control"><?= htmlspecialchars((string) ($dadosFormulario['descricao'] ?? '')) ?></textarea>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Versao definida pela App</label>
                    <input class="form-control" value="1" disabled>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Arquivo JSON</label>
                    <input type="file" name="arquivo_json" class="form-control" accept="application/json,.json" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Dono do processo</label>
                <input class="form-control" value="Definido pelo arquivo JSON" disabled>
                <div class="form-text">Dono, lista de subprocessos e raias participantes serão lidos do arquivo JSON.</div>
            </div>
            <div class="form-check mb-3">
                <input type="checkbox" name="status" value="1" class="form-check-input" id="processo-status" <?= isset($dadosFormulario['status']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="processo-status">Processo ativo</label>
            </div>
            <button class="btn btn-primary">Criar processo</button>
        </form>
    </div>
</div>