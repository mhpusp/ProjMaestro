<?php
$processos = $dados['processos'] ?? [];
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Processos</h3>
        <div class="ms-auto">
            <a href="<?= htmlspecialchars($basePath) ?>/admin/processos/novo" class="btn btn-primary">Novo processo</a>
            <a href="<?= htmlspecialchars($basePath) ?>/admin/processos/atualizar" class="btn btn-outline-primary">Atualizar processo</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>Identificador</th>
                    <th>Nome</th>
                    <th>Versao</th>
                    <th>Status</th>
                    <th>Arquivo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($processos as $processo): ?>
                    <tr>
                        <td><?= htmlspecialchars($processo->id) ?></td>
                        <td><?= htmlspecialchars($processo->nome) ?></td>
                        <td><?= htmlspecialchars((string) ($processo->versao ?? '')) ?></td>
                        <td><?= $processo->concluido ? 'Ativo' : 'Inativo' ?></td>
                        <td><?= htmlspecialchars((string) ($processo->arquivo ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>