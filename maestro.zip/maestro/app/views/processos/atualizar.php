<?php
$erro = $dados['erro'] ?? null;
$busca = (string) ($dados['busca'] ?? '');
$processos = $dados['processos'] ?? [];
$processoId = (string) ($dados['processoId'] ?? '');
$dadosFormulario = $dados['dadosFormulario'] ?? [];
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Atualizar processo</h3>
    </div>
    <div class="card-body">
        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="get" action="<?= htmlspecialchars($basePath) ?>/admin/processos/atualizar" class="mb-4">
            <label class="form-label" for="processo-busca">Pesquisar por nome</label>
            <div class="input-group">
                <input id="processo-busca" name="busca" class="form-control" value="<?= htmlspecialchars($busca) ?>" required>
                <button class="btn btn-outline-primary">Pesquisar</button>
            </div>
        </form>

        <?php if ($processos !== [] && $processoId === ''): ?>
            <h4>Processos encontrados</h4>
            <div class="list-group mb-4">
                <?php foreach ($processos as $processo): ?>
                    <a class="list-group-item list-group-item-action" href="<?= htmlspecialchars($basePath) ?>/admin/processos/atualizar?processo_id=<?= rawurlencode($processo->id) ?>">
                        <?= htmlspecialchars($processo->nome) ?> - <?= htmlspecialchars($processo->id) ?> (V<?= (int) $processo->versao ?>)
                    </a>
                <?php endforeach; ?>
            </div>
        <?php elseif ($busca !== '' && $processos === []): ?>
            <div class="alert alert-warning">Nenhum processo encontrado.</div>
        <?php endif; ?>

        <?php if ($processoId !== ''): ?>
            <?php $selecionado = $processos[0] ?? null; ?>
            <?php if ($selecionado): ?>
                <form method="post" enctype="multipart/form-data" action="<?= htmlspecialchars($basePath) ?>/admin/processos/atualizar">
                    <input type="hidden" name="processo_id" value="<?= htmlspecialchars($selecionado->id) ?>">
                    <div class="mb-3">
                        <label class="form-label">Processo selecionado</label>
                        <input class="form-control" value="<?= htmlspecialchars($selecionado->nome . ' - ' . $selecionado->id) ?>" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Identificador da nova versao</label>
                        <input class="form-control" value="Definido pela App" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nome</label>
                        <input name="nome" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['nome'] ?? $selecionado->nome)) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descricao</label>
                        <textarea name="descricao" class="form-control"><?= htmlspecialchars((string) ($dadosFormulario['descricao'] ?? $selecionado->descricao ?? '')) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Arquivo JSON</label>
                        <input type="file" name="arquivo_json" class="form-control" accept="application/json,.json" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Dono do processo</label>
                        <input name="dono_processo" maxlength="15" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['dono_processo'] ?? $selecionado->donoProcesso ?? '')) ?>">
                    </div>
                    <div class="mb-3">
                        <div class="form-text">Lista de subprocessos e raias participantes serão lidas do novo arquivo JSON.</div>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="status" value="1" class="form-check-input" id="processo-atualizado-status" <?= isset($dadosFormulario['status']) || $selecionado->concluido ? 'checked' : '' ?>><label class="form-check-label" for="processo-atualizado-status">Processo ativo</label>
                    </div>
                    <button class="btn btn-primary">Criar nova versao</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>