<?php

declare(strict_types=1);

$erros = $dados['erros'] ?? [];
$ttlRedis = (int) ($dados['ttlRedis'] ?? 0);
$componentes = dirname(__DIR__) . '/componentes';
?>
<div class="row g-3 g-md-4">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between gap-3">
            <div>
                <p class="text-secondary mb-1">Administracao</p>
                <h2 class="mb-0">Erros recentes</h2>
            </div>
            <a href="/erro-teste" class="btn btn-outline-danger">Provocar erro de teste</a>
        </div>
    </div>

    <div class="col-12">
        <?php
        $tipo = 'info';
        $titulo = 'Painel interno';
        $mensagem = 'Esta pagina usa middleware ficticio de permissao e esta preparada para integracao futura com autenticacao real.';
        $itens = ['TTL Redis configurado: ' . $ttlRedis . ' segundos', 'Fallback local: storage/logs/erros/erros.jsonl'];
        require $componentes . '/alerta.php';
        ?>
    </div>

    <div class="col-12">
        <div class="card poli-card">
            <div class="card-body">
                <?php
                $colunas = [
                    'codigo' => 'Codigo',
                    'registrado_em' => 'Registrado em',
                    'rota' => 'Rota',
                    'erro' => 'Erro',
                    'origem_registro' => 'Origem',
                ];
                $linhas = array_map(static function (array $erro): array {
                    return [
                        'codigo' => (string) ($erro['codigo'] ?? ''),
                        'registrado_em' => (string) ($erro['registrado_em'] ?? ''),
                        'rota' => (string) ($erro['contexto']['rota'] ?? ''),
                        'erro' => (string) ($erro['erro'] ?? ''),
                        'origem_registro' => (string) ($erro['origem_registro'] ?? 'redis'),
                    ];
                }, $erros);
                $vazio = 'Nenhum erro registrado recentemente.';
                require $componentes . '/tabela_responsiva.php';
                ?>
            </div>
        </div>
    </div>
</div>
