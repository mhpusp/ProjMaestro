<?php

declare(strict_types=1);

$titulo = $titulo ?? 'Erro inesperado';
$codigoErro = (string) ($codigoErro ?? 'REQ-' . date('Y') . '-000000');
$assinaturaErro = (string) ($assinaturaErro ?? 'versao-indisponivel');
$suporteUrl = (string) ($suporteUrl ?? '#');
$layout = $layout ?? [];
$nomeSistema = (string) ($layout['nomeSistema'] ?? 'Projeto Base');
$versao = (string) ($layout['versao'] ?? '0.1.0');
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars((string) $titulo) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/core@1.0.0-beta20/dist/css/tabler.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/poli-theme.css">
</head>
<body>
    <main class="page page-center">
        <div class="container-tight py-4">
            <div class="card poli-card">
                <div class="card-body text-center">
                    <p class="text-secondary mb-2"><?= htmlspecialchars($nomeSistema) ?></p>
                    <h1 class="h2 mb-3">Nao foi possivel concluir a operacao.</h1>
                    <p class="text-secondary">
                        Nossa equipe pode investigar o ocorrido com o codigo abaixo.
                        Informe esse codigo ao entrar em contato com o suporte.
                    </p>
                    <div class="alert alert-warning text-start" role="alert">
                        <strong>Codigo do erro:</strong>
                        <span class="font-monospace"><?= htmlspecialchars($codigoErro) ?></span>
                        <br>
                        <strong>Assinatura do codigo:</strong>
                        <span class="font-monospace"><?= htmlspecialchars($assinaturaErro) ?></span>
                    </div>
                    <div class="d-flex flex-column flex-sm-row justify-content-center gap-2">
                        <a href="<?= htmlspecialchars($suporteUrl) ?>" class="btn btn-primary">Contato com suporte</a>
                        <a href="<?= htmlspecialchars($basePath) ?>/" class="btn btn-outline-secondary">Voltar ao inicio</a>
                    </div>
                </div>
                <div class="card-footer text-center text-secondary">
                    Versao <?= htmlspecialchars($versao) ?>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
