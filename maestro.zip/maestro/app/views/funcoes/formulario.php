<?php
$dadosFormulario = $dados['dadosFormulario'] ?? [];
$erro = $dados['erro'] ?? null;
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Nova funcao</h3>
    </div>
    <div class="card-body">
        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="post" action="/admin/funcoes">
            <div class="mb-3">
                <label class="form-label">Nome</label>
                <input name="nome" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['nome'] ?? '')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Descricao</label>
                <textarea name="descricao" class="form-control"><?= htmlspecialchars((string) ($dadosFormulario['descricao'] ?? '')) ?></textarea>
            </div>
            <button class="btn btn-primary">Criar</button>
        </form>
    </div>
</div>
