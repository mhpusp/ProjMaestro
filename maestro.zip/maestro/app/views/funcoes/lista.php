<?php
$funcoes = $dados['funcoes'] ?? [];
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Funcoes</h3>
        <div class="ms-auto">
            <a href="/admin/funcoes/nova" class="btn btn-primary">Nova funcao</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descricao</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($funcoes as $f): ?>
                    <tr>
                        <td><?= htmlspecialchars((string) ($f['id'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($f['nome'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($f['descricao'] ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
