<?php

declare(strict_types=1);

$solicitacaoCard = $solicitacaoCard ?? ($solicitacao ?? null);
$statusDisponiveis = $statusDisponiveis ?? ($dados['statusDisponiveis'] ?? []);
$componentes = dirname(__DIR__) . '/componentes';
?>
<?php if (is_array($solicitacaoCard)): ?>
    <div class="col-12 col-lg-6" id="solicitacao-card-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>">
        <article class="card poli-card h-100">
            <div class="card-body">
                <div class="d-flex flex-column flex-sm-row justify-content-between gap-3 mb-3">
                    <div>
                        <h3 class="card-title mb-1">
                            <?= htmlspecialchars((string) $solicitacaoCard['titulo']) ?>
                        </h3>
                        <p class="text-secondary mb-0">
                            <?= htmlspecialchars((string) $solicitacaoCard['descricao']) ?>
                        </p>
                    </div>
                    <?php
                    $texto = (string) $solicitacaoCard['status_rotulo'];
                    $tipo = (string) $solicitacaoCard['status_tipo'];
                    require $componentes . '/badge_status.php';
                    ?>
                </div>

                <dl class="row g-2 mb-3">
                    <dt class="col-5 text-secondary fw-normal">Solicitante</dt>
                    <dd class="col-7 mb-0 fw-semibold">
                        <?= htmlspecialchars((string) $solicitacaoCard['solicitante']) ?>
                    </dd>
                    <dt class="col-5 text-secondary fw-normal">Prioridade</dt>
                    <dd class="col-7 mb-0 fw-semibold">
                        <?= htmlspecialchars(ucfirst((string) $solicitacaoCard['prioridade'])) ?>
                    </dd>
                    <dt class="col-5 text-secondary fw-normal">Criada em</dt>
                    <dd class="col-7 mb-0 fw-semibold">
                        <?= htmlspecialchars((string) $solicitacaoCard['criada_em']) ?>
                    </dd>
                </dl>

                <form
                    method="post"
                    action="/solicitacoes/<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>/status"
                    hx-post="/solicitacoes/<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>/status"
                    hx-target="#solicitacao-card-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>"
                    hx-swap="outerHTML"
                    hx-indicator="#solicitacao-card-loading-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>"
                    class="mb-3"
                >
                    <label class="form-label" for="status-card-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>">
                        Alterar status
                    </label>
                    <div class="d-flex flex-column flex-sm-row gap-2">
                        <select
                            class="form-select"
                            id="status-card-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>"
                            name="status"
                        >
                            <?php foreach ($statusDisponiveis as $valor => $rotulo): ?>
                                <option value="<?= htmlspecialchars((string) $valor) ?>" <?= $valor === $solicitacaoCard['status'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars((string) $rotulo) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-outline-primary">Atualizar</button>
                    </div>
                    <div id="solicitacao-card-loading-<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>" class="htmx-indicator text-secondary small mt-2">
                        Atualizando status...
                    </div>
                </form>

                <a href="/solicitacoes/<?= htmlspecialchars((string) $solicitacaoCard['id']) ?>" class="btn btn-outline-primary">
                    Ver detalhe
                </a>
            </div>
        </article>
    </div>
<?php endif; ?>
