<?php

declare(strict_types=1);

$erro = $dados['erro'] ?? null;
$dadosFormulario = $dados['dadosFormulario'] ?? [];
$rascunho = $dados['rascunho'] ?? [];
$rascunhoTtlDias = (int) ($dados['rascunhoTtlDias'] ?? 21);
$componentes = dirname(__DIR__) . '/componentes';
?>
<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="d-flex flex-column flex-md-row justify-content-between gap-3 mb-3">
            <div>
                <p class="text-secondary mb-1">Solicitacoes</p>
                <h2 class="mb-0">Nova solicitacao</h2>
            </div>
            <a href="/solicitacoes" class="btn btn-outline-primary">Voltar para lista</a>
        </div>

        <?php if ($erro !== null): ?>
            <?php
            $tipo = 'erro';
            $titulo = 'Revise o formulario';
            $mensagem = (string) $erro;
            require $componentes . '/alerta.php';
            ?>
        <?php endif; ?>

        <form
            id="form-solicitacao"
            method="post"
            action="/solicitacoes"
            class="card poli-card"
        >
            <input type="hidden" name="rascunho_id" value="<?= htmlspecialchars((string) ($rascunho['id'] ?? '')) ?>">
            <div
                class="card-body"
                hx-post="/solicitacoes/rascunho"
                hx-trigger="keyup changed delay:800ms from:input, change from:select, change delay:800ms from:textarea"
                hx-include="#form-solicitacao"
                hx-target="#rascunho-status"
                hx-swap="innerHTML"
            >
                <div id="rascunho-status" class="mb-3">
                    <?php require __DIR__ . '/parcial_status_rascunho.php'; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="titulo">Titulo</label>
                    <input
                        type="text"
                        class="form-control"
                        id="titulo"
                        name="titulo"
                        value="<?= htmlspecialchars((string) ($dadosFormulario['titulo'] ?? '')) ?>"
                    >
                </div>

                <div class="mb-3">
                    <label class="form-label" for="descricao">Descricao</label>
                    <textarea class="form-control" id="descricao" name="descricao" rows="4"><?= htmlspecialchars((string) ($dadosFormulario['descricao'] ?? '')) ?></textarea>
                </div>

                <div class="row g-3">
                    <div class="col-12 col-md-7">
                        <label class="form-label" for="solicitante">Solicitante</label>
                        <input
                            type="text"
                            class="form-control"
                            id="solicitante"
                            name="solicitante"
                            value="<?= htmlspecialchars((string) ($dadosFormulario['solicitante'] ?? '')) ?>"
                        >
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label" for="prioridade">Prioridade</label>
                        <?php $prioridadeAtual = (string) ($dadosFormulario['prioridade'] ?? 'media'); ?>
                        <select class="form-select" id="prioridade" name="prioridade">
                            <option value="baixa" <?= $prioridadeAtual === 'baixa' ? 'selected' : '' ?>>Baixa</option>
                            <option value="media" <?= $prioridadeAtual === 'media' ? 'selected' : '' ?>>Media</option>
                            <option value="alta" <?= $prioridadeAtual === 'alta' ? 'selected' : '' ?>>Alta</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="card-footer d-flex flex-column flex-sm-row justify-content-end gap-2">
                <a href="/solicitacoes" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">Enviar solicitacao</button>
            </div>
        </form>
    </div>
</div>
