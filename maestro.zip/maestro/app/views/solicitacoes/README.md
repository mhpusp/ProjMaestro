# Modulo Solicitacoes

Este modulo demonstra como estruturar uma funcionalidade real no scaffold mantendo o fluxo simples e copiavel.

## Fluxo

1. `config/routes.php` registra rotas Web, htmx e API.
2. `SolicitacaoController` recebe a requisicao, chama o service e escolhe a resposta.
3. `SolicitacaoService` concentra regras de negocio, validacao e padronizacao dos dados.
4. `SolicitacaoRepository` isola a origem dos dados. Hoje usa arrays em memoria de sessao para nao depender de banco; em um sistema real, este arquivo pode ser trocado por consultas PDO.
5. `RascunhoService` salva o formulario de nova solicitacao de forma gradual enquanto o usuario preenche.
6. `app/views/solicitacoes` contem templates separados para lista, detalhe, formulario e parciais htmx.
7. `AuditoriaService` registra criacao, alteracao de status, exportacoes e exclusoes no arquivo JSONL de auditoria.

## Rotas

- `GET /solicitacoes`: lista Web com filtro.
- `GET /solicitacoes/filtro`: parcial htmx da lista filtrada.
- `GET /solicitacoes/nova`: formulario de criacao.
- `POST /solicitacoes/rascunho`: salva dados parciais do formulario em rascunho.
- `POST /solicitacoes`: cria uma solicitacao de exemplo.
- `GET /solicitacoes/{id}`: detalhe da solicitacao.
- `POST /solicitacoes/{id}/status`: altera status e atualiza o detalhe por htmx.
- `POST /solicitacoes/{id}/excluir`: remove uma solicitacao da lista em memoria.
- `GET /api/solicitacoes`: lista em JSON para API.
- `GET /api/solicitacoes/{id}`: detalhe em JSON para API.
- `POST /api/solicitacoes`: cria solicitacao pela API.
- `POST /api/solicitacoes/{id}/alterar-status`: altera status pela API.
- `GET /solicitacoes/exportar/json`: exporta dados em JSON.
- `GET /solicitacoes/exportar/csv`: exporta dados em CSV.
- `GET /solicitacoes/exportar/pdf`: ponto futuro para geracao de PDF.
- `GET /solicitacoes/exportar/excel`: ponto futuro para geracao de Excel.

## Como copiar

Para criar um novo modulo, copie o controller, service, repository e a pasta de views. Depois renomeie rotas, metodos e campos de dominio, preservando a separacao:

- controller fino para HTTP;
- service para regra de negocio;
- repository para dados;
- templates para apresentacao;
- parciais htmx para interacoes pequenas.

## Padrao htmx

O modulo usa htmx apenas para pequenas atualizacoes de HTML renderizado no servidor:

- campo de busca com `hx-get` para atualizar `#lista-solicitacoes`;
- formulario de criacao com `hx-post` para salvar rascunho sem interceptar o submit final;
- forms de status com `hx-post` e `hx-swap="outerHTML"` para trocar apenas o card ou o detalhe;
- `hx-indicator` para loading visual simples;
- `method` e `action` permanecem nos formularios para manter fallback funcional sem JavaScript.

Novos modulos devem seguir o mesmo padrao: uma rota normal para pagina completa e uma partial pequena quando a interacao puder ser atualizada sem recarregar tudo.

## Rascunho persistivel

O formulario `GET /solicitacoes/nova` cria ou retoma um rascunho do tipo `solicitacao` vinculado ao usuario logado. Enquanto o usuario digita, a rota `POST /solicitacoes/rascunho` atualiza os dados parciais.

Quando `POST /solicitacoes` recebe o submit final:

- se a validacao falha, os dados continuam no rascunho;
- se a validacao passa, o rascunho muda de `rascunho` para `enviado`;
- a solicitacao demonstrativa e criada no repository em memoria.

Rascunhos sem atualizacao sao removidos apos `RASCUNHOS_TTL_DIAS`, cujo padrao e 21 dias.
