<?php

declare(strict_types=1);

$solicitacoes = is_array($solicitacoes ?? null) ? $solicitacoes : ($dados['solicitacoes'] ?? []);
$statusDisponiveis = $statusDisponiveis ?? ($dados['statusDisponiveis'] ?? []);
$componentes = dirname(__DIR__) . '/componentes';
?>
<?php if ($solicitacoes === []): ?>
    <?php
    $tipo = 'info';
    $titulo = 'Nenhuma solicitacao encontrada';
    $mensagem = 'Ajuste o filtro ou crie uma nova solicitacao.';
    require $componentes . '/alerta.php';
    ?>
<?php else: ?>
    <div class="row g-3">
        <?php foreach ($solicitacoes as $solicitacaoItem): ?>
            <?php
            $solicitacaoCard = $solicitacaoItem;
            require __DIR__ . '/parcial_card.php';
            ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
