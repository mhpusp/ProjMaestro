<?php

declare(strict_types=1);

$erro = $dados['erro'] ?? null;
$solicitacao = $dados['solicitacao'] ?? null;
$statusDisponiveis = $dados['statusDisponiveis'] ?? [];
$mensagemSucesso = $dados['mensagemSucesso'] ?? '';
$componentes = dirname(__DIR__) . '/componentes';
?>
<div class="row g-3 g-md-4">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between gap-3">
            <div>
                <p class="text-secondary mb-1">Solicitacoes</p>
                <h2 class="mb-0">Detalhe da solicitacao</h2>
            </div>
            <a href="/solicitacoes" class="btn btn-outline-primary">Voltar para lista</a>
        </div>
    </div>

    <div class="col-12">
        <?php if ($erro !== null): ?>
            <?php
            $tipo = 'erro';
            $titulo = 'Solicitacao nao encontrada';
            $mensagem = (string) $erro;
            require $componentes . '/alerta.php';
            ?>
        <?php else: ?>
            <?php require __DIR__ . '/parcial_detalhe.php'; ?>
        <?php endif; ?>
    </div>
</div>
