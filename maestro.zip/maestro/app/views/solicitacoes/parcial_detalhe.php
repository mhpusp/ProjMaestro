<?php

declare(strict_types=1);

$solicitacao = $solicitacao ?? ($dados['solicitacao'] ?? null);
$statusDisponiveis = $statusDisponiveis ?? ($dados['statusDisponiveis'] ?? []);
$mensagemSucesso = (string) ($mensagemSucesso ?? ($dados['mensagemSucesso'] ?? ''));
$componentes = dirname(__DIR__) . '/componentes';
?>
<?php if (is_array($solicitacao)): ?>
    <div id="solicitacao-detalhe" class="row g-3">
        <?php if ($mensagemSucesso !== ''): ?>
            <div class="col-12">
                <?php
                $tipo = 'sucesso';
                $titulo = 'Operacao concluida';
                $mensagem = $mensagemSucesso;
                require $componentes . '/alerta.php';
                ?>
            </div>
        <?php endif; ?>

        <div class="col-12 col-lg-7">
            <div class="card poli-card h-100">
                <div class="card-body">
                    <div class="d-flex flex-column flex-md-row justify-content-between gap-3 mb-3">
                        <div>
                            <p class="text-secondary mb-1">#<?= htmlspecialchars((string) $solicitacao['id']) ?></p>
                            <h3 class="card-title mb-0"><?= htmlspecialchars((string) $solicitacao['titulo']) ?></h3>
                        </div>
                        <?php
                        $texto = (string) $solicitacao['status_rotulo'];
                        $tipo = (string) $solicitacao['status_tipo'];
                        require $componentes . '/badge_status.php';
                        ?>
                    </div>

                    <p><?= htmlspecialchars((string) $solicitacao['descricao']) ?></p>

                    <dl class="row g-2 mb-0">
                        <dt class="col-5 text-secondary fw-normal">Solicitante</dt>
                        <dd class="col-7 fw-semibold"><?= htmlspecialchars((string) $solicitacao['solicitante']) ?></dd>
                        <dt class="col-5 text-secondary fw-normal">Prioridade</dt>
                        <dd class="col-7 fw-semibold"><?= htmlspecialchars(ucfirst((string) $solicitacao['prioridade'])) ?></dd>
                        <dt class="col-5 text-secondary fw-normal">Criada em</dt>
                        <dd class="col-7 fw-semibold"><?= htmlspecialchars((string) $solicitacao['criada_em']) ?></dd>
                    </dl>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-5">
            <div class="d-flex flex-column gap-3">
                <form
                    class="card poli-card"
                    method="post"
                    action="/solicitacoes/<?= htmlspecialchars((string) $solicitacao['id']) ?>/status"
                    hx-post="/solicitacoes/<?= htmlspecialchars((string) $solicitacao['id']) ?>/status"
                    hx-target="#solicitacao-detalhe"
                    hx-swap="outerHTML"
                    hx-indicator="#solicitacao-detalhe-loading"
                >
                    <div class="card-body">
                        <h3 class="card-title">Alterar status</h3>
                        <p class="text-secondary">
                            Esta acao usa htmx para atualizar apenas o detalhe da solicitacao.
                        </p>
                        <label class="form-label" for="status">Novo status</label>
                        <select class="form-select mb-3" id="status" name="status">
                            <?php foreach ($statusDisponiveis as $valor => $rotulo): ?>
                                <option value="<?= htmlspecialchars((string) $valor) ?>" <?= $valor === $solicitacao['status'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars((string) $rotulo) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary w-100">Atualizar status</button>
                        <div id="solicitacao-detalhe-loading" class="htmx-indicator text-secondary small mt-2">
                            Atualizando detalhe...
                        </div>
                    </div>
                </form>

                <form
                    class="card poli-card"
                    method="post"
                    action="/solicitacoes/<?= htmlspecialchars((string) $solicitacao['id']) ?>/excluir"
                >
                    <div class="card-body">
                        <h3 class="card-title">Apagar solicitacao</h3>
                        <p class="text-secondary">
                            Remove este registro apenas da lista em memoria da sessao atual.
                        </p>
                        <button type="submit" class="btn btn-outline-danger w-100">Apagar solicitacao</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
