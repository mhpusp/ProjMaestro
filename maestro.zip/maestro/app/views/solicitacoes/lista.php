<?php

declare(strict_types=1);

$solicitacoesLista = $dados['solicitacoes'] ?? [];
$filtro = (string) ($dados['filtro'] ?? '');
$statusDisponiveis = $dados['statusDisponiveis'] ?? [];
$componentes = dirname(__DIR__) . '/componentes';
?>
<div class="row g-3 g-md-4">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between gap-3">
            <div>
                <p class="text-secondary mb-1">Modulo exemplo</p>
                <h2 class="mb-0">Solicitacoes</h2>
            </div>
            <div class="d-flex flex-column flex-sm-row gap-2">
                <a href="/solicitacoes/nova" class="btn btn-primary">Nova solicitacao</a>
                <a href="/solicitacoes/exportar/csv" class="btn btn-outline-primary">Exportar CSV</a>
                <a href="/solicitacoes/exportar/json" class="btn btn-outline-primary">Exportar JSON</a>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="card poli-card">
            <div class="card-body">
                <?php
                $id = 'busca-solicitacoes';
                $nome = 'busca';
                $valor = $filtro;
                $rotulo = 'Filtrar solicitacoes';
                $placeholder = 'Digite titulo, solicitante ou status';
                $hxGet = '/solicitacoes/filtro';
                $hxTarget = '#lista-solicitacoes';
                $hxIndicator = '#busca-solicitacoes-loading';
                require $componentes . '/campo_busca_htmx.php';
                ?>
                <div id="busca-solicitacoes-loading" class="htmx-indicator text-secondary small mb-3">
                    Atualizando lista...
                </div>
                <div id="lista-solicitacoes">
                    <?php $solicitacoes = $solicitacoesLista; ?>
                    <?php require __DIR__ . '/parcial_lista.php'; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12">
        <?php
        $acoes = [
            ['rotulo' => 'Nova solicitacao', 'url' => '/solicitacoes/nova', 'classe' => 'btn btn-primary'],
            ['rotulo' => 'Exportar CSV', 'url' => '/solicitacoes/exportar/csv', 'classe' => 'btn btn-outline-primary'],
            ['rotulo' => 'Preparar PDF', 'url' => '/solicitacoes/exportar/pdf', 'classe' => 'btn btn-outline-secondary'],
            ['rotulo' => 'Preparar Excel', 'url' => '/solicitacoes/exportar/excel', 'classe' => 'btn btn-outline-secondary'],
        ];
        require $componentes . '/barra_acoes_mobile.php';
        ?>
    </div>
</div>
