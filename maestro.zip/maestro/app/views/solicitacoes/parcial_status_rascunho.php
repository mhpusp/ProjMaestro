<?php

declare(strict_types=1);

$rascunho = is_array($rascunho ?? null) ? $rascunho : [];
$rascunhoTtlDias = (int) ($rascunhoTtlDias ?? 21);
$status = (string) ($rascunho['status'] ?? 'rascunho');
$atualizadoEm = (string) ($rascunho['atualizado_em'] ?? '');
$dataAtualizacao = $atualizadoEm !== '' ? date('d/m/Y H:i', strtotime($atualizadoEm)) : 'agora';
$rotuloStatus = $status === 'enviado' ? 'Enviado' : 'Rascunho salvo';
?>
<div class="alert alert-info mb-0" role="status">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-1">
        <div>
            <strong><?= htmlspecialchars($rotuloStatus) ?>.</strong>
            Voce pode sair e retomar este formulario depois.
        </div>
        <div class="text-secondary">
            Atualizado em <?= htmlspecialchars($dataAtualizacao) ?>.
            Rascunhos expiram em <?= htmlspecialchars((string) $rascunhoTtlDias) ?> dias.
        </div>
    </div>
</div>
