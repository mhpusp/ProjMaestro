# Login Views

Telas de autenticação local para ambiente de desenvolvimento.

## Arquivos

- `formulario.php` — Formulário de login com campos de email e senha.

## Uso

O usuário será redirecionado para `/login` automaticamente se não estiver autenticado. Após fazer login com sucesso, será redirecionado para a página inicial.

Para fazer logout, acesse `/logout`.
