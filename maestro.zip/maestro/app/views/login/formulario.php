<?php
$erro = $dados['erro'] ?? null;
?>
<div class="page page-center">
    <div class="container-tight py-4">
        <div class="text-center mb-4">
            <h2><?= htmlspecialchars($layout['nomeSistema'] ?? 'Maestro') ?></h2>
            <p class="text-secondary">Autenticação Local</p>
        </div>

        <form class="card card-md" method="POST" action="/maestro/login">
            <div class="card-body">
                <div class="card-title text-center mb-4">Login</div>

                <?php if ($erro): ?>
                    <div class="alert alert-danger" role="alert">
                        <?= htmlspecialchars($erro) ?>
                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="seu@email.com" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Senha</label>
                    <input type="password" name="senha" class="form-control" placeholder="Sua senha" required>
                </div>

                <div class="form-footer">
                    <button type="submit" class="btn btn-primary w-100">Entrar</button>
                </div>
            </div>
        </form>

        <div class="text-center text-secondary mt-3">
            <small>Ambiente de desenvolvimento - Autenticação Local</small>
        </div>
    </div>
</div>
