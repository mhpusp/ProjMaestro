<?php
$usuarios = $dados['usuarios'] ?? [];
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Usuarios</h3>
        <div class="ms-auto">
            <a href="/admin/usuarios/nova" class="btn btn-primary">Novo usuario</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $u): ?>
                    <tr>
                        <td><?= htmlspecialchars((string) ($u['id'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($u['nome'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($u['email'] ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
