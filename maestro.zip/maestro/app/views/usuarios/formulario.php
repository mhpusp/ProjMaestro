<?php
$dadosFormulario = $dados['dadosFormulario'] ?? [];
$erro = $dados['erro'] ?? null;
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Novo usuario</h3>
    </div>
    <div class="card-body">
        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="post" action="/admin/usuarios">
            <div class="mb-3">
                <label class="form-label">Nome</label>
                <input name="nome" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['nome'] ?? '')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input name="email" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['email'] ?? '')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">NUSP</label>
                <input name="nusp" class="form-control" value="<?= htmlspecialchars((string) ($dadosFormulario['nusp'] ?? '')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Senha (opcional)</label>
                <input name="senha" class="form-control" type="password">
            </div>
            <button class="btn btn-primary">Criar</button>
        </form>
    </div>
</div>
