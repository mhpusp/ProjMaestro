<?php

declare(strict_types=1);

namespace App\controllers;

use App\services\UsuarioService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class UsuarioController
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly UsuarioService $service
    ) {
    }

    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $usuarios = $this->service->listar();

        return $this->renderizar($request, $response, 'usuarios/lista.php', [
            'usuarios' => $usuarios,
        ]);
    }

    public function novo(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->renderizar($request, $response, 'usuarios/formulario.php', []);
    }

    public function criar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();

        try {
            $usuario = $this->service->criar($dados);

            return $response->withHeader('Location', '/admin/usuarios')->withStatus(303);
        } catch (\RuntimeException $erro) {
            return $this->renderizar($request, $response->withStatus(422), 'usuarios/formulario.php', [
                'erro' => $erro->getMessage(),
                'dadosFormulario' => $dados,
            ]);
        }
    }

    private function renderizar(ServerRequestInterface $request, ResponseInterface $response, string $view, array $dados): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Usuarios',
            'view' => $view,
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => $dados,
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }
}
