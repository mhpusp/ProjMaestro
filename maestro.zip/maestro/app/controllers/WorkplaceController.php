<?php

declare(strict_types=1);

namespace App\controllers;

use App\middlewares\WorkplaceSessionMiddleware;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Controller de operacoes simples da sessao institucional Workplace.
 */
class WorkplaceController
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     */
    public function __construct(private readonly array $configuracao)
    {
    }

    /**
     * Troca o papel ativo usando dados mockados da sessao atual.
     */
    public function trocarPapel(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $workplace = $request->getAttribute(WorkplaceSessionMiddleware::ATRIBUTO);
        $dados = (array) $request->getParsedBody();
        $novoPapel = (string) ($dados['papel'] ?? '');

        if ($workplace instanceof WorkplaceSession && $workplace->podeUsarPapel($novoPapel)) {
            $_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO] = $novoPapel;
        }

        $destino = $request->getHeaderLine('Referer') ?: '/';

        return $response
            ->withHeader('Location', $destino)
            ->withStatus(303);
    }

    /**
     * Encerra a sessao local e redireciona para logout federado quando habilitado.
     */
    public function logout(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        if (session_status() === PHP_SESSION_NONE) {
            $this->configurarSessao();
            session_start();
        }

        unset($_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO]);
        session_destroy();

        $destino = (bool) $this->configuracao['sso']['habilitado']
            ? (string) $this->configuracao['sso']['logout_url']
            : ((string) $this->configuracao['app']['base_path'] ?: '/');

        return $response
            ->withHeader('Location', $destino)
            ->withStatus(303);
    }

    private function configurarSessao(): void
    {
        $savePath = (string) ($this->configuracao['sessao']['save_path'] ?? '');

        if ($savePath !== '') {
            if (!str_starts_with($savePath, '/')) {
                $savePath = dirname(__DIR__, 2) . '/' . $savePath;
            }

            if (!is_dir($savePath)) {
                @mkdir($savePath, 0775, true);
            }

            if (is_dir($savePath) && is_writable($savePath)) {
                session_save_path($savePath);
            }
        }

        session_set_cookie_params([
            'secure' => (bool) ($this->configuracao['sessao']['cookie_secure'] ?? false),
            'httponly' => (bool) ($this->configuracao['sessao']['cookie_httponly'] ?? true),
            'samesite' => (string) ($this->configuracao['sessao']['cookie_samesite'] ?? 'Lax'),
            'path' => '/',
        ]);
    }
}
