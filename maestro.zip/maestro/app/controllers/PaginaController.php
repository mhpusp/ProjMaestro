<?php

declare(strict_types=1);

namespace App\controllers;

use App\models\SaudeModel;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Controller das paginas iniciais do scaffold.
 *
 * Mantem o fluxo simples: recebe a requisicao, chama models quando necessario
 * e devolve HTML ou JSON usando respostas PSR-7 do Slim.
 */
class PaginaController
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     * @param array<string, mixed> $dependencias Servicos explicitos da aplicacao.
     */
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias
    ) {
    }

    /**
     * Renderiza a pagina inicial HTML.
     */
    public function inicio(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $template = $this->dependencias['template'];

        $html = $template->renderizar('base.php', [
            'titulo' => $this->configuracao['app']['nome'],
            'view' => 'inicio.php',
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => [
                'nomeAplicacao' => $this->configuracao['app']['nome'],
                'ambiente' => $this->configuracao['app']['ambiente'],
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
            ],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /**
     * Retorna o estado basico da aplicacao em JSON.
     */
    public function saude(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $model = new SaudeModel(
            $this->configuracao,
            $this->dependencias['pdo'],
            $this->dependencias['logger'],
            $this->dependencias['versao_codigo']
        );
        $payload = json_encode($model->resumo(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        $response->getBody()->write($payload ?: '{}');

        return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
    }
}
