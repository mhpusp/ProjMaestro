<?php

declare(strict_types=1);

namespace App\controllers;

use App\services\AutorizacaoRotaService;
use InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use RuntimeException;

/**
 * REST API para gerenciar papeis autorizados por rota.
 */
class AutorizacaoRotaController
{
    public function __construct(private readonly AutorizacaoRotaService $autorizacoes)
    {
    }

    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->json($response, [
            'sucesso' => true,
            'dados' => $this->autorizacoes->listarRotas(),
            'mensagem' => null,
            'codigo_erro' => null,
        ]);
    }

    public function adicionarPapel(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->alterarPapel($request, $response, (string) $args['rota_id'], 'adicionar');
    }

    public function removerPapel(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        return $this->alterarPapel($request, $response, (string) $args['rota_id'], 'remover');
    }

    private function alterarPapel(
        ServerRequestInterface $request,
        ResponseInterface $response,
        string $rotaId,
        string $operacao
    ): ResponseInterface {
        $dados = (array) $request->getParsedBody();
        $papel = strtolower(trim((string) ($dados['papel'] ?? '')));

        try {
            $rota = $operacao === 'adicionar'
                ? $this->autorizacoes->adicionarPapel($rotaId, $papel)
                : $this->autorizacoes->removerPapel($rotaId, $papel);

            return $this->json($response, [
                'sucesso' => true,
                'dados' => $rota,
                'mensagem' => 'Autorizacao atualizada.',
                'codigo_erro' => null,
            ]);
        } catch (InvalidArgumentException $erro) {
            return $this->json($response->withStatus(422), [
                'sucesso' => false,
                'dados' => null,
                'mensagem' => $erro->getMessage(),
                'codigo_erro' => 'VALIDACAO',
            ]);
        } catch (RuntimeException $erro) {
            return $this->json($response->withStatus(404), [
                'sucesso' => false,
                'dados' => null,
                'mensagem' => $erro->getMessage(),
                'codigo_erro' => 'ROTA_NAO_ENCONTRADA',
            ]);
        }
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function json(ResponseInterface $response, array $payload): ResponseInterface
    {
        $response->getBody()->write((string) json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
    }
}
