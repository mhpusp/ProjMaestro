<?php

declare(strict_types=1);

namespace App\controllers;

use App\services\UsuarioService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Controller para autenticação local (desenvolvimento).
 */
class LoginController
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly UsuarioService $usuarioService
    ) {
    }

    /**
     * Exibe formulário de login.
     */
    public function formulario(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Login',
            'view' => 'login/formulario.php',
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => null,
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => [],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /**
     * Processa login (POST).
     */
    public function autenticar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();
        $email = (string) ($dados['email'] ?? '');
        $senha = (string) ($dados['senha'] ?? '');

        if (empty($email) || empty($senha)) {
            $html = $this->dependencias['template']->renderizar('base.php', [
                'titulo' => 'Login',
                'view' => 'login/formulario.php',
                'layout' => [
                    'nomeSistema' => $this->configuracao['app']['nome'],
                    'workplaceSession' => null,
                    'versao' => $this->dependencias['versao_codigo']->assinatura(),
                    'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                    'basePath' => $this->configuracao['app']['base_path'],
                ],
                'dados' => ['erro' => 'Email e senha são obrigatórios.'],
            ]);

            $response->getBody()->write($html);

            return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
        }

        try {
            $usuario = $this->usuarioService->autenticar($email, $senha);
        } catch (\RuntimeException $e) {
            $html = $this->dependencias['template']->renderizar('base.php', [
                'titulo' => 'Login',
                'view' => 'login/formulario.php',
                'layout' => [
                    'nomeSistema' => $this->configuracao['app']['nome'],
                    'workplaceSession' => null,
                    'versao' => $this->dependencias['versao_codigo']->assinatura(),
                    'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                    'basePath' => $this->configuracao['app']['base_path'],
                ],
                'dados' => ['erro' => $e->getMessage()],
            ]);

            $response->getBody()->write($html);

            return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
        }

        if ($usuario === null) {
            $html = $this->dependencias['template']->renderizar('base.php', [
                'titulo' => 'Login',
                'view' => 'login/formulario.php',
                'layout' => [
                    'nomeSistema' => $this->configuracao['app']['nome'],
                    'workplaceSession' => null,
                    'versao' => $this->dependencias['versao_codigo']->assinatura(),
                    'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                    'basePath' => $this->configuracao['app']['base_path'],
                ],
                'dados' => ['erro' => 'Email ou senha inválidos.'],
            ]);

            $response->getBody()->write($html);

            return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
        }

        $this->usuarioService->iniciarSessaoUsuario((int) $usuario['id']);

        return $response
            ->withHeader('Location', $this->configuracao['app']['base_path'] . '/')
            ->withStatus(302);
    }

    /**
     * Logout.
     */
    public function logout(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $this->usuarioService->encerrarSessao();

        return $response
            ->withHeader('Location', $this->configuracao['app']['base_path'] . '/login')
            ->withStatus(302);
    }
}
