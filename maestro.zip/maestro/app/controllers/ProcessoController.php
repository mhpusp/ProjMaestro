<?php

declare(strict_types=1);

namespace App\controllers;

use App\workflow\contracts\WorkflowMetaInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class ProcessoController
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly WorkflowMetaInterface $service
    ) {
    }

    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->renderizar($request, $response, 'processos/lista.php', [
            'processos' => $this->service->listar(),
        ]);
    }

    public function novo(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        return $this->renderizar($request, $response, 'processos/formulario.php', ['modo' => 'novo']);
    }

    public function criarNovo(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();
        $arquivoJson = $request->getUploadedFiles()['arquivo_json'] ?? null;

        try {
            if (!$arquivoJson instanceof \Psr\Http\Message\UploadedFileInterface) {
                throw new \InvalidArgumentException('Selecione o arquivo JSON do processo.');
            }

            $this->service->criarNovo($dados, $arquivoJson);

            return $response->withHeader('Location', $this->url('/admin/processos'))->withStatus(303);
        } catch (\InvalidArgumentException|\RuntimeException $erro) {
            return $this->renderizar(
                $request,
                $response->withStatus(422),
                'processos/formulario.php',
                ['erro' => $erro->getMessage(), 'dadosFormulario' => $dados]
            );
        }
    }

    public function atualizar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $query = $request->getQueryParams();
        $busca = trim((string) ($query['busca'] ?? ''));
        $processoId = trim((string) ($query['processo_id'] ?? ''));

        if ($processoId !== '') {
            $processos = array_values(array_filter(
                $this->service->listar(),
                static fn ($processo): bool => $processo->id === $processoId
            ));
        } elseif ($busca !== '') {
            $processos = $this->service->pesquisar($busca);
        } else {
            $processos = [];
        }

        return $this->renderizar($request, $response, 'processos/atualizar.php', [
            'busca' => $busca,
            'processoId' => $processoId,
            'processos' => $processos,
        ]);
    }

    public function salvarAtualizacao(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();
        $processoId = trim((string) ($dados['processo_id'] ?? ''));
        $arquivoJson = $request->getUploadedFiles()['arquivo_json'] ?? null;

        try {
            if (!$arquivoJson instanceof \Psr\Http\Message\UploadedFileInterface) {
                throw new \InvalidArgumentException('Selecione o novo arquivo JSON do processo.');
            }

            $this->service->atualizar($processoId, $dados, $arquivoJson);

            return $response->withHeader('Location', $this->url('/admin/processos'))->withStatus(303);
        } catch (\InvalidArgumentException|\RuntimeException $erro) {
            return $this->renderizar(
                $request,
                $response->withStatus(422),
                'processos/atualizar.php',
                ['erro' => $erro->getMessage(), 'processoId' => $processoId, 'dadosFormulario' => $dados]
            );
        }
    }

    private function renderizar(
        ServerRequestInterface $request,
        ResponseInterface $response,
        string $view,
        array $dados
    ): ResponseInterface {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Processos',
            'view' => $view,
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => $dados,
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function url(string $path): string
    {
        return rtrim((string) $this->configuracao['app']['base_path'], '/') . $path;
    }
}