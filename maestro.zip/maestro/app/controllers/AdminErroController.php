<?php

declare(strict_types=1);

namespace App\controllers;

use App\repositories\ErroRepository;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Controller do painel administrativo simples de erros recentes.
 */
class AdminErroController
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     * @param array<string, mixed> $dependencias Servicos explicitos da aplicacao.
     */
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly ErroRepository $erros
    ) {
    }

    /**
     * Lista erros recentes registrados em Redis ou fallback local.
     */
    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Erros recentes',
            'view' => 'admin/erros.php',
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => [
                'erros' => $this->erros->listarRecentes(),
                'ttlRedis' => $this->configuracao['erros']['ttl_redis'],
            ],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }
}
