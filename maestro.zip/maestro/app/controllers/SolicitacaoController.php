<?php

declare(strict_types=1);

namespace App\controllers;

use App\exportadores\ExportadorCsv;
use App\services\RascunhoService;
use App\services\SolicitacaoService;
use App\workplace\WorkplaceSession;
use InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use RuntimeException;

/**
 * Controller fino do modulo de solicitacoes.
 */
class SolicitacaoController
{
    private const TIPO_RASCUNHO = 'solicitacao';

    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     * @param array<string, mixed> $dependencias Servicos explicitos da aplicacao.
     */
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly SolicitacaoService $service,
        private readonly RascunhoService $rascunhos
    ) {
    }

    /**
     * Lista solicitacoes em pagina HTML.
     */
    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $filtro = (string) ($request->getQueryParams()['busca'] ?? '');

        return $this->renderizar($request, $response, 'solicitacoes/lista.php', [
            'solicitacoes' => $this->service->listar($filtro),
            'filtro' => $filtro,
            'statusDisponiveis' => $this->service->statusDisponiveis(),
        ]);
    }

    /**
     * Retorna apenas o trecho da lista para atualizacao htmx.
     */
    public function filtrar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $filtro = (string) ($request->getQueryParams()['busca'] ?? '');
        $html = $this->dependencias['template']->renderizar('solicitacoes/parcial_lista.php', [
            'solicitacoes' => $this->service->listar($filtro),
            'statusDisponiveis' => $this->service->statusDisponiveis(),
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /**
     * Exibe detalhe de uma solicitacao.
     */
    public function detalhe(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            return $this->renderizar($request, $response, 'solicitacoes/detalhe.php', [
                'solicitacao' => $this->service->buscar((int) $args['id']),
                'statusDisponiveis' => $this->service->statusDisponiveis(),
            ]);
        } catch (RuntimeException $erro) {
            return $this->renderizar($request, $response->withStatus(404), 'solicitacoes/detalhe.php', [
                'erro' => $erro->getMessage(),
            ]);
        }
    }

    /**
     * Exibe formulario de criacao.
     */
    public function novo(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $rascunho = $this->rascunhos->obterOuCriar(self::TIPO_RASCUNHO, $this->usuarioId($request), [
            'prioridade' => 'media',
        ]);

        return $this->renderizar($request, $response, 'solicitacoes/formulario.php', [
            'dadosFormulario' => (array) ($rascunho['dados'] ?? []),
            'rascunho' => $rascunho,
            'rascunhoTtlDias' => $this->configuracao['rascunhos']['ttl_dias'],
        ]);
    }

    /**
     * Salva dados parciais do formulario em um rascunho do usuario logado.
     */
    public function salvarRascunho(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();
        $rascunhoId = (string) ($dados['rascunho_id'] ?? '');

        if ($rascunhoId === '') {
            return $this->responderJson($response->withStatus(422), [
                'sucesso' => false,
                'mensagem' => 'Rascunho nao informado.',
            ]);
        }

        try {
            $rascunho = $this->rascunhos->salvarParcial(
                $rascunhoId,
                self::TIPO_RASCUNHO,
                $this->usuarioId($request),
                $this->service->normalizarDadosFormulario($dados)
            );

            return $this->responderStatusRascunho($response, $rascunho);
        } catch (RuntimeException $erro) {
            return $this->responderJson($response->withStatus(422), [
                'sucesso' => false,
                'mensagem' => $erro->getMessage(),
            ]);
        }
    }

    /**
     * Cria uma solicitacao e exibe o detalhe gerado.
     */
    public function criar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();
        $rascunhoId = (string) ($dados['rascunho_id'] ?? '');

        try {
            $solicitacao = $this->service->criar($dados);
            $dadosNormalizados = $this->service->normalizarDadosFormulario($dados);

            if ($rascunhoId !== '') {
                $this->rascunhos->marcarEnviado(
                    $rascunhoId,
                    self::TIPO_RASCUNHO,
                    $this->usuarioId($request),
                    $dadosNormalizados
                );
            }

            $this->auditar($request, 'solicitacao.criar', 'sucesso', [
                'solicitacao_id' => $solicitacao['id'],
                'prioridade' => $solicitacao['prioridade'],
            ]);

            return $this->renderizar($request, $response->withStatus(201), 'solicitacoes/detalhe.php', [
                'solicitacao' => $solicitacao,
                'statusDisponiveis' => $this->service->statusDisponiveis(),
                'mensagemSucesso' => 'Solicitacao criada para demonstracao.',
            ]);
        } catch (InvalidArgumentException $erro) {
            $this->auditar($request, 'solicitacao.criar', 'falha_validacao');
            try {
                $rascunho = $rascunhoId !== ''
                    ? $this->rascunhos->salvarParcial(
                        $rascunhoId,
                        self::TIPO_RASCUNHO,
                        $this->usuarioId($request),
                        $this->service->normalizarDadosFormulario($dados)
                    )
                    : $this->rascunhos->obterOuCriar(
                        self::TIPO_RASCUNHO,
                        $this->usuarioId($request),
                        $this->service->normalizarDadosFormulario($dados)
                    );
            } catch (RuntimeException) {
                $rascunho = $this->rascunhos->obterOuCriar(
                    self::TIPO_RASCUNHO,
                    $this->usuarioId($request),
                    $this->service->normalizarDadosFormulario($dados)
                );
            }

            return $this->renderizar($request, $response->withStatus(422), 'solicitacoes/formulario.php', [
                'erro' => $erro->getMessage(),
                'dadosFormulario' => (array) ($rascunho['dados'] ?? $dados),
                'rascunho' => $rascunho,
                'rascunhoTtlDias' => $this->configuracao['rascunhos']['ttl_dias'],
            ]);
        }
    }

    /**
     * Altera status e retorna pagina completa ou parcial htmx.
     */
    public function alterarStatus(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();

        try {
            $solicitacao = $this->service->alterarStatus((int) $args['id'], (string) ($dados['status'] ?? ''));
            $this->auditar($request, 'solicitacao.alterar_status', 'sucesso', [
                'solicitacao_id' => $solicitacao['id'],
                'status' => $solicitacao['status'],
            ]);
            $payload = [
                'solicitacao' => $solicitacao,
                'statusDisponiveis' => $this->service->statusDisponiveis(),
                'mensagemSucesso' => 'Status atualizado para demonstracao.',
            ];

            if ($request->hasHeader('HX-Request')) {
                $templateParcial = str_starts_with($request->getHeaderLine('HX-Target'), 'solicitacao-card-')
                    ? 'solicitacoes/parcial_card.php'
                    : 'solicitacoes/parcial_detalhe.php';
                $html = $this->dependencias['template']->renderizar($templateParcial, [
                    ...$payload,
                    'solicitacaoCard' => $solicitacao,
                ]);
                $response->getBody()->write($html);

                return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
            }

            return $this->renderizar($request, $response, 'solicitacoes/detalhe.php', $payload);
        } catch (InvalidArgumentException | RuntimeException $erro) {
            $this->auditar($request, 'solicitacao.alterar_status', 'falha');

            return $this->responderJson($response->withStatus(422), [
                'status' => 'erro',
                'mensagem' => $erro->getMessage(),
            ]);
        }
    }

    /**
     * Exclui uma solicitacao da lista em memoria.
     */
    public function excluir(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            $this->service->excluir((int) $args['id']);
            $this->auditar($request, 'solicitacao.excluir', 'sucesso', [
                'solicitacao_id' => (int) $args['id'],
            ]);

            return $response
                ->withHeader('Location', '/solicitacoes')
                ->withStatus(303);
        } catch (RuntimeException $erro) {
            $this->auditar($request, 'solicitacao.excluir', 'falha');

            return $this->renderizar($request, $response->withStatus(404), 'solicitacoes/detalhe.php', [
                'erro' => $erro->getMessage(),
            ]);
        }
    }

    /**
     * Lista solicitacoes em JSON para rota API.
     */
    public function apiListar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $filtro = (string) ($request->getQueryParams()['busca'] ?? '');

        return $this->responderApi($response, true, $this->service->listar($filtro));
    }

    /**
     * Busca uma solicitacao em JSON para rota API.
     */
    public function apiDetalhe(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            return $this->responderApi($response, true, $this->service->buscar((int) $args['id']));
        } catch (RuntimeException $erro) {
            return $this->responderApi(
                $response->withStatus(404),
                false,
                null,
                $erro->getMessage(),
                'SOLICITACAO_NAO_ENCONTRADA'
            );
        }
    }

    /**
     * Cria uma solicitacao pela API REST.
     */
    public function apiCriar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();

        try {
            $solicitacao = $this->service->criar($dados);
            $this->auditar($request, 'solicitacao.api_criar', 'sucesso', [
                'solicitacao_id' => $solicitacao['id'],
                'prioridade' => $solicitacao['prioridade'],
            ]);

            return $this->responderApi(
                $response->withStatus(201),
                true,
                $solicitacao,
                'Solicitacao criada.'
            );
        } catch (InvalidArgumentException $erro) {
            $this->auditar($request, 'solicitacao.api_criar', 'falha_validacao');

            return $this->responderApi(
                $response->withStatus(422),
                false,
                null,
                $erro->getMessage(),
                'VALIDACAO'
            );
        }
    }

    /**
     * Altera status pela API REST.
     */
    public function apiAlterarStatus(
        ServerRequestInterface $request,
        ResponseInterface $response,
        array $args
    ): ResponseInterface {
        $dados = (array) $request->getParsedBody();

        try {
            $solicitacao = $this->service->alterarStatus((int) $args['id'], (string) ($dados['status'] ?? ''));
            $this->auditar($request, 'solicitacao.api_alterar_status', 'sucesso', [
                'solicitacao_id' => $solicitacao['id'],
                'status' => $solicitacao['status'],
            ]);

            return $this->responderApi($response, true, $solicitacao, 'Status atualizado.');
        } catch (InvalidArgumentException $erro) {
            $this->auditar($request, 'solicitacao.api_alterar_status', 'falha_validacao');

            return $this->responderApi(
                $response->withStatus(422),
                false,
                null,
                $erro->getMessage(),
                'VALIDACAO'
            );
        } catch (RuntimeException $erro) {
            $this->auditar($request, 'solicitacao.api_alterar_status', 'falha');

            return $this->responderApi(
                $response->withStatus(404),
                false,
                null,
                $erro->getMessage(),
                'SOLICITACAO_NAO_ENCONTRADA'
            );
        }
    }

    /**
     * Exporta a lista em JSON.
     */
    public function exportarJson(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = $this->service->listar();
        $this->auditar($request, 'solicitacao.exportar_json', 'sucesso', [
            'quantidade' => count($dados),
        ]);

        return $this->responderJson($response, ['dados' => $dados]);
    }

    /**
     * Exporta a lista em CSV reutilizando os dados do service.
     */
    public function exportarCsv(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = $this->service->listar();
        $exportador = new ExportadorCsv();
        $conteudo = $exportador->exportar($dados, $this->colunasExportacao());

        $this->auditar($request, 'solicitacao.exportar_csv', 'sucesso', [
            'quantidade' => count($dados),
        ]);

        $response->getBody()->write($conteudo);

        return $response
            ->withHeader('Content-Type', $exportador->contentType())
            ->withHeader('Content-Disposition', 'attachment; filename="solicitacoes.' . $exportador->extensao() . '"');
    }

    /**
     * Retorna placeholder para exportacao futura em PDF.
     */
    public function prepararPdf(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $this->auditar($request, 'solicitacao.exportar_pdf', 'pendente');

        return $this->responderJson($response->withStatus(501), $this->service->prepararExportacao('pdf'));
    }

    /**
     * Retorna placeholder para exportacao futura em Excel.
     */
    public function prepararExcel(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $this->auditar($request, 'solicitacao.exportar_excel', 'pendente');

        return $this->responderJson($response->withStatus(501), $this->service->prepararExportacao('excel'));
    }

    /**
     * @param array<string, mixed> $rascunho
     */
    private function responderStatusRascunho(ResponseInterface $response, array $rascunho): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('solicitacoes/parcial_status_rascunho.php', [
            'rascunho' => $rascunho,
            'rascunhoTtlDias' => $this->configuracao['rascunhos']['ttl_dias'],
        ]);
        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function usuarioId(ServerRequestInterface $request): string
    {
        $workplace = $request->getAttribute('workplace');

        if (!$workplace instanceof WorkplaceSession) {
            throw new RuntimeException('Usuario autenticado nao encontrado na requisicao.');
        }

        return $workplace->usuario->codpes ?? $workplace->usuario->id;
    }

    /**
     * @param array<string, mixed> $dados
     */
    private function renderizar(
        ServerRequestInterface $request,
        ResponseInterface $response,
        string $view,
        array $dados
    ): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Solicitacoes',
            'view' => $view,
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => $dados,
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function responderJson(ResponseInterface $response, array $payload): ResponseInterface
    {
        $response->getBody()->write((string) json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
    }

    private function responderApi(
        ResponseInterface $response,
        bool $sucesso,
        mixed $dados = null,
        ?string $mensagem = null,
        ?string $codigoErro = null
    ): ResponseInterface {
        return $this->responderJson($response, [
            'sucesso' => $sucesso,
            'dados' => $dados,
            'mensagem' => $mensagem,
            'codigo_erro' => $codigoErro,
        ]);
    }

    /**
     * @return array<string, string>
     */
    private function colunasExportacao(): array
    {
        return [
            'id' => 'ID',
            'titulo' => 'Titulo',
            'solicitante' => 'Solicitante',
            'status_rotulo' => 'Status',
            'prioridade' => 'Prioridade',
            'criada_em' => 'Criada em',
        ];
    }

    /**
     * @param array<string, mixed> $contexto
     */
    private function auditar(
        ServerRequestInterface $request,
        string $acao,
        string $resultado,
        array $contexto = []
    ): void {
        $this->dependencias['auditoria']->registrar($request, $acao, $resultado, $contexto, 'solicitacoes');
    }
}
