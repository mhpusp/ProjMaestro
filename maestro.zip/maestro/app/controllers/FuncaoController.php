<?php

declare(strict_types=1);

namespace App\controllers;

use App\services\FuncaoService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class FuncaoController
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly FuncaoService $service
    ) {
    }

    public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $funcoes = $this->service->listar();

        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Funcoes',
            'view' => 'funcoes/lista.php',
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => ['funcoes' => $funcoes],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    public function novo(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Nova Funcao',
            'view' => 'funcoes/formulario.php',
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $request->getAttribute('workplace'),
                'versao' => $this->dependencias['versao_codigo']->assinatura(),
                'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
            'dados' => [],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    public function criar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $dados = (array) $request->getParsedBody();

        try {
            $funcao = $this->service->criar((string) ($dados['nome'] ?? ''), $dados['descricao'] ?? null);

            return $response->withHeader('Location', '/admin/funcoes')->withStatus(303);
        } catch (\RuntimeException $erro) {
            $html = $this->dependencias['template']->renderizar('base.php', [
                'titulo' => 'Nova Funcao',
                'view' => 'funcoes/formulario.php',
                'layout' => [
                    'nomeSistema' => $this->configuracao['app']['nome'],
                    'workplaceSession' => $request->getAttribute('workplace'),
                    'versao' => $this->dependencias['versao_codigo']->assinatura(),
                    'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
                    'basePath' => $this->configuracao['app']['base_path'],
                ],
                'dados' => ['erro' => $erro->getMessage(), 'dadosFormulario' => $dados],
            ]);

            $response->getBody()->write($html);

            return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
        }
    }
}
