<?php

declare(strict_types=1);

namespace App\exportadores;

/**
 * Placeholder para exportacao PDF futura.
 */
class ExportadorPdf implements ExportadorInterface
{
    public function exportar(array $linhas, array $colunas): string
    {
        return 'Exportacao PDF ainda nao implementada. Dados recebidos: ' . count($linhas) . ' linhas.';
    }

    public function contentType(): string
    {
        return 'application/pdf';
    }

    public function extensao(): string
    {
        return 'pdf';
    }
}
