<?php

declare(strict_types=1);

namespace App\exportadores;

/**
 * Placeholder para exportacao Excel futura.
 */
class ExportadorExcel implements ExportadorInterface
{
    public function exportar(array $linhas, array $colunas): string
    {
        return 'Exportacao Excel ainda nao implementada. Dados recebidos: ' . count($linhas) . ' linhas.';
    }

    public function contentType(): string
    {
        return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    }

    public function extensao(): string
    {
        return 'xlsx';
    }
}
