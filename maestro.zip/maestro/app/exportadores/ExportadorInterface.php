<?php

declare(strict_types=1);

namespace App\exportadores;

/**
 * Contrato comum para exportadores de dados tabulares.
 */
interface ExportadorInterface
{
    /**
     * @param array<int, array<string, mixed>> $linhas
     * @param array<string, string> $colunas Chave da linha => rotulo da coluna.
     */
    public function exportar(array $linhas, array $colunas): string;

    public function contentType(): string;

    public function extensao(): string;
}
