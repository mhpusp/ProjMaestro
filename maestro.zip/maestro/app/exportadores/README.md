# Exportadores

Estrutura inicial para exportacao de dados tabulares.

## Fluxo

1. A regra de negocio prepara arrays padronizados.
2. O controller escolhe o exportador adequado.
3. O exportador recebe linhas e colunas, sem consultar banco ou acessar request.

## Implementado

- `ExportadorInterface`: contrato comum.
- `ExportadorCsv`: gera CSV simples com separador `;`.

## Futuro

- `ExportadorPdf`: deve usar uma biblioteca livre de PDF e receber HTML/dados ja preparados.
- `ExportadorExcel`: deve usar uma biblioteca livre para XLSX ou CSV enriquecido, mantendo a regra de negocio fora do exportador.

PDF e Excel devem continuar usando os mesmos dados do service para evitar divergencia entre tela, API e arquivos.
