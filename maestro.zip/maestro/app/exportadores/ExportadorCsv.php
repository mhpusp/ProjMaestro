<?php

declare(strict_types=1);

namespace App\exportadores;

use RuntimeException;

/**
 * Exportador CSV simples para dados tabulares.
 */
class ExportadorCsv implements ExportadorInterface
{
    /**
     * @param array<int, array<string, mixed>> $linhas
     * @param array<string, string> $colunas
     */
    public function exportar(array $linhas, array $colunas): string
    {
        $arquivo = fopen('php://temp', 'r+');

        if ($arquivo === false) {
            throw new RuntimeException('Nao foi possivel preparar o CSV.');
        }

        fputcsv($arquivo, array_values($colunas), ';');

        foreach ($linhas as $linha) {
            $valores = [];

            foreach (array_keys($colunas) as $chave) {
                $valores[] = (string) ($linha[$chave] ?? '');
            }

            fputcsv($arquivo, $valores, ';');
        }

        rewind($arquivo);
        $conteudo = stream_get_contents($arquivo);
        fclose($arquivo);

        if ($conteudo === false) {
            throw new RuntimeException('Nao foi possivel ler o CSV gerado.');
        }

        return $conteudo;
    }

    public function contentType(): string
    {
        return 'text/csv; charset=utf-8';
    }

    public function extensao(): string
    {
        return 'csv';
    }
}
