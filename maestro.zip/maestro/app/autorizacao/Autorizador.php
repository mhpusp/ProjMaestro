<?php

declare(strict_types=1);

namespace App\autorizacao;

use App\workplace\WorkplaceSession;

/**
 * Verifica permissoes por sistema, papel, acao e escopo opcional.
 */
class Autorizador
{
    /**
     * @param array<string, array<string, array<int, mixed>>> $permissoes
     */
    public function __construct(private readonly array $permissoes)
    {
    }

    public function pode(
        WorkplaceSession $workplace,
        string $sistema,
        string $acao,
        ?string $escopo = null
    ): bool {
        $papel = $workplace->papelAtivo->codigo;
        $regras = $this->permissoes[$sistema][$papel] ?? [];

        foreach ($regras as $regra) {
            if ($regra === '*') {
                return true;
            }

            if (is_string($regra) && $regra === $acao) {
                return true;
            }

            if (is_array($regra) && $this->regraPermite($regra, $acao, $escopo)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $regra
     */
    private function regraPermite(array $regra, string $acao, ?string $escopo): bool
    {
        if (($regra['acao'] ?? null) !== $acao) {
            return false;
        }

        if ($escopo === null) {
            return true;
        }

        $escopos = $regra['escopos'] ?? [];

        return is_array($escopos) && in_array($escopo, $escopos, true);
    }
}
