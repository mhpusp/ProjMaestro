# Autorizacao por Rota

O modelo oficial do scaffold e autorizacao por rota e papel.

## Fonte de verdade

As permissoes ficam em `config/autorizacoes_rotas.php`. Esse arquivo possui um aviso no topo e nao deve ser editado manualmente. Use a REST API nativa para alterar papeis.

## Fluxo

1. `config/routes.php` registra cada rota em `AutorizacaoRotaService`.
2. `AutenticacaoSsoMiddleware` injeta a `WorkplaceSession`.
3. `ExigePapelRota` verifica se o papel ativo esta autorizado para a rota.
4. Em caso de negativa, a tentativa e auditada e a resposta e `403`.
5. A REST API de autorizacoes lista rotas e altera papeis no arquivo local.

## Exemplo

```php
$rota = $registrar('solicitacoes.criar', ['POST'], '/solicitacoes', false, ['admin', 'operador']);

$app->post('/solicitacoes', $handler)
    ->add($exigeRota($rota))
    ->add($autenticacao);
```

## REST API

- `GET /api/autorizacoes/rotas`
- `POST /api/autorizacoes/rotas/{rota_id}/papeis`
- `DELETE /api/autorizacoes/rotas/{rota_id}/papeis`

O modelo antigo por acao (`config/permissoes.php`, `Autorizador`, `ExigePermissao`) permanece no codigo apenas como legado para consultas futuras e nao deve ser usado em novas rotas.
