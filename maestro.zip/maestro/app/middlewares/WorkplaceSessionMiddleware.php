<?php

declare(strict_types=1);

namespace App\middlewares;

use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Injeta o contexto Workplace na requisicao atual.
 */
class WorkplaceSessionMiddleware implements MiddlewareInterface
{
    public const ATRIBUTO = 'workplace';
    public const SESSAO_PAPEL_ATIVO = 'workplace_papel_ativo';

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $codigoPapelAtivo = isset($_SESSION[self::SESSAO_PAPEL_ATIVO])
            ? (string) $_SESSION[self::SESSAO_PAPEL_ATIVO]
            : null;

        $workplace = WorkplaceSession::mock($codigoPapelAtivo);

        if ($codigoPapelAtivo !== $workplace->papelAtivo->codigo) {
            $_SESSION[self::SESSAO_PAPEL_ATIVO] = $workplace->papelAtivo->codigo;
        }

        return $handler->handle($request->withAttribute(self::ATRIBUTO, $workplace));
    }
}
