<?php

declare(strict_types=1);

namespace App\middlewares;

use App\autorizacao\Autorizador;
use App\services\AuditoriaService;
use App\services\VersaoCodigoService;
use App\suporte\Template;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Middleware simples para exigir permissao por acao.
 */
class ExigePermissao implements MiddlewareInterface
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     */
    public function __construct(
        private readonly ResponseFactoryInterface $responseFactory,
        private readonly Template $template,
        private readonly Autorizador $autorizador,
        private readonly AuditoriaService $auditoria,
        private readonly array $configuracao,
        private readonly string $sistema,
        private readonly string $acao,
        private readonly ?string $escopo = null,
        private readonly ?VersaoCodigoService $versaoCodigo = null
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $workplace = $request->getAttribute(WorkplaceSessionMiddleware::ATRIBUTO);

        if (!$workplace instanceof WorkplaceSession) {
            return $this->responderNaoAutenticado($request);
        }

        if ($this->autorizador->pode(
            $workplace,
            $this->sistema,
            $this->acao,
            $this->escopo
        )) {
            return $handler->handle($request);
        }

        if ($workplace instanceof WorkplaceSession) {
            $this->auditoria->registrar($request, $this->acao, 'negado', [
                'escopo' => $this->escopo,
            ], $this->sistema);
        }

        return $this->responderNegado($request, $workplace instanceof WorkplaceSession ? $workplace : null);
    }

    private function responderNaoAutenticado(ServerRequestInterface $request): ResponseInterface
    {
        $response = $this->responseFactory->createResponse(401);

        if ($this->prefereJson($request)) {
            $response->getBody()->write((string) json_encode([
                'sucesso' => false,
                'dados' => null,
                'mensagem' => 'Autenticacao necessaria.',
                'codigo_erro' => 'NAO_AUTENTICADO',
            ], JSON_UNESCAPED_UNICODE));

            return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
        }

        $response->getBody()->write('Autenticacao necessaria.');

        return $response->withHeader('Content-Type', 'text/plain; charset=utf-8');
    }

    private function responderNegado(ServerRequestInterface $request, ?WorkplaceSession $workplace): ResponseInterface
    {
        $response = $this->responseFactory->createResponse(403);

        if ($this->prefereJson($request)) {
            $response->getBody()->write((string) json_encode([
                'sucesso' => false,
                'dados' => null,
                'mensagem' => 'Voce nao tem permissao para executar esta acao.',
                'codigo_erro' => 'ACESSO_NEGADO',
            ], JSON_UNESCAPED_UNICODE));

            return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
        }

        $html = $this->template->renderizar('403.php', [
            'titulo' => 'Acesso negado',
            'sistema' => $this->sistema,
            'acao' => $this->acao,
            'escopo' => $this->escopo,
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $workplace,
                'versao' => $this->versaoCodigo?->assinatura() ?? $this->configuracao['app']['versao'],
                'versaoCodigo' => $this->versaoCodigo?->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
        ]);
        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function prefereJson(ServerRequestInterface $request): bool
    {
        $accept = implode(',', $request->getHeader('Accept'));
        $path = (string) $request->getUri()->getPath();

        return str_starts_with($path, '/api/') || str_contains($accept, 'application/json');
    }
}
