<?php

declare(strict_types=1);

namespace App\middlewares;

use App\services\OpenSsoClient;
use App\workplace\PapelInstitucional;
use App\workplace\UsuarioLogado;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Autentica rotas protegidas usando OpenSSO ou usuario local de desenvolvimento.
 */
class AutenticacaoSsoMiddleware implements MiddlewareInterface
{
    /**
     * @param array<string, mixed> $configuracao
     */
    public function __construct(
        private readonly ResponseFactoryInterface $responseFactory,
        private readonly array $configuracao,
        private readonly OpenSsoClient $openSso
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $this->iniciarSessao();

        $workplace = $this->ssoHabilitado()
            ? $this->autenticarPorOpenSso($request)
            : $this->criarSessaoDesenvolvimento();

        if (!$workplace instanceof WorkplaceSession) {
            return $this->responderNaoAutenticado($request);
        }

        if ($this->papelAtivoDaSessao() !== $workplace->papelAtivo->codigo) {
            $_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO] = $workplace->papelAtivo->codigo;
        }

        return $handler->handle($request->withAttribute(WorkplaceSessionMiddleware::ATRIBUTO, $workplace));
    }

    private function iniciarSessao(): void
    {
        if (session_status() !== PHP_SESSION_NONE) {
            return;
        }

        $this->configurarSessao();
        session_start();
    }

    private function configurarSessao(): void
    {
        $savePath = (string) ($this->configuracao['sessao']['save_path'] ?? '');

        if ($savePath !== '') {
            if (!str_starts_with($savePath, '/')) {
                $savePath = dirname(__DIR__, 2) . '/' . $savePath;
            }

            if (!is_dir($savePath)) {
                @mkdir($savePath, 0775, true);
            }

            if (is_dir($savePath) && is_writable($savePath)) {
                session_save_path($savePath);
            }
        }

        session_set_cookie_params([
            'secure' => (bool) ($this->configuracao['sessao']['cookie_secure'] ?? false),
            'httponly' => (bool) ($this->configuracao['sessao']['cookie_httponly'] ?? true),
            'samesite' => (string) ($this->configuracao['sessao']['cookie_samesite'] ?? 'Lax'),
            'path' => '/',
        ]);
    }

    private function ssoHabilitado(): bool
    {
        return (bool) $this->configuracao['sso']['habilitado'];
    }

    private function autenticarPorOpenSso(ServerRequestInterface $request): ?WorkplaceSession
    {
        $cookieName = (string) $this->configuracao['sso']['cookie_name'];
        $cookies = $request->getCookieParams();
        $subjectId = isset($cookies[$cookieName]) ? (string) $cookies[$cookieName] : '';

        if ($subjectId === '') {
            return null;
        }

        $atributos = $this->openSso->buscarAtributos($subjectId);

        if ($atributos === null) {
            return null;
        }

        $usuario = UsuarioLogado::fromOpenSso(
            $atributos,
            $this->montarPapeis((array) $this->configuracao['sso']['papeis_padrao'])
        );

        return $this->criarWorkplace($usuario, 'opensso');
    }

    private function criarSessaoDesenvolvimento(): WorkplaceSession
    {
        $usuario = UsuarioLogado::desenvolvimentoConfigurado(
            (array) $this->configuracao['sso']['dev_usuario'],
            $this->montarPapeis((array) $this->configuracao['sso']['dev_usuario']['papeis'])
        );

        return $this->criarWorkplace($usuario, 'mock-desenvolvimento');
    }

    private function criarWorkplace(UsuarioLogado $usuario, string $origem): WorkplaceSession
    {
        $codigoPapelAtivo = $this->papelAtivoDaSessao();
        $papelAtivo = $codigoPapelAtivo !== null ? $usuario->papelPorCodigo($codigoPapelAtivo) : null;

        return new WorkplaceSession(
            $usuario,
            $papelAtivo ?? $usuario->primeiroPapel(),
            $origem,
            date(DATE_ATOM)
        );
    }

    private function papelAtivoDaSessao(): ?string
    {
        return isset($_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO])
            ? (string) $_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO]
            : null;
    }

    /**
     * @param array<int, string> $codigos
     * @return array<int, PapelInstitucional>
     */
    private function montarPapeis(array $codigos): array
    {
        $papeis = [];

        foreach ($codigos as $codigo) {
            $codigo = trim((string) $codigo);

            if ($codigo === '') {
                continue;
            }

            $papeis[] = new PapelInstitucional(
                $codigo,
                $this->rotuloPapel($codigo),
                'Papel carregado para a sessao institucional.'
            );
        }

        return $papeis !== [] ? $papeis : [
            new PapelInstitucional('leitor', 'Leitor', 'Consulta de informacoes sem alteracao.'),
        ];
    }

    private function rotuloPapel(string $codigo): string
    {
        return match ($codigo) {
            'admin' => 'Administrador',
            'operador' => 'Operador',
            'leitor' => 'Leitor',
            default => ucfirst($codigo),
        };
    }

    private function responderNaoAutenticado(ServerRequestInterface $request): ResponseInterface
    {
        if ($this->prefereJson($request)) {
            $response = $this->responseFactory->createResponse(401);
            $response->getBody()->write((string) json_encode([
                'sucesso' => false,
                'dados' => null,
                'mensagem' => 'Autenticacao necessaria.',
                'codigo_erro' => 'NAO_AUTENTICADO',
            ], JSON_UNESCAPED_UNICODE));

            return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
        }

        return $this->responseFactory
            ->createResponse(302)
            ->withHeader('Location', $this->montarUrlLogin($request));
    }

    private function montarUrlLogin(ServerRequestInterface $request): string
    {
        $loginUrl = (string) $this->configuracao['sso']['login_url'];
        $separador = str_contains($loginUrl, '?') ? '&' : '?';

        return $loginUrl . $separador . 'goto=' . rawurlencode($this->urlRetorno($request));
    }

    private function urlRetorno(ServerRequestInterface $request): string
    {
        $base = rtrim((string) $this->configuracao['app']['url'], '/');
        $uri = $request->getUri();
        $path = '/' . ltrim($uri->getPath(), '/');
        $query = $uri->getQuery();

        return $base . $path . ($query !== '' ? '?' . $query : '');
    }

    private function prefereJson(ServerRequestInterface $request): bool
    {
        $accept = implode(',', $request->getHeader('Accept'));
        $path = (string) $request->getUri()->getPath();

        return str_starts_with($path, '/api/') || str_contains($accept, 'application/json');
    }
}
