<?php

declare(strict_types=1);

namespace App\middlewares;

use App\repositories\UsuarioFuncoesRepository;
use App\repositories\UsuarioRepository;
use App\workplace\PapelInstitucional;
use App\workplace\UsuarioLogado;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Middleware de autenticação local para desenvolvimento.
 * Verifica se existe usuário na sessão; caso contrário, redireciona para login.
 */
class AutenticacaoLocalMiddleware implements MiddlewareInterface
{
    public function __construct(
        private readonly UsuarioRepository $usuarioRepository,
        private readonly UsuarioFuncoesRepository $usuarioFuncoesRepository
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $usuarioId = $_SESSION['usuario_id'] ?? null;

        if ($usuarioId === null) {
            return (new \Slim\Psr7\Response())
                ->withHeader('Location', '/maestro/login')
                ->withStatus(302);
        }

        $usuarioData = $this->usuarioRepository->buscarPorId((int) $usuarioId);

        if ($usuarioData === null) {
            unset($_SESSION['usuario_id']);
            session_destroy();

            return (new \Slim\Psr7\Response())
                ->withHeader('Location', '/maestro/login')
                ->withStatus(302);
        }

        $funcoes = $this->usuarioFuncoesRepository->listarFuncoesDoUsuario((int) $usuarioData['id']);
        $papeis = [];

        foreach ($funcoes as $funcao) {
            $codigo = strtolower((string) ($funcao['nome'] ?? 'leitor'));
            $nome = (string) ($funcao['nome'] ?? 'Leitor');
            $descricao = (string) ($funcao['descricao'] ?? 'Papel institucional.');

            $papeis[] = new PapelInstitucional($codigo, $nome, $descricao);
        }

        if ($papeis === []) {
            $papeis[] = new PapelInstitucional('leitor', 'Leitor', 'Consulta de informacoes sem alteracao.');
        }

        $usuarioLogado = new UsuarioLogado(
            (string) $usuarioData['id'],
            (string) $usuarioData['nome'],
            (string) $usuarioData['email'],
            (string) ($usuarioData['telefone_whatsapp'] ?? ''),
            $papeis,
            (string) ($usuarioData['nusp'] ?? (string) $usuarioData['id'])
        );

        $codigoPapelAtivo = isset($_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO])
            ? (string) $_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO]
            : null;

        $papelAtivo = $codigoPapelAtivo !== null
            ? $usuarioLogado->papelPorCodigo($codigoPapelAtivo)
            : null;

        if ($papelAtivo === null) {
            $papelAtivo = $usuarioLogado->primeiroPapel();
        }

        $_SESSION[WorkplaceSessionMiddleware::SESSAO_PAPEL_ATIVO] = $papelAtivo->codigo;

        $workplace = new WorkplaceSession(
            $usuarioLogado,
            $papelAtivo,
            'local',
            date(DATE_ATOM)
        );

        $request = $request->withAttribute('usuario', $usuarioLogado);
        $request = $request->withAttribute('usuario_id', $usuarioData['id']);
        $request = $request->withAttribute(WorkplaceSessionMiddleware::ATRIBUTO, $workplace);

        return $handler->handle($request);
    }
}
