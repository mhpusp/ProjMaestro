<?php

declare(strict_types=1);

namespace App\middlewares;

use App\services\AuditoriaService;
use App\services\AutorizacaoRotaService;
use App\services\VersaoCodigoService;
use App\suporte\Template;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Exige que o papel ativo do usuario esteja autorizado para a rota.
 */
class ExigePapelRota implements MiddlewareInterface
{
    /**
     * @param array<string, mixed> $configuracao
     */
    public function __construct(
        private readonly ResponseFactoryInterface $responseFactory,
        private readonly Template $template,
        private readonly AutorizacaoRotaService $autorizacoes,
        private readonly AuditoriaService $auditoria,
        private readonly array $configuracao,
        private readonly string $rotaId,
        private readonly VersaoCodigoService $versaoCodigo
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $workplace = $request->getAttribute(WorkplaceSessionMiddleware::ATRIBUTO);

        if (!$workplace instanceof WorkplaceSession) {
            return $this->responderJsonOuTexto($request, 401, 'Autenticacao necessaria.', 'NAO_AUTENTICADO');
        }

        if ($this->autorizacoes->usuarioPodeAcessar($this->rotaId, $workplace)) {
            return $handler->handle($request);
        }

        $this->auditoria->registrar($request, $this->rotaId, 'negado', [
            'papel' => $workplace->papelAtivo->codigo,
        ], 'rotas');

        if ($this->prefereJson($request)) {
            return $this->responderJsonOuTexto($request, 403, 'Voce nao tem permissao para acessar esta rota.', 'ACESSO_NEGADO');
        }

        $response = $this->responseFactory->createResponse(403);
        $html = $this->template->renderizar('403.php', [
            'titulo' => 'Acesso negado',
            'sistema' => 'rotas',
            'acao' => $this->rotaId,
            'escopo' => null,
            'layout' => [
                'nomeSistema' => $this->configuracao['app']['nome'],
                'workplaceSession' => $workplace,
                'versao' => $this->versaoCodigo->assinatura(),
                'versaoCodigo' => $this->versaoCodigo->resumo(),
                'basePath' => $this->configuracao['app']['base_path'],
            ],
        ]);
        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function responderJsonOuTexto(
        ServerRequestInterface $request,
        int $status,
        string $mensagem,
        string $codigoErro
    ): ResponseInterface {
        $response = $this->responseFactory->createResponse($status);

        if ($this->prefereJson($request)) {
            $response->getBody()->write((string) json_encode([
                'sucesso' => false,
                'dados' => null,
                'mensagem' => $mensagem,
                'codigo_erro' => $codigoErro,
            ], JSON_UNESCAPED_UNICODE));

            return $response->withHeader('Content-Type', 'application/json; charset=utf-8');
        }

        $response->getBody()->write($mensagem);

        return $response->withHeader('Content-Type', 'text/plain; charset=utf-8');
    }

    private function prefereJson(ServerRequestInterface $request): bool
    {
        $accept = implode(',', $request->getHeader('Accept'));
        $path = (string) $request->getUri()->getPath();

        return str_starts_with($path, '/api/') || str_contains($accept, 'application/json');
    }
}
