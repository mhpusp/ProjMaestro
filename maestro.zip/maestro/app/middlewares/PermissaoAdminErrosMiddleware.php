<?php

declare(strict_types=1);

namespace App\middlewares;

use App\workplace\WorkplaceSession;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Middleware ficticio de permissao para o painel de erros.
 *
 * A regra atual usa um usuario fixo do scaffold. Em um sistema real, este ponto
 * deve consultar a sessao/autenticador e verificar uma permissao institucional.
 */
class PermissaoAdminErrosMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly ResponseFactoryInterface $responseFactory)
    {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $workplace = $request->getAttribute(WorkplaceSessionMiddleware::ATRIBUTO);
        $permitido = $workplace instanceof WorkplaceSession
            && $workplace->papelAtivo->codigo === 'admin';

        if (!$permitido) {
            $response = $this->responseFactory->createResponse(403);
            $response->getBody()->write('Acesso negado.');

            return $response->withHeader('Content-Type', 'text/plain; charset=utf-8');
        }

        return $handler->handle($request);
    }
}
