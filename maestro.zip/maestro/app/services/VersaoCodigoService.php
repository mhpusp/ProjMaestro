<?php

declare(strict_types=1);

namespace App\services;

use Throwable;

/**
 * Le metadados do codigo versionado diretamente da pasta .git.
 */
class VersaoCodigoService
{
    public function __construct(
        private readonly string $raizProjeto,
        private readonly string $versaoAplicacao,
        private readonly ?string $gitPath = null
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function resumo(): array
    {
        try {
            $gitDir = $this->resolverGitDir();
            $head = $this->lerArquivo($gitDir . '/HEAD');
            $branch = null;
            $commit = null;

            if (str_starts_with($head, 'ref:')) {
                $ref = trim(substr($head, 4));
                $branch = basename($ref);
                $commit = $this->commitDaReferencia($gitDir, $ref);
            } else {
                $commit = trim($head);
            }

            if (!$this->commitValido($commit)) {
                throw new \RuntimeException('Commit Git nao encontrado ou invalido.');
            }

            return [
                'status' => 'disponivel',
                'app' => $this->versaoAplicacao,
                'branch' => $branch ?? 'detached',
                'commit' => $commit,
                'commit_curto' => substr($commit, 0, 12),
                'assinatura' => sprintf('%s@%s', $branch ?? 'detached', substr($commit, 0, 12)),
                'mensagem' => 'Versao obtida da pasta .git.',
            ];
        } catch (Throwable $erro) {
            return [
                'status' => 'indisponivel',
                'app' => $this->versaoAplicacao,
                'branch' => null,
                'commit' => null,
                'commit_curto' => null,
                'assinatura' => 'versao-indisponivel',
                'mensagem' => 'Nao foi possivel obter a versao do codigo local.',
                'erro' => $erro->getMessage(),
            ];
        }
    }

    public function assinatura(): string
    {
        return (string) $this->resumo()['assinatura'];
    }

    private function resolverGitDir(): string
    {
        $gitPath = $this->gitPath ?: $this->raizProjeto . '/.git';

        if (is_dir($gitPath)) {
            return $gitPath;
        }

        if (is_file($gitPath)) {
            $conteudo = $this->lerArquivo($gitPath);

            if (str_starts_with($conteudo, 'gitdir:')) {
                $gitDir = trim(substr($conteudo, 7));

                if (!str_starts_with($gitDir, '/')) {
                    $gitDir = $this->raizProjeto . '/' . $gitDir;
                }

                if (is_dir($gitDir)) {
                    return $gitDir;
                }
            }
        }

        throw new \RuntimeException('Pasta .git nao encontrada.');
    }

    private function commitDaReferencia(string $gitDir, string $ref): string
    {
        $refPath = $gitDir . '/' . $ref;

        if (is_file($refPath)) {
            return trim($this->lerArquivo($refPath));
        }

        $packedRefs = $gitDir . '/packed-refs';

        if (is_file($packedRefs)) {
            $linhas = file($packedRefs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

            foreach ($linhas ?: [] as $linha) {
                if (str_starts_with($linha, '#') || str_starts_with($linha, '^')) {
                    continue;
                }

                [$commit, $referencia] = array_pad(explode(' ', $linha, 2), 2, '');

                if ($referencia === $ref) {
                    return trim($commit);
                }
            }
        }

        throw new \RuntimeException('Referencia Git nao encontrada: ' . $ref);
    }

    private function lerArquivo(string $path): string
    {
        if (!is_readable($path)) {
            throw new \RuntimeException('Arquivo Git nao pode ser lido: ' . basename($path));
        }

        $conteudo = file_get_contents($path);

        if ($conteudo === false || trim($conteudo) === '') {
            throw new \RuntimeException('Arquivo Git vazio ou invalido: ' . basename($path));
        }

        return trim($conteudo);
    }

    private function commitValido(?string $commit): bool
    {
        return is_string($commit) && preg_match('/^[a-f0-9]{40}$/', $commit) === 1;
    }
}
