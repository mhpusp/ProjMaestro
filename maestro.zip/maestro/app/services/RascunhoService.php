<?php

declare(strict_types=1);

namespace App\services;

use App\repositories\RascunhoRepositoryInterface;
use DateInterval;
use DateTimeImmutable;
use RuntimeException;

/**
 * Regra de negocio para objetos persistiveis preenchidos parcialmente.
 */
class RascunhoService
{
    public const STATUS_RASCUNHO = 'rascunho';
    public const STATUS_ENVIADO = 'enviado';

    public function __construct(
        private readonly RascunhoRepositoryInterface $repository,
        private readonly int $ttlDias
    ) {
    }

    /**
     * @param array<string, mixed> $dadosIniciais
     * @return array<string, mixed>
     */
    public function obterOuCriar(string $tipo, string $usuarioId, array $dadosIniciais = []): array
    {
        $this->removerExpirados();
        $rascunho = $this->repository->buscarRascunhoAtivo($tipo, $usuarioId);

        if ($rascunho !== null) {
            return $rascunho;
        }

        $agora = $this->agora();

        return $this->repository->salvar([
            'id' => $this->novoId(),
            'tipo' => $tipo,
            'usuario_id' => $usuarioId,
            'status' => self::STATUS_RASCUNHO,
            'dados' => $dadosIniciais,
            'criado_em' => $agora,
            'atualizado_em' => $agora,
            'enviado_em' => null,
        ]);
    }

    /**
     * @param array<string, mixed> $dados
     * @return array<string, mixed>
     */
    public function salvarParcial(string $id, string $tipo, string $usuarioId, array $dados): array
    {
        $rascunho = $this->rascunhoDoUsuario($id, $tipo, $usuarioId);

        if (($rascunho['status'] ?? '') !== self::STATUS_RASCUNHO) {
            throw new RuntimeException('Somente rascunhos podem receber atualizacoes parciais.');
        }

        $rascunho['dados'] = $dados;
        $rascunho['atualizado_em'] = $this->agora();

        return $this->repository->salvar($rascunho);
    }

    /**
     * @param array<string, mixed> $dados
     * @return array<string, mixed>
     */
    public function marcarEnviado(string $id, string $tipo, string $usuarioId, array $dados): array
    {
        $rascunho = $this->rascunhoDoUsuario($id, $tipo, $usuarioId);
        $agora = $this->agora();

        $rascunho['status'] = self::STATUS_ENVIADO;
        $rascunho['dados'] = $dados;
        $rascunho['atualizado_em'] = $agora;
        $rascunho['enviado_em'] = $agora;

        return $this->repository->salvar($rascunho);
    }

    public function removerExpirados(): int
    {
        $limite = (new DateTimeImmutable())->sub(new DateInterval('P' . $this->ttlDias . 'D'));

        return $this->repository->removerExpirados($limite);
    }

    /**
     * @return array<string, mixed>
     */
    private function rascunhoDoUsuario(string $id, string $tipo, string $usuarioId): array
    {
        $rascunho = $this->repository->buscarPorId($id);

        if ($rascunho === null) {
            throw new RuntimeException('Rascunho nao encontrado.');
        }

        if (($rascunho['tipo'] ?? '') !== $tipo || ($rascunho['usuario_id'] ?? '') !== $usuarioId) {
            throw new RuntimeException('Rascunho nao pertence ao usuario autenticado.');
        }

        return $rascunho;
    }

    private function novoId(): string
    {
        return bin2hex(random_bytes(16));
    }

    private function agora(): string
    {
        return (new DateTimeImmutable())->format(DATE_ATOM);
    }
}
