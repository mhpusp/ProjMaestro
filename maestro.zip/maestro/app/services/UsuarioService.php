<?php

declare(strict_types=1);

namespace App\services;

use App\repositories\UsuarioRepository;
use App\repositories\UsuarioFuncoesRepository;
use RuntimeException;

class UsuarioService
{
    public function __construct(
        private readonly UsuarioRepository $repo,
        private readonly UsuarioFuncoesRepository $repoFuncoes
    ) {
    }

    public function listar(int $limit = 100, int $offset = 0): array
    {
        return $this->repo->listar($limit, $offset);
    }

    public function buscar(int $id): array
    {
        $usuario = $this->repo->buscarPorId($id);

        if ($usuario === null) {
            throw new RuntimeException('Usuario nao encontrado');
        }

        $usuario['funcoes'] = $this->repoFuncoes->listarFuncoesDoUsuario($id);

        return $usuario;
    }

    public function autenticar(string $email, string $senha): ?array
    {
        $email = trim($email);
        $senha = (string) $senha;

        if ($email === '' || $senha === '') {
            throw new RuntimeException('Email e senha sao obrigatorios');
        }

        $usuario = $this->repo->buscarPorUsername($email);

        if ($usuario === null) {
            return null;
        }

        $hash = (string) ($usuario['senha'] ?? '');

        if (!password_verify($senha, $hash)) {
            return null;
        }

        $usuario['funcoes'] = $this->repoFuncoes->listarFuncoesDoUsuario((int) $usuario['id']);

        return $usuario;
    }

    public function iniciarSessaoUsuario(int $usuarioId): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['usuario_id'] = $usuarioId;
    }

    public function encerrarSessao(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION = [];
        session_destroy();
    }

    public function criar(array $dados): array
    {
        if (empty($dados['nome']) || empty($dados['email'])) {
            throw new RuntimeException('Nome e email sao obrigatorios');
        }

        $senha = $dados['senha'] ?? bin2hex(random_bytes(4));

        $usuarioId = $this->repo->criar([
            'nome' => $dados['nome'],
            'nusp' => $dados['nusp'] ?? '',
            'email' => $dados['email'],
            'senha' => password_hash($senha, PASSWORD_DEFAULT),
        ]);

        // atribui funcoes iniciais se fornecidas
        $funcoes = $dados['funcoes'] ?? [];

        foreach ($funcoes as $funcaoId) {
            $this->repoFuncoes->atribuir((int) $usuarioId, (int) $funcaoId);
        }

        return $this->buscar((int) $usuarioId);
    }
}
