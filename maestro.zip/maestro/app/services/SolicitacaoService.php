<?php

declare(strict_types=1);

namespace App\services;

use App\repositories\SolicitacaoRepository;
use InvalidArgumentException;
use RuntimeException;

/**
 * Service com regras de negocio do modulo de solicitacoes.
 */
class SolicitacaoService
{
    /** @var array<string, string> */
    private const STATUS_PERMITIDOS = [
        'nova' => 'Nova',
        'em_analise' => 'Em analise',
        'concluida' => 'Concluida',
        'cancelada' => 'Cancelada',
    ];

    public function __construct(private readonly SolicitacaoRepository $repository)
    {
    }

    /**
     * Lista solicitacoes em DTO padronizado para Web e API.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listar(?string $filtro = null): array
    {
        return array_map(
            fn (array $solicitacao): array => $this->normalizar($solicitacao),
            $this->repository->listar($filtro)
        );
    }

    /**
     * Busca uma solicitacao ou falha com mensagem clara.
     *
     * @return array<string, mixed>
     */
    public function buscar(int $id): array
    {
        $solicitacao = $this->repository->buscarPorId($id);

        if ($solicitacao === null) {
            throw new RuntimeException('Solicitacao nao encontrada.');
        }

        return $this->normalizar($solicitacao);
    }

    /**
     * Cria uma nova solicitacao a partir dos dados do formulario.
     *
     * @param array<string, mixed> $dados
     * @return array<string, mixed>
     */
    public function criar(array $dados): array
    {
        $prioridadeInformada = trim((string) ($dados['prioridade'] ?? 'media'));
        $dados = $this->normalizarDadosFormulario($dados);
        $titulo = $dados['titulo'];
        $descricao = $dados['descricao'];
        $solicitante = $dados['solicitante'];
        $prioridade = $dados['prioridade'];

        if ($titulo === '' || $descricao === '' || $solicitante === '') {
            throw new InvalidArgumentException('Informe titulo, descricao e solicitante.');
        }

        if (!in_array($prioridadeInformada, ['baixa', 'media', 'alta'], true)) {
            throw new InvalidArgumentException('Prioridade invalida.');
        }

        return $this->normalizar($this->repository->criar([
            'titulo' => $titulo,
            'descricao' => $descricao,
            'solicitante' => $solicitante,
            'prioridade' => $prioridade,
        ]));
    }

    /**
     * Normaliza dados parciais de formulario para persistencia de rascunho.
     *
     * @param array<string, mixed> $dados
     * @return array<string, string>
     */
    public function normalizarDadosFormulario(array $dados): array
    {
        $prioridade = trim((string) ($dados['prioridade'] ?? 'media'));

        if (!in_array($prioridade, ['baixa', 'media', 'alta'], true)) {
            $prioridade = 'media';
        }

        return [
            'titulo' => trim((string) ($dados['titulo'] ?? '')),
            'descricao' => trim((string) ($dados['descricao'] ?? '')),
            'solicitante' => trim((string) ($dados['solicitante'] ?? '')),
            'prioridade' => $prioridade,
        ];
    }

    /**
     * Altera o status de uma solicitacao.
     *
     * @return array<string, mixed>
     */
    public function alterarStatus(int $id, string $status): array
    {
        if (!array_key_exists($status, self::STATUS_PERMITIDOS)) {
            throw new InvalidArgumentException('Status invalido.');
        }

        $solicitacao = $this->repository->alterarStatus($id, $status);

        if ($solicitacao === null) {
            throw new RuntimeException('Solicitacao nao encontrada.');
        }

        return $this->normalizar($solicitacao);
    }

    /**
     * Exclui uma solicitacao da lista em memoria.
     */
    public function excluir(int $id): void
    {
        if (!$this->repository->excluir($id)) {
            throw new RuntimeException('Solicitacao nao encontrada.');
        }
    }

    /**
     * Retorna os status disponiveis para formularios e APIs.
     *
     * @return array<string, string>
     */
    public function statusDisponiveis(): array
    {
        return self::STATUS_PERMITIDOS;
    }

    /**
     * Prepara metadados para exportacoes futuras em PDF e Excel.
     *
     * @return array<string, mixed>
     */
    public function prepararExportacao(string $formato): array
    {
        return [
            'formato' => $formato,
            'status' => 'pendente',
            'mensagem' => 'Ponto de extensao preparado para geracao futura.',
            'dados' => $this->listar(),
        ];
    }

    /**
     * @param array<string, mixed> $solicitacao
     * @return array<string, mixed>
     */
    private function normalizar(array $solicitacao): array
    {
        $status = (string) $solicitacao['status'];

        return [
            'id' => (int) $solicitacao['id'],
            'titulo' => (string) $solicitacao['titulo'],
            'descricao' => (string) $solicitacao['descricao'],
            'solicitante' => (string) $solicitacao['solicitante'],
            'status' => $status,
            'status_rotulo' => self::STATUS_PERMITIDOS[$status] ?? ucfirst($status),
            'status_tipo' => $this->tipoStatus($status),
            'prioridade' => (string) $solicitacao['prioridade'],
            'criada_em' => (string) $solicitacao['criada_em'],
        ];
    }

    private function tipoStatus(string $status): string
    {
        return match ($status) {
            'concluida' => 'sucesso',
            'cancelada' => 'erro',
            'em_analise' => 'aviso',
            default => 'info',
        };
    }
}
