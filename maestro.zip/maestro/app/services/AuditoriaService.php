<?php

declare(strict_types=1);

namespace App\services;

use App\middlewares\WorkplaceSessionMiddleware;
use App\repositories\AuditoriaRepository;
use App\suporte\SanitizadorContextoErro;
use App\workplace\WorkplaceSession;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Helper para registrar eventos relevantes de auditoria.
 */
class AuditoriaService
{
    public function __construct(
        private readonly AuditoriaRepository $repository,
        private readonly SanitizadorContextoErro $sanitizador
    ) {
    }

    /**
     * Registra um evento de auditoria da requisicao atual.
     *
     * @param array<string, mixed> $contexto Contexto nao sensivel da acao.
     */
    public function registrar(
        ServerRequestInterface $request,
        string $acao,
        string $resultado,
        array $contexto = [],
        ?string $sistema = null
    ): void {
        $workplace = $request->getAttribute(WorkplaceSessionMiddleware::ATRIBUTO);

        if (!$workplace instanceof WorkplaceSession) {
            $workplace = WorkplaceSession::mock();
        }

        $this->repository->registrar([
            'data_hora' => date(DATE_ATOM),
            'usuario_id' => $workplace->usuario->id,
            'usuario_nome' => $workplace->usuario->nome,
            'papel_ativo' => $workplace->papelAtivo->codigo,
            'sistema' => $sistema,
            'acao' => $acao,
            'rota' => (string) $request->getUri()->getPath(),
            'metodo' => $request->getMethod(),
            'resultado' => $resultado,
            'contexto' => $this->sanitizador->sanitizar($contexto),
        ]);
    }
}
