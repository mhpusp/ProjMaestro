<?php

declare(strict_types=1);

namespace App\services;

use App\repositories\AutorizacaoRotaRepository;
use App\workplace\WorkplaceSession;
use InvalidArgumentException;
use RuntimeException;

/**
 * Gerencia o catalogo de rotas e os papeis autorizados para cada uma.
 */
class AutorizacaoRotaService
{
    /** @var array<string, array<string, mixed>> */
    private array $catalogo = [];

    public function __construct(private readonly AutorizacaoRotaRepository $repository)
    {
    }

    /**
     * @param array<int, string> $metodos
     * @param array<int, string> $papeisPadrao
     */
    public function registrarRota(
        string $id,
        array $metodos,
        string $caminho,
        bool $publica = false,
        array $papeisPadrao = [],
        ?string $descricao = null
    ): void {
        $this->catalogo[$id] = [
            'id' => $id,
            'metodos' => array_values($metodos),
            'caminho' => $caminho,
            'publica' => $publica,
            'descricao' => $descricao,
            'papeis_padrao' => $this->normalizarPapeis($papeisPadrao),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listarRotas(): array
    {
        $papeisPersistidos = $this->repository->listarPapeisPorRota();
        $rotas = [];

        foreach ($this->catalogo as $id => $rota) {
            $papeis = $papeisPersistidos[$id] ?? $rota['papeis_padrao'];
            $rotas[] = [
                'id' => $id,
                'metodos' => $rota['metodos'],
                'caminho' => $rota['caminho'],
                'publica' => (bool) $rota['publica'],
                'descricao' => $rota['descricao'],
                'papeis' => (bool) $rota['publica'] ? [] : $papeis,
            ];
        }

        usort($rotas, static fn (array $a, array $b): int => strcmp((string) $a['id'], (string) $b['id']));

        return $rotas;
    }

    /**
     * @return array<string, mixed>
     */
    public function detalheRota(string $id): array
    {
        foreach ($this->listarRotas() as $rota) {
            if ($rota['id'] === $id) {
                return $rota;
            }
        }

        throw new RuntimeException('Rota nao encontrada no catalogo.');
    }

    public function usuarioPodeAcessar(string $rotaId, WorkplaceSession $workplace): bool
    {
        $rota = $this->detalheRota($rotaId);

        if ((bool) $rota['publica']) {
            return true;
        }

        return in_array($workplace->papelAtivo->codigo, (array) $rota['papeis'], true);
    }

    /**
     * @return array<string, mixed>
     */
    public function adicionarPapel(string $rotaId, string $papel): array
    {
        $this->detalheRota($rotaId);
        $this->validarPapel($papel);
        $this->repository->adicionarPapel($rotaId, $papel);

        return $this->detalheRota($rotaId);
    }

    /**
     * @return array<string, mixed>
     */
    public function removerPapel(string $rotaId, string $papel): array
    {
        $this->detalheRota($rotaId);
        $this->validarPapel($papel);
        $this->repository->removerPapel($rotaId, $papel);

        return $this->detalheRota($rotaId);
    }

    private function validarPapel(string $papel): void
    {
        if (!preg_match('/^[a-z0-9_-]+$/', $papel)) {
            throw new InvalidArgumentException('Papel invalido.');
        }
    }

    /**
     * @param array<int, mixed> $papeis
     * @return array<int, string>
     */
    private function normalizarPapeis(array $papeis): array
    {
        $normalizados = array_map(
            static fn (mixed $papel): string => strtolower(trim((string) $papel)),
            $papeis
        );

        return array_values(array_unique(array_filter($normalizados)));
    }
}
