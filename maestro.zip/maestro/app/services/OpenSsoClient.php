<?php

declare(strict_types=1);

namespace App\services;

use App\suporte\LoggerArquivo;

/**
 * Cliente minimo para validar o cookie institucional no OpenSSO.
 */
class OpenSsoClient
{
    /**
     * @param array<string, mixed> $configuracaoSso
     */
    public function __construct(
        private readonly array $configuracaoSso,
        private readonly LoggerArquivo $logger
    ) {
    }

    /**
     * @return array{codpes: string, codema: string, nompes: string}|null
     */
    public function buscarAtributos(string $subjectId): ?array
    {
        $subjectId = str_replace(' ', '+', trim($subjectId));

        if ($subjectId === '') {
            return null;
        }

        $url = $this->montarUrlAtributos($subjectId);
        $contexto = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => (int) $this->configuracaoSso['timeout'],
                'ignore_errors' => true,
                'header' => "Accept: application/json\r\n",
            ],
        ]);

        $resposta = @file_get_contents($url, false, $contexto);

        if ($resposta === false || $this->statusHttpIndicaErro($http_response_header ?? [])) {
            $this->logger->registrar('warning', 'Falha ao consultar atributos no OpenSSO.', [
                'endpoint' => $this->configuracaoSso['attributes_url'],
            ]);

            return null;
        }

        $dados = json_decode($resposta, true);

        if (!is_array($dados)) {
            $this->logger->registrar('warning', 'Resposta invalida do OpenSSO.', [
                'json_error' => json_last_error_msg(),
            ]);

            return null;
        }

        return $this->normalizarAtributos($dados);
    }

    private function montarUrlAtributos(string $subjectId): string
    {
        $urlBase = rtrim((string) $this->configuracaoSso['attributes_url'], '?&');
        $separador = str_contains($urlBase, '?') ? '&' : '?';

        return $urlBase . $separador . 'subjectid=' . rawurlencode($subjectId);
    }

    /**
     * @param array<int, string> $headers
     */
    private function statusHttpIndicaErro(array $headers): bool
    {
        if ($headers === []) {
            return false;
        }

        if (!preg_match('/\s(?P<status>\d{3})\s/', $headers[0], $matches)) {
            return false;
        }

        return (int) $matches['status'] >= 400;
    }

    /**
     * @param array<string, mixed> $dados
     * @return array{codpes: string, codema: string, nompes: string}|null
     */
    private function normalizarAtributos(array $dados): ?array
    {
        $codpes = trim((string) ($dados['codpes'] ?? ''));
        $codema = trim((string) ($dados['codema'] ?? ''));
        $nompes = trim((string) ($dados['nompes'] ?? ''));

        if ($codpes === '' || $codema === '' || $nompes === '') {
            $this->logger->registrar('warning', 'OpenSSO retornou atributos obrigatorios incompletos.', [
                'tem_codpes' => $codpes !== '',
                'tem_codema' => $codema !== '',
                'tem_nompes' => $nompes !== '',
            ]);

            return null;
        }

        return [
            'codpes' => $codpes,
            'codema' => $codema,
            'nompes' => $nompes,
        ];
    }
}
