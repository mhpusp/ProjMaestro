<?php

declare(strict_types=1);

namespace App\services;

use App\repositories\FuncaoRepository;
use RuntimeException;

class FuncaoService
{
    public function __construct(private readonly FuncaoRepository $repo)
    {
    }

    public function listar(int $limit = 100, int $offset = 0): array
    {
        return $this->repo->listar($limit, $offset);
    }

    public function buscar(int $id): array
    {
        $f = $this->repo->buscarPorId($id);

        if ($f === null) {
            throw new RuntimeException('Funcao nao encontrada');
        }

        return $f;
    }

    public function criar(string $nome, ?string $descricao = null): array
    {
        $id = $this->repo->criar($nome, $descricao);

        return $this->buscar((int) $id);
    }
}
