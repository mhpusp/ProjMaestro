<?php

declare(strict_types=1);

namespace App\workflow\dto;

use JsonSerializable;
use RuntimeException;

/**
 * DTO - Representa a definição de um processo, carregada a partir de um JSON.
 */
class Processo implements JsonSerializable
{
    public string $id;
    public ?string $processo_id = null;
    public string $nome;
    public ?string $descricao = null;
    public ?int $versao = null;
    public ?string $arquivo = null;
    public mixed $dados_form = null;
    public bool $concluido = false;
    public ?string $current_element_id = null;
    public ?string $donoProcesso = null;
    /** @var array<int, string>|null */
    public ?array $listaSubprocessos = null;
    /** @var array<int, string>|null */
    public ?array $raiasParticipantes = null;
    public ?string $criado_por = null;
    public ?string $created_at = null;
    public ?string $updated_at = null;
    /** @var Elemento[] */
    public array $elementos = [];

    public function __construct(array $data)
    {
        if (!isset($data['id']) || !is_string($data['id'])) {
            throw new RuntimeException('Processo: campo "id" é obrigatório e deve ser string');
        }
        $this->id = $data['id'];
        $this->processo_id = isset($data['processo_id'])
            ? (string) $data['processo_id']
            : (isset($data['processo_pai_id']) ? (string) $data['processo_pai_id'] : null);
        $this->nome = isset($data['nome']) ? (string) $data['nome'] : '';
        $this->descricao = isset($data['descricao']) ? (string) $data['descricao'] : null;
        $this->versao = isset($data['versao']) ? (int) $data['versao'] : null;
        $this->arquivo = isset($data['arquivo']) ? (string) $data['arquivo'] : null;
        $this->dados_form = $data['dados_form'] ?? null;
        $this->concluido = isset($data['concluido']) ? (bool) $data['concluido'] : (isset($data['status']) ? (bool) $data['status'] : false);
        $this->current_element_id = isset($data['current_element_id']) ? (string) $data['current_element_id'] : null;
        $this->donoProcesso = isset($data['dono_processo']) ? (string) $data['dono_processo'] : null;
        $this->listaSubprocessos = isset($data['lista_subprocessos']) && is_array($data['lista_subprocessos'])
            ? array_values(array_map('strval', $data['lista_subprocessos']))
            : null;
        $this->raiasParticipantes = isset($data['raias_participantes']) && is_array($data['raias_participantes'])
            ? array_values(array_map('strval', $data['raias_participantes']))
            : null;
        $this->criado_por = isset($data['criado_por']) ? (string) $data['criado_por'] : null;
        $this->created_at = isset($data['created_at']) ? (string) $data['created_at'] : null;
        $this->updated_at = isset($data['updated_at']) ? (string) $data['updated_at'] : null;

        $this->elementos = [];
        if (isset($data['elementos']) && is_array($data['elementos'])) {
            foreach ($data['elementos'] as $el) {
                if (is_array($el)) {
                    $this->elementos[] = Elemento::fromArray($el);
                }
            }
        }
    }

    public static function fromArray(array $data): self
    {
        return new self($data);
    }

    public static function fromJson(string $json): self
    {
        $data = json_decode($json, true);

        if (!is_array($data)) {
            throw new RuntimeException('JSON inválido para Processo');
        }

        return new self($data);
    }

    public function jsonSerialize(): array
    {
        return [
            'id' => $this->id,
            'processo_id' => $this->processo_id,
            'nome' => $this->nome,
            'descricao' => $this->descricao,
            'versao' => $this->versao,
            'arquivo' => $this->arquivo,
            'dados_form' => $this->dados_form,
            'status' => $this->concluido,
            'current_element_id' => $this->current_element_id,
            'dono_processo' => $this->donoProcesso,
            'lista_subprocessos' => $this->listaSubprocessos,
            'raias_participantes' => $this->raiasParticipantes,
            'criado_por' => $this->criado_por,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'elementos' => array_map(fn(Elemento $e) => $e->jsonSerialize(), $this->elementos),
        ];
    }

    public function toArray(): array
    {
        return $this->jsonSerialize();
    }
}
