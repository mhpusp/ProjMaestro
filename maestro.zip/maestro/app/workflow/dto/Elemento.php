<?php

declare(strict_types=1);

namespace App\workflow\dto;

use JsonSerializable;
use RuntimeException;

/**
 * DTO - Representa um elemento (nó) de um processo de workflow.
 */
class Elemento implements JsonSerializable
{
    public string $id;
    public string $tipo;
    public ?string $nome_raia = null;
    /** @var string|array<int, string>|null */
    public string|array|null $participante = null;
    public ?string $nome = null;
    public ?string $descricao = null;
    public ?string $arquivo = null;
    public ?string $pergunta = null;
    /** @var array<string,string>|null Respostas do elemento */
    public ?array $respostas = null;
    /** @var array<string,string>|null Eventos disparados pelo elemento */
    public ?array $evento = null;
    /** @var array<string,string>|null Quem pode voltar (map true/false -> papel/usuario) */
    public ?array $volta = null;
    /** @var array<string,string>|null Quem pode editar ao voltar */
    public ?array $libera = null;
    public bool $concluida = false;
    public ?string $criado_por = null;
    public ?string $created_at = null;
    public ?string $updated_at = null;
    public ?string $origem = null;
    public ?string $destino = null;

    public function __construct(array $data)
    {
        if (!isset($data['id']) || !is_string($data['id'])) {
            throw new RuntimeException('Elemento: campo "id" é obrigatório e deve ser string');
        }

        $this->id = $data['id'];
        $this->tipo = (string) ($data['tipo'] ?? 'atividade');
        $this->nome_raia = isset($data['nome_raia']) ? (string) $data['nome_raia'] : null;
        $this->participante = is_array($data['participante'] ?? null)
            ? array_values(array_map(
                static fn (mixed $participante): string => (string) $participante,
                $data['participante']
            ))
            : (isset($data['participante']) ? (string) $data['participante'] : null);
        $this->nome = isset($data['nome']) ? (string) $data['nome'] : null;
        $this->descricao = isset($data['descricao']) ? (string) $data['descricao'] : null;
        $this->arquivo = isset($data['arquivo']) ? (string) $data['arquivo'] : null;
        $this->pergunta = isset($data['pergunta']) ? (string) $data['pergunta'] : null;
        $this->respostas = isset($data['respostas']) && is_array($data['respostas']) ? $data['respostas'] : null;
        $this->evento = isset($data['evento']) && is_array($data['evento']) ? $data['evento'] : null;
        $this->volta = isset($data['volta']) && is_array($data['volta']) ? $data['volta'] : null;
        $this->libera = isset($data['libera']) && is_array($data['libera']) ? $data['libera'] : null;
        $this->concluida = isset($data['status']) ? (bool) $data['status'] : false;
        $this->criado_por = isset($data['criado_por']) ? (string) $data['criado_por'] : null;
        $this->created_at = isset($data['created_at']) ? (string) $data['created_at'] : null;
        $this->updated_at = isset($data['updated_at']) ? (string) $data['updated_at'] : null;
        $this->origem = isset($data['origem']) ? (string) $data['origem'] : null;
        $this->destino = isset($data['destino']) ? (string) $data['destino'] : null;
    }

    public static function fromArray(array $data): self
    {
        return new self($data);
    }

    public function jsonSerialize(): array
    {
        return [
            'id' => $this->id,
            'tipo' => $this->tipo,
            'nome_raia' => $this->nome_raia,
            'participante' => $this->participante,
            'nome' => $this->nome,
            'descricao' => $this->descricao,
            'arquivo' => $this->arquivo,
            'pergunta' => $this->pergunta,
            'respostas' => $this->respostas,
            'evento' => $this->evento,
            'volta' => $this->volta,
            'libera' => $this->libera,
            'status' => $this->concluida,
            'criado_por' => $this->criado_por,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'origem' => $this->origem,
            'destino' => $this->destino,
        ];
    }
}
