<?php

declare(strict_types=1);

namespace App\workflow\controllers;

use App\workflow\contracts\WorkflowRouterInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use RuntimeException;

class WorkflowRouterController
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly WorkflowRouterInterface $workflowRouter
    ) {
    }

    /** @param array<string, string> $args */
    public function despachar(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $instanciaId = filter_var($args['id'] ?? null, FILTER_VALIDATE_INT);
        if ($instanciaId === false || $instanciaId < 1) {
            throw new RuntimeException('Identificador de instância inválido.');
        }

        if (strtoupper($request->getMethod()) === 'POST') {
            $body = $request->getParsedBody();
            if (!is_array($body)) {
                throw new RuntimeException('Os dados enviados para o workflow são inválidos.');
            }

            $elementoId = $body['elemento_id'] ?? null;
            $acao = $body['acao'] ?? null;
            if ($acao === 'fechar') {
                if (!is_string($elementoId) || $elementoId === '') {
                    throw new RuntimeException('O elemento atual do workflow não foi informado.');
                }
                $usuarioId = filter_var($request->getAttribute('usuario_id'), FILTER_VALIDATE_INT);
                if ($usuarioId === false || $usuarioId < 1) {
                    throw new RuntimeException('Não foi possível identificar o usuário para criar a tarefa de retomada.');
                }
                $this->workflowRouter->fechar($instanciaId, $elementoId, $usuarioId);

                return $response
                    ->withStatus(303)
                    ->withHeader('Location', $this->urlInicio());
            }
            if (!is_string($elementoId) || !is_string($acao)) {
                throw new RuntimeException('A ação do workflow ou o elemento atual não foi informado.');
            }

            if ($acao === 'avancar') {
                $dadosForm = $body['dados_form'] ?? [];
                if (!is_array($dadosForm)) {
                    throw new RuntimeException('Os dados do formulário do elemento devem ser enviados como campos.');
                }
                $estado = $this->workflowRouter->avancar(
                    $instanciaId,
                    $elementoId,
                    $dadosForm,
                    $request->getUploadedFiles(),
                    [
                        'usuario_logado' => $request->getAttribute('usuario'),
                        'usuario_id' => $request->getAttribute('usuario_id'),
                    ]
                );
                if (($estado['confirmacaoSubstituicao'] ?? false) === true) {
                    $metadadosUpload = $estado['metadadosUpload'] ?? null;
                    $estado = $this->workflowRouter->carregarInstancia($instanciaId, $elementoId);
                    $estado['confirmacaoSubstituicao'] = true;
                    $estado['metadadosUpload'] = $metadadosUpload;
                    $estado['mensagemEvento'] = 'Já existe um pacote de arquivos com este identificador. '
                        . 'Escolha manter os arquivos existentes ou substituí-los.';

                    return $this->exibir($request, $response, $estado);
                }
                if (($estado['concluida'] ?? false) === true) {
                    return $response
                        ->withStatus(303)
                        ->withHeader('Location', $this->urlInicio());
                }
            } elseif ($acao === 'voltar') {
                $estado = $this->workflowRouter->voltar($instanciaId, $elementoId);
            } else {
                throw new RuntimeException('Ação de navegação desconhecida.');
            }

            $url = $this->urlInstancia($instanciaId)
                . '?elemento=' . rawurlencode((string) $estado['elementoId']);

            return $response
                ->withStatus(303)
                ->withHeader('Location', $url);
        }

        $query = $request->getQueryParams();
        $elementoId = $query['elemento'] ?? null;
        if ($elementoId !== null && !is_string($elementoId)) {
            throw new RuntimeException('Identificador de elemento inválido.');
        }

        return $this->exibir(
            $request,
            $response,
            $this->workflowRouter->carregarInstancia($instanciaId, $elementoId)
        );
    }

    /** @param array<string, string> $args */
    public function despacharInstanciacao(
        ServerRequestInterface $request,
        ResponseInterface $response,
        array $args
    ): ResponseInterface {
        $processoId = $args['id'] ?? '';
        if ($processoId === '') {
            throw new RuntimeException('Identificador do processo inválido.');
        }

        if (strtoupper($request->getMethod()) !== 'POST') {
            return $this->exibir(
                $request,
                $response,
                $this->workflowRouter->prepararInstanciacao($processoId)
            );
        }

        $body = $request->getParsedBody();
        if (!is_array($body)) {
            throw new RuntimeException('Os dados enviados para a instanciação são inválidos.');
        }

        $acao = $body['acao'] ?? null;
        if ($acao !== 'iniciar') {
            throw new RuntimeException('Ação de instanciação desconhecida.');
        }
        $dadosForm = $body['dados_form'] ?? [];
        if (!is_array($dadosForm)) {
            throw new RuntimeException('A resposta do nó inicial é inválida.');
        }

        if (($dadosForm['resposta'] ?? null) === 'Não') {
            $this->workflowRouter->cancelarInstanciacao();

            return $response
                ->withStatus(303)
                ->withHeader('Location', $this->urlInicio());
        }

        if (($dadosForm['resposta'] ?? null) !== 'Sim') {
            throw new RuntimeException('Selecione Sim ou Não para iniciar o processo.');
        }

        $usuarioId = $request->getAttribute('usuario_id');
        $estado = $this->workflowRouter->iniciarProcesso(
            $processoId,
            is_scalar($usuarioId) ? (string) $usuarioId : '',
            $dadosForm
        );

        $url = $this->urlInstancia((int) $estado['instancia']['id'])
            . '?elemento=' . rawurlencode((string) $estado['elementoId']);

        return $response
            ->withStatus(303)
            ->withHeader('Location', $url);
    }

    /** @param array<string, mixed> $estado */
    private function exibir(
        ServerRequestInterface $request,
        ResponseInterface $response,
        array $estado
    ): ResponseInterface {
        $layout = [
            'nomeSistema' => $this->configuracao['app']['nome'],
            'workplaceSession' => $request->getAttribute('workplace'),
            'versao' => $this->dependencias['versao_codigo']->assinatura(),
            'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
            'basePath' => $this->configuracao['app']['base_path'],
        ];
        $estado['urlAcao'] = !empty($estado['modoInstanciacao'])
            ? $this->urlInstanciacao((string) $estado['processo']['processo_id'])
            : $this->urlInstancia((int) $estado['instancia']['id']);
        ob_start();
        require dirname(__DIR__) . '/views/workflowrouter.php';
        $conteudoView = (string) ob_get_clean();

        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => (string) ($estado['noAtual']['nome'] ?? 'Workflow'),
            'view' => 'workflowrouter.php',
            'conteudoView' => $conteudoView,
            'layout' => $layout,
            'dados' => [],
        ]);
        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    private function urlInstancia(int $instanciaId): string
    {
        return rtrim((string) $this->configuracao['app']['base_path'], '/')
            . '/workflow/instancias/' . $instanciaId;
    }

    private function urlInicio(): string
    {
        $basePath = rtrim((string) $this->configuracao['app']['base_path'], '/');

        return $basePath !== '' ? $basePath . '/' : '/';
    }

    private function urlInstanciacao(string $processoId): string
    {
        return rtrim((string) $this->configuracao['app']['base_path'], '/')
            . '/workflow/processos/' . rawurlencode($processoId) . '/instanciar';
    }
}
