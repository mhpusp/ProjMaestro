<?php

declare(strict_types=1);

namespace App\workflow\controllers;

use App\workflow\contracts\WorkflowHistInterface;
use App\workflow\contracts\WorkflowMetaInterface;
use App\workflow\contracts\WorkflowNotesInterface;
use App\workplace\UsuarioLogado;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class WorkflowHub
{
    public function __construct(
        private readonly array $configuracao,
        private readonly array $dependencias,
        private readonly WorkflowHistInterface $workflowHist,
        private readonly WorkflowMetaInterface $workflowMeta,
        private readonly WorkflowNotesInterface $workflowNotes
    ) {
    }

    public function inicio(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $usuario = $request->getAttribute('usuario');
        $email = $usuario instanceof UsuarioLogado ? $usuario->email : '';

        $layout = [
            'nomeSistema' => $this->configuracao['app']['nome'],
            'workplaceSession' => $request->getAttribute('workplace'),
            'versao' => $this->dependencias['versao_codigo']->assinatura(),
            'versaoCodigo' => $this->dependencias['versao_codigo']->resumo(),
            'basePath' => $this->configuracao['app']['base_path'],
        ];
        $dados = [
            'ambiente' => $this->configuracao['app']['ambiente'],
            'instancias' => $this->workflowHist->listarInstancias(),
            'processos' => $this->workflowMeta->listarParaInstanciar(),
            'agenda' => $this->workflowNotes->listarAgenda($email),
        ];

        ob_start();
        require dirname(__DIR__) . '/views/workflowhub.php';
        $conteudoView = (string) ob_get_clean();

        $html = $this->dependencias['template']->renderizar('base.php', [
            'titulo' => 'Maestro Workflow',
            'view' => 'workflowhub.php',
            'conteudoView' => $conteudoView,
            'layout' => $layout,
            'dados' => [],
        ]);

        $response->getBody()->write($html);

        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }
}