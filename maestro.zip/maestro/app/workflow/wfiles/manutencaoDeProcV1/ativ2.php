<?php

require __DIR__ . '/formulario_padrao.php';
