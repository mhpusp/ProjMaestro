<?php

declare(strict_types=1);

$metadados = is_array($estado['metadadosUpload'] ?? null) ? $estado['metadadosUpload'] : null;
$jsonMetadados = $metadados === null
    ? ''
    : (string) json_encode($metadados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$arquivos = [];
if ($metadados !== null) {
    $arquivoPrincipal = (string) ($metadados['arquivo'] ?? '');
    $subprocessos = $metadados['subprocessos']
        ?? $metadados['lista_subprocessos']
        ?? $metadados['lista_processos']
        ?? [];
    $arquivos = array_values(array_filter(
        array_merge([$arquivoPrincipal], is_array($subprocessos) ? $subprocessos : []),
        static fn (mixed $arquivo): bool => is_string($arquivo) && trim($arquivo) !== ''
    ));
}
?>
<?php if (!empty($estado['mensagemEvento'])): ?>
    <div class="alert alert-warning" role="alert">
        <?= htmlspecialchars((string) $estado['mensagemEvento'], ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>
<?php if ($metadados !== null): ?>
    <input type="hidden" name="dados_form[arquivo_principal]" value="<?= htmlspecialchars((string) ($metadados['arquivo'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
    <input type="hidden" name="dados_form[metadados_descritor]" value="<?= htmlspecialchars($jsonMetadados, ENT_QUOTES, 'UTF-8') ?>">
    <h3 class="h5">Dados do processo</h3>
    <dl class="row" id="dados-descritor">
        <?php foreach ([
            'Nome' => $metadados['nome'] ?? '',
            'Descrição' => $metadados['descricao'] ?? '',
            'Versão' => $metadados['versao'] ?? '',
            'Identificador informado' => $metadados['id'] ?? '',
            'Responsável' => $metadados['dono_processo'] ?? '',
            'Arquivo principal' => $metadados['arquivo'] ?? '',
            'Subprocessos' => implode(', ', array_map('strval', is_array($subprocessos ?? null) ? $subprocessos : [])),
        ] as $rotulo => $valor): ?>
            <dt class="col-sm-3"><?= htmlspecialchars($rotulo, ENT_QUOTES, 'UTF-8') ?></dt>
            <dd class="col-sm-9"><?= htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8') ?></dd>
        <?php endforeach; ?>
    </dl>

    <h3 class="h5 mt-4">Arquivos JSON do processo</h3>
    <p>O identificador da pasta de destino será gerado pelo WorkflowMeta.</p>
<?php endif; ?>
<?php if (!empty($estado['confirmacaoSubstituicao'])): ?>
    <fieldset class="mb-3">
        <legend class="form-label">Como deseja proceder?</legend>
        <label class="form-check mb-2">
            <input
                class="form-check-input"
                type="radio"
                name="dados_form[decisao_arquivos]"
                value="manter"
                required
            >
            <span class="form-check-label">Manter os arquivos existentes e cadastrar o processo.</span>
        </label>
        <label class="form-check mb-2">
            <input
                class="form-check-input"
                type="radio"
                name="dados_form[decisao_arquivos]"
                value="substituir"
                required
            >
            <span class="form-check-label">Substituir os arquivos existentes pelos arquivos selecionados abaixo.</span>
        </label>
    </fieldset>
    <div id="arquivos-pacote">
        <?php foreach ($arquivos as $arquivo): ?>
            <div class="mb-3">
                <label class="form-label" for="arquivo-<?= htmlspecialchars($arquivo, ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($arquivo, ENT_QUOTES, 'UTF-8') ?>
                </label>
                <input
                    class="form-control arquivo-pacote"
                    id="arquivo-<?= htmlspecialchars($arquivo, ENT_QUOTES, 'UTF-8') ?>"
                    type="file"
                    name="arquivos[<?= htmlspecialchars($arquivo, ENT_QUOTES, 'UTF-8') ?>]"
                    accept=".json,application/json"
                >
            </div>
        <?php endforeach; ?>
    </div>
    <script>
        (() => {
            const getSubmitButton = () => document.getElementById('avancar-workflow');
            const choices = document.querySelectorAll('input[name="dados_form[decisao_arquivos]"]');
            const files = [...document.querySelectorAll('.arquivo-pacote')];

            const updateConfirmationState = () => {
                const submitButton = getSubmitButton();
                if (!submitButton) {
                    return;
                }
                const replacing = document.querySelector('input[name="dados_form[decisao_arquivos]"]:checked')?.value === 'substituir';
                files.forEach((input) => {
                    input.required = replacing;
                });
                submitButton.disabled = !document.querySelector('input[name="dados_form[decisao_arquivos]"]:checked')
                    || (replacing && files.some((input) => input.files.length === 0));
            };

            choices.forEach((choice) => choice.addEventListener('change', updateConfirmationState));
            files.forEach((input) => input.addEventListener('change', updateConfirmationState));
            updateConfirmationState();
        })();
    </script>
<?php elseif ($metadados === null): ?>
    <div class="mb-3">
        <label class="form-label" for="arquivo-descritor">Arquivo JSON principal do processo</label>
        <input
            class="form-control"
            id="arquivo-descritor"
            type="file"
            accept=".json,application/json"
            required
        >
        <div class="form-text">Selecione o JSON do processo para visualizar seus dados antes do cadastro.</div>
    </div>
    <div id="erro-descritor" class="alert alert-danger d-none" role="alert"></div>
    <section id="previa-descritor" class="d-none" aria-live="polite">
        <h3 class="h5">Dados do processo</h3>
        <dl class="row" id="dados-descritor"></dl>
        <h3 class="h5 mt-4">Arquivos JSON do processo</h3>
        <p>Verifique abaixo se todos os arquivos JSON foram apontados.</p>
        <div id="arquivos-pacote"></div>
    </section>
    <input type="hidden" name="dados_form[arquivo_principal]" id="arquivo-principal" value="">
    <script>
        (() => {
            const fileInput = document.getElementById('arquivo-descritor');
            const preview = document.getElementById('previa-descritor');
            const details = document.getElementById('dados-descritor');
            const packageFiles = document.getElementById('arquivos-pacote');
            const error = document.getElementById('erro-descritor');
            const mainFileField = document.getElementById('arquivo-principal');
            const pickerContainer = fileInput.parentElement;
            const getSubmitButton = () => document.getElementById('avancar-workflow');

            const isJsonFilename = (filename) =>
                typeof filename === 'string'
                && filename.trim() === filename
                && /\.json$/i.test(filename)
                && !/[\/\\[\]\u0000-\u001f]/.test(filename);

            const showError = (message) => {
                error.textContent = message;
                error.classList.remove('d-none');
                preview.classList.add('d-none');
                mainFileField.value = '';
                packageFiles.replaceChildren();
                pickerContainer.append(fileInput);
                fileInput.removeAttribute('name');
                const submitButton = getSubmitButton();
                if (submitButton) {
                    submitButton.disabled = true;
                }
            };

            const addDetail = (label, value) => {
                const term = document.createElement('dt');
                term.className = 'col-sm-3';
                term.textContent = label;
                const description = document.createElement('dd');
                description.className = 'col-sm-9';
                description.textContent = value == null ? '' : String(value);
                details.append(term, description);
            };

            const addFileField = (filename, isMain = false) => {
                const wrapper = document.createElement('div');
                wrapper.className = 'mb-3';
                const label = document.createElement('label');
                label.className = 'form-label';
                label.htmlFor = `arquivo-pacote-${filename}`;
                label.textContent = filename;
                const input = isMain ? fileInput : document.createElement('input');
                input.className = 'form-control arquivo-pacote';
                input.id = `arquivo-pacote-${filename}`;
                input.type = 'file';
                input.accept = '.json,application/json';
                input.name = `arquivos[${filename}]`;
                input.required = true;
                if (!isMain) {
                    input.addEventListener('change', updateSubmitState);
                }
                wrapper.append(label, input);
                packageFiles.append(wrapper);
            };

            function updateSubmitState() {
                const submitButton = getSubmitButton();
                if (!submitButton) {
                    return;
                }
                submitButton.disabled = [...packageFiles.querySelectorAll('input[type="file"]')]
                    .some((input) => input.files.length === 0);
            }

            fileInput.addEventListener('change', async () => {
                const file = fileInput.files[0];
                if (!file) {
                    showError('Selecione o arquivo JSON principal do processo.');
                    return;
                }

                try {
                    const metadata = JSON.parse(await file.text());
                    if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) {
                        throw new Error('O arquivo deve conter um objeto JSON.');
                    }
                    if (typeof metadata.nome !== 'string' || metadata.nome.trim() === '') {
                        throw new Error('O descritor não informa um nome válido.');
                    }
                    if (!isJsonFilename(metadata.arquivo)) {
                        throw new Error('O campo arquivo deve informar o nome JSON principal.');
                    }
                    const subprocesses = metadata.subprocessos
                        ?? metadata.lista_subprocessos
                        ?? metadata.lista_processos
                        ?? [];
                    if (!Array.isArray(subprocesses) || subprocesses.some((name) => !isJsonFilename(name))) {
                        throw new Error('A lista de subprocessos deve conter nomes de arquivos JSON válidos.');
                    }
                    const filenames = [metadata.arquivo, ...subprocesses];
                    if (new Set(filenames).size !== filenames.length) {
                        throw new Error('O descritor repete o nome de um arquivo JSON.');
                    }

                    details.replaceChildren();
                    packageFiles.replaceChildren();
                    [
                        ['Nome', metadata.nome],
                        ['Descrição', metadata.descricao],
                        ['Versão', metadata.versao],
                        ['Identificador informado', metadata.id],
                        ['Responsável', metadata.dono_processo],
                        ['Arquivo principal', metadata.arquivo],
                        ['Subprocessos', subprocesses.join(', ')],
                    ].forEach(([label, value]) => addDetail(label, value));

                    fileInput.removeAttribute('name');
                    addFileField(metadata.arquivo, true);
                    subprocesses.forEach((filename) => addFileField(filename));
                    mainFileField.value = metadata.arquivo;
                    error.classList.add('d-none');
                    preview.classList.remove('d-none');
                    updateSubmitState();
                } catch (exception) {
                    showError(exception instanceof Error ? exception.message : 'Não foi possível ler o descritor JSON.');
                }
            });
        })();
    </script>
<?php endif; ?>
