<?php

declare(strict_types=1);

$pergunta = (string) ($noAtual['pergunta'] ?? '');
$respostas = is_array($noAtual['respostas'] ?? null) ? $noAtual['respostas'] : [];
$resultadoAnterior = $estado['dadosFormAnterior']['resultado_eventos']['uploadArquivos'] ?? null;
?>
<?php if (is_array($resultadoAnterior) && is_string($resultadoAnterior['id'] ?? null)): ?>
    <div class="alert alert-success" role="status">
        Upload e cadastro do processo
        <?= htmlspecialchars((string) ($resultadoAnterior['nome'] ?? ''), ENT_QUOTES, 'UTF-8') ?>
        concluídos com sucesso.
    </div>
<?php endif; ?>
<?php if ($pergunta !== ''): ?>
    <p><?= htmlspecialchars($pergunta, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($respostas !== []): ?>
    <fieldset class="mb-3">
        <legend class="form-label">Resposta</legend>
        <?php foreach ($respostas as $resposta => $_destino): ?>
            <label class="form-check mb-2">
                <input
                    class="form-check-input"
                    type="radio"
                    name="dados_form[resposta]"
                    value="<?= htmlspecialchars((string) $resposta, ENT_QUOTES, 'UTF-8') ?>"
                    <?= (string) ($dadosForm['resposta'] ?? '') === (string) $resposta ? 'checked' : '' ?>
                    required
                >
                <span class="form-check-label"><?= htmlspecialchars((string) $resposta, ENT_QUOTES, 'UTF-8') ?></span>
            </label>
        <?php endforeach; ?>
    </fieldset>
<?php endif; ?>
