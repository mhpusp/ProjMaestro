<?php

declare(strict_types=1);

$valor = (string) ($dadosForm['valor'] ?? '');
$rotulo = trim((string) ($noAtual['pergunta'] ?? ''));
if ($rotulo === '') {
    $rotulo = (string) ($noAtual['nome'] ?? 'Informações');
}
?>
<label class="form-label" for="valor"><?= htmlspecialchars($rotulo, ENT_QUOTES, 'UTF-8') ?></label>
<textarea class="form-control" id="valor" name="dados_form[valor]" rows="4"><?= htmlspecialchars($valor, ENT_QUOTES, 'UTF-8') ?></textarea>
