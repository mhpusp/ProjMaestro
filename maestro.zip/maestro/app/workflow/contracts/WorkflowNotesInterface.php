<?php

declare(strict_types=1);

namespace App\workflow\contracts;

interface WorkflowNotesInterface
{
	/** @return array<int, array<string, mixed>> */
	public function listarAgenda(string $email): array;

	public function criarTarefaRetomada(
		int $usuarioId,
		int $instanciaId,
		string $processoId,
		string $nomeProcesso,
		string $nomeNo
	): int;

	public function notificarNovoProcesso(string $processoId, string $nomeProcesso): int;

	public function notificarAdministradores(
		string $tipo,
		string $assunto,
		string $cor,
		?string $processoId,
		?int $instanciaId
	): int;

	public function corDoTipo(string $tipo): string;
}
