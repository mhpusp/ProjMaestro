<?php

declare(strict_types=1);

namespace App\workflow\contracts;

use App\workflow\dto\Processo;
use Psr\Http\Message\UploadedFileInterface;

interface WorkflowMetaInterface
{
    /** @return array<int, array<string, mixed>> */
    public function listarParaInstanciar(): array;

    /** @return array<string, mixed>|null */
    public function obterParaInstanciar(string $processoId): ?array;

    /** @return Processo[] */
    public function listar(int $limit = 100, int $offset = 0): array;

    public function criarNovo(array $dados, UploadedFileInterface $arquivoJson): Processo;

    /** @return Processo[] */
    public function pesquisar(string $nome): array;

    public function atualizar(string $processoId, array $dados, UploadedFileInterface $arquivoJson): Processo;

    public function gerarId(string $nome, int $versao): string;

    /** @return array<string, mixed> */
    public function lerDescritorUpload(array $arquivosEnviados, string $arquivoPrincipal): array;

    public function pacoteExistente(array $metadados): bool;

    public function incluirPacote(array $metadados, array $arquivosEnviados, bool $substituir): Processo;

    public function incluirPacoteExistente(array $metadados): Processo;
}
