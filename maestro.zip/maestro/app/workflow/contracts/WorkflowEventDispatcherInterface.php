<?php

declare(strict_types=1);

namespace App\workflow\contracts;

/**
 * Interface WorkflowEventDispatcherInterface
 * 
 * Contrato para o orquestrador e barramento de eventos do motor de workflow.
 * Responsável por gerenciar o registro de estratégias (handlers) e despachar
 * a execução de eventos a partir de assinaturas textuais lidas dos nós.
 */
interface WorkflowEventDispatcherInterface
{
    /**
     * Registra uma estratégia de manipulador de evento no Dispatcher.
     * 
     * @param WorkflowEventHandlerInterface $handler Instância da estratégia a ser registrada.
     * @return void
     */
    public function registerHandler(WorkflowEventHandlerInterface $handler): void;

    /**
     * Interpreta a assinatura de texto do evento (ex: "notificar('TAREFA')", "persistir_dados('App\Repositories\VeiculoRepository')")
     * e dispara a execução da Strategy correspondente.
     * 
     * @param string $eventSignature Assinatura no nó JSON. Argumentos aceitam literais,
     *                                concatenação com + e referências como $NoDescritor.nome.
     * @param array $context Contexto da execução do evento.
     * @return mixed Resultado do manipulador executado.
     */
    public function dispatch(string $eventSignature, array $context): mixed;
}