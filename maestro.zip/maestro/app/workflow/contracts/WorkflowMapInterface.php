<?php

declare(strict_types=1);

namespace App\workflow\contracts;

interface WorkflowMapInterface
{
	/**
	 * @param array<string, mixed> $instancia
	 * @return array<string, array<string, mixed>>
	 */
	public function carregarMapForward(array $instancia): array;

	/**
	 * @param array<string, mixed> $instancia
	 * @return array<string, mixed>
	 */
	public function carregarDefinicao(array $instancia): array;

	/**
	 * @param array<string, mixed> $instancia
	 * @param array<string, mixed> $elemento
	 */
	public function resolverArquivoNo(array $instancia, array $elemento): ?string;
}