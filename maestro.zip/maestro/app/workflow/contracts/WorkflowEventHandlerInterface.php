<?php

declare(strict_types=1);

namespace App\workflow\contracts;

interface WorkflowEventHandlerInterface
{
    /**
     * Retorna o nome do evento mapeado na string do JSON (ex: "enviar_email", "notificar", "faturamento")
     */
    public function getKey(): string;

    /**
     * Executa a regra de negócio do evento
     * 
     * @param array $params Parâmetros extraídos da assinatura no JSON
     * @param array $context Contexto da execução (instância_id, no_ativo, dados_form, usuario_logado)
     * @return mixed Resultado da execução do evento.
     */
    public function handle(array $params, array $context): mixed;
}