<?php

declare(strict_types=1);

namespace App\workflow\contracts;

interface WorkflowHistInterface
{
	/** @return array<int, array<string, mixed>> */
	public function listarInstancias(): array;

	/** @return array<string, mixed>|null */
	public function obterInstancia(int $instanciaId): ?array;

	/** @return array<int, array<string, mixed>> */
	public function listarElementos(int $instanciaId): array;

	/** @param array<string, mixed> $elemento
	 *  @param array<string, mixed> $dadosForm
	 */
	public function consolidarElemento(int $instanciaId, array $elemento, array $dadosForm): void;

	public function concluirInstancia(int $instanciaId): void;

	/** @param array<string, mixed> $noInicial
	 *  @param array<string, mixed> $dadosForm
	 */
	public function instanciarProcesso(
		string $processoId,
		string $criadoPor,
		array $noInicial,
		array $dadosForm
	): int;
}
