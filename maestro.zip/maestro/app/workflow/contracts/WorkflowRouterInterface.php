<?php

declare(strict_types=1);

namespace App\workflow\contracts;

interface WorkflowRouterInterface
{
	/** @return array<string, mixed> */
	public function carregarInstancia(int $instanciaId, ?string $elementoId = null): array;

	/** @return array<string, mixed> */
	public function prepararInstanciacao(string $processoId): array;

	public function cancelarInstanciacao(): void;

	/** @param array<string, mixed> $dadosForm
	 *  @return array<string, mixed>
	 */
	public function iniciarProcesso(string $processoId, string $criadoPor, array $dadosForm): array;

	/** @param array<string, mixed> $dadosForm
	 *  @return array<string, mixed>
	 */
	public function avancar(
		int $instanciaId,
		string $elementoId,
		array $dadosForm,
		array $arquivosEnviados = [],
		array $contextoEvento = []
	): array;

	/** @return array<string, mixed> */
	public function voltar(int $instanciaId, string $elementoId): array;

	public function fechar(int $instanciaId, string $elementoId, int $usuarioId): int;
}