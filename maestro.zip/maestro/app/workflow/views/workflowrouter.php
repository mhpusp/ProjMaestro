<?php

declare(strict_types=1);

$noAtual = $estado['noAtual'];
$dadosForm = $estado['dadosForm'];
$instancia = $estado['instancia'];
$elementoId = (string) $estado['elementoId'];
$urlAcao = (string) $estado['urlAcao'];
$pergunta = (string) ($noAtual['pergunta'] ?? '');
$respostas = is_array($noAtual['respostas'] ?? null) ? $noAtual['respostas'] : [];
?>
<section class="card poli-card">
    <div class="card-body">
        <div class="d-flex align-items-start justify-content-between gap-3">
            <h2 class="card-title mb-2"><?= htmlspecialchars((string) ($noAtual['nome'] ?? 'Etapa do processo'), ENT_QUOTES, 'UTF-8') ?></h2>
            <?php if (empty($estado['modoInstanciacao'])): ?>
                <form method="post" enctype="multipart/form-data" action="<?= htmlspecialchars($urlAcao, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="acao" value="fechar">
                    <input type="hidden" name="elemento_id" value="<?= htmlspecialchars($elementoId, ENT_QUOTES, 'UTF-8') ?>">
                    <button class="btn btn-outline-secondary btn-sm" type="submit">Fechar</button>
                </form>
            <?php endif; ?>
        </div>
        <?php if (!empty($noAtual['descricao'])): ?>
            <p class="text-secondary mb-4"><?= htmlspecialchars((string) $noAtual['descricao'], ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" action="<?= htmlspecialchars($urlAcao, ENT_QUOTES, 'UTF-8') ?>">
            <?php if (empty($estado['modoInstanciacao'])): ?>
                <input type="hidden" name="elemento_id" value="<?= htmlspecialchars($elementoId, ENT_QUOTES, 'UTF-8') ?>">
            <?php else: ?>
                <input type="hidden" name="acao" value="iniciar">
            <?php endif; ?>

            <?php if (($estado['arquivoNo'] ?? null) !== null): ?>
                <?php require $estado['arquivoNo']; ?>
            <?php elseif ($pergunta !== '' || $respostas !== []): ?>
                <?php if ($pergunta !== ''): ?>
                    <p><?= htmlspecialchars($pergunta, ENT_QUOTES, 'UTF-8') ?></p>
                <?php endif; ?>
                <?php if ($respostas !== []): ?>
                    <fieldset class="mb-3">
                        <legend class="form-label">Resposta</legend>
                        <?php foreach ($respostas as $resposta => $_destino): ?>
                            <label class="form-check mb-2">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="dados_form[resposta]"
                                    value="<?= htmlspecialchars((string) $resposta, ENT_QUOTES, 'UTF-8') ?>"
                                    <?= (string) ($dadosForm['resposta'] ?? '') === (string) $resposta ? 'checked' : '' ?>
                                    required
                                >
                                <span class="form-check-label"><?= htmlspecialchars((string) $resposta, ENT_QUOTES, 'UTF-8') ?></span>
                            </label>
                        <?php endforeach; ?>
                    </fieldset>
                <?php endif; ?>
            <?php endif; ?>

            <div class="d-flex justify-content-between mt-4">
                <button
                    class="btn btn-outline-secondary"
                    type="submit"
                    name="acao"
                    value="voltar"
                    formnovalidate
                    <?= !empty($estado['modoInstanciacao']) || $estado['noAnteriorId'] === null ? 'disabled' : '' ?>
                >
                    Voltar
                </button>
                <button
                    class="btn btn-primary"
                    type="submit"
                    <?= $elementoId === 'ativ1' ? 'id="avancar-workflow"' : '' ?>
                    <?= !empty($estado['modoInstanciacao']) ? '' : 'name="acao" value="avancar"' ?>
                    <?= empty($estado['podeAvancar']) || ($elementoId === 'ativ1' && empty($estado['confirmacaoSubstituicao'])) ? 'disabled' : '' ?>
                >
                    <?= !empty($estado['modoInstanciacao']) ? 'Avançar' : (!empty($estado['ehNoFinal']) ? 'Concluir' : 'Avançar') ?>
                </button>
            </div>
        </form>
    </div>
</section>