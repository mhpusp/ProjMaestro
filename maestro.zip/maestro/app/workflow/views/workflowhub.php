<?php

declare(strict_types=1);

$ambiente = (string) ($dados['ambiente'] ?? 'desenvolvimento');
$instancias = is_array($dados['instancias'] ?? null) ? $dados['instancias'] : [];
$processos = is_array($dados['processos'] ?? null) ? $dados['processos'] : [];
$agenda = is_array($dados['agenda'] ?? null) ? $dados['agenda'] : [];
$basePath = rtrim((string) ($layout['basePath'] ?? ''), '/');
?>
<div class="row g-3 g-md-4">
    <div class="col-12">
        <section class="card poli-card poli-card-destaque">
            <div class="card-body">
                <div class="row align-items-center gy-3">
                    <div class="col-12 col-lg">
                        <h2 class="card-title mb-2">Bem-vindo ao Maestro Workflow</h2>
                        <p class="mb-0">Sistema orientado a fluxo de processos.</p>
                    </div>
                    <div class="col-12 col-lg-auto">
                        <span class="badge bg-azure-lt text-azure">Ambiente <?= htmlspecialchars($ambiente) ?></span>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="col-12">
        <div class="accordion d-grid gap-3" id="workflow-hub-listas">
            <section class="accordion-item poli-card">
                <h3 class="accordion-header" id="agenda-heading">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#agenda-lista" aria-expanded="true" aria-controls="agenda-lista">
                        Agenda
                    </button>
                </h3>
                <div id="agenda-lista" class="accordion-collapse collapse show" aria-labelledby="agenda-heading">
                    <div class="accordion-body">
                        <?php if ($agenda === []): ?>
                            <p class="text-secondary mb-0">Nenhum item na agenda.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-vcenter mb-0">
                                    <thead>
                                        <tr>
                                            <th scope="col">Tipo</th>
                                            <th scope="col">Assunto</th>
                                            <th scope="col">Data de notificação</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($agenda as $item): ?>
                                            <?php
                                            $cor = (string) ($item['cor'] ?? '');
                                            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) {
                                                $cor = '#f1f3f5';
                                            }
                                            $rgb = array_map('hexdec', str_split(substr($cor, 1), 2));
                                            $rgbLinear = array_map(static function (int $canal): float {
                                                $normalizado = $canal / 255;

                                                return $normalizado <= 0.03928
                                                    ? $normalizado / 12.92
                                                    : (($normalizado + 0.055) / 1.055) ** 2.4;
                                            }, $rgb);
                                            $luminancia = 0.2126 * $rgbLinear[0] + 0.7152 * $rgbLinear[1] + 0.0722 * $rgbLinear[2];
                                            $corTexto = $luminancia > 0.179 ? '#212529' : '#ffffff';
                                            $data = (string) ($item['data_notificacao'] ?? '');
                                            $timestamp = $data !== '' ? strtotime($data) : false;
                                            $dataFormatada = $timestamp === false ? $data : date('d/m/Y H:i', $timestamp);
                                            $estiloLinha = 'background-color: ' . $cor . '; color: ' . $corTexto . ';';
                                            $instanciaId = filter_var($item['instancia_id'] ?? null, FILTER_VALIDATE_INT);
                                            $instanciaEmAndamento = $instanciaId !== false
                                                && $instanciaId > 0
                                                && isset($item['instancia_concluida'])
                                                && !(bool) $item['instancia_concluida'];
                                            ?>
                                            <tr>
                                                <td style="<?= htmlspecialchars($estiloLinha, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string) ($item['tipo_agenda'] ?? '')) ?></td>
                                                <td style="<?= htmlspecialchars($estiloLinha, ENT_QUOTES, 'UTF-8') ?>">
                                                    <?php if ($instanciaEmAndamento): ?>
                                                        <a class="text-reset" href="<?= htmlspecialchars($basePath . '/workflow/instancias/' . $instanciaId, ENT_QUOTES, 'UTF-8') ?>">
                                                            <?= htmlspecialchars((string) ($item['assunto'] ?? '')) ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <?= htmlspecialchars((string) ($item['assunto'] ?? '')) ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td style="<?= htmlspecialchars($estiloLinha, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($dataFormatada) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="accordion-item poli-card">
                <h3 class="accordion-header" id="instancias-heading">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#instancias-lista" aria-expanded="false" aria-controls="instancias-lista">
                        Instâncias de Processos
                    </button>
                </h3>
                <div id="instancias-lista" class="accordion-collapse collapse" aria-labelledby="instancias-heading">
                    <div class="accordion-body">
                        <?php if ($instancias === []): ?>
                            <p class="text-secondary mb-0">Nenhuma instância disponível.</p>
                        <?php else: ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach ($instancias as $instancia): ?>
                                    <?php $concluida = (bool) ($instancia['concluido'] ?? false); ?>
                                    <?php $instanciaUrl = $basePath . '/workflow/instancias/' . (int) ($instancia['id'] ?? 0); ?>
                                    <li class="list-group-item px-0">
                                        <div class="d-flex flex-column flex-sm-row justify-content-between gap-2">
                                            <div>
                                                <h4 class="h3 mb-1">
                                                    <?php if (!$concluida && (int) ($instancia['id'] ?? 0) > 0): ?>
                                                        <a href="<?= htmlspecialchars($instanciaUrl, ENT_QUOTES, 'UTF-8') ?>">
                                                            <?= htmlspecialchars((string) ($instancia['nome'] ?? 'Processo')) ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <?= htmlspecialchars((string) ($instancia['nome'] ?? 'Processo')) ?>
                                                    <?php endif; ?>
                                                    - Instância #<?= htmlspecialchars((string) ($instancia['id'] ?? '')) ?>
                                                </h4>
                                                <!--<p class="text-secondary mb-0">Instância #<?= htmlspecialchars((string) ($instancia['id'] ?? '')) ?></p>-->
                                                <?php if (!empty($instancia['descricao'])): ?>
                                                    <p class="text-secondary mt-2 mb-0"><?= htmlspecialchars((string) $instancia['descricao']) ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <span class="badge <?= $concluida ? 'bg-success-lt text-success' : 'bg-azure-lt text-azure' ?> align-self-start">
                                                <?= $concluida ? 'Concluído' : 'Em andamento' ?>
                                            </span>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="accordion-item poli-card">
                <h3 class="accordion-header" id="processos-heading">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#processos-lista" aria-expanded="false" aria-controls="processos-lista">
                        Processos para Instanciar
                    </button>
                </h3>
                <div id="processos-lista" class="accordion-collapse collapse" aria-labelledby="processos-heading">
                    <div class="accordion-body">
                        <?php if ($processos === []): ?>
                            <p class="text-secondary mb-0">Nenhum processo disponível para instanciar.</p>
                        <?php else: ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach ($processos as $processo): ?>
                                    <li class="list-group-item px-0">
                                        <div class="d-flex flex-column flex-sm-row justify-content-between gap-2">
                                            <div>
                                                <h4 class="h3 mb-1">
                                                    <a href="<?= htmlspecialchars($basePath . '/workflow/processos/' . rawurlencode((string) ($processo['id'] ?? '')) . '/instanciar', ENT_QUOTES, 'UTF-8') ?>">
                                                        <?= htmlspecialchars((string) ($processo['nome'] ?? 'Processo')) ?>
                                                    </a>
                                                </h4>
                                                <?php if (!empty($processo['descricao'])): ?>
                                                    <p class="text-secondary mb-0"><?= htmlspecialchars((string) $processo['descricao']) ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <span class="badge bg-success-lt text-success align-self-start">
                                                Versão <?= htmlspecialchars((string) ($processo['versao'] ?? '')) ?>
                                            </span>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>