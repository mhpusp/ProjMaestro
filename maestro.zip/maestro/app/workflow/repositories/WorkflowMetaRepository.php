<?php

declare(strict_types=1);

namespace App\workflow\repositories;

use PDO;

class WorkflowMetaRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarParaInstanciar(): array
    {
        $stmt = $this->pdo->query(
            'SELECT id, nome, descricao, versao
             FROM processos
             WHERE status = 1
             ORDER BY nome ASC, versao DESC'
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** @return array<string, mixed>|null */
    public function obterParaInstanciar(string $processoId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id AS processo_id, nome AS processo_nome, descricao AS processo_descricao,
                    versao AS processo_versao, arquivo AS processo_arquivo,
                    raias_participantes, dono_processo
             FROM processos
             WHERE id = :id AND status = 1'
        );
        $stmt->execute(['id' => $processoId]);
        $processo = $stmt->fetch(PDO::FETCH_ASSOC);

        return $processo === false ? null : $processo;
    }
}
