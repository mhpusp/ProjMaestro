<?php

declare(strict_types=1);

namespace App\workflow\repositories;

use PDO;

class WorkflowHistRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarInstancias(): array
    {
        $stmt = $this->pdo->query(
            'SELECT pi.id, pi.processo_id, p.nome, p.descricao, p.versao, pi.concluido, pi.updated_at
             FROM processo_instancias pi
             INNER JOIN processos p ON p.id = pi.processo_id
             ORDER BY pi.updated_at DESC, pi.id DESC'
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** @return array<string, mixed>|null */
    public function obterInstancia(int $instanciaId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT pi.id, pi.processo_id, pi.concluido AS instancia_concluida,
                    pi.dados_form AS dados_form_instancia, pi.raias_participantes,
                    pi.criado_por, pi.created_at, pi.updated_at,
                    p.nome AS processo_nome, p.descricao AS processo_descricao,
                    p.versao AS processo_versao, p.arquivo AS processo_arquivo
             FROM processo_instancias pi
             INNER JOIN processos p ON p.id = pi.processo_id
             WHERE pi.id = :id'
        );
        $stmt->execute(['id' => $instanciaId]);
        $instancia = $stmt->fetch(PDO::FETCH_ASSOC);

        return $instancia === false ? null : $instancia;
    }

    /** @return array<string, mixed>|null */
    private function obterProcessoAtivoParaInstanciar(string $processoId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id AS processo_id, nome AS processo_nome, descricao AS processo_descricao,
                    versao AS processo_versao, arquivo AS processo_arquivo,
                    raias_participantes, dono_processo
             FROM processos
             WHERE id = :id AND status = 1'
        );
        $stmt->execute(['id' => $processoId]);
        $processo = $stmt->fetch(PDO::FETCH_ASSOC);

        return $processo === false ? null : $processo;
    }

    /** @return array<int, array<string, mixed>> */
    public function listarElementos(int $instanciaId): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, instancia_id, elemento_id, tipo, nome_raia, participante, nome,
                    descricao, arquivo, pergunta, respostas, evento, volta, libera,
                    concluido, origem, destino, dados_form, criado_por, created_at, updated_at
             FROM instancia_elementos
             WHERE instancia_id = :instancia_id
             ORDER BY created_at ASC, id ASC'
        );
        $stmt->execute(['instancia_id' => $instanciaId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * @param array<string, mixed> $elemento
     * @param array<string, mixed> $dadosForm
     */
    public function consolidarElemento(int $instanciaId, array $elemento, array $dadosForm): void
    {
        $dadosFormJson = json_encode($dadosForm, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
        $respostasJson = $this->respostasParaConsolidar($elemento, $dadosForm);
        $stmt = $this->pdo->prepare(
            'UPDATE instancia_elementos
             SET concluido = 1, respostas = :respostas, dados_form = :dados_form,
                 updated_at = CURRENT_TIMESTAMP
             WHERE instancia_id = :instancia_id AND elemento_id = :elemento_id'
        );
        $stmt->execute([
            'respostas' => $respostasJson,
            'dados_form' => $dadosFormJson,
            'instancia_id' => $instanciaId,
            'elemento_id' => (string) $elemento['id'],
        ]);

        if ($stmt->rowCount() > 0) {
            return;
        }

        $stmt = $this->pdo->prepare(
            'SELECT id FROM instancia_elementos
             WHERE instancia_id = :instancia_id AND elemento_id = :elemento_id
             LIMIT 1'
        );
        $stmt->execute([
            'instancia_id' => $instanciaId,
            'elemento_id' => (string) $elemento['id'],
        ]);
        if ($stmt->fetchColumn() !== false) {
            return;
        }

        $insert = $this->pdo->prepare(
            'INSERT INTO instancia_elementos
                (instancia_id, elemento_id, tipo, nome_raia, nome, descricao, arquivo,
                 pergunta, respostas, evento, volta, libera, concluido, origem, destino, dados_form)
             VALUES
                (:instancia_id, :elemento_id, :tipo, :nome_raia, :nome, :descricao, :arquivo,
                 :pergunta, :respostas, :evento, :volta, :libera, 1, :origem, :destino, :dados_form)'
        );
        $insert->execute([
            'instancia_id' => $instanciaId,
            'elemento_id' => (string) $elemento['id'],
            'tipo' => $elemento['tipo'] ?? null,
            'nome_raia' => $elemento['nome_raia'] ?? null,
            'nome' => $elemento['nome'] ?? null,
            'descricao' => $elemento['descricao'] ?? null,
            'arquivo' => $elemento['arquivo'] ?? null,
            'pergunta' => $elemento['pergunta'] ?? null,
            'respostas' => $respostasJson,
            'evento' => $this->jsonCampo($elemento['evento'] ?? null),
            'volta' => $this->jsonCampo($elemento['volta'] ?? null),
            'libera' => $this->jsonCampo($elemento['libera'] ?? null),
            'origem' => $elemento['origem'] ?? null,
            'destino' => $elemento['destino'] ?? null,
            'dados_form' => $dadosFormJson,
        ]);
    }

    /**
     * @param array<string, mixed> $elemento
     * @param array<string, mixed> $dadosForm
     */
    private function respostasParaConsolidar(array $elemento, array $dadosForm): ?string
    {
        $tipo = strtolower((string) ($elemento['tipo'] ?? ''));
        if (in_array($tipo, ['gate', 'gateway'], true)) {
            $opcoes = $elemento['respostas'] ?? null;
            $resposta = $dadosForm['resposta'] ?? null;
            if (!is_array($opcoes) || !is_string($resposta) || !array_key_exists($resposta, $opcoes)) {
                throw new \RuntimeException('É necessário selecionar uma resposta válida para consolidar o gate.');
            }

            return json_encode($resposta, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
        }

        return $this->jsonCampo($elemento['respostas'] ?? null);
    }

    private function jsonCampo(mixed $valor): ?string
    {
        if ($valor === null || $valor === '') {
            return null;
        }
        if (is_string($valor)) {
            try {
                json_decode($valor, true, 512, JSON_THROW_ON_ERROR);

                return $valor;
            } catch (\JsonException) {
                // Plain strings are encoded below; already encoded SQL JSON stays intact.
            }
        }

        return json_encode($valor, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    }

    public function concluirInstancia(int $instanciaId): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE processo_instancias
             SET concluido = 1, updated_at = CURRENT_TIMESTAMP
             WHERE id = :id AND concluido = 0'
        );
        $stmt->execute(['id' => $instanciaId]);
        if ($stmt->rowCount() > 0) {
            return;
        }

        $stmt = $this->pdo->prepare('SELECT concluido FROM processo_instancias WHERE id = :id');
        $stmt->execute(['id' => $instanciaId]);
        if ((int) $stmt->fetchColumn() !== 1) {
            throw new \RuntimeException("Não foi possível concluir a instância: {$instanciaId}");
        }
    }

    /**
     * Cria a instância e consolida seu nó inicial em uma única transação.
     *
     * @param array<string, mixed> $noInicial
     * @param array<string, mixed> $dadosForm
     */
    public function instanciarProcesso(
        string $processoId,
        string $criadoPor,
        array $noInicial,
        array $dadosForm
    ): int {
        $iniciadaAqui = !$this->pdo->inTransaction();
        if ($iniciadaAqui) {
            $this->pdo->beginTransaction();
        }

        try {
            $processo = $this->obterProcessoAtivoParaInstanciar($processoId);
            if ($processo === null) {
                throw new \RuntimeException("Processo disponível para instanciação não encontrado: {$processoId}");
            }

            $stmt = $this->pdo->prepare(
                'INSERT INTO processo_instancias (processo_id, concluido, raias_participantes, criado_por)
                 VALUES (:processo_id, 0, :raias_participantes, :criado_por)'
            );
            $stmt->execute([
                'processo_id' => $processoId,
                'raias_participantes' => $this->jsonCampo($processo['raias_participantes'] ?? null),
                'criado_por' => $criadoPor !== '' ? $criadoPor : null,
            ]);
            $instanciaId = (int) $this->pdo->lastInsertId();
            if ($instanciaId < 1) {
                throw new \RuntimeException('Não foi possível obter o identificador da nova instância.');
            }

            $elementoStmt = $this->pdo->prepare(
                'INSERT INTO instancia_elementos
                    (instancia_id, elemento_id, tipo, nome_raia, nome, descricao, arquivo,
                     pergunta, respostas, evento, volta, libera, concluido, origem, destino, dados_form)
                 VALUES
                    (:instancia_id, :elemento_id, :tipo, :nome_raia, :nome, :descricao, :arquivo,
                     :pergunta, :respostas, :evento, :volta, :libera, 1, :origem, :destino, :dados_form)'
            );
            $elementoStmt->execute([
                'instancia_id' => $instanciaId,
                'elemento_id' => (string) $noInicial['id'],
                'tipo' => $noInicial['tipo'] ?? null,
                'nome_raia' => $noInicial['nome_raia'] ?? null,
                'nome' => $noInicial['nome'] ?? null,
                'descricao' => $noInicial['descricao'] ?? null,
                'arquivo' => $noInicial['arquivo'] ?? null,
                'pergunta' => $noInicial['pergunta'] ?? null,
                'respostas' => $this->jsonCampo($noInicial['respostas'] ?? null),
                'evento' => $this->jsonCampo($noInicial['evento'] ?? null),
                'volta' => $this->jsonCampo($noInicial['volta'] ?? null),
                'libera' => $this->jsonCampo($noInicial['libera'] ?? null),
                'origem' => $noInicial['origem'] ?? null,
                'destino' => $noInicial['destino'] ?? null,
                'dados_form' => json_encode($dadosForm, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            ]);

            if ($iniciadaAqui) {
                $this->pdo->commit();
            }

            return $instanciaId;
        } catch (\Throwable $erro) {
            if ($iniciadaAqui && $this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }

            throw $erro;
        }
    }
}
