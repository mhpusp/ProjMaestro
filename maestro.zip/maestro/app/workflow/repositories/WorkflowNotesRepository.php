<?php

declare(strict_types=1);

namespace App\workflow\repositories;

use PDO;

class WorkflowNotesRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarAgenda(string $email): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT av.tipo_agenda, av.tipo_node, av.assunto, av.data_notificacao, av.cor,
                    av.instancia_id, pi.concluido AS instancia_concluida
             FROM agendavw av
             LEFT JOIN processo_instancias pi ON pi.id = av.instancia_id
             WHERE av.email = :email
             ORDER BY av.data_notificacao ASC, av.id ASC'
        );
        $stmt->execute(['email' => $email]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obterTarefaRetomadaId(int $usuarioId, int $instanciaId): ?int
    {
        $stmt = $this->pdo->prepare(
            "SELECT id FROM agenda
             WHERE usuario_id = :usuario_id
               AND instancia_id = :instancia_id
               AND tipo_agenda = 'Tarefa'
               AND tipo_node = 'workflow_retoma'
             ORDER BY id ASC
             LIMIT 1"
        );
        $stmt->execute([
            'usuario_id' => $usuarioId,
            'instancia_id' => $instanciaId,
        ]);

        $id = $stmt->fetchColumn();

        return $id === false ? null : (int) $id;
    }

    public function atualizarTarefaRetomada(int $tarefaId, string $assunto, string $mensagem): bool
    {
        $stmt = $this->pdo->prepare(
            'UPDATE agenda
             SET assunto = :assunto, mensagem = :mensagem
             WHERE id = :id'
        );
        $stmt->execute([
            'assunto' => $assunto,
            'mensagem' => $mensagem,
            'id' => $tarefaId,
        ]);
        if ($stmt->rowCount() > 0) {
            return true;
        }

        $verificar = $this->pdo->prepare('SELECT id FROM agenda WHERE id = :id');
        $verificar->execute(['id' => $tarefaId]);

        return $verificar->fetchColumn() !== false;
    }

    public function criarTarefaRetomada(
        int $usuarioId,
        int $instanciaId,
        string $processoId,
        string $assunto,
        string $mensagem
    ): int {
        $stmt = $this->pdo->prepare(
            "INSERT INTO agenda
                (usuario_id, processo_id, instancia_id, tipo_agenda, tipo_node, assunto, mensagem,
                 cor, data_notificacao, concluido)
             VALUES
                (:usuario_id, :processo_id, :instancia_id, 'Tarefa', 'workflow_retoma',
                 :assunto, :mensagem, '#FAFAD2', CURRENT_TIMESTAMP, 0)"
        );
        $stmt->execute([
            'usuario_id' => $usuarioId,
            'processo_id' => $processoId,
            'instancia_id' => $instanciaId,
            'assunto' => $assunto,
            'mensagem' => $mensagem,
        ]);

        $tarefaId = (int) $this->pdo->lastInsertId();
        if ($tarefaId < 1) {
            throw new \RuntimeException('Não foi possível obter o identificador da tarefa de retomada.');
        }

        return $tarefaId;
    }

    public function notificarAdministradoresNovoProcesso(string $processoId, string $nomeProcesso): int
    {
        $assunto = 'Um novo processo (' . $nomeProcesso . ') foi incluído no sistema.';
        return $this->notificarAdministradores(
            'Notificação',
            $assunto,
            '#98FB98',
            $processoId,
            null
        );
    }

    public function notificarAdministradores(
        string $tipo,
        string $assunto,
        string $cor,
        ?string $processoId,
        ?int $instanciaId
    ): int {
        $stmt = $this->pdo->prepare(
            "INSERT INTO agenda
                (usuario_id, processo_id, instancia_id, tipo_agenda, tipo_node, assunto, mensagem,
                 cor, data_notificacao, concluido)
             SELECT u.id, :processo_id, :instancia_id, :tipo_agenda, 'workflow_notificacao',
                    :assunto, :mensagem, :cor, CURRENT_TIMESTAMP, 0
             FROM usuarios u
             INNER JOIN usuario_funcoes uf ON uf.usuario_id = u.id
             INNER JOIN funcoes f ON f.id = uf.funcao_id
             WHERE LOWER(f.nome) = 'admin'"
        );
        $stmt->execute([
            'processo_id' => $processoId,
            'instancia_id' => $instanciaId,
            'tipo_agenda' => $tipo,
            'assunto' => $assunto,
            'mensagem' => $assunto,
            'cor' => $cor,
        ]);

        if ($stmt->rowCount() < 1) {
            throw new \RuntimeException('Não foi encontrado usuário com o papel admin para notificar na Agenda.');
        }

        return $stmt->rowCount();
    }
}
