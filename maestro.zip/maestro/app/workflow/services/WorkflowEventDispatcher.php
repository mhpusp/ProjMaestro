<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\workflow\contracts\WorkflowEventDispatcherInterface;
use App\workflow\contracts\WorkflowEventHandlerInterface;
use InvalidArgumentException;
use RuntimeException;

class WorkflowEventDispatcher implements WorkflowEventDispatcherInterface
{
    /** @var array<string, WorkflowEventHandlerInterface> */
    private array $handlers = [];

    /**
     * Registra um manipulador de evento no Dispatcher
     */
    public function registerHandler(WorkflowEventHandlerInterface $handler): void
    {
        $key = trim($handler->getKey());
        if ($key === '') {
            throw new InvalidArgumentException('A chave do manipulador de evento não pode estar vazia.');
        }
        if (isset($this->handlers[$key])) {
            throw new InvalidArgumentException("Já existe um manipulador registrado para o evento: {$key}");
        }

        $this->handlers[$key] = $handler;
    }

    /**
     * Executa um evento a partir de sua assinatura em string (ex: "enviar_email('financeiro@empresa.com')")
     */
    public function dispatch(string $eventSignature, array $context): mixed
    {
        [$eventName, $expressions] = $this->parseSignature($eventSignature);

        if (!isset($this->handlers[$eventName])) {
            throw new RuntimeException("Não há manipulador registrado para o evento: {$eventName}");
        }

        $params = array_map(
            fn (string $expression): string => $this->evaluateExpression($expression, $context),
            $expressions
        );

        return $this->handlers[$eventName]->handle($params, $context);
    }

    /** @return array{0: string, 1: array<int, string>} */
    private function parseSignature(string $signature): array
    {
        $signature = trim($signature);
        if (!preg_match('/^([A-Za-z_][A-Za-z0-9_]*)\s*(?:\((.*)\))?$/s', $signature, $matches)) {
            throw new InvalidArgumentException('Assinatura de evento inválida.');
        }

        $eventName = $matches[1];
        $rawArguments = $matches[2] ?? '';
        if (trim($rawArguments) === '') {
            return [$eventName, []];
        }

        return [$eventName, $this->parseArguments($rawArguments)];
    }

    /** @return array<int, string> */
    private function parseArguments(string $rawArguments): array
    {
        $arguments = $this->splitOutsideQuotes($rawArguments, ',');
        foreach ($arguments as $argument) {
            if (trim($argument) === '') {
                throw new InvalidArgumentException('A assinatura do evento contém um parâmetro vazio.');
            }
        }

        return array_map('trim', $arguments);
    }

    private function evaluateExpression(string $expression, array $context): string
    {
        $segments = $this->splitOutsideQuotes($expression, '+');
        $value = '';
        foreach ($segments as $segment) {
            $segment = trim($segment);
            if ($segment === '') {
                throw new InvalidArgumentException('A expressão do evento contém um operando vazio.');
            }
            if ($this->isQuotedString($segment)) {
                $quote = $segment[0];
                $value .= $this->unescapeQuotedString(substr($segment, 1, -1), $quote);
                continue;
            }

            if (preg_match('/^\$(NoDescritor|NoAtual)\.([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)$/', $segment, $matches)) {
                $raiz = $matches[1] === 'NoDescritor'
                    ? ($context['no_descritor'] ?? $context['definicao_processo'] ?? null)
                    : ($context['no_atual'] ?? null);
                $propriedade = $this->obterPropriedade($raiz, explode('.', $matches[2]), $segment);
                if (!is_scalar($propriedade) && $propriedade !== null) {
                    throw new InvalidArgumentException("A propriedade {$segment} não pode ser usada como texto.");
                }
                $value .= $propriedade === null ? '' : (string) $propriedade;
                continue;
            }

            if (str_starts_with($segment, '$') || str_contains($segment, "'") || str_contains($segment, '"')) {
                throw new InvalidArgumentException("Expressão de evento não suportada: {$segment}");
            }

            $value .= $segment;
        }

        return $value;
    }

    private function isQuotedString(string $segment): bool
    {
        $length = strlen($segment);
        if ($length < 2 || !in_array($segment[0], ["'", '"'], true) || $segment[$length - 1] !== $segment[0]) {
            return false;
        }

        $quote = $segment[0];
        for ($index = 1; $index < $length - 1; $index++) {
            if ($segment[$index] === '\\') {
                $index++;
            } elseif ($segment[$index] === $quote) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<int, string> $caminho
     */
    private function obterPropriedade(mixed $raiz, array $caminho, string $referencia): mixed
    {
        foreach ($caminho as $propriedade) {
            if (!is_array($raiz) || !array_key_exists($propriedade, $raiz)) {
                throw new InvalidArgumentException("A propriedade {$referencia} não existe no contexto do evento.");
            }
            $raiz = $raiz[$propriedade];
        }

        return $raiz;
    }

    private function unescapeQuotedString(string $value, string $quote): string
    {
        $result = '';
        for ($index = 0, $length = strlen($value); $index < $length; $index++) {
            if ($value[$index] === '\\' && $index + 1 < $length) {
                $next = $value[$index + 1];
                if ($next === $quote || $next === '\\') {
                    $result .= $next;
                    $index++;
                    continue;
                }
            }
            $result .= $value[$index];
        }

        return $result;
    }

    /** @return array<int, string> */
    private function splitOutsideQuotes(string $value, string $separator): array
    {
        $parts = [];
        $part = '';
        $quote = null;
        for ($index = 0, $length = strlen($value); $index < $length; $index++) {
            $character = $value[$index];

            if ($quote !== null) {
                if ($character === '\\') {
                    $part .= $character;
                    if (isset($value[$index + 1])) {
                        $part .= $value[++$index];
                    }
                } elseif ($character === $quote) {
                    $quote = null;
                    $part .= $character;
                } else {
                    $part .= $character;
                }
                continue;
            }

            if ($character === "'" || $character === '"') {
                $quote = $character;
                $part .= $character;
            } elseif ($character === $separator) {
                $parts[] = $part;
                $part = '';
            } else {
                $part .= $character;
            }
        }

        if ($quote !== null) {
            throw new InvalidArgumentException('Assinatura de evento contém aspas não finalizadas.');
        }

        $parts[] = $part;

        return $parts;
    }
}