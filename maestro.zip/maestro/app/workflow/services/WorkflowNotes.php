<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\workflow\contracts\WorkflowNotesInterface;
use App\workflow\repositories\WorkflowNotesRepository;

class WorkflowNotes implements WorkflowNotesInterface
{
    private const CORES_TIPO_AGENDA = [
        'tarefa' => '#FFF7CC',
        'notificação' => '#98FB98',
        'mensagem' => '#E0FFFF',
    ];

    public function __construct(private readonly WorkflowNotesRepository $repository)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarAgenda(string $email): array
    {
        return $this->repository->listarAgenda($email);
    }

    public function criarTarefaRetomada(
        int $usuarioId,
        int $instanciaId,
        string $processoId,
        string $nomeProcesso,
        string $nomeNo
    ): int {
        if (
            $usuarioId < 1
            || $instanciaId < 1
            || trim($processoId) === ''
            || trim($nomeProcesso) === ''
            || trim($nomeNo) === ''
        ) {
            throw new \InvalidArgumentException('Dados inválidos para criar tarefa de retomada.');
        }

        $assunto = $nomeProcesso . ' - Instância #' . $instanciaId . ' - ' . $nomeNo;
        $mensagem = 'A instância #' . $instanciaId . ' do processo "' . $nomeProcesso
            . '" foi fechada antes da conclusão no nó "' . $nomeNo
            . '". Selecione esta tarefa para continuar.';

        $tarefaExistenteId = $this->repository->obterTarefaRetomadaId($usuarioId, $instanciaId);
        if (
            $tarefaExistenteId !== null
            && $this->repository->atualizarTarefaRetomada($tarefaExistenteId, $assunto, $mensagem)
        ) {
            return $tarefaExistenteId;
        }

        return $this->repository->criarTarefaRetomada(
            $usuarioId,
            $instanciaId,
            $processoId,
            $assunto,
            $mensagem
        );
    }

    public function notificarNovoProcesso(string $processoId, string $nomeProcesso): int
    {
        if (trim($processoId) === '' || trim($nomeProcesso) === '') {
            throw new \InvalidArgumentException('Informe o processo e o nome para criar a notificação.');
        }

        $assunto = 'Um novo processo (' . $nomeProcesso . ') foi incluído no sistema.';

        return $this->notificarAdministradores(
            'Notificação',
            $assunto,
            self::CORES_TIPO_AGENDA['notificação'],
            $processoId,
            null
        );
    }

    public function notificarAdministradores(
        string $tipo,
        string $assunto,
        string $cor,
        ?string $processoId,
        ?int $instanciaId
    ): int {
        $tipoCanonico = $this->normalizarTipoAgenda($tipo);
        if (trim($assunto) === '') {
            throw new \InvalidArgumentException('Informe o assunto da notificação da Agenda.');
        }
        if (strtoupper($cor) !== self::CORES_TIPO_AGENDA[$this->chaveTipoAgenda($tipoCanonico)]) {
            throw new \InvalidArgumentException("A cor informada não corresponde ao tipo de Agenda {$tipoCanonico}.");
        }

        return $this->repository->notificarAdministradores(
            $tipoCanonico,
            trim($assunto),
            $cor,
            $processoId,
            $instanciaId
        );
    }

    public function corDoTipo(string $tipo): string
    {
        $tipoCanonico = $this->normalizarTipoAgenda($tipo);

        return self::CORES_TIPO_AGENDA[$this->chaveTipoAgenda($tipoCanonico)];
    }

    private function normalizarTipoAgenda(string $tipo): string
    {
        $tipo = strtr(trim($tipo), [
            'Á' => 'á', 'É' => 'é', 'Í' => 'í', 'Ó' => 'ó', 'Ú' => 'ú',
            'Ç' => 'ç',
        ]);
        $chave = strtolower($tipo);
        $tipos = [
            'tarefa' => 'Tarefa',
            'notificação' => 'Notificação',
            'notificacao' => 'Notificação',
            'mensagem' => 'Mensagem',
        ];
        if (!isset($tipos[$chave])) {
            throw new \InvalidArgumentException('Tipo de Agenda inválido. Use Tarefa, Notificação ou Mensagem.');
        }

        return $tipos[$chave];
    }

    private function chaveTipoAgenda(string $tipo): string
    {
        return strtolower(strtr($tipo, [
            'Á' => 'á', 'É' => 'é', 'Í' => 'í', 'Ó' => 'ó', 'Ú' => 'ú',
            'Ç' => 'ç',
        ]));
    }
}