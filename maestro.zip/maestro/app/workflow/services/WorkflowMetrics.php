<?php

declare(strict_types=1);

namespace App\workflow;


class WorkflowMetrics
{
    public function __construct()
    {
    }




    
}