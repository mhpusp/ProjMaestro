<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\workflow\contracts\WorkflowMapInterface;
use JsonException;
use RuntimeException;

class WorkflowMap implements WorkflowMapInterface
{
    private readonly string $diretorioPacotes;

    public function __construct(string $diretorioPacotes)
    {
        $diretorioReal = realpath($diretorioPacotes);
        if ($diretorioReal === false || !is_dir($diretorioReal)) {
            throw new RuntimeException('Diretório de pacotes de workflow não encontrado.');
        }

        $this->diretorioPacotes = $diretorioReal;
    }

    public function carregarMapForward(array $instancia): array
    {
        $definicao = $this->carregarDefinicao($instancia);

        if (!isset($definicao['elementos']) || !is_array($definicao['elementos'])) {
            throw new RuntimeException('A definição JSON do processo não contém uma lista de elementos válida.');
        }

        $mapForward = [];
        foreach ($definicao['elementos'] as $elemento) {
            if (!is_array($elemento) || !isset($elemento['id']) || !is_scalar($elemento['id'])) {
                throw new RuntimeException('A definição JSON contém um elemento sem identificador válido.');
            }

            $id = (string) $elemento['id'];
            if ($id === '' || isset($mapForward[$id])) {
                throw new RuntimeException("Identificador de elemento vazio ou duplicado no processo: {$id}");
            }

            $mapForward[$id] = $elemento;
            $mapForward[$id]['id'] = $id;
            if (strtolower((string) ($elemento['tipo'] ?? '')) === 'inicio') {
                $mapForward[$id]['pergunta'] = 'Você deseja iniciar este processo?';
                $mapForward[$id]['respostas'] = ['Sim' => true, 'Não' => false];
            }
        }

        return $mapForward;
    }

    /** @return array<string, mixed> */
    public function carregarDefinicao(array $instancia): array
    {
        $arquivoJson = (string) ($instancia['processo_arquivo'] ?? '');
        if ($arquivoJson === '' || basename($arquivoJson) !== $arquivoJson) {
            throw new RuntimeException('Arquivo JSON do processo inválido.');
        }

        $diretorioProcesso = $this->resolverDiretorioProcesso($instancia);
        $caminhoJson = realpath($diretorioProcesso . DIRECTORY_SEPARATOR . $arquivoJson);
        if ($caminhoJson === false || !str_starts_with($caminhoJson, $diretorioProcesso . DIRECTORY_SEPARATOR)) {
            throw new RuntimeException("Arquivo JSON do processo não encontrado: {$arquivoJson}");
        }

        try {
            $definicao = json_decode(
                (string) file_get_contents($caminhoJson),
                true,
                512,
                JSON_THROW_ON_ERROR
            );
        } catch (JsonException $erro) {
            throw new RuntimeException('Não foi possível interpretar o JSON do processo.', 0, $erro);
        }

        if (!is_array($definicao)) {
            throw new RuntimeException('A definição JSON do processo deve ser um objeto.');
        }

        return $definicao;
    }

    public function resolverArquivoNo(array $instancia, array $elemento): ?string
    {
        $arquivo = trim((string) ($elemento['arquivo'] ?? ''));
        if ($arquivo === '') {
            return null;
        }
        if (basename($arquivo) !== $arquivo || str_contains($arquivo, "\0")) {
            throw new RuntimeException('O arquivo da view do elemento é inválido.');
        }

        $diretorioProcesso = $this->resolverDiretorioProcesso($instancia);
        $caminho = realpath($diretorioProcesso . DIRECTORY_SEPARATOR . $arquivo);
        if (
            $caminho === false
            || !str_starts_with($caminho, $diretorioProcesso . DIRECTORY_SEPARATOR)
            || !is_file($caminho)
        ) {
            throw new RuntimeException("View do elemento não encontrada: {$arquivo}");
        }

        return $caminho;
    }

    private function resolverDiretorioProcesso(array $instancia): string
    {
        $processoId = (string) ($instancia['processo_id'] ?? '');
        if ($processoId === '') {
            throw new RuntimeException('A instância não informa o identificador do processo.');
        }

        $diretorio = realpath($this->diretorioPacotes . DIRECTORY_SEPARATOR . $processoId);
        if (
            $diretorio === false
            || !str_starts_with($diretorio, $this->diretorioPacotes . DIRECTORY_SEPARATOR)
            || !is_dir($diretorio)
        ) {
            throw new RuntimeException("Pacote do processo não encontrado: {$processoId}");
        }

        return $diretorio;
    }
}