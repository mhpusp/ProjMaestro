<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\repositories\ProcessoRepository;
use App\workflow\contracts\WorkflowMetaInterface;
use App\workflow\dto\Processo;
use App\workflow\repositories\WorkflowMetaRepository;
use InvalidArgumentException;
use Psr\Http\Message\UploadedFileInterface;
use RuntimeException;

class WorkflowMeta implements WorkflowMetaInterface
{
    public function __construct(
        private readonly WorkflowMetaRepository $repository,
        private readonly ProcessoRepository $processoRepository
    ) {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarParaInstanciar(): array
    {
        return $this->repository->listarParaInstanciar();
    }

    public function obterParaInstanciar(string $processoId): ?array
    {
        return $this->repository->obterParaInstanciar($processoId);
    }

    /** @return Processo[] */
    public function listar(int $limit = 100, int $offset = 0): array
    {
        return $this->processoRepository->listar($limit, $offset);
    }

    public function criarNovo(array $dados, UploadedFileInterface $arquivoJson): Processo
    {
        $nome = trim((string) ($dados['nome'] ?? ''));

        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do processo.');
        }

        $id = $this->gerarId($nome, 1);

        if ($this->processoRepository->existe($id)) {
            throw new InvalidArgumentException('Ja existe um processo com esse nome. Use Atualizar para criar uma nova versao.');
        }

        $documento = $this->lerUploadJson($arquivoJson);
        $nomeArquivo = $id . '.json';

        $processo = Processo::fromArray(array_merge($documento, [
            'id' => $id,
            'nome' => $nome,
            'descricao' => trim((string) ($dados['descricao'] ?? '')) ?: null,
            'versao' => 1,
            'arquivo' => $nomeArquivo,
            'status' => isset($dados['status']) && (string) $dados['status'] === '1',
            'dono_processo' => $this->textoDono($documento['dono_processo'] ?? null),
            'lista_subprocessos' => $this->listaSubprocessosJson($documento),
            'raias_participantes' => $this->listaJson($documento, 'raias_participantes'),
        ]));

        $this->salvarArquivoJson($nomeArquivo, $documento);
        $this->processoRepository->salvar($processo);

        return $processo;
    }

    /** @param array<string, mixed> $metadados */
    public function pacoteExistente(array $metadados): bool
    {
        $nome = trim((string) ($metadados['nome'] ?? ''));
        if ($nome === '') {
            throw new InvalidArgumentException('O descritor do processo não informa um nome válido.');
        }

        $versao = $this->versaoNumerica($metadados['versao'] ?? 1);
        $id = $this->gerarId($nome, $versao);
        if ($this->processoRepository->existe($id)) {
            return false;
        }
        $diretorio = dirname(__DIR__, 2) . '/workflow/wfiles/' . $id;
        if (is_link($diretorio)) {
            throw new RuntimeException('A pasta de destino do processo não pode ser um link simbólico.');
        }

        return is_dir($diretorio);
    }

    /**
     * Inclui o pacote de um processo meta-descrito e seus dados no catálogo.
     *
     * @param array<string, mixed> $metadados
     * @param array<string, mixed> $arquivosEnviados
     */
    public function incluirPacote(array $metadados, array $arquivosEnviados, bool $substituir): Processo
    {
        $arquivosEsperados = $this->arquivosDoMetaDescritor($metadados);
        $arquivos = $this->normalizarArquivosEnviados($arquivosEnviados);
        $faltantes = array_values(array_diff($arquivosEsperados, array_keys($arquivos)));
        $extras = array_values(array_diff(array_keys($arquivos), $arquivosEsperados));
        if ($faltantes !== [] || $extras !== []) {
            throw new InvalidArgumentException(
                'Envie exatamente os arquivos JSON informados no descritor do processo.'
            );
        }

        $documentos = [];
        foreach ($arquivosEsperados as $nomeArquivo) {
            $upload = $arquivos[$nomeArquivo];
            if ($upload->getError() !== UPLOAD_ERR_OK) {
                throw new InvalidArgumentException("Não foi possível receber o arquivo {$nomeArquivo}.");
            }

            $conteudo = $upload->getStream()->getContents();
            try {
                $documento = json_decode($conteudo, true, 512, JSON_THROW_ON_ERROR);
            } catch (\JsonException $erro) {
                throw new InvalidArgumentException("O arquivo {$nomeArquivo} não contém JSON válido.", 0, $erro);
            }
            if (!is_array($documento)) {
                throw new InvalidArgumentException("O arquivo {$nomeArquivo} deve conter um objeto JSON.");
            }

            $documentos[$nomeArquivo] = [$conteudo, $documento];
        }

        $arquivoPrincipal = (string) ($metadados['arquivo'] ?? '');
        $processo = $this->criarProcessoDoPacote($metadados, $documentos);
        $id = $processo->id;
        if ($this->processoRepository->existe($id)) {
            throw new InvalidArgumentException(
                'Já existe um processo com esse identificador. Atualize a versão ou revise o nome do processo.'
            );
        }

        $diretorio = dirname(__DIR__, 2) . '/workflow/wfiles/' . $id;
        if (is_link($diretorio)) {
            throw new RuntimeException('A pasta de destino do processo não pode ser um link simbólico.');
        }
        if (is_dir($diretorio) && !$substituir) {
            throw new RuntimeException('Já existe uma pasta de arquivos para este processo. Confirme a substituição.');
        }
        if (file_exists($diretorio) && !is_dir($diretorio)) {
            throw new RuntimeException('O caminho de destino dos arquivos do processo não é uma pasta.');
        }

        $criadoDiretorio = false;
        if (!is_dir($diretorio)) {
            if (!mkdir($diretorio, 0775, true) && !is_dir($diretorio)) {
                throw new RuntimeException('Não foi possível criar a pasta dos arquivos do processo.');
            }
            $criadoDiretorio = true;
        }
        if (!is_writable($diretorio)) {
            throw new RuntimeException('A pasta dos arquivos do processo não permite gravação.');
        }

        $conteudosAnteriores = [];
        $arquivosGravados = [];
        $iniciouTransacao = !$this->processoRepository->emTransacao();
        if ($iniciouTransacao) {
            $this->processoRepository->iniciarTransacao();
        }

        try {
            foreach ($documentos as $nomeArquivo => [$conteudo]) {
                $destino = $diretorio . '/' . $nomeArquivo;
                if (is_link($destino)) {
                    throw new RuntimeException("O arquivo de destino {$nomeArquivo} não pode ser um link simbólico.");
                }
                if (is_file($destino)) {
                    $conteudoAnterior = file_get_contents($destino);
                    if ($conteudoAnterior === false) {
                        throw new RuntimeException("Não foi possível ler o arquivo existente {$nomeArquivo}.");
                    }
                    $conteudosAnteriores[$destino] = $conteudoAnterior;
                }
                $arquivosGravados[] = $destino;
                $bytesGravados = file_put_contents($destino, $conteudo, LOCK_EX);
                if ($bytesGravados === false || $bytesGravados !== strlen($conteudo)) {
                    throw new RuntimeException("Não foi possível salvar o arquivo {$nomeArquivo}.");
                }
            }

            $this->processoRepository->salvar($processo);
            if ($iniciouTransacao) {
                $this->processoRepository->confirmarTransacao();
            }
        } catch (\Throwable $erro) {
            if ($iniciouTransacao) {
                $this->processoRepository->reverterTransacao();
            }
            $falhasRestauracao = [];
            foreach ($arquivosGravados as $caminho) {
                if (array_key_exists($caminho, $conteudosAnteriores)) {
                    $restaurado = file_put_contents($caminho, $conteudosAnteriores[$caminho], LOCK_EX);
                    if ($restaurado === false || $restaurado !== strlen($conteudosAnteriores[$caminho])) {
                        $falhasRestauracao[] = basename($caminho);
                    }
                } elseif (is_file($caminho) && !unlink($caminho)) {
                    $falhasRestauracao[] = basename($caminho);
                }
            }
            if ($criadoDiretorio && is_dir($diretorio) && !rmdir($diretorio)) {
                $falhasRestauracao[] = basename($diretorio);
            }
            if ($falhasRestauracao !== []) {
                throw new RuntimeException(
                    'Falha ao restaurar o pacote após erro: ' . implode(', ', $falhasRestauracao) . '.',
                    0,
                    $erro
                );
            }
            throw $erro;
        }

        return $processo;
    }

    /** @param array<string, mixed> $metadados */
    public function incluirPacoteExistente(array $metadados): Processo
    {
        $arquivosEsperados = $this->arquivosDoMetaDescritor($metadados);
        $nome = trim((string) ($metadados['nome'] ?? ''));
        $versao = $this->versaoNumerica($metadados['versao'] ?? 1);
        $id = $this->gerarId($nome, $versao);
        if ($this->processoRepository->existe($id)) {
            throw new InvalidArgumentException('Já existe um processo com esse identificador.');
        }

        $diretorio = dirname(__DIR__, 2) . '/workflow/wfiles/' . $id;
        if (is_link($diretorio) || !is_dir($diretorio)) {
            throw new RuntimeException('O pacote existente do processo não está disponível.');
        }

        $documentos = [];
        foreach ($arquivosEsperados as $nomeArquivo) {
            $caminho = $diretorio . '/' . $nomeArquivo;
            if (is_link($caminho) || !is_file($caminho)) {
                throw new RuntimeException("O arquivo existente {$nomeArquivo} não foi encontrado.");
            }
            $conteudo = file_get_contents($caminho);
            if ($conteudo === false) {
                throw new RuntimeException("Não foi possível ler o arquivo existente {$nomeArquivo}.");
            }
            try {
                $documento = json_decode($conteudo, true, 512, JSON_THROW_ON_ERROR);
            } catch (\JsonException $erro) {
                throw new InvalidArgumentException("O arquivo existente {$nomeArquivo} não contém JSON válido.", 0, $erro);
            }
            if (!is_array($documento)) {
                throw new InvalidArgumentException("O arquivo existente {$nomeArquivo} deve conter um objeto JSON.");
            }
            $documentos[$nomeArquivo] = [$conteudo, $documento];
        }

        $processo = $this->criarProcessoDoPacote($metadados, $documentos);
        $iniciouTransacao = !$this->processoRepository->emTransacao();
        if ($iniciouTransacao) {
            $this->processoRepository->iniciarTransacao();
        }

        try {
            $this->processoRepository->salvar($processo);
            if ($iniciouTransacao) {
                $this->processoRepository->confirmarTransacao();
            }
        } catch (\Throwable $erro) {
            if ($iniciouTransacao) {
                $this->processoRepository->reverterTransacao();
            }
            throw $erro;
        }

        return $processo;
    }

    /** @return Processo[] */
    public function pesquisar(string $nome): array
    {
        $nome = trim($nome);

        if ($nome === '') {
            throw new InvalidArgumentException('Informe um nome para pesquisar.');
        }

        return $this->processoRepository->pesquisarPorNome($nome);
    }

    public function atualizar(string $processoId, array $dados, UploadedFileInterface $arquivoJson): Processo
    {
        $base = $this->processoRepository->buscarPorId($processoId);

        if ($base === null) {
            throw new InvalidArgumentException('Processo selecionado nao encontrado.');
        }

        $nome = trim((string) ($dados['nome'] ?? $base->nome));

        if ($nome === '') {
            throw new InvalidArgumentException('Informe o nome do processo.');
        }

        $raizId = $base->processo_id ?? $base->id;
        $versao = $this->processoRepository->maiorVersao($raizId) + 1;
        $id = $this->gerarId($base->nome, $versao);
        $documento = $this->lerUploadJson($arquivoJson);
        $nomeArquivo = $id . '.json';

        $processo = Processo::fromArray(array_merge($documento, [
            'id' => $id,
            'processo_id' => $raizId,
            'nome' => $nome,
            'descricao' => trim((string) ($dados['descricao'] ?? '')) ?: null,
            'versao' => $versao,
            'arquivo' => $nomeArquivo,
            'status' => isset($dados['status']) && (string) $dados['status'] === '1',
            'dono_processo' => $this->textoDono($documento['dono_processo'] ?? null),
            'lista_subprocessos' => $this->listaSubprocessosJson($documento),
            'raias_participantes' => $this->listaJson($documento, 'raias_participantes'),
        ]));

        $this->salvarArquivoJson($nomeArquivo, $documento);
        $this->processoRepository->salvar($processo);

        return $processo;
    }

    /** @return array<string, mixed> */
    public function lerDescritorUpload(array $arquivosEnviados, string $arquivoPrincipal): array
    {
        $arquivos = $this->normalizarArquivosEnviados($arquivosEnviados);
        $arquivo = $arquivos[$arquivoPrincipal] ?? null;
        if (!$arquivo instanceof UploadedFileInterface || $arquivo->getError() !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException('O arquivo JSON principal do processo não foi recebido corretamente.');
        }

        $stream = $arquivo->getStream();
        $stream->rewind();
        $conteudo = $stream->getContents();
        $stream->rewind();

        try {
            $metadados = json_decode($conteudo, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $erro) {
            throw new InvalidArgumentException('O descritor selecionado não contém JSON válido.', 0, $erro);
        }

        if (!is_array($metadados)) {
            throw new InvalidArgumentException('O descritor selecionado deve conter um objeto JSON.');
        }
        if (($metadados['arquivo'] ?? null) !== $arquivoPrincipal) {
            throw new InvalidArgumentException('O nome do arquivo enviado não corresponde ao descritor principal.');
        }

        $this->arquivosDoMetaDescritor($metadados);

        return $metadados;
    }

    public function gerarId(string $nome, int $versao): string
    {
        $palavras = preg_split('/[^\p{L}\p{N}]+/u', trim($nome), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $palavras = array_map(fn (string $palavra): string => $this->semAcentos($palavra), $palavras);

        if ($palavras === []) {
            throw new InvalidArgumentException('Informe um nome valido para o processo.');
        }

        $id = ucfirst(strtolower($palavras[0]));
        foreach (array_slice($palavras, 1) as $palavra) {
            $id .= ucfirst(strtolower(substr($palavra, 0, 4)));
        }

        return $id . 'V' . $versao;
    }

    private function semAcentos(string $valor): string
    {
        return strtr($valor, [
            'Á' => 'A', 'À' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A',
            'á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
            'É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'Í' => 'I', 'Ì' => 'I', 'Î' => 'I', 'Ï' => 'I',
            'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
            'Ó' => 'O', 'Ò' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O',
            'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
            'Ú' => 'U', 'Ù' => 'U', 'Û' => 'U', 'Ü' => 'U',
            'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
            'Ç' => 'C', 'ç' => 'c',
        ]);
    }

    /** @return array<string, mixed> */
    private function lerUploadJson(UploadedFileInterface $arquivo): array
    {
        if ($arquivo->getError() !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException('Selecione um arquivo JSON valido.');
        }

        $conteudo = $arquivo->getStream()->getContents();
        $json = json_decode($conteudo, true);

        if (!is_array($json)) {
            throw new InvalidArgumentException('O arquivo selecionado nao contem um JSON valido.');
        }

        return $json;
    }

    private function salvarArquivoJson(string $nomeArquivo, array $documento): void
    {
        $diretorio = dirname(__DIR__, 2) . '/jsons';

        if (!is_dir($diretorio) && !mkdir($diretorio, 0775, true) && !is_dir($diretorio)) {
            throw new RuntimeException('Nao foi possivel criar a pasta app/jsons.');
        }

        $conteudo = json_encode($documento, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($conteudo === false || file_put_contents($diretorio . '/' . $nomeArquivo, $conteudo, LOCK_EX) === false) {
            throw new RuntimeException('Nao foi possivel salvar o arquivo JSON do processo.');
        }
    }

    private function textoDono(mixed $valor): ?string
    {
        if ($valor === null || trim((string) $valor) === '') {
            throw new InvalidArgumentException('O campo dono_processo deve ser informado no arquivo JSON.');
        }

        $dono = trim((string) $valor);

        if (strlen($dono) > 15) {
            throw new InvalidArgumentException('O dono do processo deve ter no maximo 15 caracteres.');
        }

        return $dono;
    }

    /** @return array<int, string> */
    private function listaJson(array $documento, string $campo): array
    {
        $valor = $documento[$campo] ?? [];

        if (!is_array($valor)) {
            throw new InvalidArgumentException("O campo {$campo} deve ser um array no arquivo JSON.");
        }

        return array_values(array_filter(array_map(
            static fn (mixed $item): string => trim((string) $item),
            $valor
        ), static fn (string $item): bool => $item !== ''));
    }

    /** @return array<int, string> */
    private function listaSubprocessosJson(array $documento): array
    {
        return $this->listaJson(
            $documento,
            array_key_exists('lista_subprocessos', $documento)
                ? 'lista_subprocessos'
                : (array_key_exists('subprocessos', $documento) ? 'subprocessos' : 'lista_processos')
        );
    }

    /** @return array<int, string> */
    private function arquivosDoMetaDescritor(array $metadados): array
    {
        $arquivoPrincipal = trim((string) ($metadados['arquivo'] ?? ''));
        if (!$this->nomeArquivoJsonValido($arquivoPrincipal)) {
            throw new InvalidArgumentException('O descritor deve informar um nome de arquivo JSON principal válido.');
        }

        $subprocessos = $metadados['subprocessos']
            ?? $metadados['lista_subprocessos']
            ?? $metadados['lista_processos']
            ?? [];
        if (!is_array($subprocessos)) {
            throw new InvalidArgumentException('A lista de subprocessos do descritor deve ser um array.');
        }

        $arquivos = [$arquivoPrincipal];
        foreach ($subprocessos as $subprocesso) {
            if (!is_string($subprocesso) || trim($subprocesso) === '') {
                throw new InvalidArgumentException('O descritor contém um nome de subprocesso inválido.');
            }
            $nomeArquivo = trim($subprocesso);
            if (!$this->nomeArquivoJsonValido($nomeArquivo)) {
                throw new InvalidArgumentException('Os arquivos dos subprocessos devem ser nomes JSON simples.');
            }
            $arquivos[] = $nomeArquivo;
        }

        if (count(array_unique($arquivos)) !== count($arquivos)) {
            throw new InvalidArgumentException('O descritor repete o nome de um arquivo JSON.');
        }

        return $arquivos;
    }

    /**
     * @param array<string, mixed> $metadados
     * @param array<string, array{0: string, 1: array<string, mixed>}> $documentos
     */
    private function criarProcessoDoPacote(array $metadados, array $documentos): Processo
    {
        $arquivoPrincipal = (string) ($metadados['arquivo'] ?? '');
        if (!isset($documentos[$arquivoPrincipal][1])) {
            throw new InvalidArgumentException('O pacote não contém o JSON principal do processo.');
        }
        $documentoPrincipal = $documentos[$arquivoPrincipal][1];
        if (!isset($documentoPrincipal['elementos']) || !is_array($documentoPrincipal['elementos'])) {
            throw new InvalidArgumentException('O JSON principal deve conter a lista de elementos do processo.');
        }

        $nome = trim((string) ($documentoPrincipal['nome'] ?? ''));
        if ($nome === '' || $nome !== trim((string) ($metadados['nome'] ?? ''))) {
            throw new InvalidArgumentException('O nome do JSON principal não corresponde ao descritor exibido.');
        }
        if ($this->versaoNumerica($documentoPrincipal['versao'] ?? 1)
            !== $this->versaoNumerica($metadados['versao'] ?? 1)
        ) {
            throw new InvalidArgumentException('A versão do JSON principal não corresponde ao descritor exibido.');
        }
        if ($this->arquivosDoMetaDescritor($documentoPrincipal) !== array_keys($documentos)) {
            throw new InvalidArgumentException('A lista de subprocessos do JSON não corresponde ao descritor exibido.');
        }

        $versao = $this->versaoNumerica($documentoPrincipal['versao'] ?? $metadados['versao'] ?? 1);

        return Processo::fromArray(array_merge($documentoPrincipal, [
            'id' => $this->gerarId($nome, $versao),
            'nome' => $nome,
            'descricao' => trim((string) ($documentoPrincipal['descricao'] ?? '')) ?: null,
            'versao' => $versao,
            'arquivo' => $arquivoPrincipal,
            'status' => true,
            'dono_processo' => $this->textoDono($documentoPrincipal['dono_processo'] ?? null),
            'lista_subprocessos' => $this->listaSubprocessosJson($documentoPrincipal),
            'raias_participantes' => $this->listaJson($documentoPrincipal, 'raias_participantes'),
        ]));
    }

    /**
     * @param array<string, mixed> $arquivosEnviados
     * @return array<string, UploadedFileInterface>
     */
    private function normalizarArquivosEnviados(array $arquivosEnviados): array
    {
        $arquivos = $arquivosEnviados['arquivos'] ?? $arquivosEnviados;
        $resultado = [];
        foreach ($arquivos as $nome => $arquivo) {
            if (!$arquivo instanceof UploadedFileInterface || !is_string($nome)) {
                throw new InvalidArgumentException('A lista de arquivos enviados é inválida.');
            }
            if (!$this->nomeArquivoJsonValido($nome)) {
                throw new InvalidArgumentException('Foi enviado um nome de arquivo JSON inválido.');
            }
            $resultado[$nome] = $arquivo;
        }

        return $resultado;
    }

    private function nomeArquivoJsonValido(string $nome): bool
    {
        return $nome !== ''
            && trim($nome) === $nome
            && basename($nome) === $nome
            && !str_contains($nome, '\\')
            && !str_contains($nome, '[')
            && !str_contains($nome, ']')
            && preg_match('/[\x00-\x1F]/', $nome) !== 1
            && strtolower(pathinfo($nome, PATHINFO_EXTENSION)) === 'json';
    }

    private function versaoNumerica(mixed $versao): int
    {
        if (is_numeric($versao) && (float) $versao > 0 && floor((float) $versao) === (float) $versao) {
            return (int) $versao;
        }

        throw new InvalidArgumentException('A versão do processo deve ser um número inteiro positivo.');
    }
}