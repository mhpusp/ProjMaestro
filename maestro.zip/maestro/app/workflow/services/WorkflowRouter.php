<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\workflow\contracts\WorkflowHistInterface;
use App\workflow\contracts\WorkflowEventDispatcherInterface;
use App\workflow\contracts\WorkflowMetaInterface;
use App\workflow\contracts\WorkflowMapInterface;
use App\workflow\contracts\WorkflowNotesInterface;
use App\workflow\contracts\WorkflowRouterInterface;
use RuntimeException;

class WorkflowRouter implements WorkflowRouterInterface
{
    /** @var array<string, mixed>|null */
    private ?array $instanciaAtual = null;
    /** @var array<string, array<string, mixed>> */
    private array $mapForward = [];
    /** @var array<int, array<string, mixed>> */
    private array $mapBackward = [];
    /** @var array<string, mixed>|null */
    private ?array $noAtual = null;
    /** @var array<string, mixed> */
    private array $dadosFormAtual = [];

    public function __construct(
        private readonly WorkflowHistInterface $workflowHist,
        private readonly WorkflowMetaInterface $workflowMeta,
        private readonly WorkflowMapInterface $workflowMap,
        private readonly WorkflowNotesInterface $workflowNotes,
        private readonly ?WorkflowEventDispatcherInterface $eventDispatcher = null
    ) {
    }

    public function carregarInstancia(int $instanciaId, ?string $elementoId = null): array
    {
        $instancia = $this->workflowHist->obterInstancia($instanciaId);
        if ($instancia === null) {
            throw new RuntimeException("Instância de processo não encontrada: {$instanciaId}");
        }
        if ((bool) ($instancia['instancia_concluida'] ?? false)) {
            throw new RuntimeException('A instância já foi concluída; a situação 3 será implementada separadamente.');
        }

        $this->instanciaAtual = $instancia;
        $this->mapForward = $this->workflowMap->carregarMapForward($instancia);
        $elementos = $this->workflowHist->listarElementos($instanciaId);
        $this->mapBackward = array_values(array_filter(
            $elementos,
            static fn (array $elemento): bool => (bool) ($elemento['concluido'] ?? false)
        ));

        if ($elementoId !== null) {
            if (!isset($this->mapForward[$elementoId])) {
                throw new RuntimeException("Elemento não pertence ao processo da instância: {$elementoId}");
            }
            $proximoNaTrilha = $this->obterProximoNoDaTrilha();
            $elementoConcluido = false;
            foreach ($this->mapBackward as $elementoHistorico) {
                if ((string) ($elementoHistorico['elemento_id'] ?? '') === $elementoId) {
                    $elementoConcluido = true;
                    break;
                }
            }
            if ($elementoId !== $proximoNaTrilha && !$elementoConcluido) {
                throw new RuntimeException('O elemento solicitado não pertence ao caminho atual da instância.');
            }
            $noIdAtual = $elementoId;
        } elseif ($this->mapBackward !== []) {
            $noIdAtual = $this->obterProximoNoDaTrilha();
        } else {
            $noIdAtual = $this->encontrarNoInicial();
        }

        $this->noAtual = $this->mapForward[$noIdAtual];
        $this->dadosFormAtual = $this->dadosFormDoElemento($elementos, $noIdAtual);
        $idAnterior = $this->resolverNoAnterior($noIdAtual);
        $idProximo = $this->resolverDestino($this->noAtual, $this->dadosFormAtual);
        $tipoNoAtual = strtolower((string) ($this->noAtual['tipo'] ?? ''));

        return [
            'instancia' => $instancia,
            'mapForward' => $this->mapForward,
            'mapBackward' => $this->mapBackward,
            'noAtual' => $this->noAtual,
            'elementoId' => $noIdAtual,
            'dadosForm' => $this->dadosFormAtual,
            'noAnteriorId' => $idAnterior,
            'proximoNoId' => $idProximo,
            'podeAvancar' => $idProximo !== null
                || $tipoNoAtual === 'fim'
                || (in_array(trim((string) ($this->noAtual['destino'] ?? '')), ['', 'respostas'], true)
                    && is_array($this->noAtual['respostas'] ?? null)
                    && $this->noAtual['respostas'] !== []),
            'ehNoFinal' => $tipoNoAtual === 'fim',
            'arquivoNo' => $this->workflowMap->resolverArquivoNo($instancia, $this->noAtual),
            'definicaoProcesso' => $this->workflowMap->carregarDefinicao($instancia),
            'dadosFormAnterior' => $this->dadosFormDoUltimoElemento($this->mapBackward),
        ];
    }

    public function prepararInstanciacao(string $processoId): array
    {
        $processo = $this->workflowMeta->obterParaInstanciar($processoId);
        if ($processo === null) {
            throw new RuntimeException("Processo disponível para instanciação não encontrado: {$processoId}");
        }

        $this->mapForward = $this->workflowMap->carregarMapForward($processo);
        $noInicialId = $this->encontrarNoInicial();
        $this->instanciaAtual = $processo;
        $this->noAtual = $this->mapForward[$noInicialId];
        $this->mapBackward = [];
        $this->dadosFormAtual = [];

        return [
            'instancia' => ['id' => null, 'processo_id' => $processoId],
            'processo' => $processo,
            'mapForward' => $this->mapForward,
            'mapBackward' => [],
            'noAtual' => $this->noAtual,
            'elementoId' => $noInicialId,
            'dadosForm' => [],
            'noAnteriorId' => null,
            'proximoNoId' => $this->resolverDestino($this->noAtual, []),
            'podeAvancar' => true,
            'ehNoFinal' => false,
            'modoInstanciacao' => true,
            'arquivoNo' => $this->workflowMap->resolverArquivoNo($processo, $this->noAtual),
        ];
    }

    public function cancelarInstanciacao(): void
    {
        $this->limparEstado();
    }

    public function iniciarProcesso(string $processoId, string $criadoPor, array $dadosForm): array
    {
        $estado = $this->prepararInstanciacao($processoId);
        if (($dadosForm['resposta'] ?? null) !== 'Sim') {
            throw new RuntimeException('A instanciação requer confirmação afirmativa no nó inicial.');
        }

        $instanciaId = $this->workflowHist->instanciarProcesso(
            $processoId,
            $criadoPor,
            $estado['noAtual'],
            $dadosForm
        );
        $proximoNoId = $estado['proximoNoId'];
        if (!is_string($proximoNoId) || $proximoNoId === '') {
            throw new RuntimeException('O nó inicial do processo não define um próximo destino.');
        }

        return $this->carregarInstancia($instanciaId, $proximoNoId);
    }

    public function avancar(
        int $instanciaId,
        string $elementoId,
        array $dadosForm,
        array $arquivosEnviados = [],
        array $contextoEvento = []
    ): array
    {
        $estado = $this->carregarInstancia($instanciaId, $elementoId);
        if ($estado['ehNoFinal']) {
            $respostas = is_array($estado['noAtual']['respostas'] ?? null)
                ? $estado['noAtual']['respostas']
                : [];
            $resposta = $dadosForm['resposta'] ?? null;

            if ($respostas !== [] && (!is_string($resposta) || !array_key_exists($resposta, $respostas))) {
                throw new RuntimeException('Selecione uma opção válida para o nó final.');
            }

            if ($respostas !== [] && !$this->respostaConfirmaConclusao($respostas[$resposta])) {
                return $estado;
            }

            $this->workflowHist->consolidarElemento($instanciaId, $estado['noAtual'], $dadosForm);
            $this->workflowHist->concluirInstancia($instanciaId);
            $this->limparEstado();

            return ['concluida' => true];
        }

        $proximoNoId = $this->resolverDestino($estado['noAtual'], $dadosForm);
        if ($proximoNoId === null) {
            throw new RuntimeException('O nó atual não possui um próximo destino navegável.');
        }

        $eventos = $estado['noAtual']['evento'] ?? [];
        if (!is_array($eventos)) {
            throw new RuntimeException('A lista de eventos do nó atual é inválida.');
        }
        $resultadosEventos = [];
        foreach ($eventos as $assinatura) {
            if (!is_string($assinatura) || trim($assinatura) === '') {
                throw new RuntimeException('A definição contém uma assinatura de evento inválida.');
            }
            if ($this->eventDispatcher === null) {
                throw new RuntimeException('O dispatcher de eventos do workflow não foi configurado.');
            }

            $contexto = array_merge($contextoEvento, [
                'instancia_id' => $instanciaId,
                'no_id' => $elementoId,
                'dados_form' => $dadosForm,
                'uploaded_files' => $arquivosEnviados,
                'definicao_processo' => $estado['definicaoProcesso'],
                'no_descritor' => $resultadosEventos['uploadArquivos']['descritor']
                    ?? $estado['definicaoProcesso'],
                'no_atual' => $estado['noAtual'],
                'processo' => $estado['instancia'],
                'evento_resultados' => $resultadosEventos,
            ]);
            $resultado = $this->eventDispatcher->dispatch($assinatura, $contexto);

            if (is_array($resultado) && ($resultado['confirmation_required'] ?? false) === true) {
                return [
                    'confirmacaoSubstituicao' => true,
                    'metadadosUpload' => $resultado['descritor'] ?? null,
                ];
            }

            [$nomeEvento] = $this->nomeEvento($assinatura);
            $resultadosEventos[$nomeEvento] = $resultado;
        }
        if ($resultadosEventos !== []) {
            $dadosForm['resultado_eventos'] = $resultadosEventos;
        }

        $this->workflowHist->consolidarElemento($instanciaId, $estado['noAtual'], $dadosForm);

        return $this->carregarInstancia($instanciaId, $proximoNoId);
    }

    public function voltar(int $instanciaId, string $elementoId): array
    {
        $estado = $this->carregarInstancia($instanciaId, $elementoId);
        $noAnteriorId = $estado['noAnteriorId'];
        if ($noAnteriorId === null) {
            throw new RuntimeException('Não há nó anterior no histórico desta instância.');
        }

        return $this->carregarInstancia($instanciaId, $noAnteriorId);
    }

    public function fechar(int $instanciaId, string $elementoId, int $usuarioId): int
    {
        $estado = $this->carregarInstancia($instanciaId, $elementoId);
        if ((bool) ($estado['instancia']['instancia_concluida'] ?? false)) {
            throw new RuntimeException('Não é possível fechar pelo roteador uma instância já concluída.');
        }

        $tarefaId = $this->workflowNotes->criarTarefaRetomada(
            $usuarioId,
            $instanciaId,
            (string) ($estado['instancia']['processo_id'] ?? ''),
            (string) ($estado['instancia']['processo_nome'] ?? 'Processo'),
            (string) ($estado['noAtual']['nome'] ?? 'Etapa do processo')
        );
        $this->limparEstado();

        return $tarefaId;
    }

    private function respostaConfirmaConclusao(mixed $valor): bool
    {
        return $valor === true
            || $valor === 1
            || (is_string($valor) && in_array(strtolower(trim($valor)), ['true', '1', 'sim', 'yes'], true));
    }

    private function limparEstado(): void
    {
        $this->instanciaAtual = null;
        $this->mapForward = [];
        $this->mapBackward = [];
        $this->noAtual = null;
        $this->dadosFormAtual = [];
    }

    private function encontrarNoInicial(): string
    {
        foreach ($this->mapForward as $id => $elemento) {
            if (strtolower((string) ($elemento['tipo'] ?? '')) === 'inicio') {
                return $id;
            }
        }

        throw new RuntimeException('O mapa do processo não contém um nó inicial.');
    }

    private function obterProximoNoDaTrilha(): string
    {
        if ($this->mapBackward === []) {
            return $this->encontrarNoInicial();
        }

        $ultimoConcluido = $this->mapBackward[array_key_last($this->mapBackward)];
        $ultimoNoId = (string) ($ultimoConcluido['elemento_id'] ?? '');
        if (!isset($this->mapForward[$ultimoNoId])) {
            throw new RuntimeException("Elemento histórico não existe no mapa estático: {$ultimoNoId}");
        }

        $proximoNoId = $this->resolverDestino(
            $this->mapForward[$ultimoNoId],
            (array) ($ultimoConcluido['dados_form'] ?? [])
        );
        if ($proximoNoId === null) {
            throw new RuntimeException('O último elemento concluído não define um próximo nó navegável.');
        }

        return $proximoNoId;
    }

    /** @param array<string, mixed> $elemento
     *  @param array<string, mixed> $dadosForm
     */
    private function resolverDestino(array $elemento, array $dadosForm): ?string
    {
        $destino = trim((string) ($elemento['destino'] ?? ''));
        if ($destino !== '' && $destino !== 'respostas' && isset($this->mapForward[$destino])) {
            return $destino === (string) ($elemento['id'] ?? '') ? null : $destino;
        }

        if ($destino === '' || $destino === 'respostas') {
            $resposta = $dadosForm['resposta'] ?? null;
            if (is_scalar($resposta)) {
                $destinoResposta = $elemento['respostas'][(string) $resposta] ?? null;
                if (is_string($destinoResposta) && isset($this->mapForward[$destinoResposta])) {
                    return $destinoResposta;
                }
            }
        }

        return null;
    }

    private function resolverNoAnterior(string $noIdAtual): ?string
    {
        $origem = trim((string) ($this->mapForward[$noIdAtual]['origem'] ?? ''));
        if ($origem !== '' && $origem !== $noIdAtual) {
            foreach ($this->mapBackward as $elemento) {
                if ((string) ($elemento['elemento_id'] ?? '') === $origem) {
                    return $origem;
                }
            }
        }

        $indiceAtual = null;
        foreach ($this->mapBackward as $indice => $elemento) {
            if ((string) ($elemento['elemento_id'] ?? '') === $noIdAtual) {
                $indiceAtual = $indice;
                break;
            }
        }

        if ($indiceAtual !== null) {
            return $indiceAtual === 0
                ? null
                : (string) $this->mapBackward[$indiceAtual - 1]['elemento_id'];
        }

        if ($this->mapBackward === []) {
            return null;
        }

        return (string) $this->mapBackward[array_key_last($this->mapBackward)]['elemento_id'];
    }

    /**
     * @param array<int, array<string, mixed>> $elementos
     * @return array<string, mixed>
     */
    private function dadosFormDoElemento(array $elementos, string $elementoId): array
    {
        foreach ($elementos as $elemento) {
            if ((string) ($elemento['elemento_id'] ?? '') === $elementoId) {
                return is_array($elemento['dados_form'] ?? null) ? $elemento['dados_form'] : [];
            }
        }

        return [];
    }

    /**
     * @param array<int, array<string, mixed>> $elementos
     * @return array<string, mixed>
     */
    private function dadosFormDoUltimoElemento(array $elementos): array
    {
        if ($elementos === []) {
            return [];
        }

        $ultimo = $elementos[array_key_last($elementos)];
        $dados = $ultimo['dados_form'] ?? [];

        return is_array($dados) ? $dados : [];
    }

    /** @return array{0: string, 1: array<int, string>} */
    private function nomeEvento(string $assinatura): array
    {
        if (!preg_match('/^([A-Za-z_][A-Za-z0-9_]*)/', trim($assinatura), $matches)) {
            throw new RuntimeException('Não foi possível identificar o nome do evento do nó.');
        }

        return [$matches[1], []];
    }
}