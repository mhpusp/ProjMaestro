<?php

declare(strict_types=1);

namespace App\workflow\services;

use App\workflow\contracts\WorkflowHistInterface;
use App\workflow\repositories\WorkflowHistRepository;

class WorkflowHist implements WorkflowHistInterface
{
    public function __construct(private readonly WorkflowHistRepository $repository)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function listarInstancias(): array
    {
        return $this->repository->listarInstancias();
    }

    public function obterInstancia(int $instanciaId): ?array
    {
        return $this->repository->obterInstancia($instanciaId);
    }

    /** @return array<int, array<string, mixed>> */
    public function listarElementos(int $instanciaId): array
    {
        $elementos = $this->repository->listarElementos($instanciaId);

        foreach ($elementos as &$elemento) {
            $dadosForm = $elemento['dados_form'] ?? null;
            if ($dadosForm === null || $dadosForm === '') {
                $elemento['dados_form'] = [];
                continue;
            }

            if (is_string($dadosForm)) {
                $dadosForm = json_decode($dadosForm, true, 512, JSON_THROW_ON_ERROR);
            }
            if (!is_array($dadosForm)) {
                throw new \RuntimeException('Os dados do formulário do elemento devem ser um objeto JSON.');
            }

            $elemento['dados_form'] = $dadosForm;
        }
        unset($elemento);

        return $elementos;
    }

    public function consolidarElemento(int $instanciaId, array $elemento, array $dadosForm): void
    {
        $this->repository->consolidarElemento($instanciaId, $elemento, $dadosForm);
    }

    public function concluirInstancia(int $instanciaId): void
    {
        $this->repository->concluirInstancia($instanciaId);
    }

    public function instanciarProcesso(
        string $processoId,
        string $criadoPor,
        array $noInicial,
        array $dadosForm
    ): int {
        return $this->repository->instanciarProcesso($processoId, $criadoPor, $noInicial, $dadosForm);
    }
}