<?php

declare(strict_types=1);

namespace App\workflow\events;

use App\workflow\contracts\WorkflowEventHandlerInterface;
use App\workflow\contracts\WorkflowNotesInterface;
class AgendaNotifierEventHandler implements WorkflowEventHandlerInterface
{
    public function __construct(
        private WorkflowNotesInterface $notesService,
        private string $eventKey = 'notificar'
    ) {}

    public function getKey(): string
    {
        return $this->eventKey;
    }

    public function handle(array $params, array $context): mixed
    {
        if (count($params) > 2) {
            throw new \InvalidArgumentException(
                "{$this->eventKey} aceita no máximo tipo e assunto."
            );
        }

        $tipo = $params[0] ?? 'Notificação';
        $assunto = $params[1] ?? 'Nova ação no processo';
        $resultados = $context['evento_resultados'] ?? [];
        $processoCriado = is_array($resultados) ? ($resultados['uploadArquivos'] ?? null) : null;
        $processoAtual = $context['processo'] ?? [];
        $processoId = is_array($processoCriado) && is_string($processoCriado['id'] ?? null)
            ? $processoCriado['id']
            : (is_array($processoAtual) && is_string($processoAtual['processo_id'] ?? null)
                ? $processoAtual['processo_id']
                : null);
        $instanciaId = $context['instancia_id'] ?? null;

        if (!is_string($tipo) || !is_string($assunto)) {
            throw new \InvalidArgumentException('O tipo e o assunto da Agenda devem ser textos.');
        }

        return $this->notesService->notificarAdministradores(
            $tipo,
            $assunto,
            $this->notesService->corDoTipo($tipo),
            $processoId,
            is_int($instanciaId) ? $instanciaId : null
        );
    }
}