<?php

declare(strict_types=1);

namespace App\workflow\events;

use App\workflow\contracts\WorkflowEventHandlerInterface;
use App\workflow\contracts\WorkflowMetaInterface;
