<?php

declare(strict_types=1);

namespace App\workflow\events;

use App\workflow\contracts\WorkflowEventHandlerInterface;
use Psr\Container\ContainerInterface;
use RuntimeException;

class DataFormPersistEventHandler implements WorkflowEventHandlerInterface
{
    public function __construct(
        private ContainerInterface $container // Acesso ao Container de DI do Slim
    ) {}

    public function getKey(): string
    {
        return 'persistir_dados'; // Mapeado no JSON como: "persistir_dados('App\Repositories\VeiculoRepository')"
    }

    public function handle(array $params, array $context): mixed
    {
        // $params[0] contém a classe do Repository do Slim definida na assinatura do JSON
        $repositoryClass = $params[0] ?? null;

        if (!is_string($repositoryClass) || trim($repositoryClass) === '' || !$this->container->has($repositoryClass)) {
            throw new RuntimeException('Repository de negócio não foi encontrado no container do Slim.');
        }

        $repository = $this->container->get($repositoryClass);
        if (!is_object($repository) || !method_exists($repository, 'salvarDadosWorkflow')) {
            throw new RuntimeException(
                "O serviço {$repositoryClass} deve implementar o método salvarDadosWorkflow()."
            );
        }

        $dadosFormulario = $context['dados_form'] ?? [];
        if (!is_array($dadosFormulario)) {
            throw new RuntimeException('O contexto do evento deve conter dados_form como array.');
        }
        if (!isset($context['instancia_id']) || !is_int($context['instancia_id'])) {
            throw new RuntimeException('O contexto do evento deve conter instancia_id como inteiro.');
        }

        return $repository->salvarDadosWorkflow(
            instanciaId: $context['instancia_id'],
            dados: $dadosFormulario
        );
    }
}