<?php

declare(strict_types=1);

namespace App\workflow\events;

use App\workflow\contracts\WorkflowEventHandlerInterface;
use RuntimeException;

class SendEmailEventHandler implements WorkflowEventHandlerInterface
{
    public function getKey(): string
    {
        return 'enviar_email';
    }

    public function handle(array $params, array $context): mixed
    {
        throw new RuntimeException(
            'O evento enviar_email ainda requer um serviço de envio de e-mail configurado.'
        );
    }
}