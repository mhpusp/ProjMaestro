<?php

declare(strict_types=1);

namespace App\workflow\events;

use App\workflow\contracts\WorkflowEventHandlerInterface;
use App\workflow\contracts\WorkflowMetaInterface;
use App\workflow\dto\Processo;
use InvalidArgumentException;
use Psr\Http\Message\UploadedFileInterface;
use RuntimeException;

class UploadFilesEventHandler implements WorkflowEventHandlerInterface
{
    private string $uploadDirectory;

    public function __construct(
        private readonly ?WorkflowMetaInterface $workflowMeta = null,
        private readonly string $eventKey = 'uploadFiles'
    ) {
        $this->uploadDirectory = dirname(__DIR__, 2) . '/workflow/uploads';
    }

    public function getKey(): string
    {
        return $this->eventKey;
    }

    /**
     * Recebe os uploads PSR-7 da chave uploaded_files no contexto.
     * O primeiro parâmetro opcional seleciona um campo; os nomes enviados
     * pelo cliente nunca são usados como caminho de armazenamento.
     *
     * @return array<int, array{field: string, original_name: ?string, stored_name: string, path: string, size: ?int, media_type: ?string}>
     */
    public function handle(array $params, array $context): array
    {
        if ($this->eventKey === 'uploadArquivos') {
            if ($params !== []) {
                throw new InvalidArgumentException('uploadArquivos não aceita parâmetros no nó.');
            }
            if ($this->workflowMeta === null) {
                throw new RuntimeException('O evento uploadArquivos não foi configurado com WorkflowMeta.');
            }

            $arquivosEnviados = $context['uploaded_files'] ?? null;
            if (!is_array($arquivosEnviados)) {
                throw new InvalidArgumentException('O evento uploadArquivos requer os arquivos enviados.');
            }

            $dadosForm = $context['dados_form'] ?? [];
            if (!is_array($dadosForm)) {
                throw new InvalidArgumentException('Os dados do formulário do upload são inválidos.');
            }

            $decisao = $dadosForm['decisao_arquivos'] ?? null;
            if ($decisao === 'manter') {
                $metadados = $this->metadadosConfirmados($dadosForm);
                if (!$this->workflowMeta->pacoteExistente($metadados)) {
                    throw new InvalidArgumentException('Não há pacote existente para manter.');
                }

                return $this->resultadoProcesso($this->workflowMeta->incluirPacoteExistente($metadados));
            }

            $arquivoPrincipal = $dadosForm['arquivo_principal'] ?? null;
            if (!is_string($arquivoPrincipal) || $arquivoPrincipal === '') {
                throw new InvalidArgumentException('Selecione o arquivo JSON principal do processo.');
            }
            $metadados = $this->workflowMeta->lerDescritorUpload($arquivosEnviados, $arquivoPrincipal);
            $pacoteExistente = $this->workflowMeta->pacoteExistente($metadados);
            if ($pacoteExistente && $decisao !== 'substituir') {
                return ['confirmation_required' => true, 'descritor' => $metadados];
            }

            $processo = $this->workflowMeta->incluirPacote(
                $metadados,
                $arquivosEnviados,
                $pacoteExistente && $decisao === 'substituir'
            );

            return $this->resultadoProcesso($processo);
        }

        if (count($params) > 1) {
            throw new InvalidArgumentException('uploadFiles aceita no máximo o nome de um campo de upload.');
        }

        $uploadedFiles = $context['uploaded_files'] ?? null;
        if (!is_array($uploadedFiles)) {
            throw new InvalidArgumentException('O contexto do evento deve conter uploaded_files como array.');
        }

        $field = $params[0] ?? null;
        if ($field !== null) {
            if (!array_key_exists($field, $uploadedFiles)) {
                throw new InvalidArgumentException("Campo de upload não encontrado: {$field}");
            }
            $selectedFiles = [$field => $uploadedFiles[$field]];
        } else {
            $selectedFiles = $uploadedFiles;
        }

        $files = [];
        foreach ($selectedFiles as $fieldName => $uploadedFile) {
            $this->flattenUploadedFiles($uploadedFile, (string) $fieldName, $files);
        }

        if ($files === []) {
            throw new InvalidArgumentException('Nenhum arquivo válido foi enviado para upload.');
        }

        $this->ensureUploadDirectory();
        $savedFiles = [];

        foreach ($files as [$fieldName, $uploadedFile]) {
            $error = $uploadedFile->getError();
            if ($error === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            if ($error !== UPLOAD_ERR_OK) {
                throw new RuntimeException("Falha no upload do campo {$fieldName} (código {$error}).");
            }

            $storedName = bin2hex(random_bytes(16));
            $destination = $this->uploadDirectory . '/' . $storedName;
            $uploadedFile->moveTo($destination);

            $savedFiles[] = [
                'field' => $fieldName,
                'original_name' => $uploadedFile->getClientFilename(),
                'stored_name' => $storedName,
                'path' => 'workflow/uploads/' . $storedName,
                'size' => $uploadedFile->getSize(),
                'media_type' => $uploadedFile->getClientMediaType(),
            ];
        }

        if ($savedFiles === []) {
            throw new InvalidArgumentException('Nenhum arquivo válido foi enviado para upload.');
        }

        return $savedFiles;
    }

    /**
     * @param array<int, array{0: string, 1: UploadedFileInterface}> $files
     */
    private function flattenUploadedFiles(mixed $uploadedFile, string $fieldName, array &$files): void
    {
        if ($uploadedFile instanceof UploadedFileInterface) {
            $files[] = [$fieldName, $uploadedFile];
            return;
        }

        if (!is_array($uploadedFile)) {
            throw new InvalidArgumentException("Upload inválido no campo {$fieldName}.");
        }

        foreach ($uploadedFile as $nestedFile) {
            $this->flattenUploadedFiles($nestedFile, $fieldName, $files);
        }
    }

    private function ensureUploadDirectory(): void
    {
        if (!is_dir($this->uploadDirectory)
            && !mkdir($this->uploadDirectory, 0700, true)
            && !is_dir($this->uploadDirectory)
        ) {
            throw new RuntimeException('Não foi possível criar o diretório privado de uploads do workflow.');
        }

        if (!is_writable($this->uploadDirectory)) {
            throw new RuntimeException('O diretório privado de uploads do workflow não permite gravação.');
        }
    }

    /** @return array{id: string, nome: string, descritor: array<string, mixed>} */
    private function resultadoProcesso(Processo $processo): array
    {
        return [
            'id' => $processo->id,
            'nome' => $processo->nome,
            'descritor' => [
                'id' => $processo->id,
                'nome' => $processo->nome,
                'descricao' => $processo->descricao,
                'versao' => $processo->versao,
                'arquivo' => $processo->arquivo,
                'dono_processo' => $processo->donoProcesso,
                'lista_subprocessos' => $processo->listaSubprocessos,
                'raias_participantes' => $processo->raiasParticipantes,
            ],
        ];
    }

    /** @param array<string, mixed> $dadosForm
     * @return array<string, mixed>
     */
    private function metadadosConfirmados(array $dadosForm): array
    {
        $json = $dadosForm['metadados_descritor'] ?? null;
        if (!is_string($json) || $json === '') {
            throw new InvalidArgumentException('Os dados do descritor para confirmação não foram informados.');
        }

        try {
            $metadados = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $erro) {
            throw new InvalidArgumentException('Os dados do descritor para confirmação são inválidos.', 0, $erro);
        }

        if (!is_array($metadados)) {
            throw new InvalidArgumentException('Os dados do descritor para confirmação são inválidos.');
        }

        return $metadados;
    }
}
