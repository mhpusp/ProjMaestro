<?php

declare(strict_types=1);

namespace App\models;

use App\services\VersaoCodigoService;
use App\suporte\LoggerArquivo;
use Closure;
use PDO;
use Throwable;

/**
 * Model responsavel por informar o estado basico da aplicacao.
 */
class SaudeModel
{
    /**
     * @param array<string, mixed> $configuracao Configuracoes carregadas do ambiente.
     * @param Closure(): (?PDO) $conectarBanco Fabrica preguicosa da conexao PDO.
     */
    public function __construct(
        private readonly array $configuracao,
        private readonly Closure $conectarBanco,
        private readonly LoggerArquivo $logger,
        private readonly VersaoCodigoService $versaoCodigo
    ) {
    }

    /**
     * Retorna dados simples para verificacao de saude.
     *
     * @return array<string, mixed>
     */
    public function resumo(): array
    {
        $banco = $this->verificarBanco();
        $codigo = $this->versaoCodigo->resumo();
        $status = $banco['status'] === 'disponivel' || $banco['status'] === 'nao_configurado'
            ? 'ok'
            : 'degradado';

        if ($codigo['status'] !== 'disponivel') {
            $status = 'degradado';
        }

        return [
            'status' => $status,
            'aplicacao' => (string) $this->configuracao['app']['nome'],
            'ambiente' => (string) $this->configuracao['app']['ambiente'],
            'php' => PHP_VERSION,
            'codigo' => $codigo,
            'banco' => $banco,
        ];
    }

    /**
     * Verifica a conexao com banco apenas quando a rota de saude eh chamada.
     *
     * @return array<string, string>
     */
    private function verificarBanco(): array
    {
        try {
            $pdo = ($this->conectarBanco)();

            if (!$pdo instanceof PDO) {
                return [
                    'status' => 'nao_configurado',
                    'mensagem' => 'Banco de dados nao configurado.',
                ];
            }

            $pdo->query('SELECT 1');

            return [
                'status' => 'disponivel',
                'mensagem' => 'Conexao com banco de dados disponivel.',
            ];
        } catch (Throwable $erro) {
            $this->logger->registrar('aviso', 'Falha ao verificar banco de dados.', [
                'erro' => $erro::class,
                'mensagem' => $erro->getMessage(),
            ]);

            return [
                'status' => 'indisponivel',
                'mensagem' => 'Banco de dados indisponivel.',
            ];
        }
    }
}
