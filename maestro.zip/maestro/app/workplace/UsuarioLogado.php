<?php

declare(strict_types=1);

namespace App\workplace;

/**
 * Representa o usuario autenticado no contexto institucional.
 */
class UsuarioLogado
{
    /**
     * @param array<int, PapelInstitucional> $papeis
     */
    public function __construct(
        public readonly string $id,
        public readonly string $nome,
        public readonly string $email,
        public readonly string $telefoneWhatsapp,
        private readonly array $papeis,
        public readonly ?string $codpes = null
    ) {
    }

    /**
     * Cria um usuario ficticio para desenvolvimento local.
     */
    public static function mockDesenvolvimento(): self
    {
        return new self(
            'mock-001',
            'Maria Silva',
            'maria.silva@poli.usp.br',
            '+5511999990000',
            [
                new PapelInstitucional('admin', 'Administrador', 'Acesso administrativo ao scaffold.'),
                new PapelInstitucional('operador', 'Operador', 'Operacao de rotinas institucionais.'),
                new PapelInstitucional('leitor', 'Leitor', 'Consulta de informacoes sem alteracao.'),
            ],
            'mock-001'
        );
    }

    /**
     * Cria um usuario a partir da configuracao local de desenvolvimento.
     *
     * @param array<string, mixed> $dados
     * @param array<int, PapelInstitucional> $papeis
     */
    public static function desenvolvimentoConfigurado(array $dados, array $papeis): self
    {
        $codpes = (string) ($dados['codpes'] ?? '0000000');

        return new self(
            $codpes,
            (string) ($dados['nome'] ?? 'Usuario Desenvolvimento'),
            (string) ($dados['email'] ?? 'usuario.dev@example.test'),
            (string) ($dados['telefone_whatsapp'] ?? ''),
            $papeis,
            $codpes
        );
    }

    /**
     * Cria um usuario autenticado a partir dos atributos retornados pelo OpenSSO.
     *
     * @param array<string, string> $atributos
     * @param array<int, PapelInstitucional> $papeis
     */
    public static function fromOpenSso(array $atributos, array $papeis): self
    {
        $codpes = (string) $atributos['codpes'];

        return new self(
            $codpes,
            (string) $atributos['nompes'],
            (string) $atributos['codema'],
            '',
            $papeis,
            $codpes
        );
    }

    /**
     * @return array<int, PapelInstitucional>
     */
    public function papeis(): array
    {
        return $this->papeis;
    }

    public function papelPorCodigo(string $codigo): ?PapelInstitucional
    {
        foreach ($this->papeis as $papel) {
            if ($papel->codigo === $codigo) {
                return $papel;
            }
        }

        return null;
    }

    public function primeiroPapel(): PapelInstitucional
    {
        return $this->papeis[0];
    }

    /**
     * @return array<string, mixed>
     */
    public function paraArray(): array
    {
        return [
            'id' => $this->id,
            'codpes' => $this->codpes ?? $this->id,
            'nome' => $this->nome,
            'email' => $this->email,
            'telefone_whatsapp' => $this->telefoneWhatsapp,
            'papeis' => array_map(
                static fn (PapelInstitucional $papel): array => $papel->paraArray(),
                $this->papeis
            ),
        ];
    }
}
