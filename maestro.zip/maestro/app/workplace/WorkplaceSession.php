<?php

declare(strict_types=1);

namespace App\workplace;

/**
 * Contexto institucional da requisicao atual.
 *
 * Esta classe prepara a integracao futura com SSO, WhatsApp e autorizacao por
 * papeis sem implementar esses provedores nesta fase do scaffold.
 */
class WorkplaceSession
{
    public function __construct(
        public readonly UsuarioLogado $usuario,
        public readonly PapelInstitucional $papelAtivo,
        public readonly string $origem,
        public readonly string $criadaEm
    ) {
    }

    /**
     * Monta uma sessao mockada para ambiente de desenvolvimento.
     */
    public static function mock(?string $codigoPapelAtivo = null): self
    {
        $usuario = UsuarioLogado::mockDesenvolvimento();
        $papelAtivo = $usuario->papelPorCodigo((string) $codigoPapelAtivo) ?? $usuario->primeiroPapel();

        return new self($usuario, $papelAtivo, 'mock-desenvolvimento', date(DATE_ATOM));
    }

    public function podeUsarPapel(string $codigo): bool
    {
        return $this->usuario->papelPorCodigo($codigo) instanceof PapelInstitucional;
    }

    /**
     * @return array<string, mixed>
     */
    public function paraArray(): array
    {
        return [
            'usuario' => $this->usuario->paraArray(),
            'papel_ativo' => $this->papelAtivo->paraArray(),
            'origem' => $this->origem,
            'criada_em' => $this->criadaEm,
        ];
    }
}
