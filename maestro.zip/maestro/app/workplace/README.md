# Workplace

Camada inicial de sessao institucional do scaffold.

## Objetivo

Representar o contexto do usuario logado sem acoplar controllers ao provedor de autenticacao. Rotas autenticadas usam `AutenticacaoSsoMiddleware`, que injeta uma instancia de `WorkplaceSession` no request pelo atributo `workplace`.

## Classes

- `UsuarioLogado`: dados basicos do usuario institucional, `codpes` e lista de papeis disponiveis.
- `PapelInstitucional`: papel que pode ser ativado para autorizacao por perfil.
- `WorkplaceSession`: contexto da requisicao atual, com usuario, papel ativo e origem da sessao.

## SSO por rota

O middleware de SSO nao e global. Cada rota que exige usuario autenticado deve receber explicitamente `AutenticacaoSsoMiddleware` em `config/routes.php`. Isso permite manter rotas publicas, como `/` e `/saude`, sem redirecionamento para login.

Com `SSO_HABILITADO=true`, o middleware:

- le o cookie configurado em `SSO_COOKIE_NAME`;
- consulta `SSO_ATTRIBUTES_URL` com `subjectid`;
- valida `codpes`, `codema` e `nompes`;
- monta `UsuarioLogado`;
- carrega papeis padrao de `SSO_PAPEIS_PADRAO`;
- injeta `WorkplaceSession` no request.

Quando o cookie esta ausente ou invalido, respostas Web recebem redirect para `SSO_LOGIN_URL` com `goto`; rotas API recebem JSON `401` com `codigo_erro: NAO_AUTENTICADO`.

## Desenvolvimento local

Com `SSO_HABILITADO=false`, o middleware usa os valores `DEV_USUARIO_*` do `.env`. O papel ativo fica em `$_SESSION['workplace_papel_ativo']`, e a rota autenticada `POST /workplace/papel` permite alternar entre os papeis configurados.

## Autorizacao

Regras de autorizacao devem consultar `WorkplaceSession` e o papel ativo, substituindo gradualmente os middlewares ficticios por middlewares reais.
