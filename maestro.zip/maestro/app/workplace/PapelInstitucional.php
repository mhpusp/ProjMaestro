<?php

declare(strict_types=1);

namespace App\workplace;

/**
 * Representa um papel institucional disponivel para o usuario logado.
 */
class PapelInstitucional
{
    public function __construct(
        public readonly string $codigo,
        public readonly string $nome,
        public readonly string $descricao
    ) {
    }

    /**
     * Retorna dados simples para views, logs e APIs futuras.
     *
     * @return array<string, string>
     */
    public function paraArray(): array
    {
        return [
            'codigo' => $this->codigo,
            'nome' => $this->nome,
            'descricao' => $this->descricao,
        ];
    }
}
