<?php

declare(strict_types=1);

namespace App\repositories;

use Redis;
use Throwable;

/**
 * Registra e consulta erros tecnicos em Redis, com fallback local em JSONL.
 */
class ErroRepository
{
    private const CHAVE_LISTA = 'erros:recentes';
    private const CHAVE_ITEM = 'erros:item:';

    public function __construct(
        private readonly string $redisHost,
        private readonly int $redisPorta,
        private readonly int $ttlRedis,
        private readonly string $caminhoFallback
    ) {
    }

    /**
     * Registra erro no Redis quando possivel; caso contrario, grava JSONL local.
     *
     * @param array<string, mixed> $erro
     */
    public function registrar(array $erro): void
    {
        $erro['registrado_em'] = $erro['registrado_em'] ?? date(DATE_ATOM);

        if ($this->registrarRedis($erro)) {
            return;
        }

        $this->registrarFallback($erro);
    }

    /**
     * Lista erros recentes para o painel administrativo.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listarRecentes(int $limite = 50): array
    {
        $redis = $this->conectarRedis();

        if ($redis instanceof Redis) {
            try {
                $codigos = $redis->lRange(self::CHAVE_LISTA, 0, $limite - 1);
                $erros = [];

                foreach ($codigos ?: [] as $codigo) {
                    $json = $redis->get(self::CHAVE_ITEM . $codigo);

                    if (!is_string($json)) {
                        continue;
                    }

                    $erro = json_decode($json, true);

                    if (is_array($erro)) {
                        $erro['origem_registro'] = 'redis';
                        $erros[] = $erro;
                    }
                }

                return $erros;
            } catch (Throwable) {
                // Se Redis falhar durante consulta, mostra o fallback local.
            }
        }

        return $this->listarFallback($limite);
    }

    /**
     * @param array<string, mixed> $erro
     */
    private function registrarRedis(array $erro): bool
    {
        $redis = $this->conectarRedis();

        if (!$redis instanceof Redis) {
            return false;
        }

        try {
            $json = json_encode($erro, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            if ($json === false) {
                return false;
            }

            $codigo = (string) $erro['codigo'];
            $redis->setex(self::CHAVE_ITEM . $codigo, $this->ttlRedis, $json);
            $redis->lPush(self::CHAVE_LISTA, $codigo);
            $redis->lTrim(self::CHAVE_LISTA, 0, 99);
            $redis->expire(self::CHAVE_LISTA, $this->ttlRedis);

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    private function conectarRedis(): ?Redis
    {
        if ($this->redisHost === '' || !class_exists(Redis::class)) {
            return null;
        }

        try {
            $redis = new Redis();
            $redis->connect($this->redisHost, $this->redisPorta, 1.0);

            return $redis;
        } catch (Throwable) {
            return null;
        }
    }

    /**
     * @param array<string, mixed> $erro
     */
    private function registrarFallback(array $erro): void
    {
        $diretorio = dirname($this->caminhoFallback);

        if (!is_dir($diretorio)) {
            @mkdir($diretorio, 0775, true);
        }

        $erro['origem_registro'] = 'arquivo';
        $json = json_encode($erro, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($json === false) {
            return;
        }

        @file_put_contents($this->caminhoFallback, $json . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function listarFallback(int $limite): array
    {
        if (!is_file($this->caminhoFallback)) {
            return [];
        }

        $linhas = file($this->caminhoFallback, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        if ($linhas === false) {
            return [];
        }

        $linhas = array_slice(array_reverse($linhas), 0, $limite);
        $erros = [];

        foreach ($linhas as $linha) {
            $erro = json_decode($linha, true);

            if (is_array($erro)) {
                $erro['origem_registro'] = $erro['origem_registro'] ?? 'arquivo';
                $erros[] = $erro;
            }
        }

        return $erros;
    }
}
