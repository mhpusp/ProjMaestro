<?php

declare(strict_types=1);

namespace App\repositories;

use PDO;

class UsuarioFuncoesRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function atribuir(int $usuarioId, int $funcaoId): void
    {
        $sql = 'INSERT IGNORE INTO usuario_funcoes (usuario_id, funcao_id) VALUES (:usuario_id, :funcao_id)';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':usuario_id' => $usuarioId, ':funcao_id' => $funcaoId]);
    }

    public function remover(int $usuarioId, int $funcaoId): void
    {
        $sql = 'DELETE FROM usuario_funcoes WHERE usuario_id = :usuario_id AND funcao_id = :funcao_id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':usuario_id' => $usuarioId, ':funcao_id' => $funcaoId]);
    }

    public function listarFuncoesDoUsuario(int $usuarioId): array
    {
        $sql = 'SELECT f.* FROM funcoes f JOIN usuario_funcoes uf ON f.id = uf.funcao_id WHERE uf.usuario_id = :usuario_id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':usuario_id' => $usuarioId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listarUsuariosDaFuncao(int $funcaoId): array
    {
        $sql = 'SELECT u.* FROM usuarios u JOIN usuario_funcoes uf ON u.id = uf.usuario_id WHERE uf.funcao_id = :funcao_id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':funcao_id' => $funcaoId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
