<?php

declare(strict_types=1);

namespace App\repositories;

use PDO;

class UsuarioRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * Cria um usuário e retorna o id gerado.
     * @param array $dados ['nome','nusp','email','senha']
     */
    public function criar(array $dados): int
    {
        $sql = 'INSERT INTO usuarios (nome, nusp, email, senha) VALUES (:nome, :nusp, :email, :senha)';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':nome' => $dados['nome'] ?? '',
            ':nusp' => $dados['nusp'] ?? '',
            ':email' => $dados['email'] ?? '',
            ':senha' => $dados['senha'] ?? '',
        ]);

        return (int) $this->pdo->lastInsertId();
    }

    public function buscarPorId(int $id): ?array
    {
        $sql = 'SELECT * FROM usuarios WHERE id = :id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    public function buscarPorUsername(string $username): ?array
    {
        $sql = 'SELECT * FROM usuarios WHERE email = :username OR nusp = :username LIMIT 1';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':username' => $username]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    public function listar(int $limit = 100, int $offset = 0): array
    {
        $sql = 'SELECT * FROM usuarios ORDER BY id DESC LIMIT :limit OFFSET :offset';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
