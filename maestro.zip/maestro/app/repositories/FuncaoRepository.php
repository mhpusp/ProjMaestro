<?php

declare(strict_types=1);

namespace App\repositories;

use PDO;

class FuncaoRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function criar(string $nome, ?string $descricao = null): int
    {
        $sql = 'INSERT INTO funcoes (nome, descricao) VALUES (:nome, :descricao)';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':nome' => $nome,
            ':descricao' => $descricao,
        ]);

        return (int) $this->pdo->lastInsertId();
    }

    public function buscarPorId(int $id): ?array
    {
        $sql = 'SELECT * FROM funcoes WHERE id = :id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    public function buscarPorNome(string $nome): ?array
    {
        $sql = 'SELECT * FROM funcoes WHERE nome = :nome LIMIT 1';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':nome' => $nome]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    public function listar(int $limit = 100, int $offset = 0): array
    {
        $sql = 'SELECT * FROM funcoes ORDER BY id DESC LIMIT :limit OFFSET :offset';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
