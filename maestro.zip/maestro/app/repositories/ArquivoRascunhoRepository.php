<?php

declare(strict_types=1);

namespace App\repositories;

use DateTimeImmutable;

/**
 * Persistencia local em JSON para rascunhos enquanto nao ha banco real.
 */
class ArquivoRascunhoRepository implements RascunhoRepositoryInterface
{
    public function __construct(private readonly string $caminhoArquivo)
    {
    }

    public function salvar(array $rascunho): array
    {
        $rascunhos = $this->lerTodos();
        $rascunhos[(string) $rascunho['id']] = $rascunho;
        $this->gravarTodos($rascunhos);

        return $rascunho;
    }

    public function buscarPorId(string $id): ?array
    {
        $rascunhos = $this->lerTodos();

        return isset($rascunhos[$id]) && is_array($rascunhos[$id]) ? $rascunhos[$id] : null;
    }

    public function buscarRascunhoAtivo(string $tipo, string $usuarioId): ?array
    {
        $encontrados = array_filter(
            $this->lerTodos(),
            static fn (array $rascunho): bool => ($rascunho['tipo'] ?? '') === $tipo
                && ($rascunho['usuario_id'] ?? '') === $usuarioId
                && ($rascunho['status'] ?? '') === 'rascunho'
        );

        usort($encontrados, static fn (array $a, array $b): int => strcmp(
            (string) ($b['atualizado_em'] ?? ''),
            (string) ($a['atualizado_em'] ?? '')
        ));

        return $encontrados[0] ?? null;
    }

    public function remover(string $id): void
    {
        $rascunhos = $this->lerTodos();
        unset($rascunhos[$id]);
        $this->gravarTodos($rascunhos);
    }

    public function removerExpirados(DateTimeImmutable $limite): int
    {
        $rascunhos = $this->lerTodos();
        $mantidos = [];
        $removidos = 0;

        foreach ($rascunhos as $id => $rascunho) {
            $status = (string) ($rascunho['status'] ?? '');
            $atualizadoEm = DateTimeImmutable::createFromFormat(DATE_ATOM, (string) ($rascunho['atualizado_em'] ?? ''));

            if ($status === 'rascunho' && $atualizadoEm instanceof DateTimeImmutable && $atualizadoEm < $limite) {
                $removidos++;
                continue;
            }

            $mantidos[(string) $id] = $rascunho;
        }

        if ($removidos > 0) {
            $this->gravarTodos($mantidos);
        }

        return $removidos;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function lerTodos(): array
    {
        if (!is_file($this->caminhoArquivo)) {
            return [];
        }

        $conteudo = file_get_contents($this->caminhoArquivo);

        if ($conteudo === false || trim($conteudo) === '') {
            return [];
        }

        $dados = json_decode($conteudo, true);

        return is_array($dados) ? $dados : [];
    }

    /**
     * @param array<string, array<string, mixed>> $rascunhos
     */
    private function gravarTodos(array $rascunhos): void
    {
        $diretorio = dirname($this->caminhoArquivo);

        if (!is_dir($diretorio)) {
            @mkdir($diretorio, 0775, true);
        }

        $conteudo = json_encode($rascunhos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($conteudo === false) {
            return;
        }

        @file_put_contents($this->caminhoArquivo, $conteudo . PHP_EOL, LOCK_EX);
    }
}
