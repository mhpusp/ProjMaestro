<?php

declare(strict_types=1);

namespace App\repositories;

use DateTimeImmutable;

/**
 * Contrato para persistencia de objetos preenchidos parcialmente.
 */
interface RascunhoRepositoryInterface
{
    /**
     * @param array<string, mixed> $rascunho
     * @return array<string, mixed>
     */
    public function salvar(array $rascunho): array;

    /**
     * @return array<string, mixed>|null
     */
    public function buscarPorId(string $id): ?array;

    /**
     * @return array<string, mixed>|null
     */
    public function buscarRascunhoAtivo(string $tipo, string $usuarioId): ?array;

    public function remover(string $id): void;

    public function removerExpirados(DateTimeImmutable $limite): int;
}
