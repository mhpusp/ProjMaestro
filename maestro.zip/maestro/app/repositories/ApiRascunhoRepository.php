<?php

declare(strict_types=1);

namespace App\repositories;

use DateTimeImmutable;
use RuntimeException;

/**
 * Adaptador para persistir rascunhos em uma API externa.
 */
class ApiRascunhoRepository implements RascunhoRepositoryInterface
{
    /**
     * @param array<string, mixed> $configuracao
     */
    public function __construct(private readonly array $configuracao)
    {
    }

    public function salvar(array $rascunho): array
    {
        return $this->requisitar('PUT', '/rascunhos/' . rawurlencode((string) $rascunho['id']), $rascunho) ?? $rascunho;
    }

    public function buscarPorId(string $id): ?array
    {
        return $this->requisitar('GET', '/rascunhos/' . rawurlencode($id));
    }

    public function buscarRascunhoAtivo(string $tipo, string $usuarioId): ?array
    {
        return $this->requisitar('GET', sprintf(
            '/rascunhos/ativo?tipo=%s&usuario_id=%s',
            rawurlencode($tipo),
            rawurlencode($usuarioId)
        ));
    }

    public function remover(string $id): void
    {
        $this->requisitar('DELETE', '/rascunhos/' . rawurlencode($id));
    }

    public function removerExpirados(DateTimeImmutable $limite): int
    {
        $resposta = $this->requisitar('DELETE', '/rascunhos/expirados?limite=' . rawurlencode($limite->format(DATE_ATOM)));

        return (int) ($resposta['removidos'] ?? 0);
    }

    /**
     * @param array<string, mixed>|null $payload
     * @return array<string, mixed>|null
     */
    private function requisitar(string $metodo, string $path, ?array $payload = null): ?array
    {
        $baseUrl = rtrim((string) $this->configuracao['api_base_url'], '/');

        if ($baseUrl === '') {
            throw new RuntimeException('Configure RASCUNHOS_API_BASE_URL para usar persistencia de rascunhos por API.');
        }

        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
        ];
        $token = (string) ($this->configuracao['api_token'] ?? '');

        if ($token !== '') {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        $opcoes = [
            'http' => [
                'method' => $metodo,
                'timeout' => (int) ($this->configuracao['api_timeout'] ?? 3),
                'ignore_errors' => true,
                'header' => implode("\r\n", $headers) . "\r\n",
            ],
        ];

        if ($payload !== null) {
            $opcoes['http']['content'] = (string) json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        $resposta = @file_get_contents($baseUrl . $path, false, stream_context_create($opcoes));

        if ($resposta === false || $resposta === '') {
            return null;
        }

        $dados = json_decode($resposta, true);

        return is_array($dados) ? $dados : null;
    }
}
