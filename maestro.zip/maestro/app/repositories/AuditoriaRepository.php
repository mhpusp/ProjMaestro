<?php

declare(strict_types=1);

namespace App\repositories;

/**
 * Grava eventos de auditoria em JSONL.
 *
 * A classe isola o destino atual dos eventos para facilitar troca futura por
 * banco de dados, fila ou servico externo.
 */
class AuditoriaRepository
{
    public function __construct(private readonly string $caminhoArquivo)
    {
    }

    /**
     * @param array<string, mixed> $evento
     */
    public function registrar(array $evento): void
    {
        $diretorio = dirname($this->caminhoArquivo);

        if (!is_dir($diretorio)) {
            @mkdir($diretorio, 0775, true);
        }

        $linha = json_encode($evento, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($linha === false) {
            return;
        }

        @file_put_contents($this->caminhoArquivo, $linha . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
