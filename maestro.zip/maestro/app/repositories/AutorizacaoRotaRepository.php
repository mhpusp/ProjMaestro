<?php

declare(strict_types=1);

namespace App\repositories;

/**
 * Persiste papeis permitidos por rota em arquivo PHP local.
 */
class AutorizacaoRotaRepository
{
    public function __construct(private readonly string $caminhoArquivo)
    {
    }

    /**
     * @return array<string, array<int, string>>
     */
    public function listarPapeisPorRota(): array
    {
        $dados = $this->carregar();
        $rotas = $dados['rotas'] ?? [];
        $resultado = [];

        foreach ($rotas as $rotaId => $configuracao) {
            $papeis = is_array($configuracao) ? ($configuracao['papeis'] ?? []) : [];
            $resultado[(string) $rotaId] = $this->normalizarPapeis(is_array($papeis) ? $papeis : []);
        }

        return $resultado;
    }

    /**
     * @return array<int, string>
     */
    public function papeisDaRota(string $rotaId): array
    {
        return $this->listarPapeisPorRota()[$rotaId] ?? [];
    }

    /**
     * @param array<int, string> $papeis
     * @return array<int, string>
     */
    public function definirPapeis(string $rotaId, array $papeis): array
    {
        $dados = $this->carregar();
        $dados['rotas'][$rotaId] = [
            'papeis' => $this->normalizarPapeis($papeis),
        ];
        $this->salvar($dados);

        return $dados['rotas'][$rotaId]['papeis'];
    }

    /**
     * @return array<int, string>
     */
    public function adicionarPapel(string $rotaId, string $papel): array
    {
        return $this->definirPapeis($rotaId, [
            ...$this->papeisDaRota($rotaId),
            $papel,
        ]);
    }

    /**
     * @return array<int, string>
     */
    public function removerPapel(string $rotaId, string $papel): array
    {
        return $this->definirPapeis(
            $rotaId,
            array_values(array_filter(
                $this->papeisDaRota($rotaId),
                static fn (string $papelAtual): bool => $papelAtual !== $papel
            ))
        );
    }

    /**
     * @return array{rotas: array<string, array{papeis: array<int, string>}>}
     */
    private function carregar(): array
    {
        if (!is_file($this->caminhoArquivo)) {
            return ['rotas' => []];
        }

        $dados = require $this->caminhoArquivo;

        if (!is_array($dados)) {
            return ['rotas' => []];
        }

        if (!isset($dados['rotas']) || !is_array($dados['rotas'])) {
            $dados['rotas'] = [];
        }

        return $dados;
    }

    /**
     * @param array{rotas: array<string, array{papeis: array<int, string>}>} $dados
     */
    private function salvar(array $dados): void
    {
        ksort($dados['rotas']);
        $conteudo = "<?php\n\n";
        $conteudo .= "declare(strict_types=1);\n\n";
        $conteudo .= "/*\n";
        $conteudo .= " * ATENCAO: NAO EDITE ESTE ARQUIVO MANUALMENTE.\n";
        $conteudo .= " *\n";
        $conteudo .= " * Este arquivo e gerenciado pela REST API nativa de autorizacoes do scaffold.\n";
        $conteudo .= " * Alteracoes manuais podem quebrar o controle de acesso das rotas, bloquear\n";
        $conteudo .= " * administradores ou expor rotas privadas. Use sempre os endpoints de\n";
        $conteudo .= " * gerenciamento de autorizacoes para adicionar ou remover papeis.\n";
        $conteudo .= " */\n\n";
        $conteudo .= 'return ' . var_export($dados, true) . ";\n";

        @file_put_contents($this->caminhoArquivo, $conteudo, LOCK_EX);
    }

    /**
     * @param array<int, mixed> $papeis
     * @return array<int, string>
     */
    private function normalizarPapeis(array $papeis): array
    {
        $normalizados = array_map(
            static fn (mixed $papel): string => strtolower(trim((string) $papel)),
            $papeis
        );

        return array_values(array_unique(array_filter($normalizados)));
    }
}
