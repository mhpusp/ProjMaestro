<?php

declare(strict_types=1);

namespace App\repositories;

use App\workflow\dto\Processo;
use PDO;

class ProcessoRepository
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly string $diretorioJson
    )
    {
    }

    public function emTransacao(): bool
    {
        return $this->pdo->inTransaction();
    }

    public function iniciarTransacao(): void
    {
        $this->pdo->beginTransaction();
    }

    public function confirmarTransacao(): void
    {
        $this->pdo->commit();
    }

    public function reverterTransacao(): void
    {
        if ($this->pdo->inTransaction()) {
            $this->pdo->rollBack();
        }
    }

    public function salvar(Processo $processo): void
    {
        $sql = 'INSERT INTO processos (id, processo_pai_id, nome, descricao, versao, arquivo, status, lista_subprocessos, dono_processo, raias_participantes, created_at, updated_at)
            VALUES (:id, :processo_pai_id, :nome, :descricao, :versao, :arquivo, :status, :lista_subprocessos, :dono_processo, :raias_participantes, NOW(), NOW())';

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':id' => $processo->id,
            ':processo_pai_id' => $processo->processo_id,
            ':nome' => $processo->nome,
            ':descricao' => $processo->descricao,
            ':versao' => $processo->versao ?? 1,
            ':arquivo' => $processo->arquivo,
            ':status' => $processo->concluido ? 1 : 0,
            ':dono_processo' => $processo->donoProcesso,
            ':lista_subprocessos' => json_encode($processo->listaSubprocessos ?? [], JSON_UNESCAPED_UNICODE),
            ':raias_participantes' => json_encode($processo->raiasParticipantes, JSON_UNESCAPED_UNICODE),
        ]);
    }

    public function buscarPorNome(string $nome): ?Processo
    {
        $sql = 'SELECT * FROM processos WHERE nome = :nome ORDER BY versao DESC LIMIT 1';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':nome' => $nome]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $this->processoFromRow($row);
    }

    /** @return Processo[] */
    public function pesquisarPorNome(string $nome): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM processos WHERE nome LIKE :nome ORDER BY nome ASC, versao DESC'
        );
        $stmt->execute([':nome' => '%' . $nome . '%']);
        $resultados = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $resultados[] = $this->processoFromRow($row);
        }

        return $resultados;
    }

    public function existe(string $id): bool
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM processos WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);

        return $stmt->fetchColumn() !== false;
    }

    public function maiorVersao(string $processoRaizId): int
    {
        $stmt = $this->pdo->prepare(
            'SELECT MAX(versao) FROM processos WHERE id = :raiz OR processo_pai_id = :raiz'
        );
        $stmt->execute([':raiz' => $processoRaizId]);

        return (int) $stmt->fetchColumn();
    }

    public function buscarPorId(string $id): ?Processo
    {
        $sql = 'SELECT * FROM processos WHERE id = :id LIMIT 1';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $this->processoFromRow($row);
    }

    /** @return Processo[] */
    public function listar(int $limit = 100, int $offset = 0): array
    {
        $sql = 'SELECT * FROM processos ORDER BY created_at DESC LIMIT :limit OFFSET :offset';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        $results = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = $this->processoFromRow($row);
        }

        return $results;
    }

    private function processoFromRow(array $row): Processo
    {
        $arquivo = basename((string) ($row['arquivo'] ?? ''));
        $dados = [];
        $caminhoPacote = $arquivo === ''
            ? ''
            : dirname(__DIR__) . '/workflow/wfiles/' . basename((string) ($row['id'] ?? '')) . '/' . $arquivo;
        $caminho = $caminhoPacote !== '' && is_file($caminhoPacote)
            ? $caminhoPacote
            : ($arquivo === '' ? '' : rtrim($this->diretorioJson, '/') . '/' . $arquivo);

        if ($caminho !== '' && is_file($caminho)) {
            $conteudo = file_get_contents($caminho);
            $json = $conteudo === false ? null : json_decode($conteudo, true);
            $dados = is_array($json) ? $json : [];
        }

        $dados['id'] = (string) $row['id'];
        $dados['processo_id'] = $row['processo_pai_id'] ?? null;
        $dados['nome'] = (string) $row['nome'];
        $dados['descricao'] = $row['descricao'] ?? null;
        $dados['versao'] = (int) $row['versao'];
        $dados['arquivo'] = $arquivo !== '' ? $arquivo : null;
        $dados['status'] = (bool) $row['status'];
        $dados['dono_processo'] = $row['dono_processo'] ?? null;
        $dados['lista_subprocessos'] = $this->jsonArray($row['lista_subprocessos'] ?? null) ?? [];
        $dados['raias_participantes'] = $this->jsonArray($row['raias_participantes'] ?? null);

        return Processo::fromArray($dados);
    }

    private function jsonArray(mixed $valor): ?array
    {
        if (is_array($valor)) {
            return $valor;
        }

        $json = is_string($valor) ? json_decode($valor, true) : null;

        return is_array($json) ? $json : null;
    }
}
