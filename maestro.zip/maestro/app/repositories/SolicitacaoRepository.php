<?php

declare(strict_types=1);

namespace App\repositories;

/**
 * Repository de exemplo para solicitacoes.
 *
 * Nesta versao do scaffold os dados ficam em memoria para o modulo funcionar sem
 * banco. Em um sistema real, esta classe e o ponto natural para trocar os arrays
 * por consultas PDO com parametros preparados.
 */
class SolicitacaoRepository
{
    private const SESSAO_CHAVE = 'solicitacoes_em_memoria';

    /**
     * Lista solicitacoes aplicando um filtro textual simples.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listar(?string $filtro = null): array
    {
        $solicitacoes = $this->solicitacoes();
        $filtro = trim((string) $filtro);

        if ($filtro === '') {
            return $solicitacoes;
        }

        return array_values(array_filter(
            $solicitacoes,
            static fn (array $solicitacao): bool => str_contains(
                strtolower(
                    $solicitacao['titulo'] . ' ' . $solicitacao['solicitante'] . ' ' . $solicitacao['status']
                ),
                strtolower($filtro)
            )
        ));
    }

    /**
     * Busca uma solicitacao pelo identificador.
     *
     * @return array<string, mixed>|null
     */
    public function buscarPorId(int $id): ?array
    {
        foreach ($this->solicitacoes() as $solicitacao) {
            if ((int) $solicitacao['id'] === $id) {
                return $solicitacao;
            }
        }

        return null;
    }

    /**
     * Cria uma solicitacao de exemplo e retorna o DTO padronizado.
     *
     * @param array<string, mixed> $dados
     * @return array<string, mixed>
     */
    public function criar(array $dados): array
    {
        $solicitacao = [
            'id' => $this->proximoId(),
            'titulo' => (string) $dados['titulo'],
            'descricao' => (string) $dados['descricao'],
            'solicitante' => (string) $dados['solicitante'],
            'status' => 'nova',
            'prioridade' => (string) $dados['prioridade'],
            'criada_em' => date('Y-m-d'),
        ];
        $solicitacoes = &$this->solicitacoes();
        $solicitacoes[] = $solicitacao;

        return $solicitacao;
    }

    /**
     * Retorna uma solicitacao com status alterado.
     *
     * @return array<string, mixed>|null
     */
    public function alterarStatus(int $id, string $status): ?array
    {
        $solicitacoes = &$this->solicitacoes();

        foreach ($solicitacoes as &$solicitacao) {
            if ((int) $solicitacao['id'] !== $id) {
                continue;
            }

            $solicitacao['status'] = $status;

            return $solicitacao;
        }

        return null;
    }

    /**
     * Remove uma solicitacao da lista em memoria.
     */
    public function excluir(int $id): bool
    {
        $solicitacoes = &$this->solicitacoes();

        foreach ($solicitacoes as $indice => $solicitacao) {
            if ((int) $solicitacao['id'] !== $id) {
                continue;
            }

            unset($solicitacoes[$indice]);
            $solicitacoes = array_values($solicitacoes);

            return true;
        }

        return false;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function dadosIniciais(): array
    {
        return [
            [
                'id' => 101,
                'titulo' => 'Acesso ao sistema de listas',
                'descricao' => 'Liberar acesso administrativo para acompanhamento de inscricoes.',
                'solicitante' => 'Maria Silva',
                'status' => 'em_analise',
                'prioridade' => 'media',
                'criada_em' => '2026-06-01',
            ],
            [
                'id' => 102,
                'titulo' => 'Atualizacao cadastral',
                'descricao' => 'Corrigir dados de contato de servidor no cadastro interno.',
                'solicitante' => 'Joao Souza',
                'status' => 'nova',
                'prioridade' => 'baixa',
                'criada_em' => '2026-06-03',
            ],
            [
                'id' => 103,
                'titulo' => 'Relatorio mensal',
                'descricao' => 'Preparar relatorio de acompanhamento para coordenacao.',
                'solicitante' => 'Ana Pereira',
                'status' => 'concluida',
                'prioridade' => 'alta',
                'criada_em' => '2026-06-05',
            ],
        ];
    }

    private function proximoId(): int
    {
        $ids = array_column($this->solicitacoes(), 'id');

        return ($ids !== [] ? max($ids) : 100) + 1;
    }

    /**
     * Mantem as solicitacoes em memoria de sessao para a demonstracao Web.
     *
     * @return array<int, array<string, mixed>>
     */
    private function &solicitacoes(): array
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            if (!isset($_SESSION[self::SESSAO_CHAVE]) || !is_array($_SESSION[self::SESSAO_CHAVE])) {
                $_SESSION[self::SESSAO_CHAVE] = $this->dadosIniciais();
            }

            return $_SESSION[self::SESSAO_CHAVE];
        }

        static $fallback = null;

        if (!is_array($fallback)) {
            $fallback = $this->dadosIniciais();
        }

        return $fallback;
    }
}
