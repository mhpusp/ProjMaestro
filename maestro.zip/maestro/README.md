# Projeto Base

Scaffold PHP Slim para sistemas da Escola Politecnica.

## Requisitos

- PHP 8.2 ou superior
- Composer

## Instalacao

Instale as dependencias:

```bash
composer install
```

Crie o arquivo de ambiente local:

```bash
cp .env.example .env
```

No Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

O arquivo `.env.example` nao contem credenciais reais. Ajuste apenas valores locais, como nome da aplicacao, ambiente, URL e conexao de banco quando necessario.

## SSO e autenticacao

O scaffold possui integracao preparada para OpenSSO por rota. Rotas publicas nao recebem middleware de autenticacao; rotas autenticadas usam `AutenticacaoSsoMiddleware` em `config/routes.php`.

Configuracoes principais no `.env`:

- `SSO_HABILITADO=false`: usa usuario de desenvolvimento configurado em `DEV_USUARIO_*`.
- `SSO_HABILITADO=true`: exige o cookie configurado em `SSO_COOKIE_NAME` e valida no endpoint `SSO_ATTRIBUTES_URL`.
- `SSO_LOGIN_URL` e `SSO_LOGOUT_URL`: URLs de login/logout federado.
- `SSO_PAPEIS_PADRAO`: papeis carregados para usuarios autenticados enquanto nao houver repository institucional de papeis.
- `SESSION_SAVE_PATH` e `SESSION_COOKIE_*`: caminho e atributos do cookie da sessao local da aplicacao.

Para proteger uma rota, adicione o middleware de autenticacao e `ExigePapelRota`. Os papeis permitidos ficam em `config/autorizacoes_rotas.php`, gerenciado pela API nativa:

- `GET /api/autorizacoes/rotas`
- `POST /api/autorizacoes/rotas/{rota_id}/papeis`
- `DELETE /api/autorizacoes/rotas/{rota_id}/papeis`

## Versao do codigo

O scaffold le `.git` para montar a assinatura do codigo em execucao no formato `branch@commit_curto`. Essa assinatura aparece em `/saude`, no rodape Web, na pagina de erro e no log tecnico de erros.

Se `.git` nao puder ser lido, a aplicacao continua funcionando com `versao-indisponivel` e `/saude` fica `degradado`. Use `APP_GIT_PATH` se a pasta `.git` estiver fora da raiz do projeto.

## Rascunhos de formularios

O scaffold tambem possui uma camada para salvar objetos preenchidos parcialmente em formularios. Rascunhos ficam vinculados ao usuario autenticado, nascem com status `rascunho`, sao atualizados durante o preenchimento e mudam para `enviado` quando o submit final passa pela validacao.

Configuracoes principais:

- `RASCUNHOS_DRIVER=arquivo`: persiste em JSON local por padrao.
- `RASCUNHOS_DRIVER=api`: usa API externa configurada por `RASCUNHOS_API_BASE_URL`.
- `RASCUNHOS_TTL_DIAS=21`: remove rascunhos sem atualizacao apos 21 dias.
- `RASCUNHOS_STORAGE_PATH`: caminho do arquivo local quando o driver e `arquivo`.

O modulo `solicitacoes` demonstra o uso com htmx em `POST /solicitacoes/rascunho`.

## Executar localmente

Suba o servidor embutido do PHP:

```bash
composer servidor
```

Ou diretamente:

```bash
php -S localhost:8080 -t public
```

Depois acesse:

- `http://localhost:8080/` para a pagina HTML inicial.
- `http://localhost:8080/saude` para o JSON de saude da aplicacao, incluindo a versao Git do codigo.
- `http://localhost:8080/solicitacoes` para exemplo de rota autenticada.
- `http://localhost:8080/admin/erros` para o painel interno de erros recentes, autenticado e restrito ao papel `admin`.
- `http://localhost:8080/erro-teste` para validar a pagina amigavel de erro.
- `POST /workplace/papel` para trocar o papel ativo da sessao Workplace autenticada.
- `GET /logout` para encerrar sessao local e, com SSO habilitado, redirecionar para logout federado.

## Estrutura

- `public/index.php`: ponto de entrada HTTP.
- `config/settings.php`: leitura de `.env` e configuracoes por ambiente.
- `config/dependencies.php`: registro explicito de dependencias simples.
- `config/autorizacoes_rotas.php`: papeis autorizados por rota, gerenciado via REST API.
- `config/routes.php`: rotas Slim.
- `app/controllers`: controllers da aplicacao.
- `app/models`: models e regras simples de dominio.
- `app/autorizacao`: documentacao da autorizacao por rota e codigo legado por acao.
- `app/exportadores`: estrutura inicial para CSV, PDF e Excel.
- `app/services`: regras de negocio reutilizaveis.
- `app/repositories`: acesso a dados ou fontes externas.
- `app/workplace`: sessao institucional, usuario logado e papeis.
- `app/middlewares`: middlewares de autenticacao SSO e permissao por rota.
- `app/views`: templates PHP.
- `app/views/componentes`: componentes PHP reutilizaveis de interface.
- `app/views/solicitacoes`: modulo exemplo com lista, detalhe, formulario e README.
- `app/views/admin`: paginas administrativas internas.
- `app/repositories/ErroRepository.php`: registro de erros em Redis com fallback JSONL.
- `public/assets/css/poli-theme.css`: tema visual institucional.
- `storage/logs/erros`: fallback local de erros quando Redis estiver indisponivel.
- `storage/logs/auditoria`: auditoria local de tentativas de autorizacao negadas.
- `storage/rascunhos`: fallback local para objetos persistiveis em rascunho.
- `tests`: espaco reservado para testes automatizados.

## Principios

Este scaffold busca manter familiaridade com projetos PHP Fat-Free Framework, usando Slim como base HTTP. O codigo deve permanecer simples, documentado, em Portugues quando fizer sentido e sem padroes complexos desnecessarios.

## Guias para desenvolvedores

Consulte `docs/guias` para exemplos praticos de criacao de modulos, rotas, controllers, services, repositories, visual, erros, versao do codigo, SSO, rascunhos persistiveis, autorizacao, auditoria, htmx e checklist de revisao.
