<?php

declare(strict_types=1);

use App\workflow\services\WorkflowEventDispatcher;
use App\workflow\events\AgendaNotifierEventHandler;
use App\workflow\events\DataFormPersistEventHandler;
use App\workflow\events\SendEmailEventHandler;
use App\workflow\events\UploadFilesEventHandler;
use Psr\Container\ContainerInterface;

return [
    WorkflowEventDispatcher::class => function (ContainerInterface $c) {
        $dispatcher = new WorkflowEventDispatcher();
        // Registra as estratégias de eventos suportadas
        $dispatcher->registerHandler($c->get(AgendaNotifierEventHandler::class));
        $dispatcher->registerHandler($c->get(DataFormPersistEventHandler::class));
        $dispatcher->registerHandler($c->get(SendEmailEventHandler::class));
        $dispatcher->registerHandler($c->get(UploadFilesEventHandler::class));

        return $dispatcher;
    },
];