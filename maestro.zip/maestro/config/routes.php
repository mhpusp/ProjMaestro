<?php

declare(strict_types=1);

use App\controllers\PaginaController;
use App\controllers\AdminErroController;
use App\controllers\AutorizacaoRotaController;
use App\controllers\SolicitacaoController;
use App\controllers\WorkplaceController;
use App\controllers\UsuarioController;
use App\controllers\FuncaoController;
use App\controllers\LoginController;
use App\controllers\ProcessoController;
use App\middlewares\ExigePapelRota;
use App\repositories\ProcessoRepository;
use App\repositories\SolicitacaoRepository;
use App\repositories\UsuarioRepository;
use App\repositories\FuncaoRepository;
use App\repositories\UsuarioFuncoesRepository;
use App\services\SolicitacaoService;
use App\services\UsuarioService;
use App\services\FuncaoService;
use App\workflow\services\WorkflowHist;
use App\workflow\controllers\WorkflowHub;
use App\workflow\controllers\WorkflowRouterController;
use App\workflow\services\WorkflowMeta;
use App\workflow\services\WorkflowMap;
use App\workflow\services\WorkflowRouter;
use App\workflow\repositories\WorkflowHistRepository;
use App\workflow\repositories\WorkflowMetaRepository;
use App\workflow\services\WorkflowNotes;
use App\workflow\repositories\WorkflowNotesRepository;
use App\workflow\services\WorkflowEventDispatcher;
use App\workflow\events\UploadFilesEventHandler;
use App\workflow\events\AgendaNotifierEventHandler;
use Slim\App;

return static function (App $app, array $configuracao, array $dependencias): void {
    $autenticacao = $dependencias['autenticacao_local'];
    $autorizacoes = $dependencias['autorizacoes_rotas'];
    $registrar = static function (
        string $id,
        array $metodos,
        string $caminho,
        bool $publica = false,
        array $papeisPadrao = [],
        ?string $descricao = null
    ) use ($autorizacoes): string {
        $autorizacoes->registrarRota($id, $metodos, $caminho, $publica, $papeisPadrao, $descricao);

        return $id;
    };
    $exigeRota = static function (string $rotaId) use ($app, $configuracao, $dependencias): ExigePapelRota {
        return new ExigePapelRota(
            $app->getResponseFactory(),
            $dependencias['template'],
            $dependencias['autorizacoes_rotas'],
            $dependencias['auditoria'],
            $configuracao,
            $rotaId,
            $dependencias['versao_codigo']
        );
    };
    $criarWorkflowMeta = static function (\PDO $pdo): WorkflowMeta {
        return new WorkflowMeta(
            new WorkflowMetaRepository($pdo),
            new ProcessoRepository($pdo, dirname(__DIR__) . '/app/jsons')
        );
    };

    $registrar('home.inicio', ['GET'], '/', false, [], 'Painel principal do workflow');
    $app->get('/', function ($request, $response) use ($configuracao, $dependencias, $criarWorkflowMeta) {
        $pdo = $dependencias['pdo']();
        $workflowHist = new WorkflowHist(new WorkflowHistRepository($pdo));
        $workflowMeta = $criarWorkflowMeta($pdo);
        $workflowNotes = new WorkflowNotes(new WorkflowNotesRepository($pdo));
        $controller = new WorkflowHub($configuracao, $dependencias, $workflowHist, $workflowMeta, $workflowNotes);

        return $controller->inicio($request, $response);
    })
        ->add($autenticacao());

    $rotaWorkflowInstancia = $registrar(
        'workflow.instancias.navegar',
        ['GET', 'POST'],
        '/workflow/instancias/{id:[0-9]+}',
        false,
        ['admin'],
        'Navega por uma instância de processo em andamento'
    );
    $app->map(['GET', 'POST'], '/workflow/instancias/{id:[0-9]+}', function ($request, $response, array $args) use ($configuracao, $dependencias, $criarWorkflowMeta) {
        $pdo = $dependencias['pdo']();
        $workflowHist = new WorkflowHist(new WorkflowHistRepository($pdo));
        $workflowMeta = $criarWorkflowMeta($pdo);
        $workflowMap = new WorkflowMap(dirname(__DIR__) . '/app/workflow/wfiles');
        $workflowNotes = new WorkflowNotes(new WorkflowNotesRepository($pdo));
        $eventDispatcher = new WorkflowEventDispatcher();
        $eventDispatcher->registerHandler(new UploadFilesEventHandler());
        $eventDispatcher->registerHandler(new UploadFilesEventHandler($workflowMeta, 'uploadArquivos'));
        $eventDispatcher->registerHandler(new AgendaNotifierEventHandler($workflowNotes));
        $eventDispatcher->registerHandler(new AgendaNotifierEventHandler($workflowNotes, 'notificarAgenda'));
        $workflowRouter = new WorkflowRouter(
            $workflowHist,
            $workflowMeta,
            $workflowMap,
            $workflowNotes,
            $eventDispatcher
        );
        $controller = new WorkflowRouterController($configuracao, $dependencias, $workflowRouter);

        return $controller->despachar($request, $response, $args);
    })
        ->add($exigeRota($rotaWorkflowInstancia))
        ->add($autenticacao());

    $rotaWorkflowInstanciar = $registrar(
        'workflow.processos.instanciar',
        ['GET', 'POST'],
        '/workflow/processos/{id:[A-Za-z0-9_-]+}/instanciar',
        false,
        ['admin'],
        'Prepara e instancia um processo'
    );
    $app->map(['GET', 'POST'], '/workflow/processos/{id:[A-Za-z0-9_-]+}/instanciar', function ($request, $response, array $args) use ($configuracao, $dependencias, $criarWorkflowMeta) {
        $pdo = $dependencias['pdo']();
        $workflowHist = new WorkflowHist(new WorkflowHistRepository($pdo));
        $workflowMeta = $criarWorkflowMeta($pdo);
        $workflowMap = new WorkflowMap(dirname(__DIR__) . '/app/workflow/wfiles');
        $workflowNotes = new WorkflowNotes(new WorkflowNotesRepository($pdo));
        $workflowRouter = new WorkflowRouter($workflowHist, $workflowMeta, $workflowMap, $workflowNotes);
        $controller = new WorkflowRouterController($configuracao, $dependencias, $workflowRouter);

        return $controller->despacharInstanciacao($request, $response, $args);
    })
        ->add($exigeRota($rotaWorkflowInstanciar))
        ->add($autenticacao());

    $registrar('saude.ver', ['GET'], '/saude', true, [], 'Health check publico');
    $app->get('/saude', function ($request, $response) use ($configuracao, $dependencias) {
        $controller = new PaginaController($configuracao, $dependencias);

        return $controller->saude($request, $response);
    });

    // Login routes (public, no authentication required)
    $criarLoginController = static function () use ($configuracao, $dependencias): LoginController {
        $pdo = $dependencias['pdo']();
        $usuarioRepo = new UsuarioRepository($pdo);
        $usuarioFuncoesRepo = new UsuarioFuncoesRepository($pdo);
        $usuarioService = new UsuarioService($usuarioRepo, $usuarioFuncoesRepo);

        return new LoginController($configuracao, $dependencias, $usuarioService);
    };

    $registrar('auth.login', ['GET'], '/login', true, [], 'Formulario de login');
    $app->get('/login', function ($request, $response) use ($criarLoginController) {
        return $criarLoginController()->formulario($request, $response);
    });

    $registrar('auth.autenticar', ['POST'], '/login', true, [], 'Autenticar usuario');
    $app->post('/login', function ($request, $response) use ($criarLoginController) {
        return $criarLoginController()->autenticar($request, $response);
    });

    $registrar('auth.logout', ['GET'], '/logout', true, [], 'Logout local e federado');
    $app->get('/logout', function ($request, $response) use ($configuracao, $criarLoginController) {
        return $criarLoginController()->logout($request, $response);
    });

    $rotaTrocarPapel = $registrar(
        'workplace.papel.trocar',
        ['POST'],
        '/workplace/papel',
        false,
        ['admin', 'operador', 'leitor'],
        'Troca o papel ativo da sessao'
    );
    $app->post('/workplace/papel', function ($request, $response) use ($configuracao) {
        $controller = new WorkplaceController($configuracao);

        return $controller->trocarPapel($request, $response);
    })
        ->add($exigeRota($rotaTrocarPapel))
        ->add($autenticacao());

    $registrar('erros.teste', ['GET'], '/erro-teste', true, [], 'Dispara erro de teste');
    $app->get('/erro-teste', function () {
        throw new RuntimeException('Erro de teste provocado para validar o tratamento centralizado.');
    });

    $rotaAdminErros = $registrar('admin.erros.listar', ['GET'], '/admin/erros', false, ['admin'], 'Lista erros recentes');
    $app->get('/admin/erros', function ($request, $response) use ($configuracao, $dependencias) {
        $controller = new AdminErroController($configuracao, $dependencias, $dependencias['erros']);

        return $controller->listar($request, $response);
    })
        ->add($exigeRota($rotaAdminErros))
        ->add($autenticacao());

    // Usuario management
    $criarUsuarioController = static function () use ($configuracao, $dependencias): UsuarioController {
        $pdo = $dependencias['pdo']();
        $usuarioRepo = new UsuarioRepository($pdo);
        $usuarioFuncoesRepo = new UsuarioFuncoesRepository($pdo);
        $service = new UsuarioService($usuarioRepo, $usuarioFuncoesRepo);

        return new UsuarioController($configuracao, $dependencias, $service);
    };

    $rotaAdminUsuariosListar = $registrar('admin.usuarios.listar', ['GET'], '/admin/usuarios', false, ['admin'], 'Lista usuarios');
    $app->get('/admin/usuarios', function ($request, $response) use ($criarUsuarioController) {
        return $criarUsuarioController()->listar($request, $response);
    })
        ->add($exigeRota($rotaAdminUsuariosListar))
        ->add($autenticacao());

    $rotaAdminUsuariosNovo = $registrar('admin.usuarios.novo', ['GET'], '/admin/usuarios/nova', false, ['admin'], 'Form novo usuario');
    $app->get('/admin/usuarios/nova', function ($request, $response) use ($criarUsuarioController) {
        return $criarUsuarioController()->novo($request, $response);
    })
        ->add($exigeRota($rotaAdminUsuariosNovo))
        ->add($autenticacao());

    $rotaAdminUsuariosCriar = $registrar('admin.usuarios.criar', ['POST'], '/admin/usuarios', false, ['admin'], 'Criar usuario');
    $app->post('/admin/usuarios', function ($request, $response) use ($criarUsuarioController) {
        return $criarUsuarioController()->criar($request, $response);
    })
        ->add($exigeRota($rotaAdminUsuariosCriar))
        ->add($autenticacao());

    // Funcao management
    $criarFuncaoController = static function () use ($configuracao, $dependencias): FuncaoController {
        $pdo = $dependencias['pdo']();
        $funcaoRepo = new FuncaoRepository($pdo);
        $service = new FuncaoService($funcaoRepo);

        return new FuncaoController($configuracao, $dependencias, $service);
    };

    $rotaAdminFuncoesListar = $registrar('admin.funcoes.listar', ['GET'], '/admin/funcoes', false, ['admin'], 'Lista funcoes');
    $app->get('/admin/funcoes', function ($request, $response) use ($criarFuncaoController) {
        return $criarFuncaoController()->listar($request, $response);
    })
        ->add($exigeRota($rotaAdminFuncoesListar))
        ->add($autenticacao());

    $rotaAdminFuncoesNovo = $registrar('admin.funcoes.novo', ['GET'], '/admin/funcoes/nova', false, ['admin'], 'Form nova funcao');
    $app->get('/admin/funcoes/nova', function ($request, $response) use ($criarFuncaoController) {
        return $criarFuncaoController()->novo($request, $response);
    })
        ->add($exigeRota($rotaAdminFuncoesNovo))
        ->add($autenticacao());

    $rotaAdminFuncoesCriar = $registrar('admin.funcoes.criar', ['POST'], '/admin/funcoes', false, ['admin'], 'Criar funcao');
    $app->post('/admin/funcoes', function ($request, $response) use ($criarFuncaoController) {
        return $criarFuncaoController()->criar($request, $response);
    })
        ->add($exigeRota($rotaAdminFuncoesCriar))
        ->add($autenticacao());

    // Processo management
    $criarProcessoController = static function () use ($configuracao, $dependencias, $criarWorkflowMeta): ProcessoController {
        $workflowMeta = $criarWorkflowMeta($dependencias['pdo']());

        return new ProcessoController($configuracao, $dependencias, $workflowMeta);
    };

    $rotaAdminProcessosListar = $registrar('admin.processos.listar', ['GET'], '/admin/processos', false, ['admin'], 'Lista processos');
    $app->get('/admin/processos', function ($request, $response) use ($criarProcessoController) {
        return $criarProcessoController()->listar($request, $response);
    })
        ->add($exigeRota($rotaAdminProcessosListar))
        ->add($autenticacao());

    $rotaAdminProcessosNovo = $registrar('admin.processos.novo', ['GET'], '/admin/processos/novo', false, ['admin'], 'Form novo processo');
    $app->get('/admin/processos/novo', function ($request, $response) use ($criarProcessoController) {
        return $criarProcessoController()->novo($request, $response);
    })
        ->add($exigeRota($rotaAdminProcessosNovo))
        ->add($autenticacao());

    $rotaAdminProcessosCriar = $registrar('admin.processos.criar', ['POST'], '/admin/processos', false, ['admin'], 'Criar processo');
    $app->post('/admin/processos', function ($request, $response) use ($criarProcessoController) {
        return $criarProcessoController()->criarNovo($request, $response);
    })
        ->add($exigeRota($rotaAdminProcessosCriar))
        ->add($autenticacao());

    $rotaAdminProcessosAtualizar = $registrar('admin.processos.atualizar.formulario', ['GET'], '/admin/processos/atualizar', false, ['admin'], 'Pesquisar processo para atualizar');
    $app->get('/admin/processos/atualizar', function ($request, $response) use ($criarProcessoController) {
        return $criarProcessoController()->atualizar($request, $response);
    })
        ->add($exigeRota($rotaAdminProcessosAtualizar))
        ->add($autenticacao());

    $rotaAdminProcessosSalvarAtualizacao = $registrar('admin.processos.atualizar.salvar', ['POST'], '/admin/processos/atualizar', false, ['admin'], 'Criar nova versao do processo');
    $app->post('/admin/processos/atualizar', function ($request, $response) use ($criarProcessoController) {
        return $criarProcessoController()->salvarAtualizacao($request, $response);
    })
        ->add($exigeRota($rotaAdminProcessosSalvarAtualizacao))
        ->add($autenticacao());

    $criarSolicitacaoController = static function () use ($configuracao, $dependencias): SolicitacaoController {
        $repository = new SolicitacaoRepository();
        $service = new SolicitacaoService($repository);

        return new SolicitacaoController($configuracao, $dependencias, $service, $dependencias['rascunhos']);
    };
    $rotaSolicitacoesListar = $registrar('solicitacoes.listar', ['GET'], '/solicitacoes', false, ['admin', 'operador', 'leitor']);
    $app->get('/solicitacoes', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->listar($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesListar))
        ->add($autenticacao());

    $rotaSolicitacoesFiltrar = $registrar('solicitacoes.filtrar', ['GET'], '/solicitacoes/filtro', false, ['admin', 'operador', 'leitor']);
    $app->get('/solicitacoes/filtro', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->filtrar($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesFiltrar))
        ->add($autenticacao());

    $rotaSolicitacoesNova = $registrar('solicitacoes.nova', ['GET'], '/solicitacoes/nova', false, ['admin', 'operador']);
    $app->get('/solicitacoes/nova', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->novo($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesNova))
        ->add($autenticacao());

    $rotaSolicitacoesCriar = $registrar('solicitacoes.criar', ['POST'], '/solicitacoes', false, ['admin', 'operador']);
    $app->post('/solicitacoes', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->criar($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesCriar))
        ->add($autenticacao());

    $rotaSolicitacoesRascunho = $registrar('solicitacoes.rascunho.salvar', ['POST'], '/solicitacoes/rascunho', false, ['admin', 'operador']);
    $app->post('/solicitacoes/rascunho', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->salvarRascunho($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesRascunho))
        ->add($autenticacao());

    $rotaSolicitacoesExportarJson = $registrar('solicitacoes.exportar.json', ['GET'], '/solicitacoes/exportar/json', false, ['admin', 'operador']);
    $app->get('/solicitacoes/exportar/json', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->exportarJson($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesExportarJson))
        ->add($autenticacao());

    $rotaSolicitacoesExportarCsv = $registrar('solicitacoes.exportar.csv', ['GET'], '/solicitacoes/exportar/csv', false, ['admin', 'operador']);
    $app->get('/solicitacoes/exportar/csv', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->exportarCsv($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesExportarCsv))
        ->add($autenticacao());

    $rotaSolicitacoesExportarPdf = $registrar('solicitacoes.exportar.pdf', ['GET'], '/solicitacoes/exportar/pdf', false, ['admin', 'operador']);
    $app->get('/solicitacoes/exportar/pdf', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->prepararPdf($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesExportarPdf))
        ->add($autenticacao());

    $rotaSolicitacoesExportarExcel = $registrar('solicitacoes.exportar.excel', ['GET'], '/solicitacoes/exportar/excel', false, ['admin', 'operador']);
    $app->get('/solicitacoes/exportar/excel', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->prepararExcel($request, $response);
    })
        ->add($exigeRota($rotaSolicitacoesExportarExcel))
        ->add($autenticacao());

    $rotaSolicitacoesDetalhe = $registrar('solicitacoes.detalhe', ['GET'], '/solicitacoes/{id}', false, ['admin', 'operador', 'leitor']);
    $app->get('/solicitacoes/{id:[0-9]+}', function ($request, $response, array $args) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->detalhe($request, $response, $args);
    })
        ->add($exigeRota($rotaSolicitacoesDetalhe))
        ->add($autenticacao());

    $rotaSolicitacoesStatus = $registrar('solicitacoes.status.alterar', ['POST'], '/solicitacoes/{id}/status', false, ['admin', 'operador']);
    $app->post('/solicitacoes/{id:[0-9]+}/status', function ($request, $response, array $args) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->alterarStatus($request, $response, $args);
    })
        ->add($exigeRota($rotaSolicitacoesStatus))
        ->add($autenticacao());

    $rotaSolicitacoesExcluir = $registrar('solicitacoes.excluir', ['POST'], '/solicitacoes/{id}/excluir', false, ['admin']);
    $app->post('/solicitacoes/{id:[0-9]+}/excluir', function ($request, $response, array $args) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->excluir($request, $response, $args);
    })
        ->add($exigeRota($rotaSolicitacoesExcluir))
        ->add($autenticacao());

    $rotaApiSolicitacoesListar = $registrar('api.solicitacoes.listar', ['GET'], '/api/solicitacoes', false, ['admin', 'operador', 'leitor']);
    $app->get('/api/solicitacoes', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->apiListar($request, $response);
    })
        ->add($exigeRota($rotaApiSolicitacoesListar))
        ->add($autenticacao());

    $rotaApiSolicitacoesDetalhe = $registrar('api.solicitacoes.detalhe', ['GET'], '/api/solicitacoes/{id}', false, ['admin', 'operador', 'leitor']);
    $app->get('/api/solicitacoes/{id:[0-9]+}', function ($request, $response, array $args) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->apiDetalhe($request, $response, $args);
    })
        ->add($exigeRota($rotaApiSolicitacoesDetalhe))
        ->add($autenticacao());

    $rotaApiSolicitacoesCriar = $registrar('api.solicitacoes.criar', ['POST'], '/api/solicitacoes', false, ['admin', 'operador']);
    $app->post('/api/solicitacoes', function ($request, $response) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->apiCriar($request, $response);
    })
        ->add($exigeRota($rotaApiSolicitacoesCriar))
        ->add($autenticacao());

    $rotaApiSolicitacoesStatus = $registrar('api.solicitacoes.status.alterar', ['POST'], '/api/solicitacoes/{id}/alterar-status', false, ['admin', 'operador']);
    $app->post('/api/solicitacoes/{id:[0-9]+}/alterar-status', function ($request, $response, array $args) use ($criarSolicitacaoController) {
        return $criarSolicitacaoController()->apiAlterarStatus($request, $response, $args);
    })
        ->add($exigeRota($rotaApiSolicitacoesStatus))
        ->add($autenticacao());

    $criarAutorizacaoController = static fn (): AutorizacaoRotaController => new AutorizacaoRotaController(
        $dependencias['autorizacoes_rotas']
    );

    $rotaApiAutorizacoesListar = $registrar('api.autorizacoes.rotas.listar', ['GET'], '/api/autorizacoes/rotas', false, ['admin']);
    $app->get('/api/autorizacoes/rotas', function ($request, $response) use ($criarAutorizacaoController) {
        return $criarAutorizacaoController()->listar($request, $response);
    })
        ->add($exigeRota($rotaApiAutorizacoesListar))
        ->add($autenticacao());

    $rotaApiAutorizacoesAdicionar = $registrar('api.autorizacoes.rotas.papeis.adicionar', ['POST'], '/api/autorizacoes/rotas/{rota_id}/papeis', false, ['admin']);
    $app->post('/api/autorizacoes/rotas/{rota_id}/papeis', function ($request, $response, array $args) use ($criarAutorizacaoController) {
        return $criarAutorizacaoController()->adicionarPapel($request, $response, $args);
    })
        ->add($exigeRota($rotaApiAutorizacoesAdicionar))
        ->add($autenticacao());

    $rotaApiAutorizacoesRemover = $registrar('api.autorizacoes.rotas.papeis.remover', ['DELETE'], '/api/autorizacoes/rotas/{rota_id}/papeis', false, ['admin']);
    $app->delete('/api/autorizacoes/rotas/{rota_id}/papeis', function ($request, $response, array $args) use ($criarAutorizacaoController) {
        return $criarAutorizacaoController()->removerPapel($request, $response, $args);
    })
        ->add($exigeRota($rotaApiAutorizacoesRemover))
        ->add($autenticacao());
};
