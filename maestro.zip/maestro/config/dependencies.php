<?php

declare(strict_types=1);

use App\suporte\LoggerArquivo;
use App\middlewares\AutenticacaoSsoMiddleware;
use App\middlewares\AutenticacaoLocalMiddleware;
use App\repositories\ApiRascunhoRepository;
use App\repositories\ArquivoRascunhoRepository;
use App\repositories\AutorizacaoRotaRepository;
use App\repositories\AuditoriaRepository;
use App\repositories\ErroRepository;
use App\repositories\RascunhoRepositoryInterface;
use App\repositories\UsuarioRepository;
use App\services\AuditoriaService;
use App\services\AutorizacaoRotaService;
use App\services\OpenSsoClient;
use App\services\RascunhoService;
use App\services\VersaoCodigoService;
use App\suporte\SanitizadorContextoErro;
use App\suporte\Template;
use App\suporte\TratadorErros;
use Psr\Http\Message\ResponseFactoryInterface;

return static function (array $configuracao): array {
    $raizProjeto = dirname(__DIR__);
    $caminhoLog = (string) $configuracao['logs']['caminho'];

    if (!str_starts_with($caminhoLog, '/')) {
        $caminhoLog = $raizProjeto . '/' . $caminhoLog;
    }

    $caminhoErros = (string) $configuracao['erros']['storage_path'];

    if (!str_starts_with($caminhoErros, '/')) {
        $caminhoErros = $raizProjeto . '/' . $caminhoErros;
    }

    $caminhoAuditoria = (string) $configuracao['auditoria']['path'];

    if (!str_starts_with($caminhoAuditoria, '/')) {
        $caminhoAuditoria = $raizProjeto . '/' . $caminhoAuditoria;
    }

    $caminhoRascunhos = (string) $configuracao['rascunhos']['storage_path'];

    if (!str_starts_with($caminhoRascunhos, '/')) {
        $caminhoRascunhos = $raizProjeto . '/' . $caminhoRascunhos;
    }
    $caminhoAutorizacoesRotas = $raizProjeto . '/config/autorizacoes_rotas.php';

    $logger = new LoggerArquivo(
        $caminhoLog,
        (string) $configuracao['app']['ambiente']
    );
    $template = new Template($raizProjeto . '/app/views');
    $erros = new ErroRepository(
        (string) $configuracao['erros']['redis_host'],
        (int) $configuracao['erros']['redis_porta'],
        (int) $configuracao['erros']['ttl_redis'],
        $caminhoErros
    );
    $sanitizador = new SanitizadorContextoErro();
    $auditoria = new AuditoriaService(
        new AuditoriaRepository($caminhoAuditoria),
        $sanitizador
    );
    $openSso = new OpenSsoClient((array) $configuracao['sso'], $logger);
    $rascunhoRepository = match ((string) $configuracao['rascunhos']['driver']) {
        'api' => new ApiRascunhoRepository((array) $configuracao['rascunhos']),
        default => new ArquivoRascunhoRepository($caminhoRascunhos),
    };
    assert($rascunhoRepository instanceof RascunhoRepositoryInterface);
    $rascunhos = new RascunhoService($rascunhoRepository, (int) $configuracao['rascunhos']['ttl_dias']);
    $autorizacoesRotas = new AutorizacaoRotaService(new AutorizacaoRotaRepository($caminhoAutorizacoesRotas));
    $versaoCodigo = new VersaoCodigoService(
        $raizProjeto,
        (string) $configuracao['app']['versao'],
        (string) $configuracao['app']['git_path']
    );

    return [
        'template' => $template,
        'logger' => $logger,
        'erros' => $erros,
        'auditoria' => $auditoria,
        'autorizacoes_rotas' => $autorizacoesRotas,
        'opensso_client' => $openSso,
        'rascunhos' => $rascunhos,
        'versao_codigo' => $versaoCodigo,
        'autenticacao_sso' => static fn (ResponseFactoryInterface $responseFactory): AutenticacaoSsoMiddleware => new AutenticacaoSsoMiddleware(
            $responseFactory,
            $configuracao,
            $openSso
        ),
        'autenticacao_local' => static function () use ($configuracao): AutenticacaoLocalMiddleware {
            $dsn = is_callable($configuracao['banco']['dsn'])
                ? $configuracao['banco']['dsn']()
                : $configuracao['banco']['dsn'];

            $pdo = new PDO(
                (string) $dsn,
                (string) $configuracao['banco']['usuario'],
                (string) $configuracao['banco']['senha'],
                $configuracao['banco']['opcoes']
            );
            $usuarioRepository = new UsuarioRepository($pdo);
            $usuarioFuncoesRepository = new \App\repositories\UsuarioFuncoesRepository($pdo);

            return new AutenticacaoLocalMiddleware($usuarioRepository, $usuarioFuncoesRepository);
        },
        'pdo' => static function () use ($configuracao): PDO {
            $dsn = is_callable($configuracao['banco']['dsn']) 
                ? $configuracao['banco']['dsn']() 
                : $configuracao['banco']['dsn'];
            
            $dsn = (string) $dsn;

            if ($dsn === '') {
                throw new \RuntimeException('Database DSN is empty. Check DB_DSN, DB_HOST, and DB_DATABASE environment variables.');
            }

            return new PDO(
                $dsn,
                (string) $configuracao['banco']['usuario'],
                (string) $configuracao['banco']['senha'],
                $configuracao['banco']['opcoes']
            );
        },
        'tratador_erros' => static fn (ResponseFactoryInterface $responseFactory): TratadorErros => new TratadorErros(
            $responseFactory,
            $template,
            $erros,
            $sanitizador,
            $configuracao,
            $versaoCodigo
        ),
    ];
};
