<?php

declare(strict_types=1);

use Dotenv\Dotenv;

$raizProjeto = dirname(__DIR__);

if (file_exists($raizProjeto . '/.env')) {
    Dotenv::createImmutable($raizProjeto)->safeLoad();
}

/**
 * Retorna uma variavel de ambiente com valor padrao.
 */
$ambiente = static function (string $chave, mixed $padrao = null): mixed {
    return $_ENV[$chave] ?? $_SERVER[$chave] ?? $padrao;
};

/**
 * Converte valores textuais comuns de .env para booleano.
 */
$booleano = static function (mixed $valor): bool {
    return filter_var($valor, FILTER_VALIDATE_BOOLEAN);
};

return [
    'app' => [
        'nome' => (string) $ambiente('APP_NOME', 'Maestro'),
        'ambiente' => (string) $ambiente('APP_AMBIENTE', 'desenvolvimento'),
        'debug' => $booleano($ambiente('APP_DEBUG', false)),
        'url' => (string) $ambiente('APP_URL', 'http://localhost:8080'),
        'base_path' => (string) $ambiente('APP_BASE_PATH', ''),
        'versao' => (string) $ambiente('APP_VERSAO', '0.1.0'),
        'git_path' => (string) ($ambiente('APP_GIT_PATH', '') ?: $raizProjeto . '/.git'),
    ],
    'sso' => [
        'habilitado' => $booleano($ambiente('SSO_HABILITADO', false)),
        'cookie_name' => (string) $ambiente('SSO_COOKIE_NAME', 'iPlanetDirectoryPro'),
        'attributes_url' => (string) $ambiente(
            'SSO_ATTRIBUTES_URL',
            'https://app.poli.usp.br/opensso/json/attributes'
        ),
        'login_url' => (string) $ambiente('SSO_LOGIN_URL', 'https://app.poli.usp.br/opensso/UI/Login'),
        'logout_url' => (string) $ambiente('SSO_LOGOUT_URL', 'https://app.poli.usp.br/opensso/UI/Logout'),
        'timeout' => (int) $ambiente('SSO_TIMEOUT', 3),
        'papeis_padrao' => array_filter(array_map(
            'trim',
            explode(',', (string) $ambiente('SSO_PAPEIS_PADRAO', 'leitor'))
        )),
        'dev_usuario' => [
            'codpes' => (string) $ambiente('DEV_USUARIO_CODPES', '0000000'),
            'nome' => (string) $ambiente('DEV_USUARIO_NOME', 'Usuario Desenvolvimento'),
            'email' => (string) $ambiente('DEV_USUARIO_EMAIL', 'usuario.dev@example.test'),
            'telefone_whatsapp' => (string) $ambiente('DEV_USUARIO_WHATSAPP', ''),
            'papeis' => array_filter(array_map(
                'trim',
                explode(',', (string) $ambiente('DEV_USUARIO_PAPEIS', 'admin,operador,leitor'))
            )),
        ],
    ],
    'banco' => [
        'dsn' => (string) $ambiente('DB_DSN', ''),
        'usuario' => (string) $ambiente('DB_USERNAME', $ambiente('DB_USUARIO', '')),
        'senha' => (string) $ambiente('DB_PASSWORD', $ambiente('DB_SENHA', '')),
        'opcoes' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => (int) $ambiente('DB_TIMEOUT', 2),
        ],
    ],
    'sessao' => [
        'save_path' => (string) $ambiente('SESSION_SAVE_PATH', $raizProjeto . '/storage/sessions'),
        'cookie_secure' => $booleano($ambiente('SESSION_COOKIE_SECURE', false)),
        'cookie_httponly' => $booleano($ambiente('SESSION_COOKIE_HTTPONLY', true)),
        'cookie_samesite' => (string) $ambiente('SESSION_COOKIE_SAMESITE', 'Lax'),
    ],
    'logs' => [
        'caminho' => (string) $ambiente('LOG_CAMINHO', 'logs/app.log'),
        'redis_host' => (string) $ambiente('REDIS_LOG_HOST', ''),
        'redis_porta' => (int) $ambiente('REDIS_LOG_PORT', 6379),
    ],
    'erros' => [
        'prefixo' => (string) $ambiente('ERRO_PREFIXO', 'REQ'),
        'ttl_redis' => (int) $ambiente('ERRO_TTL_REDIS', 604800),
        'suporte_url' => (string) $ambiente('ERRO_SUPORTE_URL', 'mailto:sti@poli.usp.br'),
        'storage_path' => (string) $ambiente('ERRO_STORAGE_PATH', 'storage/logs/erros/erros.jsonl'),
        'redis_host' => (string) $ambiente('ERRO_REDIS_HOST', $ambiente('REDIS_LOG_HOST', '')),
        'redis_porta' => (int) $ambiente('ERRO_REDIS_PORT', $ambiente('REDIS_LOG_PORT', 6379)),
    ],
    'auditoria' => [
        'path' => (string) $ambiente(
            'AUDITORIA_PATH',
            $ambiente('AUDITORIA_AUTORIZACOES_PATH', 'storage/logs/auditoria/auditoria.jsonl')
        ),
    ],
    'rascunhos' => [
        'driver' => (string) $ambiente('RASCUNHOS_DRIVER', 'arquivo'),
        'ttl_dias' => (int) $ambiente('RASCUNHOS_TTL_DIAS', 21),
        'storage_path' => (string) $ambiente('RASCUNHOS_STORAGE_PATH', 'storage/rascunhos/rascunhos.json'),
        'api_base_url' => (string) $ambiente('RASCUNHOS_API_BASE_URL', ''),
        'api_token' => (string) $ambiente('RASCUNHOS_API_TOKEN', ''),
        'api_timeout' => (int) $ambiente('RASCUNHOS_API_TIMEOUT', 3),
    ],
];
