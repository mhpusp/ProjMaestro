<?php

declare(strict_types=1);

return [
    'solicitacoes' => [
        'admin' => [
            '*',
        ],
        'operador' => [
            ['acao' => 'solicitacao.listar'],
            ['acao' => 'solicitacao.ver'],
            ['acao' => 'solicitacao.criar'],
            ['acao' => 'solicitacao.alterar_status', 'escopos' => ['geral']],
            ['acao' => 'solicitacao.excluir', 'escopos' => ['geral']],
            ['acao' => 'solicitacao.exportar_json'],
            ['acao' => 'solicitacao.exportar_csv'],
            ['acao' => 'solicitacao.api_listar'],
            ['acao' => 'solicitacao.api_ver'],
            ['acao' => 'solicitacao.api_criar'],
            ['acao' => 'solicitacao.api_alterar_status', 'escopos' => ['geral']],
        ],
        'leitor' => [
            ['acao' => 'solicitacao.listar'],
            ['acao' => 'solicitacao.ver'],
            ['acao' => 'solicitacao.api_listar'],
            ['acao' => 'solicitacao.api_ver'],
        ],
    ],
    'admin' => [
        'admin' => [
            ['acao' => 'erros.listar'],
        ],
    ],
];
