<?php

declare(strict_types=1);

/*
 * ATENCAO: NAO EDITE ESTE ARQUIVO MANUALMENTE.
 *
 * Este arquivo e gerenciado pela REST API nativa de autorizacoes do scaffold.
 * Alteracoes manuais podem quebrar o controle de acesso das rotas, bloquear
 * administradores ou expor rotas privadas. Use sempre os endpoints de
 * gerenciamento de autorizacoes para adicionar ou remover papeis.
 */

return [
    'rotas' => [
        'home.inicio' => ['papeis' => ['admin', 'operador1', 'operador2', 'usr']],
        //'auth.login' => ['papeis' => ['admin', 'operador1', 'operador2', 'usr']],
        //'auth.autenticar' => ['papeis' => ['admin', 'operador1', 'operador2', 'usr']],
        //'auth.logout' => ['papeis' => ['admin', 'operador1', 'operador2', 'usr']],
        'workplace.papel.trocar' => ['papeis' => ['admin', 'operador', 'leitor']],
        'admin.erros.listar' => ['papeis' => ['admin']],
        'solicitacoes.listar' => ['papeis' => ['admin', 'operador', 'leitor']],
        'solicitacoes.filtrar' => ['papeis' => ['admin', 'operador', 'leitor']],
        'solicitacoes.nova' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.criar' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.rascunho.salvar' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.exportar.json' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.exportar.csv' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.exportar.pdf' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.exportar.excel' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.detalhe' => ['papeis' => ['admin', 'operador', 'leitor']],
        'solicitacoes.status.alterar' => ['papeis' => ['admin', 'operador']],
        'solicitacoes.excluir' => ['papeis' => ['admin']],
        'api.solicitacoes.listar' => ['papeis' => ['admin', 'operador', 'leitor']],
        'api.solicitacoes.detalhe' => ['papeis' => ['admin', 'operador', 'leitor']],
        'api.solicitacoes.criar' => ['papeis' => ['admin', 'operador']],
        'api.solicitacoes.status.alterar' => ['papeis' => ['admin', 'operador']],
        'api.autorizacoes.rotas.listar' => ['papeis' => ['admin']],
        'api.autorizacoes.rotas.papeis.adicionar' => ['papeis' => ['admin']],
        'api.autorizacoes.rotas.papeis.remover' => ['papeis' => ['admin']],
    ],
];
