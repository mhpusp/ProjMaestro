<?php

declare(strict_types=1);

use Slim\Factory\AppFactory;
use Dotenv\Dotenv;
use Slim\Psr7\Factory\UriFactory;

$baseDir = dirname(__DIR__);

// 1. CARREGA O AUTOLOAD
require $baseDir . '/vendor/autoload.php';

// 2. CARREGA AS VARIÁVEIS DE AMBIENTE
$dotenv = Dotenv::createImmutable($baseDir, '.env.example');
$dotenv->safeLoad();

if (file_exists($baseDir . '/.env')) {
    $dotenvLocal = Dotenv::createMutable($baseDir, '.env');
    $dotenvLocal->load();
}

// 3. CARREGA AS CONFIGURAÇÕES E DEPENDÊNCIAS
$configuracao = require $baseDir . '/config/settings.php';
$dependencias = (require $baseDir . '/config/dependencies.php')($configuracao);

$app = AppFactory::create();

if ($configuracao['app']['base_path'] !== '') {
    $app->setBasePath($configuracao['app']['base_path']);
}

$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

// 6. TRATAMENTO DE ERROS
$debug = (bool) ($configuracao['app']['debug'] ?? false);
$errorMiddleware = $app->addErrorMiddleware($debug, $debug, $debug);

$tratadorErros = is_array($dependencias)
    ? ($dependencias['tratador_erros'] ?? null)
    : ($dependencias->has('tratador_erros') ? $dependencias->get('tratador_erros') : null);

if ($tratadorErros) {
    $errorMiddleware->setDefaultErrorHandler(
    $dependencias['tratador_erros']($app->getResponseFactory())
    );
}

(require $baseDir . '/config/routes.php')($app, $configuracao, $dependencias);

$app->run();
