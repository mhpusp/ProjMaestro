# Autorizacao por rotas

O scaffold controla acesso por rota e papel ativo do usuario autenticado. Uma aplicacao externa pode gerenciar esses papeis pela REST API nativa.

## Arquivo local

A fonte persistida fica em `config/autorizacoes_rotas.php`. O arquivo e PHP e retorna um array com `rotas`.

Nao edite esse arquivo manualmente. Ele possui um aviso no topo porque alteracoes incorretas podem bloquear administradores ou expor rotas privadas.

## Registro de rotas

Toda rota deve ser registrada em `config/routes.php` antes de ser criada no Slim:

```php
$rota = $registrar(
    'solicitacoes.criar',
    ['POST'],
    '/solicitacoes',
    false,
    ['admin', 'operador'],
    'Cria solicitacao'
);

$app->post('/solicitacoes', $handler)
    ->add($exigeRota($rota))
    ->add($autenticacao);
```

Parametros:

- `id`: identificador estavel da rota.
- `metodos`: metodos HTTP.
- `caminho`: caminho publico/documentado da rota.
- `publica`: `true` para rota sem autenticacao/autorizacao.
- `papeisPadrao`: papeis iniciais quando a rota ainda nao foi alterada pela API.
- `descricao`: texto opcional para a aplicacao externa.

## REST API

Listar rotas:

```http
GET /api/autorizacoes/rotas
```

Adicionar papel:

```http
POST /api/autorizacoes/rotas/solicitacoes.criar/papeis
Content-Type: application/json

{"papel": "leitor"}
```

Remover papel:

```http
DELETE /api/autorizacoes/rotas/solicitacoes.criar/papeis
Content-Type: application/json

{"papel": "leitor"}
```

Resposta padrao:

```json
{
  "sucesso": true,
  "dados": {
    "id": "solicitacoes.criar",
    "metodos": ["POST"],
    "caminho": "/solicitacoes",
    "publica": false,
    "papeis": ["admin", "operador"]
  },
  "mensagem": "Autorizacao atualizada.",
  "codigo_erro": null
}
```

## Regras de seguranca

- Endpoints de gerenciamento exigem autenticacao e papel `admin` por padrao.
- Rotas privadas devem usar `AutenticacaoSsoMiddleware` e `ExigePapelRota`.
- Rotas publicas devem ser registradas como publicas e nao devem receber esses middlewares.
- O arquivo local evita depender de banco de dados para liberar acesso ao proprio sistema.
