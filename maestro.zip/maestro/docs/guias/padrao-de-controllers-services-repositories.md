# Padrao de controllers, services e repositories

O scaffold usa uma separacao simples:

- Controller: entrada e saida HTTP.
- Service: regra de negocio.
- Repository: origem dos dados.

## Controller

O controller le dados da request, chama o service e devolve response.

```php
public function listar(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
{
    $filtro = (string) ($request->getQueryParams()['busca'] ?? '');

    return $this->renderizar($request, $response, 'solicitacoes/lista.php', [
        'solicitacoes' => $this->service->listar($filtro),
    ]);
}
```

Evite no controller:

- SQL;
- regra de negocio longa;
- HTML montado por string;
- acesso direto a Redis, banco ou API externa.

## Service

O service valida entrada, aplica regra e padroniza retorno.

```php
public function criar(array $dados): array
{
    $titulo = trim((string) ($dados['titulo'] ?? ''));

    if ($titulo === '') {
        throw new InvalidArgumentException('Informe o titulo.');
    }

    return $this->normalizar($this->repository->criar($dados));
}
```

## Repository

O repository isola a fonte dos dados.

```php
public function buscarPorId(int $id): ?array
{
    foreach ($this->solicitacoes() as $solicitacao) {
        if ((int) $solicitacao['id'] === $id) {
            return $solicitacao;
        }
    }

    return null;
}
```

Hoje o modulo exemplo usa memoria de sessao. Em sistemas reais, troque o corpo do repository por PDO, API externa ou outra fonte.

## Rascunhos persistiveis

Objetos preenchidos parcialmente devem usar `RascunhoService`, nao regra espalhada no controller.

- Controller le request e identifica o usuario autenticado.
- Service do modulo normaliza os campos parciais.
- `RascunhoService` cria, atualiza, envia e remove rascunhos expirados.
- Repository de rascunho decide se a persistencia usa arquivo local, banco ou API externa.

O submit final continua no service do modulo, com validacao completa antes de marcar o rascunho como `enviado`.

## Regra principal

Se a mesma regra precisa servir Web, API, CSV, PDF ou Excel, ela deve ficar no service.
