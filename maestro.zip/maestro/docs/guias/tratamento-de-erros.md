# Tratamento de erros

Erros inesperados sao tratados por `App\suporte\TratadorErros`.

## Objetivo

Nunca mostrar stack trace, caminho interno, DSN, query SQL, token ou payload sensivel para o usuario final.

## Fluxo

1. Uma excecao chega ao middleware de erro do Slim.
2. `TratadorErros` gera um codigo publico, como `REQ-2026-A8F31C`.
3. `VersaoCodigoService` adiciona a assinatura do codigo, como `main@abc123def456`.
4. O contexto e sanitizado por `SanitizadorContextoErro`.
5. O erro e registrado em Redis quando disponivel.
6. Se Redis falhar, o erro vai para `storage/logs/erros/erros.jsonl`.
7. O usuario ve uma pagina amigavel em `app/views/erro.php`.

## Configuracao

Variaveis principais:

```env
ERRO_PREFIXO=REQ
ERRO_TTL_REDIS=604800
ERRO_SUPORTE_URL=mailto:sti@poli.usp.br
ERRO_STORAGE_PATH=storage/logs/erros/erros.jsonl
ERRO_REDIS_HOST=
ERRO_REDIS_PORT=6379
```

O log tecnico inclui `versao_codigo`. A pagina e a resposta JSON incluem a assinatura para facilitar suporte e correlacao com o deploy.

## Teste manual

Acesse:

```text
/erro-teste
```

Resultado esperado:

- pagina amigavel;
- codigo publico visivel;
- assinatura do codigo visivel;
- erro registrado em Redis ou JSONL;
- nenhum stack trace para o usuario.

## Dados sensiveis

Campos como `senha`, `token`, `cpf`, `cookie`, `authorization`, `arquivo`, `conteudo`, `parecer` e `observacao` sao removidos ou mascarados antes do registro.
