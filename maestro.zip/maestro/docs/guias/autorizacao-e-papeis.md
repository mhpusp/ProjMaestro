# Autorizacao e papeis

A autorizacao usa a sessao Workplace e o papel ativo do usuario.

## Workplace

`AutenticacaoSsoMiddleware` injeta o atributo `workplace` na request das rotas autenticadas.

```php
$workplace = $request->getAttribute('workplace');
```

Com `SSO_HABILITADO=false`, o usuario vem das configuracoes `DEV_USUARIO_*`. Com `SSO_HABILITADO=true`, o usuario vem do OpenSSO a partir do cookie configurado em `SSO_COOKIE_NAME`.

## Modelo de permissao por rota

O arquivo `config/autorizacoes_rotas.php` guarda os papeis autorizados por rota. Ele e gerenciado pela REST API nativa do scaffold e nao deve ser editado manualmente.

Cada rota registrada em `config/routes.php` possui:

- identificador estavel, como `solicitacoes.criar`;
- metodos HTTP;
- caminho;
- flag publica ou privada;
- lista de papeis autorizados.

Rotas publicas nao passam por autorizacao. Rotas privadas usam `AutenticacaoSsoMiddleware` e `ExigePapelRota`.

## Proteger rota

Use autenticacao e autorizacao por rota em toda rota privada.

```php
$rotaSolicitacoesCriar = $registrar(
    'solicitacoes.criar',
    ['POST'],
    '/solicitacoes',
    false,
    ['admin', 'operador']
);

$app->post('/solicitacoes', $handler)
    ->add($exigeRota($rotaSolicitacoesCriar))
    ->add($autenticacao);
```

`ExigePapelRota` pressupoe que a autenticacao ja aconteceu. Se nao houver `WorkplaceSession` no request, a rota responde `401`.

## REST API de gerenciamento

Endpoints nativos:

- `GET /api/autorizacoes/rotas`: lista todas as rotas registradas e seus papeis.
- `POST /api/autorizacoes/rotas/{rota_id}/papeis`: adiciona um papel. Body: `{ "papel": "operador" }`.
- `DELETE /api/autorizacoes/rotas/{rota_id}/papeis`: remove um papel. Body: `{ "papel": "operador" }`.

Esses endpoints sao rotas privadas e, por padrao, exigem papel `admin`.

## Acesso negado

Quando o usuario nao tem permissao:

- Web recebe pagina 403 amigavel;
- API recebe JSON padronizado com `codigo_erro: ACESSO_NEGADO`;
- a tentativa e registrada na auditoria.

## Boas praticas

- Nao espalhe `if ($papel === ...)` em controllers ou views.
- Nao edite `config/autorizacoes_rotas.php` manualmente.
- Use identificadores de rota estaveis, como `solicitacoes.criar` ou `relatorios.exportar`.
- Altere papeis pela REST API de gerenciamento.
