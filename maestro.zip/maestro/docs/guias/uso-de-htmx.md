# Uso de htmx

Use htmx para interacoes pequenas, mantendo HTML renderizado pelo servidor. Nao transforme o scaffold em SPA.

## Busca sem recarregar a pagina

Na view:

```html
<input
    name="busca"
    hx-get="/solicitacoes/filtro"
    hx-target="#lista-solicitacoes"
    hx-indicator="#busca-loading"
>
```

No controller, retorne uma partial:

```php
$html = $template->renderizar('solicitacoes/parcial_lista.php', [
    'solicitacoes' => $service->listar($filtro),
]);
```

## Atualizar apenas um card

```html
<form
    method="post"
    action="/solicitacoes/101/status"
    hx-post="/solicitacoes/101/status"
    hx-target="#solicitacao-card-101"
    hx-swap="outerHTML"
>
```

O `method` e o `action` garantem fallback sem JavaScript.

## Salvar rascunho sem interceptar submit

Quando um formulario tiver envio final para uma rota e salvamento gradual para outra, coloque `hx-post` em um container interno, nao no `<form>`.

```html
<form id="form-solicitacao" method="post" action="/solicitacoes">
    <input type="hidden" name="rascunho_id" value="...">

    <div
        hx-post="/solicitacoes/rascunho"
        hx-trigger="keyup changed delay:800ms from:input, change from:select"
        hx-include="#form-solicitacao"
        hx-target="#rascunho-status"
    >
        ...
    </div>
</form>
```

Assim o htmx salva dados parciais enquanto o botao de envio continua chamando a rota final.

## Loading visual

```html
<div id="busca-loading" class="htmx-indicator">Atualizando...</div>
```

O CSS do tema ja exibe `.htmx-indicator` durante a requisicao.

## Regras

- A resposta htmx deve ser HTML parcial.
- Nao retorne JSON para atualizacao visual.
- Nao duplique regra de negocio para htmx.
- A rota completa deve continuar funcionando sem htmx.
- Prefira `outerHTML` quando for trocar um card inteiro.
