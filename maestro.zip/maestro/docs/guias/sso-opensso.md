# SSO OpenSSO

O projeto possui integracao de SSO por rota. Isso permite manter endpoints publicos e proteger apenas as rotas que precisam de usuario autenticado.

## Configuracao

As opcoes ficam no `.env` e sao carregadas por `config/settings.php`.

```env
SSO_HABILITADO=false
SSO_COOKIE_NAME=iPlanetDirectoryPro
SSO_ATTRIBUTES_URL=https://app.poli.usp.br/opensso/json/attributes
SSO_LOGIN_URL=https://app.poli.usp.br/opensso/UI/Login
SSO_LOGOUT_URL=https://app.poli.usp.br/opensso/UI/Logout
SSO_TIMEOUT=3
SSO_PAPEIS_PADRAO=leitor

SESSION_SAVE_PATH=storage/sessions
SESSION_COOKIE_SECURE=false
SESSION_COOKIE_HTTPONLY=true
SESSION_COOKIE_SAMESITE=Lax
```

Em desenvolvimento local, mantenha `SSO_HABILITADO=false` e configure o usuario fake:

```env
DEV_USUARIO_CODPES=0000000
DEV_USUARIO_NOME="Usuario Desenvolvimento"
DEV_USUARIO_EMAIL=usuario.dev@example.test
DEV_USUARIO_PAPEIS=admin,operador,leitor
```

## Como funciona

Com `SSO_HABILITADO=true`, `AutenticacaoSsoMiddleware`:

1. le o cookie configurado em `SSO_COOKIE_NAME`;
2. consulta `SSO_ATTRIBUTES_URL?subjectid=<cookie>`;
3. valida `codpes`, `codema` e `nompes`;
4. cria `UsuarioLogado`;
5. injeta `WorkplaceSession` no request;
6. redireciona usuarios nao autenticados para `SSO_LOGIN_URL` com `goto`;
7. responde `401` em JSON para rotas API sem autenticacao.

O valor do cookie nunca deve ser logado. Falhas de SSO devem registrar apenas metadados tecnicos, como endpoint e tipo de erro.

## Protegendo rotas

Rotas publicas nao recebem middleware:

```php
$app->get('/saude', $handler);
```

Rotas autenticadas recebem `AutenticacaoSsoMiddleware`:

```php
$app->get('/solicitacoes', $handler)
    ->add($autenticacao);
```

Rotas com autorizacao recebem permissao e autenticacao:

```php
$app->post('/solicitacoes/{id:[0-9]+}/status', $handler)
    ->add($exigePermissao('solicitacoes', 'solicitacao.alterar_status', 'geral'))
    ->add($autenticacao);
```

## Logout

A rota `GET /logout` encerra a sessao local. Com SSO habilitado, ela redireciona para `SSO_LOGOUT_URL` para encerrar tambem a sessao federada.

## Responsabilidades

- OpenSSO autentica e fornece identidade.
- `OpenSsoClient` valida o cookie e normaliza atributos.
- `AutenticacaoSsoMiddleware` cria a `WorkplaceSession`.
- `ExigePapelRota` decide acesso pelo papel ativo e pela rota.
- Controllers apenas leem `$request->getAttribute('workplace')` quando precisam do usuario.
