# Checklist de revisao

Use este checklist antes de abrir PR ou copiar um modulo para outro sistema. Marque cada item com uma evidencia curta, como rota testada, arquivo revisado ou comportamento observado.

## Checklist principal

- [ ] A tela funciona em celular?
  Evidencia: abrir a lista, formulario e detalhe em largura pequena.

- [ ] Existe versao mobile para tabelas?
  Evidencia: tabelas viram cards ou blocos legiveis, sem scroll horizontal obrigatorio.

- [ ] A regra de negocio esta fora do controller?
  Evidencia: validacoes e decisoes ficam no service, nao no controller.

- [ ] A rota Web e API reaproveitam o mesmo service?
  Evidencia: controller Web e controller/metodo API chamam a mesma classe de service.

- [ ] Erros sao tratados sem exibir stack trace?
  Evidencia: `/erro-teste` mostra pagina amigavel e codigo publico.

- [ ] A acao relevante registra auditoria?
  Evidencia: criar, alterar status, exportar ou negar acesso gera linha em `storage/logs/auditoria/auditoria.jsonl`.

- [ ] Ha autorizacao por rota?
  Evidencia: a rota sensivel usa `ExigePapelRota` e aparece em `GET /api/autorizacoes/rotas`.

- [ ] Ha exportacao quando aplicavel?
  Evidencia: CSV, JSON ou placeholder documentado para PDF/Excel reutiliza dados do service.

- [ ] O README do modulo foi atualizado?
  Evidencia: `app/views/<modulo>/README.md` explica fluxo, rotas e pontos de copia.

- [ ] Um desenvolvedor novo conseguiria entender o fluxo?
  Evidencia: rota, controller, service, repository e view sao faceis de localizar.

- [ ] Nao ha credenciais no codigo?
  Evidencia: segredos ficam no `.env`, e `.env.example` nao contem credenciais reais.

- [ ] Nao ha dados sensiveis nos logs?
  Evidencia: auditoria registra IDs/status/resultados, nao payloads completos, senhas ou tokens.

- [ ] O codigo segue nomenclatura em portugues?
  Evidencia: classes, metodos, variaveis e views usam portugues quando fizer sentido.

- [ ] Existe exemplo de uso?
  Evidencia: modulo, componente ou guia mostra um exemplo curto copiavel.

## Testes manuais minimos

- Abrir lista.
- Filtrar com htmx.
- Criar registro.
- Alterar status.
- Tentar acesso com papel sem permissao.
- Exportar CSV ou JSON.
- Provocar `/erro-teste` em ambiente local.
