# Padrao de rotas

As rotas ficam em `config/routes.php`. Elas devem ser explicitas e apontar para controllers pequenos.

## Convencao

Use nomes simples e previsiveis:

- `GET /solicitacoes`: lista Web.
- `GET /solicitacoes/nova`: formulario de criacao.
- `POST /solicitacoes`: cria registro.
- `GET /solicitacoes/{id}`: detalhe.
- `POST /solicitacoes/{id}/status`: acao de formulario.
- `GET /solicitacoes/filtro`: partial htmx.
- `GET /api/solicitacoes`: API REST.
- `GET /solicitacoes/exportar/csv`: exportacao.

## Controller explicito

```php
$app->get('/solicitacoes', function ($request, $response) use ($criarSolicitacaoController) {
    return $criarSolicitacaoController()->listar($request, $response);
});
```

## Rotas protegidas

Use `AutenticacaoSsoMiddleware` em toda rota que exige usuario autenticado. No arquivo `config/routes.php`, ele e obtido por:

```php
$autenticacao = $dependencias['autenticacao_sso']($app->getResponseFactory());
```

Exemplo de rota autenticada e autorizada por papel:

```php
$rotaSolicitacoes = $registrar(
    'solicitacoes.listar',
    ['GET'],
    '/solicitacoes',
    false,
    ['admin', 'operador', 'leitor']
);

$app->get('/solicitacoes', $handler)
    ->add($exigeRota($rotaSolicitacoes))
    ->add($autenticacao);
```

Rotas publicas devem ser registradas como publicas e nao recebem middlewares de autenticacao/autorizacao.

```php
$registrar('saude.ver', ['GET'], '/saude', true, [], 'Health check publico');
$app->get('/saude', $handler);
```

O registro alimenta `GET /api/autorizacoes/rotas`, usado por aplicacoes externas para gerenciar papeis por rota.

## htmx

Rotas htmx devem retornar HTML parcial, nao JSON.

```php
$app->get('/solicitacoes/filtro', function ($request, $response) use ($controller) {
    return $controller()->filtrar($request, $response);
});
```

## API

Rotas API devem retornar JSON padronizado:

```json
{
  "sucesso": true,
  "dados": {},
  "mensagem": null,
  "codigo_erro": null
}
```
