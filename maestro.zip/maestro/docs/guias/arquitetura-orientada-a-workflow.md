# Arquitetura de Software para Sistema Orientado a Workflow

Esta especificação define a arquitetura de software para um **Process-Aware Information System (PAIS)** fundamentado no paradigma de usabilidade *Task-First*, na estrutura de roteamento topológico *Dual-Source* e na autocontenção de processos (*Meta-Workflow*).

---

## 1. Visão Geral dos Componentes

### WorkflowHub
- **Conceito:** fornece a interface de operação para o workflow, nesta interface apresenta a lista de processos em andamento e ou concluídos, a agenda do usuário com as tarefas, notificações e mensagens, a lista de processos disponíveis para o usuário instanciar. Com isso, provê interface Guiada a Eventos/Agenda em vez de Menus (Paradigma *Task-First*).
- **Descrição:** Elimina os menus de sistemas tradicionais e os substitui pela agenda do usuário impulsionada por eventos do fluxo. É o painel de visão principal do usuário, exibindo:
  - Processos em andamento (`RunningProcesses`).
  - Processos disponíveis para instanciar (`AvailableProcesses`).
  - Agenda do usuário com notificações e tarefas (`Tasks`, `Notifications`) em ordem de prioridade de trabalho.
  - Envia notificações de usuário aos participantes.
  - Chat com os participantes online.
- **Propriedades:** 
  1. listaProcessos   -- Lista de processos disponíveis para instanciar
  2. listaInstancias  -- Lista de processos instanciados em andamento e concluídos
  3. Agenga           -- Lista de tarefas, notificações e mensagens     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Integração:** 
  - WorkflowHub carrega o WorkflowHist para mostrar processos em andamento e processos concluídos.
  - WorkflowHub carrega o WorkflowNotes para mostrar a agenda do usuário com as tarefas e notificações, alem disso provê envio de mensagens e chat.
  - WorkflowHub carrega o WorkflowMeta para mostrar os processos disponíveis para instânciar.
As notificações e tarefas na agenda do usuário são solicitadas pelo `WorkflowRouter` ao componente `WorkflowNotes` durante a execução dos processos em andamento. Para compor a visão do usuário, o `WorkflowHub` utiliza informações fornecidas pelos componentes `WorkflowHist`, `WorkflowNotes` e `WorkflowMeta`. A navegação é tratada separadamente pelo `WorkflowRouter`, acionado pelas rotas de execução.
- **Regras de Visualização:**
  1. Exibe apenas os processos que o usuário logado possui permissão para instanciar.
  2. Exibe apenas os processos concluídos e em andamento dos quais o usuário participa.
  3. Exibe a agenda de eventos e notificações do usuário logado.
  4. Pesquisa e exibe processos concluídos pelo usuário logado.
  5. Usuários com níveis gerenciais e administrativos possuem uma visão expandida de processos a instanciar e em andamento.

---

### WorkflowMap
- **Conceito:** fornece as estruturas com os mapas MapForward e MapBackward para definir o roteamento de navegação, estes mapas são produzidos a partir das duas fontes de dados, o arquivo  JSON modelo do processo é o mapa estático, e Banco de dados é caminho percorrido e consolidado.
- **Descrição:** Carrega o mapa estático do processo proveniente de arquivos (JSON/XML) que definem o modelo do processo (`Load JSON file`). Gera uma estrutura topológica para o roteamento sequencial (`MapForward`) do fluxo do início ao fim.
- **Propriedades:** 
  1. 
  2. 
  3.     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Mecanismo:** A estrutura contém a sequência de nós, onde cada nó possui um ID de chave única e os endereços de origem e destino. O mapa funciona como uma tabela de endereços em um grafo estático, tratando vértices e arestas (nós) como os caminhos fornecidos pelo modelo.
- **Informações Providas:** Ao avançar (`MapForward`), carrega o grafo com as propriedades específicas de cada nó:
  - Tipo do nó: `"inicio"`, `"atividade"`, `"gateway"`, `"evento"`, `"fim"`, `"bifurca"`, `"junta"`, `"processo"`.
  - A propriedade arquivo do nó especifica o HTML que renderiza a *view* (interface) do nó.
  - A propriedade evento do nó define os Eventos que serão disparados pelo nó.
  - A propriedade Raia (*Lane*) define a qual raia e participante o nó está associado.
- **Regras de Mapeamento do Fluxo:**
  1. Gera o `MapForward` a partir de arquivos JSON/XML com todos os endereços dos nós do início ao fim do fluxo.
  2. O `MapForward` apresenta todas as possibilidades de caminhos mapeados no processo modelo.
  3. Gera o `MapBackward` a partir de dos registros na tabela SQL do banco de dados. 
  4. O `MapBackward` representa o caminho consolidado pelos usuários na instância do processo.
  5. Para compor `MapForward` e `MapBackward` são necessários dois DTO's, uma para o processo e outro para elemento. Como existem duas fontes de dados, uma para o caminho estático e outra para o caminho consolidado, esses DTO's devem ser genáricos reunindo propriedades que se apresentam nas duas fontes de dados, conforme tabela esplicativa abaixo:
   

---

### WorkflowHist
- **Conceito:** fornece as instâncias dos processos que estão consolidados em banco de dados, a saber, processos em andamento e processos concluídos.
- **Descrição:** Instancia o processo e carrega as informações de instância a partir do banco de dados, preparando o início da execução (`Instantiate Process`). Recupera do banco (`Retrieve Process`) apenas os dados necessários para a criação da instância: ID, nome do processo, versão atual, localização do arquivo JSON/XML do modelo, permissões de instanciação e nomes das raias. Dispara eventos definidos no nós dos processos.
- **Propriedades:** 
  1. 
  2. 
  3.     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Mecanismo:** Gera uma estrutura topológica para o roteamento em sentido inverso (`MapBackward`), representando o histórico de execução efetivo (caminho consolidado) percorrido pelo usuário na instância.
- Os métodos (funções) de persistência e recuperação de dados devem ser dinâmicos, com isso, devem se adaptar às necessidades específicas de cada nó do processo quanto ao formato de dados e processamento. 
     
- **Regras de Persistência e Recuperação de Dados:**
  1. As informações para instanciar um novo processo são recuperadas do banco de dados de processos disponíveis.
  2. Ao instanciar um novo processo, o usuário pode definir as atribuições para atuação nas Raias. Cada Raia deve ser atribuida a um usuário específico ou a uma função que caracteriza um grupo de usuários. Caso a atribuição não seja definida na instânciação do processo, poderá ser definida depois disso pelo dono do processo.
  3. O processo principal vincula a instância inicial. Subprocessos anexados têm seus nós persistidos na mesma instância do processo principal, mantendo a referência hierárquica pai-filho.
  4. Cada nó consolidado durante o avanço do fluxo gera um novo registro no banco de dados relacional com referência ao processo pai.
  5. O tipo de nó `subp` no modelo principal dispara o carregamento e mapeamento do subprocesso correspondente no `WorkflowMap`.
  6. Gera o mapa `MapBackward` exclusivamente a partir dos dados persistidos no banco de dados relacional.
  7. O `MapBackward` contém estritamente o caminho histórico consolidado pela execução do usuário.

---

### WorkflowRouter
- **Conceito:** coordena a navegação pelos nós do processo com base em duas fontes (Dual Source): o mapa estático do JSON e o histórico consolidado no banco. Determina o nó atual e as transições, delegando a leitura e persistência do histórico ao `WorkflowHist`, a resolução da definição ao `WorkflowMap` e as operações de agenda ao `WorkflowNotes`. Não acessa diretamente as tabelas da agenda.
- **Descrição:** Opera a estrutura *Dual-Source* (Sincronismo de Grafos), diferenciando formalmente a **Topologia do Processo** (grafo completo no JSON/XML) do **Histórico de Execução Efetivo** (trilha linear auditável no banco de dados). Para isso, utiliza uma estrutura de dados DTO (Data Transfer Object) que é genérica e pode acomodar tanto as informações de `MapForward` como de `MapBackward` no mesmo DTO, ou seja, uma única estrutura de dados comum aos dois mapas. Ao avançar, pode disparar os eventos previstos nos nós de cada processo.
Ao avançar na execução do processo, um outro processo, mapeado em outro arquivo JSON, pode ser carregado como subprocesso do processo principal.
Por padrão, todo arquivo JSON carregado mapeia um processo, a distinção entre processo e subprocesso é uma convenção para facilidade de visualização em notações (como BPMN) e reuso na biblioteca de processos. Para o `MapBackward`, o sistema de navegação, no carregamento de arquivos tudo é mapa de processo, não há distinção entre processo e subprocesso, o mapa acumula todos os nós de arquivos carregados e trata a sequência como um fluxo único.
O carregamento de um fluxo completo pode envolver a leitura de múltiplos arquivos JSON interconectados.
- **Propriedades:** 
  1. 
  2. 
  3.     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Mecanismo:** Provê navegação bidirecional:
  - **Avançar (`Forward Process`):** Determina o próximo nó de destino utilizando o `MapForward` (fornecido pelo `WorkflowMap`).
  - **Retroceder (`Backward Process`):** Determina o nó anterior (a origem) utilizando o `MapBackward` (fornecido pelo `WorkflowHist`).
  - **Disparo de Eventos:**
     Cada nó do processo possui uma propriedade chamada evento que é utilizada para notificar, agendar tarefa, enviar email etc, essa propriedade executa um método dinâmico para disparar esses eventos que estão previstos em cada nó. O método deve receber dados e algoritmo e prover informação de retorno. 

  EXISTEM TRÊS SITUAÇÕES PARA ROTEAMENTO

  1 - Quando um processo vai ser instanciado para iniciar. O Router carrega o `MapForward`, isso significa ler o arquivo JSON do processo,, sincroniza e aponta para o nó inicial do processo e não existe caminho para retroceder ainda. Neste caso, conforme o usuário avança pelos nós do processo, o `MapBackward` é mapeado em tempo de execução armazenando o caminho percorrido a partir do nó inicial. 
  2 - Quando um processo em andamento foi recuperado do banco de dados. O Router carrega o `MapBackward` a partir do banco de dados, dessa forma encontra o último nó consolidado. Em seguida, o Router carrega o `MapForward`, pois para saber qual o próximo nó precisa do mapeamento estático, sincroniza e aponta para o próximo nó. A partir daí o `MapBackward` continua a ser mapeado em tempo de execução armazenando o caminho percorrido a partir do nó atual.  
  3 - Quando um processo terminado foi recuperado do banco de dados. Este é o caso mais simples para o Router, pois neste caso o `MapBackward` possui todo o caminho consolidado e por isso pode ser utilizado como única fonte de informação para avançar ou retroceder pelos nós do processo, isso apenas para visualização, uma vez que este processo já está concluído. 

- **Regras de Navegação:**
  1. Sincroniza os endereços dos mapas `MapForward` e `MapBackward` ao carregar um processo em andamento para posicionar no próximo nó em aberto.
  2. Todas as *views* disponibilizam ações de **Avançar** e **Voltar** (exceto o nó inicial, que possui apenas Avançar, e o nó final, que possui Voltar e Concluir).
  3. O movimento à frente utiliza obrigatoriamente o `MapForward` devido às escolhas condicionais e transições do modelo.
  4. Ao avançar, as propriedades do nó determinam a renderização do formulário HTML, execução de eventos (cálculos, integrações, notificações) e validação de pré-requisitos antes da consolidação.
  5. O movimento para trás utiliza obrigatoriamente o `MapBackward`, garantindo o retorno estrito pela trilha consolidada.
  6. **Ações no Retrocesso:**
     - Leitura/visualização de dados em nós consolidados.
     - Alterações em nós consolidados dependem de permissões e propriedades do nó.
     - **Regra para Nós Órfãos:** Caso uma alteração em nó passado invalide a rota subsequente, os registros posteriores no banco de dados são marcados como descontinuados/cancelados (*soft-delete* ou versão de histórico) e suas tarefas/notificações pendentes são revogadas, preservando a auditabilidade.

---

### WorkflowEventHandler

- **Conceito:** Provedor e orquestrador de execução de eventos dinâmicos baseados no Padrão Strategy. Atua como o barramento/mediador entre os nós do workflow e as ações do sistema (notificações, envio de e-mails, integrações e chamadas a Repositories de negócio do Slim PHP).

- **Descrição:** Registra e gerencia os manipuladores (handlers) de eventos. Processa a string de assinatura definida na propriedade evento do nó no arquivo JSON, extrai parâmetros e invoca a estratégia correspondente sem acoplar o motor do workflow às regras de negócio específicas das aplicações.

- **Propriedades:** handlers -- Lista/Registro de estratégias de eventos registradas na aplicação.

- **Métodos:** 
registerHandler(WorkflowEventHandlerInterface $handler) -- Registra uma nova estratégia de evento.
dispatch(string $eventSignature, array $context) -- Interpreta a assinatura textual e executa o manipulador correspondente.

1. Visão Geral e Responsabilidade

O **`WorkflowEventHandler`** é o componente orquestrador de execução de eventos baseados no **Padrão Strategy**. Atua como o barramento/mediador entre a topologia do workflow e as ações do sistema (notificações, envio de e-mails, integrações e chamadas a Repositories de negócio do Slim PHP).

2.  Principais Objetivos:
- **Desacoplamento do Core:** Isola a lógica de execução de ações da navegação topológica do `WorkflowRouter`.
- **Reuso Máximo de Código:** Garante que o motor principal não precise ser modificado ao adicionar novos tipos de processos ou regras de negócio.
- **Integração Nativa com o Slim PHP:** Permite que eventos de persistência acessem diretamente os Repositories e Services da aplicação Slim via Injeção de Dependências (PHP-DI / PSR-11).

4. Padrões de Projeto Aplicados

  1. **Strategy Pattern:** Cada tipo de evento (`AgendaNotifierEventHandler`, `DataFormPersistEventHandler`, `SendEmailEventHandler`) é uma estratégia isolada que implementa uma interface comum (`WorkflowEventHandlerInterface`).
  2. **Event Dispatcher / Command Bus:** O `WorkflowEventDispatcher` recebe assinaturas textuais lidas das propriedades do nó no JSON (ex: `"notificar('TAREFA')", "persistir_dados('App\\Repositories\\VeiculoRepository')"`) e as despacha para a Strategy correspondente.
  3. **Dependency Injection (PSR-11):** O container do Slim resolve automaticamente as dependências necessárias para cada handler de evento.

5. Interfaces e Estrutura de Contratos

6.  Interface da Estratégia de Evento (`app/workflow/contracts/WorkflowEventHandlerInterface.php`)

---

### WorkflowNotes
- **Conceito:** fornece a Agenda de eventos do usuário, nesta agenda encontra-se tarefas, notificações, mensagens. É o mecanismo que o usuário utiliza para interagir com os processos, as tarefas do usuário apontam para as as ações que ele deve executar nos nós dos processos estanciados e em andamento, cada usuário tem um papel a desempenhar na execução de um processo, este papel é delimitado pelas raias do processo, ao clicar em uma tarefa, o processo é carregado e o router mostra o processo à partir do nó referente à tarefa de ação que o usuário deve executar, cada usuário tem a sua raia, a partir daí ele continua navegando pelo fluxo do processo e interagindo com os próximos nós disponíveis em sua raia.

- **Descrição:** Mantém a agenda individual do usuário (`Agenda Notifications, Tasks`) e fornece dados para composição do `WorkflowHub`.
- **Propriedades:** 
  1. 
  2. 
  3.     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Mecanismo:** Atende aos eventos disparados pelo `WorkflowRouter` durante a execução dos nós.
- **Regras da Agenda:**
  1. Armazena notificações e tarefas ordenadas por prioridade de trabalho.
  2. Atribui os itens automaticamente aos usuários participantes das raias (*Lanes*) do nó em execução.
  3. Cada registro contém referências diretas apontando para o ID da instância do processo e o ID do nó gerador.
  4. É o único componente responsável pelas regras de negócio da agenda, incluindo validação, deduplicação, criação, atualização e exclusão de itens.
  5. Ao criar uma tarefa de retomada, verifica a existência de uma tarefa para o mesmo usuário e instância, atualiza seus dados se já existir e retorna ao solicitante o identificador do item criado ou atualizado.

---

### WorkflowMeta
- **Conceito:** fornece a manutenção do cadastro de processos, insere o cadastro de um novo processo, atualiza a versão de processos existentes. Fornece a lista de processos para instanciar. Pesquisa e mostra informações de processos cadastrados, Desativa processos (Quando uma nova versão é criada, a versão pai anterior é desativada), Excluir processos (permite exclusão apenas de processos que não possuem instâncias). (*Self-Hosting Processes* / Meta-Workflow).
- **Descrição:** Gerencia o ciclo de vida e a governança de processos utilizando um processo mapeado no próprio motor para versionar e cadastrar outros processos (*Process-Aware Process Management*).
- **Propriedades:** 
  1. 
  2. 
  3.     
- **Métodos:** 
  1. 
  2. 
  3.     

- **Regras de Versionamento:**
  1. A tabela processos mantém os dados do cadastro, a atualização de versão e a inativação de qualquer processo do sistema. As colunas id e versao são geradas pelo sistema e não são editáveis. 
  2. Ao incluir um novo processo, o número da versão é definido como 1. A coluna id é a identificação única do processo no cadastro; a coluna versao descreve o número de versão do processo.
  3. Ao incluir uma nova versão de um processo já existente, a versão anterior é marcada como inativa na coluna status e a nova versão passa a ser a versão ativa. A coluna processo_pai_id aponta para o id da versão anterior do processo.  Processos inativados não podem ser instanciados.
  4. Ao incluir um novo processo, o usuário deve apontar o local onde se encontra o arquivo json que mapeia o processo, este arquivo deve ser carregado em upload para a pasta jsons. O arquivo json possui um nó inicial que, como um metadados descreve informações do processo. Este metadados fornece várias informações úteis ao cadastro do processo, entre elas estará uma lista dos com os nomes de arquivos json dos subprocessos que compõem o processo principal. Todos estes arquivos json devem ser carregados em upload para a pasta jsons, o sistema deve validar este carregamento, garantindo que todos estes arquivos sejam carregados em upload no momento do cadastro do processo principal.

---

### WorkflowMetrics
- **Conceito:** fornece a visão de um dashboard com métricas sobre os processos consolidados em andamento e também processos concluídos. Provedor de Indicadores e Métricas de Processos.
- **Descrição:** Consolida dados extraídos pelo `WorkflowHist` de instâncias concluídas e em andamento.
- **Entrega:** Alimenta a camada de apresentação com painéis de *Dashboards* e indicadores chave de desempenho (KPIs).

---

### Princípio de coesão e limites de responsabilidade

Cada componente do Workflow é dono das regras de negócio de sua área. Os demais componentes solicitam operações por meio dos contratos (`Workflow*Interface`) e não acessam diretamente seus repositórios, tabelas ou arquivos internos. O componente proprietário valida os pré-requisitos, executa a operação e devolve o resultado; erros reais de domínio ou persistência são propagados explicitamente, sem sucesso implícito.

- **WorkflowHub** coordena a composição da tela inicial, obtendo agenda, histórico e processos disponíveis pelos contratos correspondentes. Não implementa regras dessas áreas nem acessa seus repositórios.
- **WorkflowRouter** coordena a navegação e o ciclo da instância. Usa `WorkflowMeta` para obter processos disponíveis à instanciação, `WorkflowMap` para definição e resolução dos nós, `WorkflowHist` para leitura e persistência do histórico e `WorkflowNotes` para operações de agenda. Não manipula diretamente registros da agenda.
- **WorkflowNotes** é dono do ciclo de vida e das regras dos itens da agenda; seu repositório limita-se à leitura e persistência SQL.
- **WorkflowHist** é dono da leitura e persistência de instâncias, elementos consolidados e histórico de execução.
- **WorkflowMap** é dono do carregamento, validação e resolução do modelo estático do processo e dos arquivos de nó.
- **WorkflowMeta** é dono das operações e regras do catálogo de processos. O `WorkflowHist` pode revalidar que um processo ainda está ativo dentro da transação de criação da instância, protegendo a integridade do registro.
- **WorkflowMetrics** permanece como espaço reservado: ainda não possui contrato nem implementação funcional integrada.
- **Controllers** adaptam HTTP e apresentação às operações dos componentes; não substituem regras de domínio.

Serviços podem coordenar outros componentes por interfaces quando o caso de uso exigir, mas não devem contornar o proprietário da regra. Repositórios encapsulam detalhes de persistência; não devem decidir políticas que pertencem ao serviço de domínio. Um método de serviço deve retornar um resultado explícito quando a operação produzir um identificador ou estado relevante ao solicitante.

## 2. Integração Workflow com o framework Slim PHP

### Recomendações de Integração e Arquitetura no Slim PHP
Para acomodar o motor de workflow mantendo o desacoplamento e a organização do ecossistema Slim PHP, recomenda-se organizar os componentes em uma subestrutura dedicada em `app/workflow` (com `contracts`, `services`, `dto` e `controllers`). 

1. **Abstração por Contratos (Interfaces vs. Implementações):**
   - **Programar para Interfaces:** Componentes de domínio consumidos por outros componentes devem expor contratos em `contracts/` e implementações em `services/`. Controllers são adaptadores HTTP; não precisam de uma interface de serviço se não forem consumidos por outro componente.
   - **Injeção de Dependências (PSR-11):** As dependências de domínio são fornecidas pelos contratos. Isso permite que serviços como o `WorkflowRouter` recebam `WorkflowHistInterface`, `WorkflowMetaInterface`, `WorkflowMapInterface` e `WorkflowNotesInterface` no construtor (*Constructor Injection*).

2. **Formato Interno de Troca de Dados (Arrays / DTOs em Memória):**
   - **Atenção ao Desempenho:** Não utilize strings JSON serializadas para a comunicação interna entre os serviços PHP do motor. O parse e encode sucessivos geram *overhead* de processamento.
   - **Fronteiras do Sistema:** Mantenha o formato JSON estritamente nas pontas do sistema (leitura do arquivo estático de mapa e entrega da resposta HTTP no Controller) ou na persistência de colunas SQL do tipo JSON.
   - **Trânsito Interno:** O intercâmbio de informações entre `WorkflowHist`, `WorkflowMap`, `WorkflowRouter` e os Controllers deve ocorrer via objetos DTO tipados ou arrays associativos indexados por ID do nó em tempo de execução.

3. Estratégia da Rota Única no Slim PHP
Detalhamento do papel do componente **WorkflowRouter**, a estratégia de roteamento via **Rota Única no Slim PHP** e a convenção de **armazenamento isolado de arquivos JSON e views PHP** por processo.
O roteamento do Slim PHP e o roteamento topológico do `WorkflowRouter` possuem papéis totalmente distintos:

a. **Roteador do Slim PHP:** Trata apenas os endpoints da API Web. Possui **rotas genéricas estáticas** de execução.
b. **`WorkflowRouter` (Motor):** Decide dinamicamente qual formulário/view PHP/HTML carregar com base na propriedade `arquivo` do nó no mapa do processo.

Com essa separação, **não é necessário criar novas rotas no Slim ao cadastrar um novo processo de negócio**.

O **`WorkflowRouter` deve ser implementado estritamente como um SERVICE (Regra de Negócio/Domínio)** e **NÃO** como um Controller HTTP.

* **WorkflowRouter (Service):**
  * É o motor de navegação do processo e gerenciador do estado do grafo.
  * Determina o nó atual, analisa a transição topológica ($MapForward$ e $MapBackward$) e aplica as regras do nó.
  * Valida permissões de raias, executa algoritmos e dispara eventos de domínio (envio de e-mails, notificações via `WorkflowNotes`).
  * **Independência de Protocolo:** Não processa requisições HTTP (`$request`/`$response`), cookies ou cabeçalhos. Recebe dados puros do PHP (DTOs, IDs, arrays) e devolve DTOs com o resultado do processamento.

* **Controllers (Camada de Entrega HTTP Slim):**
  * Atuam como intermediários entre a Web/API e os Services.
  * Capturam a requisição HTTP do cliente, extraem os parâmetros e delegam a execução para o `WorkflowRouter`.
  * Formatam a resposta final (geralmente JSON) devolvendo a view e o estado do nó para a interface do `WorkflowHub`.

Armazenamento de Arquivos por ID do Processo (Pacote do Processo)

Para garantir o isolamento e evitar conflitos de nomes entre arquivos de views PHP/HTML (como `ativ1.php`) teremos uma pasta chamada workflow/wfiles, todos os arquivos de um mesmo processo (modelo JSON e views HTML) devem ficar organizados em uma subpasta cujo nome reflete a identificação do processo (por exemplo, o `id` do cadastro do processo).

Vantagens do Modelo

a. **Desacoplamento Completo:** Adicionar novos processos ou versionar processos existentes não requer alterações nas rotas do Slim PHP.
b. **Organização e Governança:** Agrupar arquivos por ID do processo facilita o upload via `WorkflowMeta` e a manutenção dos modelos e formulários.
c. **Isolamento de Versões:** Diferentes versões do mesmo processo ficam isoladas em suas próprias pastas por ID, garantindo estabilidade para instâncias em andamento.

### 2.1 Rodando o Workflow no Linux com Apache - Configurar Permissões

1. Configuração de permissões para o Workflow gravar em pastas do servidor

Exemplo concedendo permissão na pasta wfiles em que os arquivos JSON são transferidos para o servidor por upload:

sudo setfacl -m u:daemon:rwx /opt/lampp/htdocs/maestro/app/workflow/wfiles
sudo setfacl -d -m u:daemon:rwx /opt/lampp/htdocs/maestro/app/workflow/wfiles

O primeiro comando permite que o Apache crie a pasta do processo. O segundo faz com que novas pastas criadas ali também concedam acesso ao Apache, necessário para gravar os JSON.

Para conferir:

getfacl /opt/lampp/htdocs/maestro/app/workflow/wfiles
sudo -u daemon test -w /opt/lampp/htdocs/maestro/app/workflow/wfiles \
  && echo "Apache pode gravar" \
  || echo "Apache ainda não pode gravar"

Evite usar chmod 777: as ACLs concedem a permissão necessária ao usuário do Apache sem abrir o diretório para todos.

#### Retomada de instâncias em andamento

A rota genérica `GET/POST /workflow/instancias/{id}` carrega uma instância pela tabela `processo_instancias`, monta o `MapForward` a partir do JSON armazenado no pacote identificado por `processo_id` e compõe o `MapBackward` com os elementos concluídos em `instancia_elementos`. Na retomada, o próximo nó é o destino do último elemento concluído. Se ainda não houver elemento concluído, o roteador posiciona a instância no nó de tipo `inicio`.

Ao avançar, os dados do formulário e a conclusão do nó atual são persistidos antes de abrir o destino. Ao voltar, o roteador usa a propriedade `origem` quando ela aponta para um elemento do histórico e, caso contrário, retorna ao último elemento consolidado. O parâmetro `elemento` da rota mantém o nó selecionado entre requisições GET/POST; a view do nó é carregada do pacote do processo dentro da view padrão `workflow/views/workflowrouter.php`.

No nó de tipo `fim`, a ação é **Concluir**: a resposta afirmativa consolida o nó, marca a instância como concluída e devolve o controle ao `WorkflowHub`, limpando o estado mantido pelo `WorkflowRouter`. A resposta negativa mantém a instância aberta no nó final. Respostas de escolha única são exibidas como opções de seleção direta (radio), em vez de combo.

#### Instanciação e fechamento

A rota genérica `GET/POST /workflow/processos/{id}/instanciar` carrega o modelo de um processo ativo e apresenta o nó inicial sem criar registros. Cada elemento `inicio` recebe a pergunta padrão “Você deseja iniciar este processo?” e opções **Sim/Não**. **Sim** cria a instância e consolida o nó inicial em uma transação antes de navegar ao próximo nó; **Não** limpa o estado e retorna ao `WorkflowHub` sem persistir a instância.

Durante a execução, o botão **Fechar** retorna ao `WorkflowHub` sem concluir a instância. Os nós concluídos já persistidos são mantidos; dados ainda não enviados do nó atual não são gravados.

Ao fechar uma instância em andamento, o `WorkflowRouter` também solicita ao `WorkflowNotes` uma nova tarefa `workflow_retoma` para o usuário que a fechou. A tarefa é vinculada à instância e ao processo e aparece na Agenda com um link para retomar o fluxo. A instância continua em andamento.

### Mapeamento das Rotas Genéricas   

5. **Mapeamento das Classes e Interfaces dos Componentes:**

| Componente | Interface (`contracts/`) | Classe Concreta (`services/` / `controllers/`) | Função no Ecossistema Slim |
| :--- | :--- | :--- | :--- |
| **WorkflowHub** | Não aplicável (Controller HTTP) | `WorkflowHub` | Controller PSR-7 que compõe a tela inicial consultando os componentes por seus contratos. |
| **WorkflowRouter** | `WorkflowRouterInterface` | `WorkflowRouter` | Service responsável pela navegação topológica e sincronismo *Dual-Source*. |
| **WorkflowMap** | `WorkflowMapInterface` | `WorkflowMap` | Service leitor de arquivos de mapa estático (JSON/XML) e construtor do `MapForward`. |
| **WorkflowHist** | `WorkflowHistInterface` | `WorkflowHist` / `WorkflowHistRepository` | Service/Repository responsável por gerenciar a persistência relacional do `MapBackward`. |
| **WorkflowNotes** | `WorkflowNotesInterface` | `WorkflowNotes` / `WorkflowNotesRepository` | Service e repositório que gerenciam as regras e a persistência da agenda do usuário. |
| **WorkflowMeta** | `WorkflowMetaInterface` | `WorkflowMeta` / `WorkflowMetaRepository` / `ProcessoRepository` | Service de governança, cadastro, versionamento e catálogo de processos; `ProcessoRepository` mantém a integração de persistência com o Slim. |
| **WorkflowMetrics**| Não definido | `WorkflowMetrics` (espaço reservado) | Componente ainda não integrado; definir contrato e responsabilidade ao implementar métricas. |

4. **Estrutura de Diretórios Recomendada (`app/workflow`):**

```text
app/
└── workflow/
    ├── contracts/                  <-- Interfaces (Contratos PSR)
    │   ├── WorkflowHubInterface.php
    │   ├── WorkflowRouterInterface.php
    │   ├── WorkflowEventHandlerInterface.php  <-- Interface base para cada Strategy
    │   ├── WorkflowEventDispatcherInterface.php
    │   ├── WorkflowMapInterface.php
    │   ├── WorkflowHistInterface.php
    │   ├── WorkflowNotesInterface.php
    │   ├── WorkflowMetaInterface.php
    │   └── WorkflowMetricsInterface.php
    │
    ├── services/                   <-- Regras de Negócio e Motores (Classes Concretas)
    │   ├── WorkflowRouter.php      <-- Recebe Hist e Map via Injeção de Dependência
    │   ├── WorkflowEventDispatcher.php  <-- O novo componente WorkflowEventHandler
    │   ├── WorkflowMap.php         <-- Parser do JSON
    │   ├── WorkflowHist.php        <-- Consulta o Banco SQL
    │   ├── WorkflowNotes.php       <-- Gerenciador da Agenda
    │   ├── WorkflowMeta.php        <-- Meta-Processos
    │   └── WorkflowMetrics.php     <-- KPIs
    │
    ├── events/                     <-- Estratégias Concretas de Eventos (Strategies)
    │   ├── NotificarAgendaEventHandler.php
    │   ├── EnviarEmailEventHandler.php
    │   └── PersistirDadosFormEventHandler.php
    │
    ├── repositories/
    │   └── WorkflowHistReposytory.php    
    │
    ├── dto/                        <-- Objetos de Transferência de Dados Genéricos
    │   ├── ProcessoDTO.php         <-- Metadados do processo
    │   └── ElementoDTO.php         <-- Representação padronizada do Nó
    │
    └── controllers/                <-- Camada de Entrega HTTP do Slim
        └── WorkflowHubController.php <-- Ponto central que atende o frontend

---

## 3. Integração Workflow com Banco de Dados SQL

#### Diagrama De Para entre DTO Processo/Elemento, Arquivo JSON, Tabelas SQL

#### DTO Processo

<!-- TABELA 1: DTO PROCESSO -->
<h4>DTO Processo</h4>
<table>
  <thead>
    <tr>
      <th width="25%">DTO Processo</th>
      <th width="25%">JSON</th>
      <th width="25%">SQL</th>
      <th width="25%">Tabela</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>id</td>
      <td>id</td>
      <td>id</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>processo_id</td>
      <td></td>
      <td>processo_id</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>nome</td>
      <td>nome</td>
      <td>nome</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>descricao</td>
      <td>descricao</td>
      <td>descricao</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>versao</td>
      <td>versão</td>
      <td>versão</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>arquivo</td>
      <td>arquivo</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>dados_form</td>
      <td></td>
      <td>dados_form</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>concluido</td>
      <td></td>
      <td>concluido</td>
      <td>Processo e processo_instancia</td>
    </tr>
    <tr>
      <td>dono_processo</td>
      <td>dono_processo</td>
      <td>dono_processo</td>
      <td>processo</td>
    </tr>
    <tr>
      <td>lista_subprocessos</td>
      <td>lista_subprocessos</td>
      <td></td>
      <td>processo</td>
    </tr>
    <tr>
      <td>raias_participantes</td>
      <td>raias_participantes</td>
      <td>raias_participantes</td>
      <td>Processo e processo_instancia</td>
    </tr>
    <tr>
      <td>criado_por</td>
      <td></td>
      <td>criado_por</td>
      <td>Processo e processo_instancia</td>
    </tr>
    <tr>
      <td>created_at</td>
      <td></td>
      <td>created_at</td>
      <td>Processo e processo_instancia</td>
    </tr>
    <tr>
      <td>updated_at</td>
      <td></td>
      <td>updated_at</td>
      <td>Processo e processo_instancia</td>
    </tr>
    <tr>
      <td>Elementos</td>
      <td>elementos</td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>

<br>

### DTO Elemento

<!-- TABELA 2: DTO ELEMENTO -->
<h4>DTO Elemento</h4>
<table>
  <thead>
    <tr>
      <th width="25%">DTO Elemento</th>
      <th width="25%">JSON</th>
      <th width="25%">SQL</th>
      <th width="25%">Tabela</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>id</td>
      <td>id</td>
      <td>elemento_id</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>tipo</td>
      <td>tipo</td>
      <td>tipo</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>nome_raia</td>
      <td>nome_raia</td>
      <td>nome_raia</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>participante</td>
      <td>participante</td>
      <td>participante</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>nome</td>
      <td>nome</td>
      <td>nome</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>descricao</td>
      <td>descricao</td>
      <td>descricao</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>arquivo</td>
      <td>arquivo</td>
      <td>arquivo</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>dados_form</td>
      <td></td>
      <td>dados_form</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>pergunta</td>
      <td>pergunta</td>
      <td>pergunta</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>respostas</td>
      <td>respostas</td>
      <td>respostas</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>evento</td>
      <td>evento</td>
      <td>evento</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>volta</td>
      <td>volta</td>
      <td>volta</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>libera</td>
      <td>libera</td>
      <td>libera</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>concluido</td>
      <td></td>
      <td>concluido</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>criado_por</td>
      <td></td>
      <td>criado_por</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>created_at</td>
      <td></td>
      <td>created_at</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>updated_at</td>
      <td></td>
      <td>updated_at</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>origem</td>
      <td>origem</td>
      <td>origem</td>
      <td>instancia_elementos</td>
    </tr>
    <tr>
      <td>destino</td>
      <td>destino</td>
      <td>destino</td>
      <td>instancia_elementos</td>
    </tr>
  </tbody>
</table>

---

## 4. Paradigma de Desenvolvimento e Usabilidade

### Usabilidade e Operação
- **Modelo Orientado a Tarefas (*Task-First*):** O usuário não navega por menus de módulos administrativos (ex: telas ERP convencionais). Toda a interação ocorre via agenda priorizada.
- **Curva de Aprendizagem:** A execução guiada reduz a necessidade de treinamento, pois o sistema apresenta os formulários, regras e ações estritamente no momento em que a tarefa deve ser realizada.

### Ciclo de Desenvolvimento
1. **Modelagem:** O analista desenha o fluxo em ferramentas BPMN (ex: Camunda) e mapeia dados de entrada, saídas, propriedades e eventos de cada nó.
2. **Conversão:** O mapa XML BPMN é convertido para a estrutura JSON utilizada pelo `WorkflowMap`.
3. **Implementação de Eventos:** Os desenvolvedores codificam as funções específicas dos nós (regras de negócio, integrações e formulários HTML) registradas nos eventos do processo.