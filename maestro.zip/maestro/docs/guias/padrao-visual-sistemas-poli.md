# Padrao visual Sistemas Poli

O layout visual deve ser sobrio, institucional e responsivo. A base usa Tabler, Bootstrap 5 e o tema `public/assets/css/poli-theme.css`.

## Layout base

Use `app/views/base.php` para paginas completas. Ele ja inclui:

- cabecalho `Sistemas Poli`;
- nome do sistema;
- componente do usuario Workplace;
- area principal;
- rodape com STI, Escola Politecnica da USP e versao.

## Componentes

Componentes reutilizaveis ficam em `app/views/componentes`.

Exemplo:

```php
$texto = 'Ativo';
$tipo = 'sucesso';
require __DIR__ . '/../componentes/badge_status.php';
```

Componentes disponiveis:

- `badge_status.php`
- `card_processo.php`
- `tabela_responsiva.php`
- `barra_acoes_mobile.php`
- `alerta.php`
- `modal_confirmacao.php`
- `seletor_papel_ativo.php`
- `campo_busca_htmx.php`
- `workplace_usuario.php`

## Mobile-first

Primeiro pense na tela pequena. Evite tabelas espremidas. Quando houver lista, prefira cards no celular e tabela apenas em telas maiores.

## Evite

- identidade visual extravagante;
- excesso de JavaScript;
- cores fora do tema;
- HTML montado no controller;
- views que acessam banco.
