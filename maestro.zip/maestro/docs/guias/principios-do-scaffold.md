# Principios do scaffold

Data: 2026-06-07

## Objetivo

Este documento define os principios e decisoes arquiteturais do scaffold PHP Slim que sera usado como base para novas aplicacoes da Informatica Poli.

O scaffold deve modernizar pontos criticos observados nos exemplos Fat-Free Framework, sem perder a familiaridade operacional da equipe. A prioridade e produzir uma base simples, compreensivel, segura e sustentavel, evitando arquitetura excessivamente abstrata.

## Principios gerais

### Familiaridade com Fat-Free Framework

O scaffold deve ser familiar para desenvolvedores acostumados com PHP Fat-Free Framework. A organizacao deve preservar ideias ja conhecidas pela equipe:

- rotas explicitas;
- controllers com nomes diretos;
- views organizadas por telas;
- layout base com partes reutilizaveis;
- configuracao centralizada;
- fluxo facil de rastrear entre rota, controller, regra de negocio, dados e apresentacao.

A mudanca para Slim nao deve tornar a aplicacao dificil de seguir. Um desenvolvedor deve conseguir abrir a rota, encontrar o controller, entender a regra chamada e localizar a view sem precisar conhecer muitos padroes externos.

### PHP Slim como base HTTP

Slim sera usado como base para roteamento, request, response, middlewares e tratamento HTTP.

Slim deve ser tratado como infraestrutura de entrada e saida, nao como local para concentrar regra de negocio. Controllers Slim devem adaptar requisicoes HTTP para chamadas da aplicacao e transformar resultados em respostas HTML, JSON, PDF ou Excel.

### PHP 8.2 como versao alvo

O scaffold deve usar recursos disponiveis no PHP 8.2, sem depender de versoes futuras. Isso inclui tipagem, classes, enums quando fizer sentido, `readonly` quando trouxer clareza, tratamento moderno de erros e funcoes nativas atuais.

O uso de recursos novos deve ser moderado. A preferencia e por clareza para a equipe, nao por demonstrar todas as possibilidades da linguagem.

### Nomes em Portugues

Classes, metodos, variaveis, views e conceitos de dominio devem usar Portugues sempre que fizer sentido.

Exemplos de nomes esperados:

- `UsuarioController`
- `ListaController`
- `ServidorModel`
- `PessoaModel`
- `buscarPorCodigoPessoa`
- `listarInscritos`
- `gerarRelatorio`
- `$codigoPessoa`
- `$nomePessoa`
- `$mensagemErro`

Termos tecnicos consolidados podem permanecer em Ingles quando forem nomes do framework, da linguagem ou de padroes externos, como `Request`, `Response`, `Middleware`, `Controller`, `Model`, `View`, `JSON`, `PDF` e `Excel`.

### PHPDocs obrigatorios

Classes e metodos publicos devem ser documentados com PHPDocs.

PHPDocs devem explicar:

- o objetivo da classe ou metodo;
- parametros relevantes;
- retorno esperado;
- excecoes ou falhas conhecidas quando aplicavel;
- regras de negocio importantes.

PHPDocs nao devem repetir obviedades. O foco deve ser ajudar manutencao, revisao e uso correto das classes.

### Simplicidade antes de abstracao

O scaffold deve evitar complexidade desnecessaria. Uma abstracao so deve existir quando:

- remove duplicacao real;
- isola uma responsabilidade importante;
- melhora seguranca ou testabilidade;
- representa um conceito que a equipe reconhece;
- facilita manutencao recorrente.

Nao devem ser introduzidos padroes apenas por serem comuns em frameworks modernos. A equipe deve conseguir entender o scaffold sem estudar uma arquitetura sofisticada.

## Decisoes arquiteturais

### Padrao MVC

O scaffold deve separar regra de negocio, acesso a dados e apresentacao usando uma variacao simples de MVC.

Responsabilidades:

- Controller recebe a requisicao, valida o fluxo HTTP basico, chama a regra adequada e retorna a resposta.
- Model representa conceitos da aplicacao e coordena regras de negocio ligadas ao dominio.
- Camada de dados acessa banco de dados ou APIs externas.
- View renderiza HTML, componentes de tela e mensagens ao usuario.

Controllers nao devem conter SQL grande, chamadas complexas a API externa, regra de negocio longa ou montagem manual de HTML.

Views nao devem acessar banco, chamar API externa nem conter regra de negocio. Views recebem dados prontos para apresentacao.

### Sem injecao de dependencia

O scaffold nao deve utilizar injecao de dependencia como padrao arquitetural.

Isso significa:

- nao usar container de dependencia para resolver controllers, models ou services da aplicacao;
- nao exigir interfaces e factories para casos simples;
- nao depender de configuracao complexa para instanciar classes comuns;
- nao criar uma hierarquia abstrata dificil de rastrear.

As classes devem ser instanciadas de forma explicita e previsivel. Quando uma dependencia for necessaria, a criacao deve estar em local claro, documentado e facil de encontrar.

Essa decisao privilegia manutencao pela equipe atual. O scaffold pode usar os mecanismos internos minimos exigidos pelo Slim, mas nao deve transformar o container em eixo da arquitetura da aplicacao.

### Regra de negocio reutilizavel

Toda regra de negocio relevante deve ficar fora dos controllers e fora das views.

A mesma regra deve poder atender:

- interface Web;
- REST API;
- geracao de PDF;
- exportacao Excel;
- integracoes futuras.

O controller decide o formato da resposta, mas a regra chamada deve ser a mesma. Isso evita duplicacao entre uma tela HTML e um endpoint REST que executam a mesma operacao.

### Acesso a dados por fonte

O scaffold deve ser capaz de acessar dados por:

- conexao direta com banco de dados;
- API externa;
- arquivos gerados ou importados quando necessario.

A regra de negocio nao deve saber detalhes de conexao, credenciais, endpoints ou formato bruto de resposta externa. Esses detalhes devem ficar isolados na camada de dados.

Para a equipe, a diferenca deve ser simples:

- uma classe consulta banco;
- outra classe consulta API;
- ambas entregam dados normalizados para a regra de negocio.

### Banco de dados

Consultas diretas ao banco devem usar parametros preparados e validacao de entrada.

Nao devem ser permitidos:

- SQL montado por concatenacao com dados de usuario;
- credenciais versionadas;
- hostnames hardcoded para decidir ambiente;
- consultas espalhadas em views;
- operacoes administrativas sensiveis sem autorizacao clara.

O scaffold deve prever multiplas conexoes quando necessario, por exemplo uma base da aplicacao e uma base institucional replicada.

### APIs externas

Acesso a APIs externas deve ser isolado em classes proprias. Essas classes devem:

- montar requisicoes;
- tratar timeouts;
- interpretar erros;
- normalizar respostas;
- registrar logs tecnicos;
- retornar dados em formato compreensivel para a aplicacao.

Servicos externos pagos devem ser evitados. Quando uma integracao externa for necessaria, preferir APIs institucionais, servicos ja disponiveis ou componentes livres.

### Interface Web, REST, PDF e Excel

O scaffold deve permitir diferentes saidas a partir da mesma logica de negocio.

Decisao:

- Web usa controller e view HTML.
- REST API usa controller e resposta JSON.
- PDF usa gerador de documento a partir dos mesmos dados.
- Excel usa gerador de planilha a partir dos mesmos dados.

A regra de negocio deve produzir um resultado neutro. Adaptadores de apresentacao transformam esse resultado no formato final.

### Frontend mobile-first

A interface Web deve ser mobile-first. Telas administrativas podem ter tabelas grandes, mas devem degradar bem em telas menores.

Diretrizes:

- priorizar layout responsivo desde o inicio;
- evitar telas que dependam apenas de largura desktop;
- usar formularios simples e legiveis;
- manter botoes e acoes principais acessiveis em celular;
- evitar excesso de Javascript customizado.

### Tabler, Bootstrap 5 e htmx

O frontend deve usar Tabler, Bootstrap 5 e htmx.

Decisao:

- Bootstrap 5 fornece grid, componentes base e responsividade.
- Tabler fornece identidade visual administrativa consistente.
- htmx cobre interacoes dinamicas simples sem criar uma SPA.

O scaffold deve evitar frameworks frontend pesados por padrao. Javascript customizado deve ser pontual, organizado por tela e usado quando htmx ou HTML simples nao forem suficientes.

### Renderizacao de templates

O scaffold deve ter layout base e partes reutilizaveis, preservando a familiaridade dos exemplos F3.

Partes esperadas:

- cabecalho;
- menu;
- mensagens;
- conteudo principal;
- rodape;
- assets comuns.

As views devem receber dados prontos para exibicao. Formatacoes recorrentes podem ficar em helpers simples de apresentacao.

### Tratamento centralizado de erros

Erros devem ser tratados de forma centralizada.

O usuario nao deve ver stack trace, caminho interno de arquivo, DSN, query SQL, token, payload sensivel ou detalhes tecnicos.

O scaffold deve distinguir:

- erro esperado de validacao;
- erro de autorizacao;
- recurso nao encontrado;
- erro de integracao externa;
- erro de banco de dados;
- erro inesperado.

Cada tipo de erro deve produzir uma resposta adequada para Web, REST API, PDF ou Excel quando aplicavel.

### Logs tecnicos

Logs tecnicos devem ser acessiveis para manutencao, sem expor detalhes ao usuario final.

Decisao:

- logs tecnicos devem ser enviados a um servidor Redis externo;
- se Redis estiver indisponivel, o sistema deve gravar em arquivo local;
- falha de log nao deve derrubar a aplicacao principal;
- logs devem conter contexto suficiente para suporte.

Contexto recomendado:

- data e hora;
- ambiente;
- rota;
- usuario autenticado quando existir;
- codigo da acao;
- mensagem tecnica;
- identificador de correlacao;
- resumo de parametros nao sensiveis;
- origem do erro.

Dados sensiveis nao devem ser registrados, incluindo senhas, tokens, cookies de sessao, documentos pessoais completos e payloads confidenciais.

### Erros para usuario

Mensagens para usuario devem ser claras, curtas e sem detalhe interno.

Exemplos de comportamento esperado:

- mostrar que a operacao nao pode ser concluida;
- informar quando o usuario nao tem permissao;
- orientar proximo passo quando houver acao possivel;
- registrar detalhe tecnico apenas em log.

### Preparacao para WhatsApp, n8n e agentes

O scaffold deve preparar integracoes futuras com WhatsApp, n8n e agentes, sem depender delas para funcionar.

Decisao:

- regras de negocio devem poder ser chamadas por controllers Web, REST ou integradores;
- eventos importantes devem poder ser representados de forma estruturada;
- a aplicacao deve ter pontos claros para disparar notificacoes futuras;
- integracoes externas devem ser opcionais e substituiveis.

O scaffold nao deve acoplar regra de negocio a fornecedor especifico de WhatsApp, plataforma paga de automacao ou agente externo.

### Evitar servicos externos pagos

O scaffold deve evitar dependencia de servicos externos pagos.

Quando houver necessidade de fila, cache, log, PDF, Excel ou integracao, priorizar:

- recursos nativos do PHP;
- bibliotecas open source;
- infraestrutura ja disponivel na Poli;
- formatos abertos;
- servicos internos.

Dependencias pagas so devem ser consideradas por decisao explicita posterior.

## Organizacao conceitual

### Entrada HTTP

Rotas Slim devem ser explicitas e agrupadas por area funcional.

Controllers devem ter nomes alinhados ao dominio:

- `UsuarioController`
- `ListaController`
- `ServidorController`
- `RelatorioController`
- `ApiListaController`

Rotas de pagina e rotas REST podem compartilhar a mesma regra de negocio, mas devem ter controllers ou metodos separados quando isso melhorar clareza.

### Controllers

Controllers devem:

- receber request;
- ler parametros;
- chamar validacao simples ou classe de entrada;
- chamar regra de negocio;
- escolher tipo de resposta;
- retornar response.

Controllers nao devem:

- montar SQL complexo;
- conter regra de negocio longa;
- enviar e-mail diretamente;
- conhecer detalhes de Redis;
- montar PDF ou Excel manualmente;
- renderizar HTML por concatenacao de string.

### Models e regras de negocio

Models devem representar conceitos da aplicacao e regras de negocio. A regra deve ser escrita em Portugues e com nomes proximos do dominio da equipe.

Exemplos de responsabilidades:

- verificar se usuario pode gerenciar lista;
- incluir inscrito;
- remover inscrito;
- listar servidores por filtro;
- preparar dados de relatorio;
- decidir se uma notificacao deve ser disparada.

### Dados

Classes de dados devem isolar origem e formato dos dados.

Exemplos de responsabilidades:

- consultar banco institucional;
- consultar banco da aplicacao;
- chamar API externa;
- normalizar resposta;
- aplicar parametros preparados;
- tratar falhas tecnicas da fonte.

### Views

Views devem ser simples e orientadas a apresentacao.

Elas podem conter condicionais leves de exibicao, repeticoes e includes, mas nao devem conter regra de negocio nem acesso a dados.

### Saidas especializadas

PDF, Excel e JSON devem ser tratados como apresentacoes da mesma informacao.

Geradores de PDF e Excel devem receber dados preparados pela regra de negocio. Eles nao devem consultar banco diretamente.

## Documentacao e manutencao

### Documentacao no proprio scaffold

O scaffold deve trazer exemplos oficiais para os casos mais comuns:

- pagina HTML protegida;
- formulario com validacao;
- endpoint REST;
- resposta htmx;
- consulta em banco;
- consulta em API externa;
- geracao de PDF;
- geracao de Excel;
- tratamento de erro;
- log tecnico;
- autorizacao por papel.

Esses exemplos devem ser pequenos, completos e copiados como referencia pela equipe.

### Padrao de comentarios

Comentarios devem explicar regra de negocio, decisao tecnica ou comportamento nao obvio.

Nao devem ser mantidos:

- blocos antigos comentados;
- logs temporarios;
- historico de tentativa;
- comentarios que apenas repetem o nome da variavel.

### Manutencao pela equipe atual

O scaffold deve ser compreensivel e manutenivel pela equipe atual da Informatica Poli.

Isso significa:

- preferir nomes claros a padroes genericos;
- manter arquivos pequenos;
- evitar heranca profunda;
- evitar configuracao magica;
- documentar decisoes;
- permitir depuracao simples;
- manter fluxo entre rota, controller, regra e view visivel.

## Decisoes que ficam proibidas por padrao

O scaffold nao deve adotar por padrao:

- injecao de dependencia via container;
- ORM complexo se SQL simples resolver melhor;
- framework frontend SPA;
- servico externo pago obrigatorio;
- SQL concatenado com entrada de usuario;
- stack trace exibido ao usuario;
- segredos versionados;
- regras de autorizacao espalhadas em cada view;
- controllers com centenas de linhas;
- codigo gerado ou abstrato demais para a equipe manter.

## Criterio de sucesso

O scaffold sera considerado adequado se um desenvolvedor da equipe conseguir:

- criar uma rota nova sem entender arquitetura complexa;
- encontrar rapidamente onde esta uma regra de negocio;
- trocar uma consulta de banco por uma chamada de API sem reescrever a tela;
- reutilizar a mesma regra para Web, REST, PDF e Excel;
- depurar erro por log tecnico sem expor stack trace ao usuario;
- manter telas responsivas com Tabler, Bootstrap 5 e htmx;
- evoluir integracoes futuras sem reescrever o nucleo da aplicacao.

## Decisao final

O scaffold deve ser uma ponte entre o estilo Fat-Free Framework conhecido pela equipe e uma base Slim mais organizada.

A arquitetura deve ser simples, explicita e documentada. O objetivo nao e aplicar arquitetura moderna em excesso, mas criar uma fundacao segura e reutilizavel para sistemas Web, APIs, relatorios e integracoes futuras da Informatica Poli.
