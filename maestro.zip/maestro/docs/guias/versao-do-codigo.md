# Versao do codigo

O scaffold le metadados da pasta `.git` para identificar qual codigo esta rodando no servidor.

## Onde aparece

- `GET /saude`, no campo `codigo`.
- Rodape das paginas Web.
- Pagina amigavel de erro.
- Respostas JSON de erro.
- Registro tecnico de erros em Redis ou JSONL.

## Assinatura

A assinatura usa o formato:

```text
branch@commit_curto
```

Exemplo:

```text
main@abc123def456
```

Em HEAD detached, a branch aparece como `detached`. Se a pasta `.git` nao puder ser lida, a assinatura sera `versao-indisponivel` e `/saude` ficara com status `degradado`.

## Configuracao

Por padrao, o scaffold procura `.git` na raiz do projeto. Para deployments em que `.git` esteja em outro caminho, configure:

```env
APP_GIT_PATH=/caminho/para/.git
```

Se `APP_GIT_PATH` ficar vazio, o padrao e usado.

## Tratamento de falhas

Falhas esperadas:

- pasta `.git` ausente;
- arquivo `HEAD` ilegivel;
- referencia de branch ausente;
- commit invalido;
- arquivo `packed-refs` sem a referencia esperada.

Nesses casos, a aplicacao continua funcionando com assinatura `versao-indisponivel`.
