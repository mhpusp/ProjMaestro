# Especificação do Novo Componente: WorkflowEventHandler / WorkflowEventDispatcher

## WorkflowEventHandler

* **Conceito:** Provedor e orquestrador de execução de eventos dinâmicos baseados no Padrão Strategy. Atua como o barramento/mediador entre os nós do workflow e as ações do sistema (notificações, envio de e-mails, integrações e chamadas a Repositories de negócio do Slim PHP).
* **Descrição:** Registra e gerencia os manipuladores (*handlers*) de eventos. Processa a string de assinatura definida na propriedade `evento` do nó no arquivo JSON, extrai parâmetros e invoca a estratégia correspondente sem acoplar o motor do workflow às regras de negócio específicas das aplicações.
* **Propriedades:**
  1. `handlers` -- Lista/Registro de estratégias de eventos registradas na aplicação.
* **Métodos:**
  1. `registerHandler(WorkflowEventHandlerInterface $handler)` -- Registra uma nova estratégia de evento.
  2. `dispatch(string $eventSignature, array $context)` -- Interpreta a assinatura textual e executa o manipulador correspondente.

---

Este documento especifica a arquitetura, design patterns e implementação do componente **WorkflowEventHandler** (implementado concretamente como **WorkflowEventDispatcher**), responsável por gerenciar e disparar eventos dinâmicos associados aos nós de processos no motor de workflow integrado ao micro-framework Slim PHP.

---

## 1. Visão Geral e Responsabilidade

O **WorkflowEventHandler** é o componente orquestrador de execução de eventos baseados no **Padrão Strategy**. Atua como o barramento/mediador entre a topologia do workflow e as ações do sistema (notificações, envio de e-mails, integrações e chamadas a Repositories de negócio do Slim PHP).

### Principais Objetivos:
* **Desacoplamento do Core:** Isola a lógica de execução de ações da navegação topológica do `WorkflowRouter`.
* **Reuso Máximo de Código:** Garante que o motor principal não precise ser modificado ao adicionar novos tipos de processos ou regras de negócio.
* **Integração Nativa com o Slim PHP:** Permite que eventos de persistência acessem diretamente os Repositories e Services da aplicação Slim via Injeção de Dependências (PHP-DI / PSR-11).

---

## 2. Padrões de Projeto Aplicados

* **Strategy Pattern:** Cada tipo de evento (`AgendaNotifierEventHandler`, `DataFormPersistEventHandler`, `SendEmailEventHandler`) é uma estratégia isolada que implementa uma interface comum (`WorkflowEventHandlerInterface`).
* **Event Dispatcher / Command Bus:** O `WorkflowEventDispatcher` recebe assinaturas textuais lidas das propriedades do nó no JSON (ex: `"notificarAgenda('Tarefa', 'Aprovar para ' + $NoDescritor.nome)"`, `"persistirDadosForm('App\\Repositories\\VeiculoRepository')"`) e as despacha para a Strategy correspondente.
* **Dependency Injection (PSR-11):** O container do Slim resolve automaticamente as dependências necessárias para cada handler de evento.

Define a funcionalidade de executar ações heterogêneas que devem ser executadas ao processar os nós de um processo (enviar e-mail, agendar tarefa, gravar dados específicos de negócio) a partir de uma declaração textual no JSON na propriedade `evento` do nó — é o cenário ideal para a aplicação do **Padrão Strategy** combinado com um **Event Dispatcher (ou Command Bus)** e um **Registry/Factory**.

Para evitar que o código de persistência específica (como tabelas do seu negócio de veículos, compras, RH, etc.) contamine o núcleo do `WorkflowEngine` ou os Controllers do Slim PHP, devemos separar o **mecanismo de disparo** (genérico do workflow) da **execução do evento** (específica de cada processo).

A seguir está uma proposta completa, padronizada e com foco em alto reuso de código para a sua implementação.

---

### 2.1. A Estrutura de Abstração: O Padrão Strategy

Em vez de criar uma única interface gigante com múltiplos métodos (`enviarEmail`, `inserirItemAgenda`, `persistirFormulario`), cada evento será uma **Estratégia (*Strategy*) isolada e autocontida** que implementa uma única interface comum: `WorkflowEventHandlerInterface`.

#### A Interface do Evento (`app/workflow/contracts/WorkflowEventHandlerInterface.php`)

```php
namespace App\Workflow\Contracts;

interface WorkflowEventHandlerInterface
{
    /**
     * Retorna o nome do evento mapeado na string do JSON (ex: "enviar_email", "notificar", "faturamento")
     */
    public function getKey(): string;

    /**
     * Executa a regra de negócio do evento
     * 
     * @param array $params Parâmetros extraídos da assinatura no JSON
     * @param array $context Contexto da execução (instância_id, no_ativo, dados_form, usuario_logado)
     * @return mixed Retorno da execução
     */
    public function handle(array $params, array $context): mixed;
}
```

---

### 2.2. O Registro das Estratégias: Event Registry / Dispatcher

Para que o `WorkflowRouter` saiba qual Strategy executar sem precisar de condicionais `if/else` ou `switch/case` gigantes, criamos um `WorkflowEventDispatcher`. Ele atua como um catálogo central que registra todos os manipuladores de evento disponíveis na aplicação.

#### O Dispatcher (`app/workflow/services/WorkflowEventDispatcher.php`)

```php
namespace App\Workflow\Services;

use App\Workflow\Contracts\WorkflowEventHandlerInterface;

class WorkflowEventDispatcher
{
    /** @var array<string, WorkflowEventHandlerInterface> */
    private array $handlers = [];

    /**
     * Registra um manipulador de evento no Dispatcher
     */
    public function registerHandler(WorkflowEventHandlerInterface $handler): void
    {
        $this->handlers[$handler->getKey()] = $handler;
    }

    /**
     * Executa um evento a partir de sua assinatura em string (ex: "enviar_email('financeiro@empresa.com')")
     */
    public function dispatch(string $eventSignature, array $context): void
    {
        // 1. Parser da String do Evento (separa o nome da função e os parâmetros)
        // Ex: "instanciar('SolicitacaoDeVeiV1')" -> $eventName = 'instanciar', $params = ['SolicitacaoDeVeiV1']
        [$eventName, $params] = $this->parseSignature($eventSignature);

        if (!isset($this->handlers[$eventName])) {
            // Caso o evento seja opcional ou não registrado, apenas loga ou ignora
            return;
        }

        // 2. Executa a Strategy correspondente
        $this->handlers[$eventName]->handle($params, $context);
    }

    private function parseSignature(string $signature): array
    {
        if (preg_match('/^(\w+)\((.*)\)$/', trim($signature), $matches)) {
            $name = $matches[1];
            $rawArgs = $matches[2];
            // Split simples por vírgula e limpa aspas
            $args = array_map(fn($arg) => trim($arg, " '\""), strlen($rawArgs) ? explode(',', $rawArgs) : []);
            return [$name, $args];
        }
        return [$signature, []];
    }
}
```

---

### 2.3. Implementação dos Eventos Padronizados e de Negócio

Agora dividimos os eventos em duas categorias: **Eventos Genéricos do Workflow** (reutilizáveis em qualquer processo) e **Eventos Específicos do Negócio** (que utilizam os Repositories do Slim).

#### A) Evento Genérico: Inserir Item na Agenda / Notificação
Reutiliza o serviço `WorkflowNotes` já existente na sua arquitetura.

```php
namespace App\Workflow\Events;

use App\Workflow\Contracts\WorkflowEventHandlerInterface;
use App\Workflow\Contracts\WorkflowNotesInterface;

class AgendaNotifierEventHandler implements WorkflowEventHandlerInterface
{
    public function __construct(
        private WorkflowNotesInterface $notesService
    ) {}

    public function getKey(): string
    {
        return 'notificar'; // Mapeado no JSON como "notificar()"
    }

    public function handle(array $params, array $context): mixed
    {
        // Exemplo: pega o tipo de item do argumento ou assume "NOTIFICACAO" por padrão
        $tipo = $params[0] ?? 'NOTIFICACAO';
        $assunto = $params[1] ?? 'Nova ação pendente no processo';

        return $this->notesService->inserirItemAgenda(
            usuario: $context['usuario_logado'],
            tipo: $tipo,
            assunto: $assunto,
            instanciaId: $context['instancia_id'],
            noId: $context['no_id']
        );
    }
}
```

#### B) Evento de Negócio Completo: Persistência Dinâmica com Slim Repository
Para atender o requisito de salvar os dados do formulário preenchidos no nó (`dados_form`) em tabelas específicas do seu sistema Slim, criamos uma Strategy de Persistência que utiliza a Injeção de Dependência do container PHP-DI para localizar o **Repository correto do Slim**.

```php
namespace App\Workflow\Events;

use App\Workflow\Contracts\WorkflowEventHandlerInterface;
use Psr\Container\ContainerInterface;

class DataFormPersistEventHandler implements WorkflowEventHandlerInterface
{
    public function __construct(
        private ContainerInterface $container // Acesso ao Container de DI do Slim
    ) {}

    public function getKey(): string
    {
        return 'persistir_dados'; // Mapeado no JSON como: "persistir_dados('App\Repositories\VeiculoRepository')"
    }

    public function handle(array $params, array $context): mixed
    {
        // $params[0] contém a classe do Repository do Slim definida na assinatura do JSON
        $repositoryClass = $params[0] ?? null;

        if (!$repositoryClass || !$this->container->has($repositoryClass)) {
            throw new \RuntimeException("Repository de negócio {$repositoryClass} não foi encontrado no Slim.");
        }

        // Recupera a instância do Repository do Slim (ex: VeiculoRepository)
        $repository = $this->container->get($repositoryClass);

        // Pega os dados preenchidos no formulário do nó atual
        $dadosFormulario = $context['dados_form'] ?? [];

        // Invoca o método padronizado do Repository (ex: save() ou persistirFormulario())
        return $repository->salvarDadosWorkflow(
            instanciaId: $context['instancia_id'],
            dados: $dadosFormulario
        );
    }
}
```

---

## 3. Como o Desenvolvedor Trabalha no Projeto?

Com este padrão established, o fluxo de desenvolvimento fica extremamente limpo e isolado:

1. **Na Modelagem do JSON (`SolicitacaoDeVeiV1.json`):**
   Nas propriedades do nó, o analista/desenvolvedor apenas declara as chamadas no array de eventos:
   ```json
   "evento": [
       "notificarAgenda('Tarefa', 'Aprovar taxa de locação para ' + $NoDescritor.nome)",
       "persistir_dados('App\\Repositories\\SolicitacaoVeiculoRepository')"
   ]
   ```

2. **Na Camada do Slim (Persistência Específica de Negócio):**
   O desenvolvedor cria o seu Repository normal no Slim PHP (ex: `app/repositories/SolicitacaoVeiculoRepository.php`), estendendo uma interface padrão de repositório:
   ```php
   namespace App\Repositories;

   class SolicitacaoVeiculoRepository
   {
       public function salvarDadosWorkflow(int $instanciaId, array $dados): bool
       {
           // Lógica SQL/ORM específica das tabelas de veículos do seu negócio
           // $this->db->insert('locacao_veiculos', ...);
           return true;
       }
   }
   ```

3. **No `WorkflowRouter` (Durante a Navegação):**
   Ao avançar o nó no `WorkflowRouter`, ele apenas invoca o Dispatcher passando o array de eventos lidos do DTO do nó atual:
   ```php
   // Dentro do método avançar() do WorkflowRouter:
   foreach ($noAtualDTO['evento'] as $eventoSignature) {
       $this->dispatcher->dispatch($eventoSignature, [
           'instancia_id'   => $instanciaId,
           'no_id'          => $noAtualDTO['id'],
           'dados_form'     => $dadosFormularioEnviados,
           'usuario_logado' => $usuarioLogado
       ]);
   }
   ```

---

## 4. Configuração no Container PHP-DI do Slim Framework

Para garantir que todas as Strategies sejam automaticamente registradas no `WorkflowEventDispatcher` quando a aplicação iniciar, você configura o serviço no arquivo de dependências do Slim (`config/container.php`):

```php
use App\Workflow\Services\WorkflowEventDispatcher;
use App\Workflow\Events\AgendaNotifierEventHandler;
use App\Workflow\Events\DataFormPersistEventHandler;
use App\Workflow\Events\SendEmailEventHandler;
use Psr\Container\ContainerInterface;

return [
    WorkflowEventDispatcher::class => function (ContainerInterface $c) {
        $dispatcher = new WorkflowEventDispatcher();

        // Registra as estratégias de eventos suportadas
        $dispatcher->registerHandler($c->get(AgendaNotifierEventHandler::class));
        $dispatcher->registerHandler($c->get(DataFormPersistEventHandler::class));
        $dispatcher->registerHandler($c->get(SendEmailEventHandler::class));

        return $dispatcher;
    },
];
```

---

## 5. Resumo das Vantagens da Solução

* **Reuso Máximo de Código:** Os componentes centrais do workflow (`WorkflowRouter`, `WorkflowMap`, `WorkflowHist`) nunca mudam quando um novo processo de negócio ou tabela é adicionado ao sistema.
* **Isolamento de Responsabilidade (SRP):** Códigos de persistência específica do negócio ficam restritos aos diretórios de Repositories do Slim, sem contaminar o motor do workflow.
* **Flexibilidade via JSON:** Novas ações (como enviar SMS, integrar com API externa ou gerar PDF) exigem apenas a criação de uma nova classe Strategy que implementa `WorkflowEventHandlerInterface` e o registro no container do Slim.

---

## 6. Impacto na Arquitetura do Workflow

Esta proposta evidenciou, identificou e formalizou um novo componente de domínio para a Arquitetura de Software do Workflow: o **`WorkflowEventHandler`** (ou `WorkflowEventDispatcher`).

A inclusão deste novo componente resolve o problema de "onde colocar a regra de negócio específica sem poluir o motor" e eleva o nível de maturidade da arquitetura.

### Como isso impacta e ajusta as especificações da Arquitetura?

A estrutura proposta não quebra nem invalida nada do que foi definido anteriormente no `WorkflowRouter`, `WorkflowHist` ou nos DTOs. Desonera o `WorkflowRouter` de responsabilidades que não eram dele.

A seguir alguns ajustes pontuais para acomodar formalmente o `WorkflowEventHandler`:

#### Reajuste de Responsabilidade do `WorkflowRouter`
* **Antes:** O `WorkflowRouter` navegava pelo nó e também tinha a responsabilidade de "saber como executar" e-mails, persistências em banco de dados e algoritmos das propriedades dos nós.
* **Agora (Ajustado):** O `WorkflowRouter` foca 100% no Roteamento Topológico (*Dual-Source*). Ao chegar em um nó, ele apenas lê o array de eventos do DTO e delega a execução: *"Ei, WorkflowEventHandler, execute estas assinaturas de eventos aqui para este contexto"*.

---

## 7. Resumo do Impacto

* **Sua arquitetura ficou mais coesa (SRP - Single Responsibility Principle):** O `WorkflowRouter` calcula rotas; o `WorkflowEventHandler` executa ações.
* **O contrato de dados permanece o mesmo:** O DTO do Elemento continua tendo a propriedade `evento` como um array de strings.
* **Padrão de Projeto Consolidado:** A união da Arquitetura de Referência com o Padrão Strategy no `WorkflowEventHandler` garante que desenvolvedores juniores ou seniores consigam criar novos processos no Slim apenas adicionando novas classes em `events/` ou `repositories/`, sem nunca precisar alterar o código do motor principal.

## 8. Implementação da inclusão de processos pelo nó

O avanço de um nó agora despacha, em ordem, as assinaturas declaradas em `evento`. Argumentos aceitam textos entre aspas, valores literais simples e concatenação com `+`. As referências `$NoDescritor.propriedade` e `$NoAtual.propriedade` leem propriedades do descritor do processo e do nó atual; propriedades aninhadas também podem ser acessadas por ponto. Um descritor retornado por um evento anterior chamado `uploadArquivos` passa a ser o `$NoDescritor` dos eventos seguintes no mesmo nó. O contexto do handler inclui `instancia_id`, `no_id`, `dados_form`, `uploaded_files`, `definicao_processo`, `no_atual`, `processo`, `usuario_logado`, `usuario_id` e os resultados dos eventos executados anteriormente no mesmo nó. Um evento sem handler registrado gera erro explícito.

O nó `ativ1` do processo de manutenção usa `uploadArquivos()` seguido de `notificarAgenda('Notificação', 'Um novo processo (' + $NoDescritor.nome + ') foi incluído no sistema.')`. A view só mostra os metadados depois que o usuário seleciona o JSON principal; o navegador apresenta a prévia e solicita os subprocessos declarados. No envio, `uploadArquivos` relê o descritor do arquivo recebido no servidor, valida o pacote completo, gera o identificador por `WorkflowMeta::gerarId`, grava os arquivos em `app/workflow/wfiles/<id>` e cadastra o processo. Se a pasta já existir, a tela pergunta se o usuário quer manter o pacote atual (e cadastrar o processo com os arquivos já presentes) ou substituí-lo (selecionando novamente os arquivos).

O handler `notificarAgenda` consome o resultado do upload e registra uma notificação para os usuários com o papel `admin`. A cor é determinada pelo tipo em `WorkflowNotes`: `Tarefa` usa `#FAFAD2`, `Notificação` usa `#98FB98` e `Mensagem` usa `#E0FFFF`; não é necessário passar a cor na assinatura. Exemplos de assinaturas reutilizáveis são `"notificarAgenda('Tarefa', 'Aprovar taxa de locação para ' + $NoDescritor.nome)"` e `"notificarAgenda('Mensagem', 'Etapa atual: ' + $NoAtual.nome)"`. Para adicionar uma funcionalidade específica semelhante:

1. Declare uma assinatura no array `evento` do nó.
2. Implemente um `WorkflowEventHandlerInterface` em `app/workflow/events/`.
3. Registre a implementação no dispatcher em `config/routes.php`, injetando os serviços de domínio necessários.
4. Passe apenas os dados necessários pelo contexto e valide os parâmetros e resultados no handler.
5. Teste o avanço do nó, incluindo falhas e colisões, e exiba feedback no formulário quando o usuário precisar agir.

O handler genérico `uploadFiles()` continua disponível para uploads sem regras específicas de processos; `uploadArquivos()` é a estratégia que integra o caso de uso do metaprocesso ao `WorkflowMeta`.