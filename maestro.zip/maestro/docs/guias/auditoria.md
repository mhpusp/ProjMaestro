# Auditoria

A auditoria registra acoes relevantes em JSONL em `storage/logs/auditoria/auditoria.jsonl`.

## Quando registrar

Registre eventos como:

- criacao;
- alteracao de status;
- exportacao;
- exclusao;
- acesso negado.

## Campos registrados

Cada linha contem:

- data e hora;
- usuario;
- papel ativo;
- sistema;
- acao;
- rota;
- metodo HTTP;
- resultado;
- contexto sanitizado.

## Exemplo

```php
$this->dependencias['auditoria']->registrar(
    $request,
    'solicitacao.criar',
    'sucesso',
    ['solicitacao_id' => 104],
    'solicitacoes'
);
```

## Resultado JSONL

```json
{"data_hora":"2026-06-08T22:17:37+00:00","usuario_id":"mock-001","papel_ativo":"admin","sistema":"solicitacoes","acao":"solicitacao.criar","resultado":"sucesso"}
```

## Cuidados

- Nao registre senha, token, CPF completo, cookies ou conteudo sensivel.
- Use contexto pequeno.
- Prefira IDs e status, nao payloads inteiros.

## Futuro

`AuditoriaRepository` centraliza o destino. Para gravar em banco ou servico externo, altere esse repository sem mudar controllers.
