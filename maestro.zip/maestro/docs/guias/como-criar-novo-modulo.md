# Como criar novo modulo

Use o modulo `Solicitacoes` como referencia copiavel. A ideia e manter o fluxo facil de seguir: rota, controller, service, repository e view.

## Estrutura sugerida

Para um modulo chamado `Eventos`, crie:

- `app/controllers/EventoController.php`
- `app/services/EventoService.php`
- `app/repositories/EventoRepository.php`
- `app/views/eventos/lista.php`
- `app/views/eventos/detalhe.php`
- `app/views/eventos/formulario.php`
- `app/views/eventos/parcial_lista.php`
- `app/views/eventos/README.md`

## Passo a passo

1. Crie o repository com a origem dos dados.
2. Crie o service com validacoes e regras de negocio.
3. Crie o controller chamando apenas o service e escolhendo HTML, JSON ou exportacao.
4. Registre as rotas em `config/routes.php` com identificador estavel.
5. Defina os papeis padrao da rota no registro e ajuste pela API de autorizacoes quando necessario.
6. Crie views pequenas em `app/views/<modulo>`.
7. Registre auditoria nas acoes relevantes.

## Exemplo de rota

```php
$rotaEventosListar = $registrar('eventos.listar', ['GET'], '/eventos', false, ['admin', 'operador']);

$app->get('/eventos', function ($request, $response) use ($criarEventoController) {
    return $criarEventoController()->listar($request, $response);
})
    ->add($exigeRota($rotaEventosListar))
    ->add($autenticacao);
```

## Checklist rapido

- O controller nao contem regra de negocio.
- O service nao conhece HTML, request ou response.
- O repository nao renderiza view.
- A view nao consulta banco.
- A API e a Web usam o mesmo service.
