# Rascunhos persistiveis

O scaffold possui uma camada para persistir objetos preenchidos parcialmente em formularios. A ideia e permitir que um usuario comece a preencher, saia da pagina e retome depois.

## Fluxo

Todo objeto persistivel nasce com status `rascunho`.

1. A rota de formulario chama `RascunhoService::obterOuCriar`.
2. O rascunho e vinculado ao usuario autenticado e ao tipo do objeto, por exemplo `solicitacao`.
3. Conforme campos mudam, uma rota htmx chama `RascunhoService::salvarParcial`.
4. Ao clicar em enviar, o service do modulo valida os dados.
5. Se a validacao passar, `RascunhoService::marcarEnviado` muda o status para `enviado`.
6. Rascunhos com mais de `RASCUNHOS_TTL_DIAS` dias sem atualizacao sao removidos.

## Configuracao

As configuracoes ficam no `.env`:

```env
RASCUNHOS_DRIVER=arquivo
RASCUNHOS_TTL_DIAS=21
RASCUNHOS_STORAGE_PATH=storage/rascunhos/rascunhos.json
RASCUNHOS_API_BASE_URL=
RASCUNHOS_API_TOKEN=
RASCUNHOS_API_TIMEOUT=3
```

Drivers disponiveis:

- `arquivo`: usa `ArquivoRascunhoRepository` e grava JSON local em `storage/rascunhos`.
- `api`: usa `ApiRascunhoRepository` e envia as operacoes para uma API externa.

## Contrato de repository

Qualquer origem de dados deve implementar `RascunhoRepositoryInterface`:

```php
public function salvar(array $rascunho): array;
public function buscarPorId(string $id): ?array;
public function buscarRascunhoAtivo(string $tipo, string $usuarioId): ?array;
public function remover(string $id): void;
public function removerExpirados(DateTimeImmutable $limite): int;
```

Isso permite trocar o storage local por banco, Redis, API externa ou outro backend sem mudar controller e service do modulo.

## API externa

O adaptador `ApiRascunhoRepository` espera uma API com endpoints equivalentes:

- `PUT /rascunhos/{id}` para salvar ou atualizar;
- `GET /rascunhos/{id}` para buscar por id;
- `GET /rascunhos/ativo?tipo=...&usuario_id=...` para retomar rascunho do usuario;
- `DELETE /rascunhos/{id}` para remover;
- `DELETE /rascunhos/expirados?limite=...` para remover expirados.

Quando `RASCUNHOS_API_TOKEN` estiver configurado, o token e enviado como `Authorization: Bearer`.

## Exemplo em formulario

No formulario de solicitacoes, o submit final continua apontando para a rota normal:

```html
<form method="post" action="/solicitacoes">
```

O salvamento gradual fica em uma area interna com htmx:

```html
<div
    hx-post="/solicitacoes/rascunho"
    hx-trigger="keyup changed delay:800ms from:input, change from:select, change delay:800ms from:textarea"
    hx-include="#form-solicitacao"
    hx-target="#rascunho-status"
>
```

Nao coloque `hx-post` no proprio `<form>` quando o envio final precisar ir para outra rota, pois isso pode interceptar o submit.

## Boas praticas

- O rascunho deve guardar dados parciais normalizados, nao necessariamente validos.
- A validacao completa deve acontecer apenas no envio final.
- O rascunho deve ser sempre vinculado ao usuario autenticado.
- Dados sensiveis devem ser evitados ou criptografados conforme a regra do sistema.
- O TTL deve ser tratado no service ou no backend de persistencia.
