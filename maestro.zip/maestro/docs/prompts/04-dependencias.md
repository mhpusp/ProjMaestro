Baseado nas especificações de docs/guias/principios-do-scaffold.md, implemente uma camada simples de configuração e dependências.

Requisitos:
- Criar config/settings.php para ler variáveis de ambiente.
- Criar config/dependencies.php para registrar dependências.
- Criar arquivo de configuração .env.
- Registrar conexão PDO, mas sem depender dela para a aplicação inicial funcionar.
- Registrar serviço de renderização de templates.
- Registrar serviço de logs.
- Registrar serviço de tratamento de erros.
- Manter dependências explícitas e fáceis de entender.
- Evitar container complexo demais.

Critério de aceite:
- A aplicação continua funcionando sem banco configurado.
- Se o banco não estiver disponível, a rota /saude deve indicar o problema sem quebrar a aplicação inteira.