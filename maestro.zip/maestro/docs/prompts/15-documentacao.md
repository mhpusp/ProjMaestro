Crie documentação para desenvolvedores em /docs/guias.

Arquivos:
1. como-criar-novo-modulo.md
2. padrao-de-rotas.md
3. padrao-de-controllers-services-repositories.md
4. padrao-visual-sistemas-poli.md
5. tratamento-de-erros.md
6. autorizacao-e-papeis.md
7. auditoria.md
8. uso-de-htmx.md
9. checklist-de-revisao.md

A documentação deve ser prática, com exemplos curtos, e voltada para desenvolvedores com pouca experiência em arquitetura moderna.