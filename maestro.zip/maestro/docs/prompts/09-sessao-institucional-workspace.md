Crie uma camada inicial de sessão institucional chamada Workplace.

Objetivo: representar o contexto do usuário logado, preparando integração futura com SSO, WhatsApp e autorização por papéis.

Implementar:
1. Classe UsuarioLogado.
2. Classe PapelInstitucional.
3. Classe WorkplaceSession.
4. Middleware que injeta o WorkplaceSession no request.
5. Mock inicial de usuário logado para ambiente de desenvolvimento.
6. Componente visual para exibir usuário e papel ativo.
7. Estrutura para troca de papel, ainda que usando dados mockados.

Requisitos:
- Não implementar SSO real ainda.
- Não depender do banco.
- Documentar como a integração real deve ocorrer no futuro.