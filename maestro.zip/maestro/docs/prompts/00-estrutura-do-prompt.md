Objetivo
Contexto
Restrições
Arquivos relevantes
Critérios de aceite
Decisões tomadas após a resposta
