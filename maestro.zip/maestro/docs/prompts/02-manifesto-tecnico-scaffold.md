Com base na análise anterior, crie o documento /docs/guias/[principios-do-scaffold.md](http://principios-do-scaffold.md).



O scaffold deve seguir estes princípios:

- Ser familiar para desenvolvedores acostumados com PHP Fat-Free Framework.
- Usar PHP Slim como base.
- Ter classes e métodos documentados com PHPDocs.
- Usar nomes de classes, métodos e variáveis em Português.
- Usar funções disponívels no PHP versão 8.2.
- Evitar complexidade desnecessária.
- Separar regra de negócio, acesso a dados e apresentação usando padrão MVC.
- Não utilizar injeção de dependência.
- Ser capaz de acessar dados tanto de API externa como de conexão direta com banco de dados.
- Permitir interface Web, REST API, PDF e Excel a partir da mesma lógica de negócio.
- Ser mobile-first.
- Usar Tabler + Bootstrap 5 + htmx para frontend.
- Ter tratamento centralizado de erros.
- Ter logs técnicos acessíveis sem expor stack trace ao usuário, enviados a servidor Redis externo com fallback de gravação em arquivo local.
- Preparar integração futura com WhatsApp/n8n/agentes.
- Evitar dependência de serviços externos pagos.
- Ser compreensível e manutenível pela equipe atual da Informática Poli.



Não escreva código ainda. Apenas documente os princípios e as decisões arquiteturais.