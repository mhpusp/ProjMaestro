Implemente tratamento centralizado de erros.

Requisitos:
1. Nunca exibir stack trace ao usuário em produção.
2. Gerar código público de erro no formato SISTEMA-ANO-CODIGO, por exemplo REQ-2026-A8F31C.
3. Registrar erro no Redis quando disponível.
4. Usar TTL configurável para os erros no Redis.
5. Se o Redis estiver indisponível, gravar fallback em arquivo JSONL em /storage/logs/erros.
6. Sanitizar dados sensíveis antes de registrar contexto.
7. Exibir ao usuário uma página amigável com:
   - mensagem simples;
   - código do erro;
   - link para suporte;
   - orientação para informar o código.
8. Criar uma página administrativa simples /admin/erros para listar erros recentes do Redis.
9. Proteger a página /admin/erros com middleware fictício de permissão, preparado para integração futura.

Campos sensíveis a remover ou mascarar:
senha, password, token, authorization, cookie, csrf, secret, cpf, rg, arquivo, conteudo, parecer, observacao.

Critério de aceite:
- Ao provocar um erro de teste, o usuário vê mensagem amigável.
- O erro aparece no painel interno.
- O stack trace não aparece para o usuário.
- Se o Redis estiver desligado, o erro é gravado em arquivo local.