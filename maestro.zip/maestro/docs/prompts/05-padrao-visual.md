Implemente o layout base do scaffold usando Tabler + Bootstrap 5.

Requisitos:
1. Criar um layout institucional chamado "Sistemas Poli".
2. Criar cabeçalho padrão com:
   - nome "Sistemas Poli";
   - nome do sistema;
   - usuário logado fictício;
   - papel ativo fictício;
   - botão de sair fictício.
3. Criar rodapé com:
   - Serviço Técnico de Informática;
   - Escola Politécnica da USP;
   - versão do sistema.
4. Criar arquivo poli-theme.css com variáveis de cor:
   - azul institucional;
   - amarelo de destaque;
   - cinzas neutros;
   - cores de status.
5. Criar página inicial com cards responsivos.
6. Criar comportamento mobile-first.
7. Não criar identidade visual extravagante. O objetivo é sobriedade, consistência e confiança.

Critério de aceite:
- A tela deve funcionar bem em desktop e celular.
- No celular, listas devem aparecer como cards, não como tabelas espremidas.