Adicione htmx ao módulo Solicitações.

Funcionalidades:
1. Campo de busca que atualiza a lista sem recarregar a página inteira.
2. Botão de alterar status que atualiza apenas o card/linha da solicitação.
3. Loading visual simples.
4. Fallback funcional sem JavaScript, quando possível.

Requisitos:
- Não criar SPA.
- Manter HTML renderizado pelo servidor.
- Documentar o padrão para outros módulos.