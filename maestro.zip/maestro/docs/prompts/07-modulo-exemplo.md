Crie um módulo exemplo chamado "Solicitações".

Objetivo: demonstrar como um sistema real deve ser estruturado.

Funcionalidades:
1. Listar solicitações.
2. Exibir detalhe de uma solicitação.
3. Criar nova solicitação em formulário simples.
4. Alterar status de uma solicitação.
5. Exportar lista em JSON.
6. Preparar pontos futuros para PDF e Excel, mesmo que ainda não implemente a geração final.

Requisitos arquiteturais:
1. Controller fino.
2. Service com regra de negócio.
3. Repository para acesso a dados.
4. DTO ou array padronizado para transportar dados.
5. Templates separados.
6. Rotas Web e rotas API.
7. htmx em pelo menos uma ação simples, por exemplo filtro dinâmico.

Critério de aceite:
- Um desenvolvedor deve conseguir copiar esse módulo para criar um novo sistema.
- O README do módulo deve explicar o fluxo.