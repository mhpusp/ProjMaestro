Crie uma estrutura inicial para exportação de dados.

Requisitos:
1. Criar interface ExportadorInterface.
2. Criar ExportadorCsv simples.
3. Criar placeholder para ExportadorPdf.
4. Criar placeholder para ExportadorExcel.
5. No módulo Solicitações, permitir exportar a lista em CSV.
6. Documentar como PDF e Excel serão implementados futuramente.

Critério de aceite:
- A rota /solicitacoes/exportar/csv deve funcionar.
- A lógica de busca de dados deve ser reaproveitada.