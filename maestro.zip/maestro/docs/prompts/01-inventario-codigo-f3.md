Analise os exemplos de código em /docs/referencias-f3.



Objetivo: identificar padrões de organização, nomenclatura, fluxo de controller, acesso a banco, renderização de templates, autenticação e estilo geral usados atualmente pela equipe.



Não altere nenhum arquivo ainda.



Produza um relatório em /docs/decisoes/0001-analise-codigo-legado.md com:

1\. padrões que devem ser preservados por familiaridade;

2\. padrões que devem ser melhorados;

3\. vícios que não devem entrar no novo scaffold;

4\. sugestões para adaptar esse estilo para PHP Slim;

5\. riscos de manutenção para desenvolvedores com baixa familiaridade com arquitetura moderna.

