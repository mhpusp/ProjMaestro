Crie rotas REST API para o módulo Solicitações.

Rotas:
GET /api/solicitacoes
GET /api/solicitacoes/{id}
POST /api/solicitacoes
POST /api/solicitacoes/{id}/alterar-status

Requisitos:
1. Retornar JSON padronizado.
2. Usar a mesma camada Service das rotas Web.
3. Validar entrada.
4. Retornar erros em formato JSON sem stack trace.
5. Aplicar autorização por ação.
6. Registrar auditoria.

Formato padrão de resposta:
{
  "sucesso": true,
  "dados": {},
  "mensagem": null,
  "codigo_erro": null
}

Critério de aceite:
- Web e API compartilham regra de negócio.