Implemente log de auditoria mínimo para ações relevantes.

Requisitos:
1. Registrar usuário, papel ativo, ação, rota, data/hora e resultado.
2. Registrar ações de criação, alteração de status, exportação e acesso negado.
3. Inicialmente gravar em arquivo JSONL em /storage/logs/auditoria.
4. Preparar interface para futuramente gravar em banco ou enviar para serviço externo.
5. Não registrar dados sensíveis.
6. Criar helper AuditoriaService.

Critério de aceite:
- Ao criar uma solicitação, uma linha de auditoria é registrada.
- Ao exportar dados, uma linha de auditoria é registrada.