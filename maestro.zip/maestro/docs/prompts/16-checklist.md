Crie /docs/guias/checklist-de-revisao.md.

O checklist deve verificar:

1. A tela funciona em celular?
2. Existe versão mobile para tabelas?
3. A regra de negócio está fora do controller?
4. A rota Web e API reaproveitam o mesmo service?
5. Erros são tratados sem exibir stack trace?
6. A ação relevante registra auditoria?
7. Há permissões por ação?
8. Há exportação quando aplicável?
9. O README do módulo foi atualizado?
10. Um desenvolvedor novo conseguiria entender o fluxo?
11. Não há credenciais no código?
12. Não há dados sensíveis nos logs?
13. O código segue nomenclatura em português?
14. Existe exemplo de uso?