Crie componentes reutilizáveis de interface em /app/views/componentes.

Componentes necessários:
1. badge_status.php
2. card_processo.php
3. tabela_responsiva.php
4. barra_acoes_mobile.php
5. alerta.php
6. modal_confirmacao.php
7. seletor_papel_ativo.php
8. campo_busca_htmx.php

Requisitos:
- Os componentes devem ser simples.
- Devem aceitar parâmetros claros.
- Devem ser documentados com exemplos.
- Devem funcionar com Bootstrap/Tabler.
- Não usar JavaScript complexo.