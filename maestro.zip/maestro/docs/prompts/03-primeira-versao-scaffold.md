Baseado no documento docs/guias/principios-do-scaffold.md, crie a estrutura inicial do scaffold em PHP Slim.

Requisitos:

1. Usar Composer.
2. Separar /public, /app, /config e /tests.
3. Utilizar a estrutura /app/controllers, /app/models/ e /app/views de maneira similar ao usado em Fat Free.
4. O ponto de entrada deve ser /public/index.php.
5. Criar configuração por ambiente usando arquivos .env e .env.example.
6. Não incluir credenciais reais.
7. Criar uma rota inicial GET / que renderize uma página simples usando template.
8. Criar uma rota GET /saude que retorne JSON com status da aplicação.
9. Manter o código simples e documentado.
10. Evitar padrões complexos demais para a equipe atual.

Critério de aceite:

- O projeto deve subir localmente.
- A rota / deve exibir uma página HTML.
- A rota /saude deve retornar JSON.
- O README deve explicar como instalar e executar.

