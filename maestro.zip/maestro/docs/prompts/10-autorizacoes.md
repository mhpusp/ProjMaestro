Implemente uma camada simples de autorização por ação.

Modelo:
- sistema
- papel
- ação
- escopo opcional

Exemplo:
sistema: solicitacoes
papel: gestor
acao: solicitacao.aprovar

Requisitos:
1. Criar classe Autorizador.
2. Criar middleware ExigePermissao.
3. Criar arquivo config/permissoes.php com permissões de exemplo.
4. Aplicar em pelo menos uma rota do módulo Solicitações.
5. Quando acesso for negado, exibir página 403 amigável.
6. Registrar tentativa negada em log de auditoria simples.

Critério de aceite:
- Usuário sem permissão recebe 403 amigável.
- Usuário com permissão acessa a ação.
- O código deve ser simples e fácil de manter.