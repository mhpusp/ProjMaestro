**herculesf3**

## _Sistema de Gerência de Listas de E-mail_

[![N|Solid](http://www.poli.usp.br/images/stories/media/images/svinfor/logo-ep-600.png)](https://app.poli.usp.br/herculesf3/)

herculesf3 é um sistema de gerenciamento de listas de distribuição de e-mails, auxiliando a aplicação sympa tornando uma intreface mais amigável para o usuário final

## Atributos

- Para proprietários: Gerenciar publicadores de suas listas
- Para publicadores: Gerenciar inscritos nas listas
- Ambos tem a permissão de enviar para lista
- Mostra estado de mensagens enviadas (sucesso, rejeitadas, etc.)

## Navegação

```sh
Menu
```

| Nome                | Caminho       | Método     | Rota                         |
| ------------------- | ------------- | ---------- | ---------------------------- |
| Início              | /             | GET        | UserController->login        |
| Minhas Listas       | /ger_lista    | GET - POST | ListaController->paginaTab   |
| Gerentes das listas | /todas_listas | GET        | ListaController->todasListas |
| Perfil              | /perfil       | GET        | UserController->perfil       |
| Sair                | /logout       | GET        | UserController->logout       |

```sh
View
```

| Página              | Botão         | Caminho    | Função                       | Método | Rota |
| ------------------- | ------------- | ---------- | ---------------------------- | ------ | ---- |
| gerencia.htm | lista | `ger_lista?lista=['name_list']#tabs-1` | paginaTab | GET | ListaController->paginaTab |
| gerencia.htm | delBtRegra | `gerencia.js` /exclue_regra | delBtRegra | POST | ListaController->excluirRegra |
| gerencia.htm | buscaBt | `gerencia.js` /busca_pessoa | buscaBt | POST | ListaController->buscaPessoa |
| gerencia.htm | novaBt | `gerencia.js` /pessoa_regra | novaBt | POST | ListaController->pessoaRegra |
| gerencia.htm | add-novo | `gerencia.js` | add-novo | - | toggle() |
| gerencia.htm | salvaBt | `gerencia.js` /novo_inscrito | salvaBt | POST | ListaController->novoInscrito |
| gerencia.htm | form excluir |  `ger_lista?lista=['name_list']#tabs-1` | excluirInscrito | POST | ListaController->paginaTab |
| gerencia.htm | checkbox |  `gerencia.js` | checkCheckbox | - | - |
| gerencia.htm | buscaBtmbr |  `gerencia.js` /busca_pessoa | buscaBtmbr | POST | ListaController->buscaPessoa |
| gerencia.js | form addmbr |  `ger_lista?lista=['name_list']#tabs-1` | novoInscritoUSP | POST | ListaController->paginaTab |


## Criar arquivo composer.json

```sh
{
    "name": "ricardo/hercules",
    "authors": [
        {
            "name": "3040414",
            "email": "rveira@usp.br"
        }
    ],
    "require": {"bcosca/fatfree": "3.8",
        "ikkez/f3-sheet":"v0.4.2",
        "phpmailer/phpmailer": "^6.9",
        "uspdev/wsfoto": "^2.0",
        "econea/nusoap": "^0.9.17"
    }
}
```

> inicializa o composer

- composer init `cria o arquivo composer.json`
  > instala dependencias iniciais:
- composer update
  > instalando bibliotecas:
- composer require ikkez/f3-sheet
- composer require phpmailer/phpmailer
  > desinstalando biblioteca
- composer remove ikkez/f3-mailer

## criando um repositório

- crie o repositório no gitpoli
- execute estas linhas no seu projeto:
-- git init
-- git checkout -b main
-- git commit -m "first commit"
-- git remote add origin https://git.poli.usp.br/stdev/heliosf3.git
-- git push -u origin main

### url para receber o json papeis:

> dev.poli.usp.br/heliosf3/papel_usuario_app?app=hercules&codpes=?

### função mysql para retornar detetime de um timestamp

> `from_unixtime()`

```sh
    SELECT date_logs, from_unixtime(date_logs) as dtaocor FROM sympa.logs_table
    1697897855	-> 2023-10-21 11:17:35
```

> funcao para extrair hora do timestamp:

```sh
    SELECT date_logs, time(from_unixtime(date_logs)) AS hora FROM sympa.logs_table;
    1697897855	11:17:35
```

> funcao para extrair data do timestamp:

```sh
    SELECT date_logs, date(from_unixtime(date_logs)) AS mesanodia FROM sympa.logs_table;
    1697897855	2023-10-21
```
