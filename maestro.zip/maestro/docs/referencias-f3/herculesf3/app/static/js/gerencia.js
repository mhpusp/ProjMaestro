let prefixo_url = "/herculesf3";
moment.locale("pt-br"); // pt-br

// função mensagem
function mensagem(msgs) {
  if (Array.isArray(msgs)) {
    msgs.forEach((mg) => {
      adicionaItemNaLista(mg, "lista_msg");
    });
    $("#jsmessage").show();
  } else {
    $("#jsmessage").text(msgs);
    $("#jsmessage").show();
  }
}

// funcao para adicionar um item na div mensagem quando for um array de menagens
function adicionaItemNaLista(texto, lista) {
  //  console.log(texto, lista)
  elem = document.getElementById(lista);
  if (elem) {
    var node = document.createElement("LI"); // Create a <li> node
    var textnode = document.createTextNode(texto); // Create a text node
    node.appendChild(textnode); // Append the text to <li>
    document.getElementById(lista).appendChild(node); // Append <li> to <ul> with id="lista_msg"
  } else {
    $("#jsmessage").text(texto);
    $("#jsmessage").show();
  }
}

function espera_redirect(tempo, url) {
  setTimeout(function () {
    window.location.href = url;
  }, tempo);
}

function encontraParametrosURL() {
  const urlParams = new URLSearchParams(window.location.search);

  // 👇️ key1=value1&key2=value2
  // console.log(urlParams.toString());

  const key1 = urlParams.get("key1");
  // console.log(key1); // 👉️ value1

  const key2 = urlParams.get("key2");
  // console.log(key2); // 👉️ value2
}

function formataData(data_str) {
  if (data_str) {
    let [ano, mes, dia] = data_str.split("-");

    if (dia.toString().length == 1) dia = "0" + dia;
    if (mes.toString().length == 1) mes = "0" + mes;

    return dia + "/" + mes + "/" + ano;
  }
}

function formatStrToDate(data_str) {
  if (data_str) {
    let [dia, mes, ano] = data_str.split("/");

    if (dia.toString().length == 1) dia = "0" + dia;
    if (mes.toString().length == 1) mes = "0" + mes;

    return ano + "-" + mes + "-" + dia;
  }
}

function trataString(str) {
  let result = str.replace("{", "");
  result = result.replace("}", "");
  result = result.replaceAll('"', "");
  result = result.replace(":", " -> ");
  return result;
}

function retorna_cabecalho(cab) {
  var retorno = ``;
  for (var i = 0; i < cab.length; i++) {
    retorno += `<th>${cab[i]}</th>`;
  }
  return retorno;
}

function imprimeObjeto(obj) {
  let objstr = JSON.stringify(obj, null, 4);
  // console.log(`objstr: ${objstr}`);
}

function imprimeArray(arr) {
  let txt = "";
  for (let x in arr) {
    txt += arr[x];
    // console.log(`arr[${x}]: ${txt}`);
  }
}

function convertToCSV(objArray) {
  var array = typeof objArray != "object" ? JSON.parse(objArray) : objArray;
  var str = "";

  // Forçando o Excel a usar UTF-8 para CSV
  // colocando um BOM (Byte Order Mark) como primeiros caracteres no arquivo.
  // var universalBOM = "\uFEFF";

  for (var i = 0; i < array.length; i++) {
    var line = "\uFEFF";
    for (var index in array[i]) {
      if (line != "\uFEFF") line += ";";

      line += array[i][index];
    }

    str += line + "\r\n";
  }

  return str;
}

function exportCSVFile(headers, items, fileTitle) {
  if (headers) {
    items.unshift(headers);
  }

  // imprimeObjeto(items);

  // Convert Object to JSON
  var jsonObject = JSON.stringify(items);

  var csv = this.convertToCSV(jsonObject);

  var exportedFilenmae = fileTitle + ".csv" || "export.csv";
  // alterado o charset para cp-1252 (windows-1252)
  var blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  if (navigator.msSaveBlob) {
    // IE 10+
    navigator.msSaveBlob(blob, exportedFilenmae);
  } else {
    var link = document.createElement("a");
    if (link.download !== undefined) {
      // feature detection
      // Browsers that support HTML5 download attribute
      var url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", exportedFilenmae);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
}

// função para o dia de hoje
function hoje() {
  let agora = new Date();
  let ano = agora.getFullYear();
  let dia = agora.getDate();
  let mes = agora.getMonth() + 1;
  let hora = agora.getHours();
  let min = agora.getMinutes();
  if (dia.toString().length == 1) dia = "0" + dia;
  if (mes.toString().length == 1) mes = "0" + mes;
  if (hora.toString().length == 1) hora = "0" + hora;
  if (min.toString().length == 1) min = "0" + min;
  return dia + "/" + mes + "/" + ano + " " + hora + ":" + min;
}

// função para o nome de arquivo com data
function nome_arquivo(nome) {
  let agora = new Date();
  let ano = agora.getFullYear();
  let dia = agora.getDate();
  let mes = agora.getMonth() + 1;
  let hora = agora.getHours();
  let min = agora.getMinutes();
  if (dia.toString().length == 1) dia = "0" + dia;
  if (mes.toString().length == 1) mes = "0" + mes;
  if (hora.toString().length == 1) hora = "0" + hora;
  if (min.toString().length == 1) min = "0" + min;
  return nome + "_" + ano + "_" + mes + "_" + dia + "_" + hora + "_" + min;
}

function criaTabela(pessoas, lista) {
  //  console.log("criaTabela", data.pessoas[0].nompes)
  return `
  <h4>Lista de pessoas encontradas</h4>
  <p>${pessoas.length} registros em <span>${hoje()}</span></p>
  <table class="display table responsive" style="width:100%" id="${lista}">
  <thead>
      <tr>
        <th>Nr. USP</th>
        <th>Nome</th>
        <th>E-mail</th>
        <th>Vínculo</th>
        <th>Lotação</th>
        <th>Regra</th>
        <th>Ação</th>
      </tr>
    </thead>
    <tbody>
        ${pessoas.map(trLoop).join("")}
    </tbody>
    <tfoot><tr><td colspan="7">* Caso queira dar permissão ao email da seção(corporativo) como publicador desta lista, altere o e-mail e o nome da conta antes de adicionar!</td></tr></tfoot>
  </table>
`;
}

function criaTabelambr(pessoas, lista) {
  //  console.log("criaTabelambr", pessoas[0].nompes)
  return `
  <h4>Lista de pessoas encontradas</h4>
  <p>${pessoas.length} registros em <span>${hoje()}</span></p>
  <table class="display table responsive" style="width:100%" id="${lista}mbr">
  <thead>
      <tr>
        <th>Nr. USP</th>
        <th>Nome</th>
        <th>E-mail</th>
        <th>Vínculo</th>
        <th>Lotação</th>
        <th>Ação</th>
      </tr>
    </thead>
    <tbody>
        ${pessoas.map(trLoopmbr).join("")}
    </tbody>
  </table>
`;
}

function criaDivsMbr(pessoas, lista) {
  return `
  <style>
  .row {
    display: flex;
  }
  .col {
    flex: 1;
    padding: 10px;
  }
  </style>
  <h4>Lista de pessoas encontradas</h4>
  <p>${pessoas.length} registros em <span>${hoje()}</span></p>
  <div class="container text-center">
  <div class="row">
  <div class="col-md">
  <span>Nr.USP:</span>
  </div>
  <div class="col-md">
  <span>Nome:</span>
  </div>
  <div class="col-md">
  <span>E-mail:</span>
  </div>
  <div class="col-md">
  <span>Vinculo:</span>
  </div>
  <div class="col-md">
  <span>Local:</span>
  </div>
  <div class="col-md">
  <span>Ação:</span>
  </div>
  </div>
  ${pessoas.map(divLoopMbr).join("")}
  
</div>
<div class="form-text">* Resultado limitado em 5 ocorrências, caso a pessoa procurada não consta na lista, redefina sua busca com mais termos!</div>`;
}

function divLoopMbr(dados, index) {
  return `
  <form id="formi_${index}" method="post" action="#tabs-2">
  <input type="hidden" name="index" value="${index}"/>
  <input type="hidden" name="lista" value="${dados.lista}"/>
  <div class="row border border-dark" style="padding-top: 0.5rem;">
    <div class="col">
      <div class="col input-group">
        <input type="text" name="codpes${index}" value="${
          dados.codpes
        }" readonly class="form-control"/>
      </div>
    </div>
    <div class="col-md-auto">
      <div class="col input-group">
      <input type="text" name="nompes${index}" value="${
        dados.nompes
      }" required class="form-control"/>
      </div>
    </div>
    <div class="col-md-auto">
      <div class="col input-group">
      <input type="email" name="codema${index}" value="${
        dados.codema
      }" required class="form-control"/>
      </div>
    </div>
    <div class="col-md-auto">
    <div class="col input-group"><span id="tipvinext${index}" class="input-group-text">${
      dados.tipvinext
    }</span></div>
    </div>
    <div class="col-md-auto">
    <div class="col input-group"><span id="nomabvset${index}" class="input-group-text">${
      dados.setor == null ? "-" : dados.setor
    }</span></div>
    </div>
    <div class="col-md-auto">
    <div class="col input-group"><button class="btn btn-outline-primary btn-sm" type="submit"
    name="addmbr" id="btn_add${index}"
    title="Adicionar"><i class="bi bi-person-plus"></i></button></div>
    </div>
  </div> </form>`;
}

// função para cada entrada do loop
function trLoop(dados, index) {
  return `<tr id="lin${index}">
    <td><span id="codpes${index}">${dados.codpes}</span></td>
    <td><input type="text" id="nompes${index}" value="${dados.nompes}" class="form-control"/></td>
    <td><input type="email" id="codema${index}" value="${dados.codema}" class="form-control"/></td>
    <td><span id="tipvinext${index}">${dados.tipvinext}</span></td>
    <td><span id="nomabvset${index}">${dados.setor}</span></td>
    <td>
    <select id="regra${index}">
      <option value="editor">Publicador</option>
      <option value="owner">Proprietário</option>
    </select>
    </td>
    <td>
        <a type="button" class="btn btn-outline-primary btn-sm novaBt" index_pes="${index}" title="adicionar"><i class="bi bi-person-plus"></i></a>
    </td>
  </tr>`;
}

function trLoopmbr(dados, index) {
  return `<tr id="lin${index}">
  <td><form id="formi_${index}" method="post" action="#tabs-2">
  <input type="hidden" name="index" value="${index}"/>
  <input type="hidden" name="lista" value="${dados.lista}"/>
  <span id="codpes${index}">${dados.codpes}</span></td>
    <td><input type="text" id="nompes${index}" value="${dados.nompes}" class="form-control"/></td>
    <td><input type="email" id="codema${index}" value="${dados.codema}" class="form-control"/></td>
    <td><span id="tipvinext${index}">${dados.tipvinext}</span></td>
    <td><span id="nomabvset${index}">${dados.setor}</span></td>
    <td style="overflow-x:auto; white-space:nowrap; text-align: center;">
    <button class="btn btn-outline-primary btn-sm" type="submit"
    name="addmbr" id="btn_add${index}"
    title="Adicionar"><i class="bi bi-person-plus"></i></button>
    </form></td></tr>`;
  //  console.log(`trLoopmbr: ${index}`);
}

function depois(lista) {
  //evento novo
  $(".novaBt").on("click", function () {
    let index_pes = $(this).attr("index_pes");
    let codpes = document.getElementById("codpes" + index_pes).innerText;
    // let nompes = document.getElementById("nompes" + index_pes).innerText;
    let nomabvset = document.getElementById("nomabvset" + index_pes).innerText;
    let nompes = $("#nompes" + index_pes).val();
    let codema = $("#codema" + index_pes).val();
    let regra = $("#regra" + index_pes).val();

    var count_error = 0;
    var ar_msg = [];
    var validRegex =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (!codema) {
      ar_msg[ar_msg.length] = "O campo 'e-mail' precisa ser preenchido!";
      count_error++;
    }

    if (count_error === 0) {
      //  console.log( `pessoa selecionada: [${index_pes}], ${codpes}/${nompes} - ${nomabvset}`);
      //  console.log(`email: [${codema}], regra: ${regra}, lista: ${lista}`);
      let valido = codema.match(validRegex);
      //  console.log(`valido: ${valido} `);
      if (valido) {
        // email valido
        ar_msg = [];
        req = $.ajax({
          url: `${prefixo_url}/pessoa_regra`,
          type: "POST",
          data: {
            codpes: codpes,
            nompes: nompes,
            nomabvset: nomabvset,
            codema: codema,
            regra: regra,
            lista: lista,
          },
        });

        mensagem("Por favor aguarde...");
        $(".load").show(); // habilita/deshabilita engrenagem

        req
          .done(function (data) {
            var jsonData = JSON.parse(data);
            //  console.log(`mensagem de retorno: ${jsonData.mensagem}`);
            mensagem(jsonData.mensagem);
            $(".load").toggle(); // habilita/deshabilita engrenagem

            if (jsonData.redirect == 1) {
              //  console.log(location.href);
              // recarrega a mesma página
              // para funcionar a ancora (bookmark)
              location.reload();
            } else {
              mensagem(jsonData.msg);
            }
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/`);
            //$(".load").toggle();
          }); // fim do ajax com tratamento de erro
      } else {
        ar_msg[ar_msg.length] = "Endereço de e-mail inválido!";
        mensagem(ar_msg);
      }
    } else {
      mensagem(ar_msg);
    }
  });
}

function depoismbr(lista) {
  // evento novo
  //  console.log(`depoismbr: ${lista}`);
  $(".novaBtmbr").on("click", function () {
    //debugger; // para debugar no navegador
    let index_pes = $(this).attr("index_pes");
    let codpes = document.getElementById("codpes" + index_pes).innerText;
    let nomabvset = document.getElementById("nomabvset" + index_pes).innerText;
    let nompes = $("#nompes" + index_pes).val();
    let codema = $("#codema" + index_pes).val();
    $("#novo").toggle();
    //  console.log("novaBtmbr");
    //  console.log(`codpes: ${codpes}`);
    //  console.log(`nompes: ${nompes}`);
    //  console.log(`codema: ${codema}`);

    var count_error = 0;
    var ar_msg = [];
    var validRegex =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (!codema) {
      ar_msg[ar_msg.length] = "O campo 'e-mail' precisa ser preenchido!";
      count_error++;
    }

    if (count_error === 0) {
      //  console.log( `pessoa selecionada: [${index_pes}], ${codpes}/${nompes} - ${nomabvset}`);
      //  console.log(`email: [${codema}], regra: ${regra}, lista: ${lista}`);
      let valido = codema.match(validRegex);
      //  console.log(`valido: ${valido} `);
      if (valido) {
        // email valido
        ar_msg = [];
        req = $.ajax({
          url: `${prefixo_url}/pessoa_mbr`,
          type: "POST",
          data: {
            codpes: codpes,
            nompes: nompes,
            nomabvset: nomabvset,
            codema: codema,
            lista: lista,
          },
        });

        mensagem("Novo membro adicionando, recarregar a página!");
        $(".load").show(); // habilita/deshabilita engrenagem

        req
          .done(function (data) {
            var jsonData = JSON.parse(data);
            var url = jsonData.url;
            //  console.log(`mensagem de retorno: ${jsonData.mensagem}`);
            mensagem(jsonData.mensagem);
            $(".load").toggle(); // habilita/deshabilita engrenagem

            if (jsonData.redirect == 1) {
              // console.log("423 adicionado -> URL:", url);

              if (url) {
                // window.location = `${prefixo_url}/${url}`;
                // console.log(`url que chega: ${prefixo_url}/${url}`);
                // console.log(`url completa: ${window.location.href}`);
                //location.assign(`${prefixo_url}/${url}`);
                window.location = window.location.href;
              }
              //  console.log(location.href);
              // recarrega a mesma página
              // para funcionar a ancora (bookmark)
              //location.reload();
              //location.href = location.href + `?lista=${lista}#tabs-2`;
              //  console.log("novaBtmbr para onde? ",location.href);
              // location.replace(location.href);
              //window.location.href = `${prefixo_url}/${jsonData.url}`;
              //espera_redirect(1000, `${prefixo_url}/ger_lista?lista=${lista}#tabs-2`)
              //encontraParametrosURL();
              // window.location.replace(`${prefixo_url}/ger_lista?lista=${lista}#tabs-2`);
              //espera_redirect(1000, `${prefixo_url}/${jsonData.url}`);
            } else {
              mensagem(jsonData.msg);
              Swal.fire({
                title: "Aviso!",
                text: jsonData.msg,
                icon: "warning",
              });
            }
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/`);
            //$(".load").toggle();
          }); // fim do ajax com tratamento de erro
      } else {
        ar_msg[ar_msg.length] = "Endereço de e-mail inválido!";
        mensagem(ar_msg);
      }
    } else {
      mensagem(ar_msg);
    }
  });
}

function remove_elemento(id_elemento) {
  var elemento = document.getElementById(id_elemento);
  elemento.remove();
}

function checkCheckbox() {
  var cb = document.getElementById("email_ok");
  var receber = "nomail";
  var valor_cb = cb.value;
  const myArray = valor_cb.split("/");
  let lista = myArray[0];
  let codema = myArray[1];

  if (cb.checked == true) {
    receber = "mail";
  }
  //  console.log("valor_cb: ", valor_cb);
  //  console.log("receber: ", receber);
  //  console.log(`lista: ${lista}`);
  //  console.log(`codema: ${codema}`);

  req = $.ajax({
    url: `${prefixo_url}/alterna_ativacao_email`,
    method: "POST",
    data: {
      receber: receber,
      lista: lista,
      codema: codema,
    },
  });
}

// funçoes carregadas no load
$(document).ready(function () {
  $(".buscaBt").on("click", function () {
    let busca = $("#busca_pessoa").val();
    let lista = $(this).attr("lista");
    // console.log(`busca: [${busca}], para lista: ${lista}`);

    req = $.ajax({
      url: `${prefixo_url}/busca_pessoa`,
      type: "POST",
      data: {
        busca: busca,
        lista: lista,
      },
    });
    // animação do carregamento
    //$(".load").toggle(); // mostra engrenagem, abaixo tem o fadeout para desaparecer depois da execução

    req
      .done(function (data) {
        var jsonData = JSON.parse(data);
        // mensagem(jsonData.mensagem);
        //  console.log(`mensagem: ${jsonData.mensagem}`);
        // console.log(`jsonData: ${JSON.stringify(jsonData)}`);

        if (jsonData.pessoas.length > 0) {
          // texto =
          //   jsonData.pessoas.length > 1
          //     ? `Encontradas ${jsonData.pessoas.length} ocorrências!`
          //     : `Encontrada ${jsonData.pessoas.length} ocorrência!`;

          // mensagem(texto);
          mensagem(jsonData.mensagem);

          Swal.fire({
            title: "Aviso!",
            text: jsonData.mensagem,
            icon: "success",
          });

          // criando tabela dinamica:
          document.getElementById("tabela").innerHTML = criaTabela(
            jsonData.pessoas,
            jsonData.lista,
          );

          // colocado aqui para reformatar a tabela depois de criada no js
          $(`#${lista}`).DataTable({
            language: {
              url: "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Portuguese-Brasil.json",
            },
            order: [[1, "asc"]],
          });

          depois(jsonData.lista);
        } else {
          mensagem(jsonData.mensagem);
          Swal.fire({
            title: "Aviso!",
            text: jsonData.mensagem,
            icon: "warning",
          });
        }
        //$(".load").fadeOut(2000); // para desaparecer imagem das engrenagem durante o carregamento da página
      })
      .fail(function (req, exception) {
        // Our error logic here
        var msg = "";
        if (req.status === 0) {
          msg = "Limite de conexão expirado.\n Logue novamente na aplicação.";
        } else if (req.status == 404) {
          msg = "Página não encontrada. [404]";
        } else if (req.status == 500) {
          msg = "Erro interno do servidor [500].";
        } else if (exception === "parsererror") {
          msg = "Falha em formatar o JSON.";
        } else if (exception === "timeout") {
          msg = "Erro fora do limite do tempo.";
        } else if (exception === "abort") {
          msg = "Solicitação do Ajax abortada.";
        } else {
          msg = "Uncaught Error.\n" + req.responseText;
        }
        mensagem(msg);
        alert(msg);
        espera_redirect(1000, `${prefixo_url}/`);
        //$(".load").toggle();
      }); // fim do ajax com tratamento de erro
  });

  $(".resetBt").on("click", function () {
    //  console.log(`reseta input js`)
    $("#busca_pessoa").val("");
  });

  //busca_membro
  $(".resetBtmbr").on("click", function () {
    //  console.log(`reseta mbr input js`)
    $("#busca_membro").val("");
  });

  $(".buscaBtmbr").on("click", function () {
    let busca = $("#busca_membro").val();
    let lista = $(this).attr("lista");
    //  console.log(`buscaBtmbr: [${busca}], para lista: ${lista}`);

    req = $.ajax({
      url: `${prefixo_url}/busca_pessoa`,
      type: "POST",
      data: {
        busca: busca,
        lista: lista,
      },
    });
    // animação do carregamento
    //$(".load").toggle(); // mostra engrenagem, abaixo tem o fadeout para desaparecer depois da execução

    req
      .done(function (data) {
        var jsonData = JSON.parse(data);
        var pessoas = [];
        // mensagem(jsonData.mensagem);
        //  console.log(`mensagem: ${jsonData.mensagem}`);
        //  console.log(`jsonData: ${JSON.stringify(jsonData)}`);

        if (jsonData.pessoas.length > 0) {
          // texto =
          //   jsonData.pessoas.length > 1
          //     ? `Encontradas ${jsonData.pessoas.length} ocorrências!`
          //     : `Encontrada ${jsonData.pessoas.length} ocorrência!`;
          pessoas = jsonData.pessoas;

          for (i = 0; i < pessoas.length; i++) {
            //  console.log(`codpes: ${pessoas[i].codpes}`);
            pessoas[i]["lista"] = jsonData.lista; // add nome da lista em pessoa
            //  console.log(`lista: ${pessoas[i].lista}`);
          }

          // mensagem(texto);
          mensagem(jsonData.mensagem);
          Swal.fire({
            title: "Aviso!",
            text: jsonData.mensagem,
            icon: "success",
          });

          // criando tabela dinamica:
          document.getElementById("tab_membros").innerHTML = criaDivsMbr(
            pessoas,
            jsonData.lista,
          );

          // colocado aqui para reformatar a tabela depois de criada no js
          var datatableInstance = $(`#${lista}mbr`).DataTable({
            language: {
              url: "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Portuguese-Brasil.json",
            },
            order: [[1, "asc"]],
          });

          depoismbr(jsonData.lista);
        } else {
          mensagem(jsonData.mensagem);
          Swal.fire({
            title: "Aviso!",
            text: jsonData.mensagem,
            icon: "warning",
          });
        }
        //$(".load").fadeOut(2000); // para desaparecer imagem das engrenagem durante o carregamento da página
      })
      .fail(function (req, exception) {
        // Our error logic here
        var msg = "";
        if (req.status === 0) {
          msg = "Limite de conexão expirado.\n Logue novamente na aplicação.";
        } else if (req.status == 404) {
          msg = "Página não encontrada. [404]";
        } else if (req.status == 500) {
          msg = "Erro interno do servidor [500].";
        } else if (exception === "parsererror") {
          msg = "Falha em formatar o JSON.";
        } else if (exception === "timeout") {
          msg = "Erro fora do limite do tempo.";
        } else if (exception === "abort") {
          msg = "Solicitação do Ajax abortada.";
        } else {
          msg = "Uncaught Error.\n" + req.responseText;
        }
        mensagem(msg);
        alert(msg);
        espera_redirect(1000, `${prefixo_url}/`);
        //$(".load").toggle();
      }); // fim do ajax com tratamento de erro
  });

  //   inicio do evento de exclusão de regra
  $(".delBtRegra").on("click", function () {
    let id = $(this).attr("regra_id");
    //  console.log("delBtRegra", id);
    Swal.fire({
      title: "Tem certeza que quer excluir este registro?",
      text: "Esta ação não poderá ser revertida!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sim, exclua!",
      cancelButtonText: "Cancelar!",
    }).then((result) => {
      if (result.isConfirmed) {
        req = $.ajax({
          url: `${prefixo_url}/exclue_regra`,
          type: "POST",
          data: { id: id },
        });
        req
          .done(function (data) {
            remove_elemento("regraSection" + id);
            var jsonData = JSON.parse(data);
            mensagem(jsonData.mensagem);
            Swal.fire({
              title: "Excluído!",
              text: jsonData.mensagem,
              icon: "success",
            });
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/`);
          }); // fim do ajax com tratamento de erro
      }
    });
  });

  //delBtInscrto
  $(".delBtInscrto").on("click", function () {
    let lista = $(this).attr("lista");
    let pagina = $(this).attr("pagina");
    let subscriber = $(this).attr("subscriber");

    // // console.log(`lista: ${lista} `);
    // // console.log(`pagina: ${pagina} `);
    // // console.log(`subscriber: ${subscriber} `);

    Swal.fire({
      title: `Tem certeza que quer excluir ${subscriber} da lista ${lista}?`,
      text: "Esta ação não poderá ser revertida!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sim, exclua!",
      cancelButtonText: "Cancelar!",
    }).then((result) => {
      if (result.isConfirmed) {
        req = $.ajax({
          url: `${prefixo_url}/exclue_inscrito`,
          type: "POST",
          data: { lista: lista, pagina: pagina, subscriber: subscriber },
        });
        req
          .done(function (data) {
            remove_elemento("inscrSection" + subscriber);
            var jsonData = JSON.parse(data);
            mensagem(jsonData.mensagem);
            // // console.log(`url: ${jsonData.url} `);
            Swal.fire({
              title: "Excluído!",
              text: jsonData.mensagem,
              icon: "success",
            });
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/${jsonData.url}`);
          }); // fim do ajax com tratamento de erro
      }
    });
  });

  //delBtLista
  $(".delBtLista").on("click", function () {
    let lista = $(this).attr("lista");
    let tot = $(this).attr("tot");
    // console.log(`lista: ${lista} `);

    Swal.fire({
      title: `Tem certeza que quer excluir todos registros (${tot}) da lista ${lista}?`,
      text: "Esta ação não poderá ser revertida!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sim, exclua!",
      cancelButtonText: "Cancelar!",
    }).then((result) => {
      if (result.isConfirmed) {
        req = $.ajax({
          url: `${prefixo_url}/exclue_todos_inscritos`,
          type: "POST",
          data: { lista: lista },
        });
        req
          .done(function (data) {
            var jsonData = JSON.parse(data);
            mensagem(jsonData.mensagem);
            // console.log(`mensagem: ${jsonData.mensagem} `);
            Swal.fire({
              title: "Excluído!",
              text: jsonData.mensagem,
              icon: "success",
            });
            location.reload();
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/${jsonData.url}`);
          }); // fim do ajax com tratamento de erro
      }
    });
  });

  // Inscritos
  $(".add-novo").on("click", function () {
    $("#novo").toggle();
  });

  $(".add-mult").on("click", function () {
    $("#multiplos").toggle();
  });

  $(".salvaBt").on("click", function () {
    let codpes = $("#codpes").val();
    let nompes = $("#nompes").val();
    let codema = $("#codema").val();
    let lista = $(this).attr("lista");

    var count_error = 0;
    var ar_msg = [];
    var validRegex =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (!codema) {
      ar_msg[ar_msg.length] = "O campo 'e-mail' precisa ser preenchido!";
      count_error++;
    }

    if (count_error === 0) {
      //  console.log( `codpes: ${codpes}, nompes: ${nompes}, codema: ${codema} , lista: ${lista}`);
      let valido = codema.match(validRegex);
      //  console.log(`valido: ${valido} `);
      if (valido) {
        // email valido
        $("#novo").toggle();

        ar_msg = [];
        req = $.ajax({
          url: `${prefixo_url}/novo_inscrito`,
          type: "POST",
          data: {
            codpes: codpes,
            nompes: nompes,
            codema: codema,
            lista: lista,
          },
        });

        req
          .done(function (data) {
            var jsonData = JSON.parse(data);
            mensagem("Incluindo inscrito na lista, aguarde...");
            // // console.log(`salvaBt redirect: ${jsonData.redirect}`);
            // // console.log(`lista: ${jsonData.lista}`);
            // // console.log(`salvaBt url: ${jsonData.url}`);
            //  console.log(`${location.href}?lista=${lista}#tabs-2`);
            if (jsonData.redirect == 1) {
              // // console.log(`salvaBt location.href: ${location.href}`);
              // // console.log(`salvaBt reload`);
              // recarrega a mesma página
              // para funcionar a ancora (bookmark)
              // Refresh the page after a delay
              setTimeout(function () {
                location.reload();
              }, 1000); // 1000 milliseconds = 1 second
            } else {
              mensagem(jsonData.msg);
            }
          })
          .fail(function (req, exception) {
            // Our error logic here
            var msg = "";
            // // console.log(`status do retorno: ${req.status}`);
            if (req.status === 0) {
              msg =
                "Limite de conexão expirado.\n Logue novamente na aplicação.";
            } else if (req.status == 404) {
              msg = "Página não encontrada. [404]";
            } else if (req.status == 405) {
              msg = "Método não permitido. [405]";
            } else if (req.status == 500) {
              msg = "Erro interno do servidor [500].";
            } else if (exception === "parsererror") {
              msg = "Falha em formatar o JSON.";
            } else if (exception === "timeout") {
              msg = "Erro fora do limite do tempo.";
            } else if (exception === "abort") {
              msg = "Solicitação do Ajax abortada.";
            } else {
              msg = "Uncaught Error.\n" + req.responseText;
            }
            mensagem(msg);
            alert(msg);
            espera_redirect(1000, `${prefixo_url}/`);
            //$(".load").toggle();
          }); // fim do ajax com tratamento de erro
      } else {
        ar_msg[ar_msg.length] = "Endereço de e-mail inválido!";
        mensagem(ar_msg);
      }
    } else {
      mensagem(ar_msg);
    }
  });
});
