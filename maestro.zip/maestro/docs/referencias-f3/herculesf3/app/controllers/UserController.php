<?php

class UserController extends Controller
{
    // funcao antes
    function beforeroute($f3, $args)
    {
        parent::beforeroute($f3, $args);

        $papel = $this->f3->get('papel');
        $codpes = $this->f3->get('codpes');
        $result_setor = $this->db_r->exec("SELECT nomabvset as depto FROM replicado.LOCALIZAPESSOA WHERE  codset is not null AND codpes = ?", $codpes);

        if (empty($result_setor)) {
            if ($papel == 'usr') {
                $this->f3->set('depto', 'alunogr');
            } else {
                $this->f3->set('depto', 'FUSP');
            }
        } else {
            $this->f3->set('depto', $result_setor[0]['depto']);
        }
    }
    // fim funcao antes

    // funcao depois
    function afterroute($f3, $args)
    {
        parent::afterroute($f3, $args);

        $template = new Template;
        echo $template->render('base.htm');
    }
    // fim funcao depois


    // funcao logout
    public function logout()
    {
        $codpes = $this->f3->get('codpes');

        //$this->logger->write('');
        $this->logger->write("GET /logout=UserController->logout [$codpes]");
        $this->f3->clear('SESSION');
        $this->f3->reroute('https://app.poli.usp.br/opensso/UI/Logout');
        exit();
    }
    // fim funcao logout


    // funcao index
    public function login()
    {
        //$this->logger->write('');
        //$this->logger->write('GET /=UserController->login');
        //$this->f3->clear('SESSION');

        $title = $this->f3->get("APP_DESCRIPTION");
        $agora = $this->f3->get('agora');
        $usr_id = $this->f3->get('codpes');
        $nompes = $this->f3->get('nompes');
        $email = $this->f3->get('email');
        $papel = $this->f3->get('papel');
        $setor = $this->f3->get('depto');
        $usuarios = new User($this->db);
        $usrs = $usuarios->getById($usr_id);
        $listas = array();
        $rejeitados = array();
        $alteracoes = array();
        $dias_alt = 7; // número de dias para considerar as alterações recentes

        if (empty($usrs)) {
            $usuarios->id = $usr_id;
            $usuarios->codlog = $usr_id;
            $usuarios->nome = $nompes;
            $usuarios->codema = $email;
            $usuarios->dtaalt = $agora;
            $usuarios->papel = $papel;
            $usuarios->setor = $setor;
            $usuarios->save();
            $nome_usr = $nompes; // string
            $ult_login = $agora; // data
            //$this->logger->write("novo usuario: $usr_id, $nompes, $email, $papel, $setor");
        } else {
            if (!isset($_SESSION['codpes'])) {
                $usrs[0]->dtaalt = $agora;
                $usrs[0]->papel = $papel;
                $usrs[0]->setor = $setor;
                $usrs[0]->save();
                $_SESSION["codpes"] = $usr_id;
                $_SESSION["papel"] = $papel;
            }
            //$nome_usr = implode(array_column($usrs, 'nome')); // array -> converte array to string
            //$ult_login = implode(array_column($usrs, 'dtaalt')); // array -> converte array to string
            $nome_usr = $usrs[0]['nome'];
            $ult_login = $usrs[0]['dtaalt'];
        }

        // manipulando a sessão
        $sessionName = session_name();
        //$this->logger->write('session:                      ' . $_SESSION["codpes"]);
        //$this->logger->write('session Name:                 ' . session_name());
        // definindo o timeout da sessão para 2 horas (7200 segundos)
        if (isset($_COOKIE[$sessionName])) {
            setcookie($sessionName, $_COOKIE[$sessionName], time() + $this->f3->get('cache_em_minutos'), '/');
        }
        if ($papel == 'adm') {
            $listas = $this->listasUtilizadasHoje();
            $rejeitados = $this->enviosRejeitados();
            $alteracoes = $this->alteracoes_periodo($dias_alt);
        }else {
            // filtra as alterações para mostrar apenas as do usuário logado, selecionando apenas o codpesalt do array
            $alteracoes = array_values(array_filter($this->alteracoes_periodo($dias_alt), function ($alt) {
                return $alt['codlog'] == $this->f3->get('codpes');
            }));
        }

        // $this->logger->write("alteracoes ".json_encode($alteracoes));
        $this->f3->set('title', $title);
        $this->f3->set('listas', $listas);
        $this->f3->set('rejeitados', $rejeitados);
        $this->f3->set('nome_usr', $nome_usr);
        $this->f3->set('ult_login', $ult_login);
        $this->f3->set('alteracoes', $alteracoes);
        $this->f3->set('dias_alt', $dias_alt);
        $this->f3->set('papel', $papel);
        $this->f3->set('view', 'index.htm');
    }
    // fim funcao login


    public function perfil()
    {
        // $this->logger->write('');
        // $this->logger->write('GET /perfil=UserController->perfil');

        $title = "Perfil";
        $codpes = $this->f3->get('codpes');
        $usuarios = new User($this->db);
        $usrs = $usuarios->getById($codpes);
        //$nome_usr = implode(array_column($usrs, 'nome')); // array -> converte array to string
        //$ult_login = implode(array_column($usrs, 'dtaalt')); // array -> converte array to string
        //$receber = implode(array_column($usrs, 'receber_emails')); // array -> converte array to string
        $nome_usr = $usrs[0]['nome'];
        $ult_login = $usrs[0]['dtaalt'];
        $receber = $usrs[0]['receber_emails'];
        $inscrito = $this->listasInscrito();
        $data_formatada = $this->retornaDataHorario($ult_login, IntlDateFormatter::SHORT);
        $minhas_listas = $this->retornaArrayListasGerenciaCodpes($codpes);

        $this->f3->set('nome_usr', $nome_usr);
        $this->f3->set('data_formatada', $data_formatada);
        $this->f3->set('inscrito', $inscrito);
        $this->f3->set('minhas_listas', $minhas_listas);
        $this->f3->set('nome_usr', $nome_usr);
        $this->f3->set('ult_login', $ult_login);
        $this->f3->set('receber', $receber);
        $this->f3->set('title', $title);
        $this->f3->set('view', 'perfil.htm');
    }

    public function alteraRecebeEmail()
    {
        //$this->logger->write('');
        //$this->logger->write('POST /altera_recebe_email=UserController->alteraRecebeEmail');

        $recebe = $_POST['recebe'];
        $usr_id = $this->f3->get('codpes');
        $usuarios = new User($this->db);
        $usrs = $usuarios->getById($usr_id);
        //$this->logger->write("$usr_id recebe: $recebe");

        $usrs[0]->receber_emails = $recebe;
        $usrs[0]->save();
        // $msg = "perfil atualizado para não/receber notificações por e-mail!";

        // $msg_jsonfy = json_encode(
        //     array('msg' => $msg)
        // );

        // echo $msg_jsonfy;
    }
}
