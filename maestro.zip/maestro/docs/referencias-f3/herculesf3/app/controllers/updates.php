<?php

class updates extends Controller
{
    // funcao antes
    function beforeroute($f3, $args)
    {
        parent::beforeroute($f3, $args);
    }
    // fim funcao antes

    // funcao depois
    function afterroute($f3, $args)
    {

        parent::afterroute($f3, $args);
    }



    function update()
    {

        $lista = array(
            array('asep.poli@usp.br', 5517930, 'Assoc. Servidores EP'),
            array('atfn.poli@usp.br', 3791937, 'Assistência Técnica Financeira'),
            array('convenios.poli@usp.br', 3791937, 'CONVÊNIOS'),
            array('cultura.extensao.poli@usp.br', 2452482, 'Cultura e Extensão'),
            array('informatica.poli@usp.br', 2645560, 'Serviço Técnico de Informática POLI'),
            array('inventario.poli@usp.br', 2455165, 'Patrimônio - POLI'),
            array('patrimonio.poli@usp.br', 2455165, 'Patrimônio - POLI'),
            array('operacao.poli@usp.br', 2433470, 'Operação - POLI'),
            array('relacionamento.poli@usp.br', 3795312, 'Relacionamento - POLI'),
            array('servico.terceirizado.poli@usp.br', 2478484, 'Serviço de Gestão de Terceirizados'),
            array('svorcc@poli.usp.br', 8830327, 'Serviço de Órgãos Colegiados e Concursos'),
        );

        if ($this->f3->get('codpes') == 3040414) {
            foreach ($lista as $lis) {
                //$this->logger->write($lis[2]);
                $this->updateAdminTable($lis[1], trim($lis[2]), trim($lis[0]));
            }
        }

        $this->f3->set('view', 'index.htm');
        $template = new Template;
        echo $template->render('base.htm');
    }

    function updateAdminTable($codpes, $nompes, $user_admin)
    {
        $sql = "UPDATE sympa.admin_table SET codpes=?, nompes=? WHERE trim(user_admin)=? AND codpes IS NULL";

        try {
            $result = $this->db->exec($sql, array($codpes, trim($nompes), trim($user_admin)));
        } catch (Exception $e) {
            $this->logger->write("Erro ao tentar update de $codpes/$nompes - $user_admin");
        }
    }


    function updateCodpesNompesAdminTable()
    {
        $result = array();
        $sql = "UPDATE sympa.admin_table R JOIN replicado.EMAILPESSOA E
        ON (TRIM(R.user_admin) = TRIM(E.codema))
        JOIN replicado.PESSOA P ON (P.codpes = E.codpes)
        SET R.nompes=TRIM(P.nompes), R.codpes=E.codpes WHERE IFNULL(R.codpes, 0) = 0";

        try {
            $result = $this->db_r->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro ao tentar update de updateCodpesNompesAdminTable $e - $result");
        }
    }

    function updateCodpesNompesRoleTable()
    {
        $result = array();

        $sql = "UPDATE sympa.role_table R JOIN replicado.EMAILPESSOA E 
        ON (TRIM(R.user_admin) = TRIM(E.codema)) 
        JOIN replicado.PESSOA P ON (P.codpes = E.codpes)
        SET R.nompes=TRIM(P.nompes), R.codpes=E.codpes WHERE IFNULL(R.codpes, 0) = 0";

        try {
            $result = $this->db_r->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro ao tentar update de updateCodpesNompesRoleTable  $e - $result");
        }
    }

    function updateCodpesNompesSubscriberTable()
    {
        $result = array();

        $sql = "UPDATE sympa.subscriber_table R JOIN replicado.EMAILPESSOA E 
        ON (TRIM(R.user_subscriber) = TRIM(E.codema)) 
        JOIN replicado.PESSOA P ON (P.codpes = E.codpes) 
        SET R.nompes=TRIM(P.nompes), R.codpes=E.codpes WHERE IFNULL(R.codpes, 0) = 0";

        try {
            $result = $this->db_r->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro ao tentar update de updateCodpesNompesSubscriberTable  $e - $result");
        }
    }
}
