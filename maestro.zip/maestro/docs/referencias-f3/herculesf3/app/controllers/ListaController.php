<?php

class ListaController extends Controller
{
    // funcao antes
    function beforeroute($f3, $args)
    {
        parent::beforeroute($f3, $args);
    }
    // fim funcao antes

    // funcao depois
    function afterroute($f3, $args)
    {

        parent::afterroute($f3, $args);
    }



    function listaSelecionada()
    {
        // funcao sem uso (mesclada com os inscritos em paginaTab)

        $codpes = $this->f3->get('codpes');
        $papel = $this->f3->get('papel');
        $lista = '';
        $listas = array();
        $nome_lista = '';
        $papel_lista = array();
        $regras_lista = array();
        $msg = '';

        if (isset($_GET['lista']) && $papel <> 'usr') {
            $lista = $_GET['lista'];
            $nome_lista = $lista . '@listas.poli.usp.br';
            $papel_lista = $this->papel_lista_usuario($codpes, $lista);

            $regra = $papel == 'adm' ? 'owner' : $papel_lista[0]['role_admin'];

            // $this->logger->write('lista: ' . json_encode($lista));
            // $this->logger->write('papel_lista: ' . json_encode($papel_lista));

            if ($regra == 'owner') {
                //$msg = "Proprietário da lista '$lista'!";
                $regras_lista = $this->retorna_gerentes_lista($lista);
            } else {
                $msg = "Seu Papel para esta lista '$lista' é como publicador!";
            }
            $this->f3->set('title', $nome_lista);
            $this->f3->set('msg', $msg);
            $this->f3->set('lista', $lista);
            $this->f3->set('regras_lista', $regras_lista);
        } else {
            if ($papel == 'adm') {
                $listas = $this->retornaListasAtivas();
            } else {
                $listas = $this->retornaListasPorCodpes($codpes);
            }
            //$this->logger->write('listas: ' . count($listas));
            $msg = "Você tem " . count($listas) . " listas sob sua gerência!";

            $this->f3->set("listas", $listas);
            $this->f3->set("title", "@listas.poli.usp.br");
            $this->f3->set("msg", $msg);
        }
        $this->f3->set('view', 'regras.htm');
        $template = new Template;
        echo $template->render('base.htm');
    }

    function inscricoesUsuario()
    {
        $email = $this->f3->get('email');
        $codema = $_POST['codema'] ?? $email;
        $inscricoes_usuario = $this->minhasInscricoes($codema);
        $nome_usuario = null;
        $msg = '';
        if (!empty($inscricoes_usuario)) {
            $msg = "Foram encontradas " . count($inscricoes_usuario) . " inscrições para o e-mail '$codema'";
            $nome_usuario = empty($inscricoes_usuario[0]['nompes']) ? $inscricoes_usuario[0]['comment_subscriber'] : $inscricoes_usuario[0]['nompes'];
        } else {
            $msg = "Não foram encontradas inscrições para o e-mail '$codema'";
        }
        $this->f3->set("msg", $msg);
        $this->f3->set("inscricoes_usuario", $inscricoes_usuario);
        $this->f3->set("nome_usuario", $nome_usuario);
        $this->f3->set("title", "Inscrições por usuário");
        $this->f3->set('view', 'inscricoes_usuario.htm');
        $template = new Template;
        echo $template->render('base.htm');
    }

    function paginaTab()
    {
        $codpes = $this->f3->get('codpes');
        $papel = $this->f3->get('papel');
        $codema = $this->f3->get('email');
        $lista = '';
        $listas = array();
        $minhas_inscricoes = array();
        $nome_lista = '';
        $papel_lista = array();
        $regras_lista = array();
        $msg = '';
        $inscritos = array();
        $entity = array();
        $envios = array();
        $rejeitados = array();
        $alteracoes = array();
        $ret = array();
        $autorizado = true;
        $pagina = $_GET['pagina'] ?? "1";
        $rj_pagina = $_GET['rj_pagina'] ?? "1";
        $total_reg = 50;
        $anterior = 0;
        $proximo = 0;
        $pc = 0;
        $tp = 0;
        $tam_lista = 0;
        $inicio = 0;
        $idTabela = "tb_inscrito";
        $idTabRej = "tb_rejeitados";
        $termo = '';
        $up_to_date = array();
        $dataUltimoInscrito = null;

        if (isset($_GET['lista']) && $papel <> 'usr') {
            $lista = $_GET['lista'];
            $nome_lista = $lista . '@listas.poli.usp.br';
            $up_to_date = $this->retornaQueryLista($lista);
            $papel_lista = $this->papel_lista_usuario($codpes, $lista);
            $inscritos = $this->retornaInscritosLista($lista, $pagina, $total_reg);
            $entity = $inscritos[0];
            $anterior = $inscritos[1];
            $proximo = $inscritos[2];
            $pc = $inscritos[3];
            $tp = $inscritos[4];
            $tam_lista = $inscritos[5];
            $inicio = $inscritos[6];
            // $regra = $papel == 'adm' ? 'owner' : $papel_lista[0]['role_admin'];
            $regra = $papel == 'adm' ? 'owner' : $papel_lista[0]['role_admin'];
            $envios = $this->logEnvioListaSucesso($lista);
            if (empty($envios)) {
                $envios = $this->logUltimoEnvio($lista);
            }
            $array_rj = $this->logEnvioListaErro($lista, 0, 0, $rj_pagina, $total_reg);
            $rejeitados = $array_rj[0];
            $rj_anterior = $array_rj[1];
            $rj_proximo = $array_rj[2];
            $rj_pc = $array_rj[3];
            $rj_tp = $array_rj[4];
            $rj_tam_lista = $array_rj[5];
            $rj_inicio = $array_rj[6];
            $idTabRej = $rj_tam_lista > 200 ? "tb_secundaria2" : "tb_rejeitados";

            $regras_lista = $this->retorna_gerentes_lista($lista);
            $idTabela = $tam_lista > 200 ? "tb_secundaria" : "tb_inscrito";

            // $this->logger->write("papel_lista:" . json_encode($papel_lista));
            // $this->logger->write("rj_tam_lista rejeitados: $rj_tam_lista");
            // $this->logger->write('regras_lista: ' . count($regras_lista));
            // $this->logger->write('envios: ' . count($envios));
            // $this->logger->write('rejeitados: ' . count($rejeitados));
            //$this->logger->write($rj_tam_lista < $total_reg*$rj_pagina ? $rj_tam_lista : $total_reg*$rj_pagina);

            $this->f3->set('title', $nome_lista);
            $this->f3->set('regra', $regra);
            $this->f3->set('lista', $lista);
            $this->f3->set('regras_lista', $regras_lista);
            $this->f3->set('envios', $envios);
            $this->f3->set('rj_pagina', $rj_pagina);
            $this->f3->set('rejeitados', $rejeitados);
            $this->f3->set('idTabRej', $idTabRej);
            $this->f3->set('rj_anterior', $rj_anterior);
            $this->f3->set('rj_proximo', $rj_proximo);
            $this->f3->set('rj_pc', $rj_pc);
            $this->f3->set('rj_tp', $rj_tp);
            $this->f3->set('rj_tam_lista', $rj_tam_lista);
            $this->f3->set('rj_inicio', $rj_inicio);
        } else {
            if ($papel == 'adm') {
                $listas = $this->retornaListasAtivas();
                //$this->logger->write('listas: ' . json_encode($listas));
            } else {
                // papel usr
                $listas = $this->retornaListasPorCodpes($codpes);
            }
            // minhas inscricoes
            $minhas_inscricoes = $this->minhasInscricoes($codema);
            $this->f3->set("minhas_inscricoes", $minhas_inscricoes);
            // $this->logger->write('codema: ' . $codema);
            // $this->logger->write('minhas_inscricoes: ' . json_encode($minhas_inscricoes));

            if ($listas) {
                $msg = "Você tem " . count($listas) . " listas sob sua gerência!";
                $this->f3->set("listas", $listas);
            } else {
                $autorizado = false;
            }
            //$this->logger->write('listas: ' . count($listas));

        }
        if (isset($_POST['add_multiplos'])) {
            $dados = $_POST['mults'];
            $lista = $_POST['lista'];
            $csvArray = array();
            $array_linhas = array();
            if (isset($dados)) {
                foreach ($_POST as $nome_campo => $valor) {
                    // $this->logger->write("###");
                    // $this->logger->write("post: $nome_campo => $valor");
                    // $this->logger->write("###");
                    if ($nome_campo == 'mults') {
                        $Data = str_getcsv($valor, "\n"); //parse the rows
                        foreach ($Data as &$Row) {
                            $Row = str_getcsv($Row, ","); //parse the items in rows
                            array_push($csvArray, $Row);
                        }
                        // $this->logger->write("tam row: " . count($Row));
                        // $this->logger->write("ultima linha: " . json_encode($Row));
                    }
                }

                $array_linhas = array_slice($csvArray, 1);
                $resposta = $this->retornaInscritosSalvos($lista, $array_linhas);
                $msg = array($resposta['mensagem']);
                //array_push($msg, "Total de registros na lista: " . $resposta['total']);
            } else {
                $msg = "Nenhum dado foi enviado!";
            }
        }

        if (isset($_POST['delall'])) {
            $lista = $_POST['lista'];
            $msg = $this->excluirInscritosLista($lista);
        }

        // adicionar inscrito na lista
        if (isset($_POST['addmbr'])) {
            $lista = $_POST['lista'];
            $idx = $_POST['index'];
            $codpes = $_POST["codpes$idx"];
            $nompes = $_POST["nompes$idx"];
            $codema = $_POST["codema$idx"];
            // $this->logger->write("$lista, $codpes, $nompes, $codema");
            $ret = $this->novoInscritoUSP($lista, $codpes, $nompes, $codema);
            $msg = $ret[0];
            if ($ret[1] > 0)
                $inscritos = $this->retornaInscritosLista($lista, $pagina, $total_reg);
            $entity = $inscritos[0];
            $anterior = $inscritos[1];
            $proximo = $inscritos[2];
            $pc = $inscritos[3];
            $tp = $inscritos[4];
            $tam_lista = $inscritos[5];
            $inicio = $inscritos[6];
            $idTabela = $tam_lista > 200 ? "tb_secundaria" : "tb_inscrito";
        }
        if (isset($_POST['update_inscrito'])) {
            $lista = $_POST['lista'];
            $query_array = $this->retornaQueryLista($lista);
            $this->atualizarInscritos($lista, $query_array[0]['query']);
            $inscritos = $this->retornaInscritosLista($lista, $pagina, $total_reg);
            $entity = $inscritos[0];
            $anterior = $inscritos[1];
            $proximo = $inscritos[2];
            $pc = $inscritos[3];
            $tp = $inscritos[4];
            $tam_lista = $inscritos[5];
            $inicio = $inscritos[6];
            $idTabela = $tam_lista > 200 ? "tb_secundaria" : "tb_inscrito";
        }
        // se a lista for até 200 registros, não limita, exibe todos 
        if ($tam_lista <= 200)
            $entity = $this->db->exec("SELECT * FROM sympa.subscriber_table WHERE list_subscriber=?",  $lista);

        if (isset($_POST['pesquisa_inscrito'])) {
            $lista = $_POST['lista'];
            $termo = $_POST['termo'];
            $nome_lista = $lista . '@listas.poli.usp.br';
            $entity = $this->retornaResultadoPesquisaInscrito($lista, $termo);
            $idTabela = "tb_secundaria";

            $this->f3->set('termo', $termo);
            $this->f3->set('title', $nome_lista);
        }

        if (isset($_GET['lista']) || isset($_POST['lista'])) {
            $lista = $_GET['lista'] ?? $_POST['lista'];
            $dataUltimoInscrito = $this->retornaDataUltimoInscrito($lista);
        }

        if ($autorizado) {
            $this->f3->set('pagina', $pagina);
            $this->f3->set('total_reg', $total_reg);
            $this->f3->set('up_to_date', $up_to_date[0]['query']);
            $this->f3->set('dataUltimoInscrito', $dataUltimoInscrito);
            $this->f3->set('inscritos', $entity);
            $this->f3->set('anterior', $anterior);
            $this->f3->set('proximo', $proximo);
            $this->f3->set('pc', $pc);
            $this->f3->set('tp', $tp);
            $this->f3->set('tam_lista', $tam_lista);
            $this->f3->set('inicio', $inicio);
            $this->f3->set('idTabela', $idTabela);
            $this->f3->set('view', 'gerencia.htm');
        } else {
            $this->f3->set('view', 'nao_autorizado.htm');
        }
        $this->f3->set("msg", $msg);
        $template = new Template;
        echo $template->render('base.htm');
    }

    function todasListas()
    {

        $listas = $this->gerentes_listas();

        $msg = 'Listas de distribuição e seus Gerentes (proprietários)';

        $this->f3->set("msg", $msg);
        $this->f3->set("title", "Gerentes");
        $this->f3->set("listas", $listas);
        $this->f3->set('view', 'todaslistas.htm');
        $template = new Template;
        echo $template->render('base.htm');
    }

    function buscaPessoa()
    {
        $busca = $_POST['busca'];
        $lista = $_POST['lista'];
        $pessoa = array();
        $pessoas = array();

        if ($busca != null) {

            $ehNumero = is_numeric($busca);
            if ($ehNumero) {
                $pessoa = $this->retorna_pessoa_por_codpes($busca);
                if (!empty($pessoa)) {
                    $msg = "Pessoa encontrada";
                    $pessoas = $pessoa;
                    // $this->logger->write("msg: por codpes $busca" . json_encode($pessoa));
                    // $this->logger->write("nompes: ".$pessoa[0]['nompes']);
                    // incluir encontrado
                } else {
                    $msg = "Não foi encontrado nenhum registro com este Nro. USP!";
                }
                // $this->logger->write("msg: $msg");
            } else {
                 // por email ou nome
                if (strpos($busca, '@') !== false) {
                    // por email
                    $pessoa = $this->retorna_pessoa_por_email($busca);
                    if (!empty($pessoa)) {
                        $msg = "Pessoa encontrada";
                        $pessoas = $pessoa;
                        // $this->logger->write("msg: por email $busca" . json_encode($pessoa));
                        // $this->logger->write("nompes: ".$pessoa[0]['nompes']);
                    } else {
                        $msg = "Não foi encontrado nenhum registro com este e-mail [$busca]!";
                    }
                } else {
                    // por nome
                    $pessoas = $this->retorna_lst_pessoas($busca);
                    // $this->logger->write("busca por nome $busca -> " . json_encode($pessoas));
                    if (!empty($pessoas)) {
                        $msg = count($pessoas) == 1 ? "Pessoa encontrada!" : "Encontradas " . count($pessoas) . " pessoas contendo este termo: '$busca'!";
                    } else {
                        $msg = "Não foi encontrado nenhum registro contendo este termo: '$busca'!";
                    }
                }
            }
        } else {
            $msg = "Campo de busca vazio!";
        }
        // $this->logger->write("msg: $msg - Termo procurado: '$busca' lista: $lista");

        $msg_jsonfy = json_encode(
            array(
                'mensagem' => $msg,
                'pessoas' => $pessoas,
                'lista' => $lista
            )
        );

        echo $msg_jsonfy;
    }

    function pessoaRegra()
    {
        $lista = $_POST['lista'];
        $codpes = $_POST['codpes'];
        $nompes = $_POST['nompes'];
        //$nomabvset = $_POST['nomabvset'];
        $codema = $_POST['codema'];
        $regra = $_POST['regra'];
        $redirect = 0;
        $agora = $this->f3->get('agora');
        $codpesalt = $this->f3->get('codpes');
        $msg = "Regra para a lista $lista, criada com êxito!";


        // $this->logger->write("lista: $lista");
        // $this->logger->write("codpes: $codpes");
        // $this->logger->write("regra: $regra");

        $obj = new Regra($this->db);

        $existe = $obj->getByEmailRegraList($codema, $regra, $lista);

        if (count($existe) > 0) {
            $msg = "Regra Já existe para este e-mail!";
        } else {
            $obj->list_admin = $lista;
            $obj->role_admin = $regra;
            $obj->user_admin = $codema;
            $obj->nompes = $nompes;
            $obj->codpes = $codpes;
            $obj->reception_admin = 'mail';
            $obj->update_admin = $agora;
            $obj->codpesalt = $codpesalt;
            try {
                $obj->save();
                $redirect = 1;
            } catch (Exception $e) {
                $this->logger->write("Exceção: '$e'");
                $msg = "Não foi possível adicionar por erro!";
            }
        }

        $msg_jsonfy = json_encode(
            array(
                'mensagem' => $msg,
                'lista' => $lista,
                'redirect' => $redirect
            )
        );

        echo $msg_jsonfy;
    }

    function excluirRegra()
    {

        $id = 0;
        $msg = '';
        if (isset($_POST['id'])) {
            $id = $_POST['id'];
            $obj = new Regra($this->db);
            $obj->delete($id);
            $msg = "Regra para o e-mail: '{$obj->user_admin}', apagada com êxito!";
        }

        $msg_jsonfy = json_encode(
            array('mensagem' => $msg)
        );

        echo $msg_jsonfy;
    }

    function excluirInscrito()
    {
        $msg = '';
        $lista = $_POST['lista'];
        $codema  = $_POST['subscriber'];
        $pagina  = $_POST['pagina'];
        //$url = "ger_lista?lista=$lista#tabs-2";
        $obj = new Inscrito($this->db);
        try {
            $obj->delete($codema, $lista);
            $msg = "$codema excluído da lista '$lista'";
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
            $msg = "Não foi possível excluir por erro!";
        }
        $msg_jsonfy = json_encode(
            array(
                'mensagem' => $msg,
                'lista' => $lista,
                'url' => "ger_lista?lista=$lista&pagina=$pagina#tabs-2"
            )
        );

        echo $msg_jsonfy;
    }


    function excluirInscritosLista()
    {
        $msg = '';
        $lista = $_POST['lista'];
        $val = 0;
        try {
            $val = $this->db->exec("DELETE FROM sympa.subscriber_table WHERE list_subscriber=?",  $lista);
            $msg = "Excluído todos inscritos da lista '$lista'";
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
            $msg = "Não foi possível excluir inscritos da lista '$lista'!";
        }
        $msg_jsonfy = json_encode(
            array(
                'mensagem' => $msg,
                'lista' => $lista,
                'url' => "ger_lista?lista=$lista#tabs-2"
            )
        );
        $this->logger->write("excluindo: $msg - $val");
        echo $msg_jsonfy;
    }


    function novoInscritoUSP($lista, $codpes, $nompes, $codema)
    {

        $msg = '';
        $agora = $this->f3->get('agora');
        $codpesalt = $this->f3->get('codpes');
        $from = array($lista . '@listas.poli.usp.br', $lista);
        $to = array($codema, $nompes);
        $ok = 0;

        $obj = new Inscrito($this->db);
        $existe = $this->existeInscritoLista($lista, $codema);

        if (empty($existe)) {
            $obj->comment_subscriber = trim($nompes);
            $obj->date_subscriber = $agora;
            $obj->included_subscriber = 1;
            $obj->list_subscriber = $lista;
            $obj->reception_subscriber = 'mail';
            $obj->custom_attribute_subscriber = '<?xml version="1.0" encoding="UTF-8" ?><custom_attributes><custom_attributes>';
            $obj->robot_subscriber = 'listas.poli.usp.br';
            $obj->subscribed_subscriber = 1;
            $obj->update_subscriber = $agora;
            $obj->user_subscriber = trim($codema);
            $obj->visibility_subscriber = 'noconceal';
            $obj->codpes = $codpes;
            $obj->nompes = trim($nompes);
            $obj->codpesalt = $codpesalt;
            try {
                $obj->save();
                $msg = "e-mail incluído na lista '$lista'";
                $ok = 1;
                $this->criaMensagemParaEnvio($from, $to);
            } catch (Exception $e) {
                $this->logger->write("Exceção: '$e'");
                $msg = "Não foi possível adicionar por erro!";
            }
        } else {
            $msg = "Já existe este endereço de e-mail [$codema] na lista '$lista'";
        }

        return array($msg, $ok);
    }


    function novoInscrito()
    {
        // $this->logger->write("Novo inscrito");
        $lista = $_POST['lista'];
        $codpes = $_POST['codpes'];
        $nompes = $_POST['nompes'];
        $codema = $_POST['codema'];
        $msg = '';
        $redirect = 0;
        $agora = $this->f3->get('agora');
        $codpesalt = $this->f3->get('codpes');
        $from = array($lista . '@listas.poli.usp.br', $lista);
        $to = array($codema, $nompes);
        $url = "ger_lista?lista=$lista#tabs-2";
        $production_identifiers = [
            'dev.poli.usp.br',
            'app.poli.usp.br',
        ];
        $current_identifier = $_SERVER['HTTP_HOST'];

        // $this->logger->write("Novo inscrito: $lista, $codpes, $nompes, $codema");

        $obj = new Inscrito($this->db);
        //$existe = $obj->getByCodemaLista($codema,$lista);
        $existe = $this->existeInscritoLista($lista, $codema);

        // $this->logger->write("Existe? " . json_encode($existe));
        // se não existe, inclui, se existe, retorna msg de já existe
        if (empty($existe)) {
            $pessoa = $this->retorna_pessoa_por_email($codema);
            if (!empty($pessoa)) {
                $codpes = $pessoa[0]['codpes'];
                $nompes = $pessoa[0]['nompes'];
            }
            $obj->comment_subscriber = $nompes;
            $obj->date_subscriber = $agora;
            $obj->included_subscriber = 1;
            $obj->list_subscriber = $lista;
            $obj->reception_subscriber = 'mail';
            $obj->custom_attribute_subscriber = '<?xml version="1.0" encoding="UTF-8" ?><custom_attributes><custom_attributes>';
            $obj->robot_subscriber = 'listas.poli.usp.br';
            $obj->subscribed_subscriber = 1;
            $obj->update_subscriber = $agora;
            $obj->user_subscriber = $codema;
            $obj->visibility_subscriber = 'noconceal';
            $obj->codpes = $codpes;
            $obj->nompes = $nompes;
            $obj->codpesalt = $codpesalt;
            try {
                $obj->save();
                $msg = "e-mail incluído na lista '$lista'";
                $redirect = 1;

                if (in_array($current_identifier, $production_identifiers)) {
                    $this->criaMensagemParaEnvio($from, $to);
                }
            } catch (Exception $e) {
                $msg = "Não foi possível adicionar por erro!";
                $this->logger->write("$msg Exceção: '$e'");
            }
        } else {
            $msg = "Já existe este endereço de e-mail [$codema] na lista '$lista'";
        }

        $msg_jsonfy = json_encode(
            array(
                'mensagem' => $msg,
                'redirect' => $redirect,
                'lista' => $lista,
                'url' => $url
            )
        );

        echo $msg_jsonfy;
    }


    function alternaAtivacaoEmail()
    {

        $receber = $_POST['receber'];
        $lista = $_POST['lista'];
        $codema = $_POST['codema'];
        $agora = $this->f3->get('agora');
        $codpesalt = $this->f3->get('codpes');
        $status = $codema == 'mail' ? 'ativo' : 'desativado';

        $obj = new Inscrito($this->db);
        $obj->retornaInscrito($lista, $codema);
        // $this->logger->write("inscrito:" . json_encode($obj));
        // $this->logger->write("receber: [$receber], lista: [$lista] codema: [$codema]");

        $obj->reception_subscriber = $receber;
        $obj->update_subscriber = $agora;
        $obj->codpesalt = $codpesalt;

        try {
            $obj->save();
            $msg = "e-mail $codema $status na lista [$lista]";
            $this->logger->write($msg);
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
            $msg = "Não foi possível alternar o e-mail!";
        }

        $msg_jsonfy = json_encode(
            array('mensagem' => $msg)
        );

        echo $msg_jsonfy;
    }

    function retornaInscritosSalvos($lista, $multInscritos)
    {
        $resultados = array();
        $cont_lin = 0;
        $msg =  array();
        $tam = count($multInscritos[0]);

        if ($tam == 3) {
            foreach ($multInscritos as $linha) {
                $cont_lin++;
                if ($linha[0] == '' || $linha[1] == '' || $linha[2] == '') {
                    $msg[] = "Linha inválida: " . json_encode($linha);
                    continue;
                }
                if (!$this->validarEmail(trim($linha[0]))) {
                    $msg[] = "E-mail inválido: " . json_encode($linha);
                    continue;
                }

                array_push($msg, $this->adicionaInscritoLista($lista, $linha) . " " . $cont_lin);
                // $this->logger->write($linha[0] . " " . $linha[1] . " " . $linha[2] . "  -> " . $cont_lin);
            }
            $resultados['mensagem'] = $msg;
        } // se for 3 colunas
        else {
            $msg = "Formato inválido! Use: e-mail, nome, nro. USP";
            $this->logger->write("msg: $msg");
            $resultados['mensagem'] = $msg;
            return $resultados;
        }

        $this->logger->write("Multiplos inscritos na lista '$lista' : " . count($resultados['mensagem']));
        return $resultados;
    }


    function adicionaInscritoLista($lista, $linha)
    {

        $user_subscriber = trim($linha[0]);
        $comment_subscriber = trim($linha[1]);
        $nompes = trim($linha[1]);
        $codpes = is_numeric(trim($linha[2])) ? (int) trim($linha[2]) : '0';
        $custom_attribute_subscriber = '<?xml version="1.0" encoding="UTF-8" ?><custom_attributes></custom_attributes>';
        $date_subscriber = $this->f3->get('agora');
        $included_subscriber = 1;
        $list_subscriber = $lista;
        $reception_subscriber = 'mail';
        $robot_subscriber = 'listas.poli.usp.br';
        $subscribed_subscriber = 1;
        $update_subscriber = $this->f3->get('agora');
        $visibility_subscriber = 'noconceal';
        $codpesalt = $this->f3->get('codpes');
        // $suspend_end_date_subscriber = null;    
        // $suspend_start_date_subscriber = null; 
        // $suspend_subscriber = null;        
        // $topics_subscriber = null;       
        // $bounce_address_subscriber = null;
        // $bounce_score_subscriber = null;
        // $bounce_subscriber = null; 
        // $include_sources_subscriber = '';       
        $msg = '';

        $obj = new Inscrito($this->db);
        $existe = $this->existeInscritoLista($lista, $user_subscriber);

        // $this->logger->write("Existe? " . json_encode($existe));

        if (empty($existe)) {

            $obj->comment_subscriber = $comment_subscriber;
            $obj->date_subscriber = $date_subscriber;
            $obj->included_subscriber = $included_subscriber;
            $obj->list_subscriber = $list_subscriber;
            $obj->reception_subscriber = $reception_subscriber;
            $obj->custom_attribute_subscriber = $custom_attribute_subscriber;
            $obj->robot_subscriber = $robot_subscriber;
            $obj->subscribed_subscriber = $subscribed_subscriber;
            $obj->update_subscriber = $update_subscriber;
            $obj->user_subscriber = $user_subscriber;
            $obj->visibility_subscriber = $visibility_subscriber;
            $obj->codpes = $codpes;
            $obj->nompes = $nompes;
            $obj->codpesalt = $codpesalt;
            try {
                $obj->save();
                $msg = "e-mail [$user_subscriber], incluído na lista '$lista'";
            } catch (Exception $e) {
                $this->logger->write("Exceção: '$e'");
                $msg = "Não foi possível adicionar por erro!";
            }
        } else {
            $msg = "Já existe este endereço de e-mail [$user_subscriber] na lista '$lista' ";
        }

        return $msg;
    }


    function validarEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    // Exemplo de uso
    // $email = "exemplo@dominio.com";
    // if (validarEmail($email)) {
    //     echo "E-mail válido!";
    // } else {
    //     echo "E-mail inválido!";
    // }


    function insertAdmin()
    {
        $comment_admin = '';
        $date_admin = '';
        $list_admin = '';
        $robot_admin = '';
        $role_admin = '';
        $update_admin = '';
        $user_admin = '';
        $codpes = '';
        $nompes = '';

        // $sql = "INSERT INTO sympa.admin_table";

        // try {
        //     $result = $this->db->exec($sql, array($codpes, trim($nompes), trim($user_admin)));
        // } catch (Exception $e) {
        //     $this->logger->write("Erro ao tentar update de $codpes/$nompes - $user_admin");
        // }

        //INSERT INTO sympa.admin_table
        // (comment_admin,
        // date_admin,
        // included_admin,
        // list_admin,
        // profile_admin,
        // reception_admin,
        // robot_admin,
        // role_admin,
        // subscribed_admin,
        // update_admin,
        // user_admin,
        // visibility_admin,
        // codpes,
        // nompes)
        // VALUES
        // (
        // comment_admin = nompes,
        // date_admin,
        // included_admin =0,
        // list_admin,
        // profile_admin='normal',
        // reception_admin = 'mail',
        // robot_admin,
        // role_admin,
        // subscribed_admin = 0,
        // update_admin,
        // user_admin,
        // visibility_admin = 'noconceal',
        // codpes,
        // nompes
        //);

    }
}
