<?php
class MalaDiretaController extends Controller
{
    public function index()
    {
        $papel = $this->f3->get('papel');
        $lista = 'siicusp.orientadores';
        $title = "Mala Direta SIICUSP - ";
        $agora = $this->f3->get('agora');
        $temp_msg = "";
        $projetos = array();

        $this->f3->set('papel', $papel);
        if ($papel == 'adm') {
            if (isset($_POST['enviar'])) {
                $envio = $this->malaDiretaSiicusp($lista);
                $temp_msg = $envio ? "Mala Direta SIICUSP enviada com Sucesso!" : "Mala Direta SIICUSP não enviada.";
                $this->f3->set('msg', $temp_msg);
            }
            if (isset($_POST['codpes_or'])) {
                $projetos = $this->retornaSiicuspCodpes($_POST['codpes_or']);
                $this->f3->set('msg', "Projetos do orientador: " . $_POST['nompes_or']);
            }
            $entity = $this->retornaLista($lista);
            if (!$entity) {
                $this->criaInscritos($lista);
                $entity = $this->retornaLista($lista);
            }
            $this->f3->set('title', $title . $lista);
            $this->f3->set('agora', $agora);
            $this->f3->set('lista', $lista);
            $this->f3->set('inscritos', $entity);
            $this->f3->set('projetos', $projetos);
            $this->f3->set('view', 'mala_direta_siicusp.htm');
        } else {
            $this->f3->set('view', 'nao_autorizado.htm');
        }
        $template = new Template;
        echo $template->render('base.htm');
    }

    function retornaLista($lista)
    {
        $entity = $this->db->exec("SELECT * FROM sympa.subscriber_table WHERE reception_subscriber='mail' AND list_subscriber=?",  $lista);

        return $entity;
    }


    function criaInscritos($lista)
    {
        $siicusp = $this->retornaSiicusp();
        $this->atualizarInscritosSiicusp($lista, $siicusp);
    }

    function malaDiretaSiicusp($lista)
    {
        $entity = $this->retornaLista($lista);
        $trueCount = 0;
        $falseCount = 0;
        foreach ($entity as $inscrito) {
            // o from é um array com o email e o nome do remetente, respectivamente: $from[0] = email, $from[1] = nome
            $from = array("pesquisa.poli@usp.br", "Serviço de Pesquisa");
            $to = $inscrito['user_subscriber'];
            $subject = 'SIICUSP 2026 - Indicação da área dos trabalhos';
            $codpes_or = $inscrito['codpes'];
            $nompes_or = $inscrito['nompes'];
            // $this->logger->write("from: $from" );
            // $this->logger->write("to: $to" );
            // $this->logger->write("subject: $subject" );
            // $this->logger->write("codpes_or: $codpes_or" );
            // $this->logger->write("nompes_or: $nompes_or" );
            $envio = $this->criaEnviaMensagem($from, $to, $subject, $codpes_or, $nompes_or);
            if ($envio) {
                $trueCount++;
            } else {
                $falseCount++;
            }
        }
        $this->logger->write("Resumo do envio: Enviados: $trueCount, Não Enviados: $falseCount");
        return $falseCount > 0 ? false : true;
    }

    function criaEnviaMensagem($from, $to, $subject, $to_codpes, $to_nome)
    {
        $msg = '';
        $envio = false;
        $msg = "<p>Olá, Prof. $to_nome,</p>";
        $msg .= "<p>Dando início à organização do SIICUSP 2026, 
        solicitamos a identificação da(s) áreas(s) relacionadas à cada trabalho de IC que orienta. 
        Vide link(s) abaixo.</p>";
        $projetos = $this->retornaSiicuspCodema($to);

        foreach ($projetos as $proj) {
            $msg .= '<div style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
                        <h3>' . $proj['titulo'] . '</h3>
                        <strong>Projeto:</strong> cod.: ' . $proj['cod_proj'] . ' - ano: ' . $proj['ano_proj'] . '</br>
                        <strong>Aluno:</strong>' . $proj['aluno'] . '</br>
                        <strong>Palavra Chave:</strong> ' . $proj['palavra_ch'] . '</br>
                        <a href="https://docs.google.com/forms/d/e/1FAIpQLSeTJ7FRP3FsshRF0aBalKv_oZsLOGSQDTxEOoS9iwizwNOWYw/viewform?
                        usp=pp_url&entry.1932441618=' . $to . '&entry.1126384324=' . $to_codpes . '&entry.552510481=' .
                $to_nome . '&entry.115510845=' . $proj['codpes_alu'] . '&entry.12645399=' . $proj['aluno'] .
                '&entry.1048751209=' . $proj['cod_proj'] . '&entry.1895967995=' . $proj['titulo'] .
                '">Identificação da Área</a>
                        </br></br>
                    </div>';
        }
        $msg .= "<p>São apenas 3 questões de rápido preenchimento, cujo prazo vai até 25/05/2026.</p>";
        $msg .= "<p>Contamos com a sua pronta colaboração para o sucesso do evento.</p>";
        $msg .= "<p>Favor desconsiderar a mensagem anterior</p>";
        $msg .= "<p>Atenciosamente,</p>";
        $msg .= "<p>Serviço de Pesquisa</p>";
        $msg .= "<p>Assistência Técnica de Pesquisa, Cultura e Extensão</p>";
        $msg .= "<p>Escola Politécnica da USP</p>";
        $msg .= "<p>+55 11 3091-5788</p>";


        $current_identifier = $_SERVER['HTTP_HOST'] ?? gethostname();
        // $this->logger->write("url: $current_identifier ");
        if ($current_identifier == 'stsupro.poli.usp.br') {
            $this->logger->write("Mensagem da lista  $from para $to => $msg");
        } else {
            try {
                $envio = $this->enviaEmail($from, $to, $subject, $msg);
            } catch (Exception $e) {
                $this->logger->write("Erro ao enviar email para $to: " . $e->getMessage());
            }
        }

        return $envio;
    }
}
