<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Controller
{
    protected $f3;
    protected $db;
    protected $db_r;
    protected $args;
    protected $queryParams;
    protected $uri;
    protected $logger;


    function beforeroute($f3, $args)
    {
        $this->parseQuery($args[0]);
        $this->args = $args;

        //setlocale(LC_ALL, 'pt_BR.UTF8');
        //$data = new DateTime();

        setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf8', 'pt_BR.utf8', 'portuguese');
        date_default_timezone_set("America/Sao_Paulo");
        $agora = date("Y-m-d H:i:s");

        $this->logger = new \Log('logs/app-events.log');
        //$this->logger->write("");
        //$this->logger->write("####################### Controller $agora");

        $cache_em_minutos = 7200;
        $f3->set('cache_em_minutos', $cache_em_minutos);

        session_cache_expire($cache_em_minutos);
        $cache_expire = session_cache_expire();
        $f3->set('cache_expire', $cache_expire);
        $f3->set('agora', $agora);

        $production_identifiers = [
            'dev.poli.usp.br',
            'app.poli.usp.br',
        ];

        $current_identifier = $_SERVER['HTTP_HOST'];

        if (in_array($current_identifier, $production_identifiers)) {

            //COMEÇA AQUI AS MODIFICAÇÕES FEITAS PELO KAIQUE NA PARTE DE LOGIN
            if (array_key_exists("iPlanetDirectoryPro", $_COOKIE)) { //Verifica se o usurário esta logado
                $cookie = str_replace(' ', '+', $_COOKIE['iPlanetDirectoryPro']);
                $url = 'https://app.poli.usp.br/opensso/json/attributes?subjectid=' . $cookie;
                $response =  @file_get_contents($url);
                if ($response) { //Verifica se há resposta da usp em relação ao login
                    $opensso_json = json_decode($response);
                    $this->f3->set('codpes', (int)$opensso_json->codpes);
                    $this->f3->set('email', trim($opensso_json->codema));
                    $this->f3->set('nompes', trim($opensso_json->nompes));
                } else { // Direciona para logar 
                    header("Location: https://app.poli.usp.br/opensso/UI/Login?goto=http:$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
                    exit;
                }
            } else { // Direciona para logar
                header("Location: https://app.poli.usp.br/opensso/UI/Login?goto=http:$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
                exit;
            }
            //ACABA AQUI O TRECHO QUE O KAIQUE INCLUI PARA MODIFCAÇÃO DE LOGIN
        } else {
            // ambiente de desenvolvimento
            $this->f3->set('codpes', 3040414);
            $this->f3->set('email', 'rveira@usp.br');
            $this->f3->set('nompes', 'Ricardo Oliveira');

            // $this->f3->set('codpes', 7749575);
            // $this->f3->set('email', 'amanda.rabelo@usp.br');
            // $this->f3->set('nompes', 'Amanda Rabelo Santos Luiz ');
        }

        $codpes = $this->f3->get('codpes');
        $papel = $this->consultaPapelApp("hercules", $this->f3->get('codpes'));
        $f3->set('papel', $papel);
        $nome_usr = $this->f3->get('nompes');
        $this->f3->set('nome_usr', $nome_usr);

        $result_setor = $this->db_r->exec("SELECT nomabvset AS depto, tipvin FROM replicado.LOCALIZAPESSOA WHERE codpes = ?", $codpes);
        $depto = '';
        if ($result_setor) {
            if (trim($result_setor[0]['depto']) == null) {
                $depto = trim($result_setor[0]['tipvin']);
            } else {
                $depto = trim($result_setor[0]['depto']);
            }
        } else {
            $depto = 'Sem Vinculo';
        }
        $this->f3->set('depto', $depto);

        $data = new DateTime();
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::FULL,
            IntlDateFormatter::SHORT,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN
        );
        $data_completa = $formatter->format($data);
        $this->f3->set('data_completa', $data_completa);
    }


    function afterroute($f3, $args)
    {
        $this->args = $args;
        $agora = date_create(date("Y-m-d H:i:s"));
        $user_login_date = date_create($f3->get('ult_login'));
        $diff = date_diff($user_login_date, $agora);
        $dif_dia = intval($diff->format('%d'));
        $dif_hora = intval($diff->format('%h'));
        $dif_min = intval($diff->format('%i'));
        $seg = $diff->format('%s');
        $cache_expire = intval($f3->get('cache_expire'));
        $min_dia = $dif_dia > 0 ? ($dif_dia * 24) * 60 : 0;
        $min_tot_dia = $min_dia > 0 ? ($min_dia + $dif_min) * 60 : $dif_min * 60;
        $min_tot = $dif_hora > 0 ? ($dif_hora * 3600) + $min_tot_dia : $min_tot_dia;

        //$this->logger->write('afterroute Controller logado? ' . $f3->get('codpes'));
        //$this->logger->write('afterroute Controller papel?  ' . $f3->get('papel'));
        //$this->logger->write('host name:                    ' . $f3->get('host_name'));
        //$this->logger->write('hora que loguei:              ' . $user_login_date->format('d-m-Y H:i:s'));
        //$this->logger->write('agora:                        ' . $agora->format('d-m-Y H:i:s'));
        //$this->logger->write("dif:                          $dif_dia - $dif_hora:$dif_min:$seg");

        if (intval($min_tot) > $cache_expire) {
            //$this->logger->write("tempo [$min_tot] é maior que o limite [$cache_expire]");
            unset($_SESSION['codpes']);
            $this->f3->reroute('https://app.poli.usp.br/opensso/UI/Logout');
            exit();
        } else {
            //$this->logger->write('limite em segundos:           ' . $cache_expire);
            //$this->logger->write('segundos passados:            ' . $min_tot);
            //$this->logger->write("segundos restantes:           " . $f3->get('codpes') . " - " . ($cache_expire - $min_tot));
        }
    }


    function __construct()
    {
        $f3 = Base::instance();
        $this->f3 = $f3;
        // banco do sympa
        $db = new DB\SQL(
            $f3->get('db_dsn'),
            $f3->get('db_user'),
            $f3->get('db_pass'),
            array(
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, //exibe possíveis erros do mysql para a aplicação
                \PDO::ATTR_EMULATE_PREPARES => false, // performace
                \PDO::ATTR_STRINGIFY_FETCHES => false // mostra int como int não string
            )
        );
        if ($f3->DEBUG == 0) {
            $db->log(false);
        }
        $this->db = $db;

        // var_dump($db);

        // banco do replicado
        $db_r = new DB\SQL(
            $f3->get('db_dsn_r'),
            $f3->get('db_user_r'),
            $f3->get('db_pass_r'),
            array(
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, //exibe possíveis erros do mysql para a aplicação
                \PDO::ATTR_EMULATE_PREPARES => false, // performace
                \PDO::ATTR_STRINGIFY_FETCHES => false // mostra int como int não string
            )
        );
        if ($f3->DEBUG == 0) {
            $db_r->log(false);
        }
        $this->db_r = $db_r;
    }


    protected function parseQuery($uri)
    {
        $url_dns = 'http://localhost';
        $query = parse_url($url_dns . $uri, PHP_URL_QUERY);
        $this->queryParams = array();
        parse_str($query, $this->queryParams);
        foreach ($this->queryParams as $key => $value) {
            $this->queryParams[$key] = explode(',', $value);
        }
        $this->uri = parse_url($url_dns . $uri, PHP_URL_PATH);
    }

    public function retorna_periodo_hoje()
    {
        $periodo = 0;
        $per = 1;
        $ano = date("Y");
        $mes = date("m");
        if ($mes > 6) {
            $per = 2;
        }
        $periodo = $ano . $per;
        return $periodo;
    }


    public function retorna_lista_pareceres()
    {
        $parecer_arr = array(
            'AG' => "Aguardando",
            'AQ' => "Arquivado",
            'DF' => "Deferido",
            'DV' => "Desfavorável",
            'FV' => "Favorável",
            'IN' => "Indeferido",
            'NH' => "Não Há",
            'PC' => "Parcial",
        );

        return $parecer_arr;
    }

    public function descricaoMes($mes)
    {
        $nomeMes = "Janeiro";

        switch ($mes) {
            case 1:
                $nomeMes = "Janeiro";
                break;
            case 2:
                $nomeMes = "Fevereiro";
                break;
            case 3:
                $nomeMes = "Março";
                break;
            case 4:
                $nomeMes = "Abril";
                break;
            case 5:
                $nomeMes = "Maio";
                break;
            case 6:
                $nomeMes = "Junho";
                break;
            case 7:
                $nomeMes = "Julho";
                break;
            case 8:
                $nomeMes = "Agosto";
                break;
            case 9:
                $nomeMes = "Setembro";
                break;
            case 10:
                $nomeMes = "Outubro";
                break;
            case 11:
                $nomeMes = "Novembro";
                break;
            case 12:
                $nomeMes = "Dezembro";
                break;
            default:
                $nomeMes = "Janeiro";
        }
        return $nomeMes;
    }

    public function data_em_string($data_s)
    {
        $data = strtotime($data_s);
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::MEDIUM,
            IntlDateFormatter::NONE,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN,
            "dd/MMM/YYYY"
        );
        $agora_str = $formatter->format($data);
        return $agora_str;
    }

    // public function consultaPapelApp($aplicacao = 'hercules', $codpes = 0)
    // {
    //     $papel = 'usr';

    //     // papel direto

    //     $sql = "SELECT PA.nome AS papel FROM helios.APLICACAO AP
    //     JOIN helios.AUTORIZACAO AU ON (AP.id = AU.aplicacao_id)
    //     JOIN helios.MEMBRO ME ON (ME.grupo_id = AU.grupo_id)
    //     JOIN helios.PAPEL PA ON (PA.aplicacao_id = AP.id
    //     AND AU.papel_id = PA.id)
    //     WHERE AP.nome = ? AND ME.codlog = ?";
    //     $papel_app = $this->db_r->exec($sql, array($aplicacao, $codpes));

    //     //$this->logger->write("papel_app: " . $papel_app[0]['papel']);
    //     // papel por locação
    //     if (empty($papel_app)) {
    //         $sql_loc = "SELECT DISTINCT AP.nome   AS app,
    //         PP.nome   AS papel, G.nome    AS grupo, L.nomabvset,
    //         P.nompes  AS nome, P.codpes  AS codlog
    //         FROM helios.LOTACAO L JOIN helios.GRUPO G 
    //         ON (G.id = L.grupo_id)
    //         JOIN replicado.LOCALIZAPESSOA P ON (L.codset = P.codset)
    //         JOIN helios.AUTORIZACAO A ON (A.grupo_id = G.id)
    //         JOIN helios.APLICACAO AP ON (A.aplicacao_id = AP.id)
    //         JOIN helios.PAPEL PP ON (A.papel_id = PP.id)
    //         WHERE AP.nome = ? AND P.codpes = ?";
    //         $locacao = $this->db_r->exec($sql_loc, array($aplicacao, $codpes));

    //         //$this->logger->write("locacao: " . $locacao[0]['papel']);
    //         // papel por vinculo
    //         if (empty($locacao)) {
    //             $sql_vin = "SELECT AP.nome AS app,
    //             PP.nome   AS papel, G.nome AS grupo,
    //             V.tipvin  AS vin, P.nompes  AS nome,
    //             P.codpes  AS codlog
    //             FROM helios.VINCULO V JOIN helios.GRUPO G 
    //             ON (G.id = V.grupo_id)
    //             JOIN replicado.LOCALIZAPESSOA P
    //             ON (V.tipvin = P.tipvin)
    //             JOIN helios.AUTORIZACAO A ON (A.grupo_id = G.id)
    //             JOIN helios.APLICACAO AP ON (A.aplicacao_id = AP.id)
    //             JOIN helios.PAPEL PP ON (A.papel_id = PP.id)
    //             WHERE AP.nome = ? AND P.codpes = ?";
    //             $vinculo = $this->db_r->exec($sql_vin, array($aplicacao, $codpes));

    //             //$this->logger->write("vinculo: " . $vinculo[0]['papel']);

    //             if (!empty($vinculo)) {
    //                 $papel = $vinculo[0]['papel'];
    //             }
    //         } else {
    //             $papel = $locacao[0]['papel'];
    //         }
    //     } else {
    //         $papel = $papel_app[0]['papel'];
    //     }
    //     if ($papel == 'usr') {
    //         $gerentes = $this->retornaArrayListasGerenciaCodpes($codpes);
    //         //$array_ger = array_column($gerentes, 'list_admin');
    //         //$this->logger->write("$codpes é gerente das listas: " . json_encode($gerentes) . " no papel OPR");

    //         if (!empty($gerentes)) {
    //             $papel = 'opr';
    //             //$this->logger->write("gerente");
    //         }
    //     }

    //     return $papel;
    // }

    public function consultaPapelApp($aplicacao = 'hercules', $codpes = 0)
    {
        $sql = "
        SELECT papel
        FROM (
            -- Papel direto
            SELECT PA.nome AS papel,
            CASE PA.nome
                WHEN 'adm' THEN 1
                WHEN 'opr' THEN 2
                WHEN 'avl' THEN 3
                WHEN 'usr' THEN 4
                ELSE 99
            END AS prioridade
            FROM helios.APLICACAO AP
            JOIN helios.AUTORIZACAO AU ON AP.id = AU.aplicacao_id
            JOIN helios.MEMBRO ME ON ME.grupo_id = AU.grupo_id
            JOIN helios.PAPEL PA ON PA.aplicacao_id = AP.id
            AND AU.papel_id = PA.id
            WHERE AP.nome = ? AND ME.codlog = ?

            UNION

            -- Papel por lotação
            SELECT PP.nome AS papel,
            CASE PP.nome
                WHEN 'adm' THEN 1
                WHEN 'opr' THEN 2
                WHEN 'avl' THEN 3
                WHEN 'usr' THEN 4
                ELSE 99
            END AS prioridade
            FROM helios.LOTACAO L
            JOIN helios.GRUPO G ON G.id = L.grupo_id
            JOIN replicado.LOCALIZAPESSOA P ON L.codset = P.codset
            JOIN helios.AUTORIZACAO A ON A.grupo_id = G.id
            JOIN helios.APLICACAO AP ON A.aplicacao_id = AP.id
            JOIN helios.PAPEL PP ON A.papel_id = PP.id
            WHERE AP.nome = ? AND P.codpes = ?

            UNION

            -- Papel por vínculo
            SELECT PP.nome AS papel,
            CASE PP.nome
                WHEN 'adm' THEN 1
                WHEN 'opr' THEN 2
                WHEN 'avl' THEN 3
                WHEN 'usr' THEN 4
                ELSE 99
            END AS prioridade
            FROM helios.VINCULO V
            JOIN helios.GRUPO G ON G.id = V.grupo_id
            JOIN replicado.LOCALIZAPESSOA P ON V.tipvin = P.tipvin
            JOIN helios.AUTORIZACAO A ON A.grupo_id = G.id
            JOIN helios.APLICACAO AP ON A.aplicacao_id = AP.id
            JOIN helios.PAPEL PP ON A.papel_id = PP.id
            WHERE AP.nome = ? AND P.codpes = ?
        ) AS todos
        ORDER BY prioridade
        LIMIT 1;";

        // Executa a query passando os parâmetros para cada SELECT
        $result = $this->db_r->exec($sql, array(
            $aplicacao,
            $codpes,   // para papel direto
            $aplicacao,
            $codpes,   // para lotação
            $aplicacao,
            $codpes    // para vínculo
        ));

        $papel = !empty($result) ? $result[0]['papel'] : 'usr';

        // Regra extra: se for 'usr' mas é gerente, vira 'opr'
        if ($papel === 'usr') {
            $gerentes = $this->retornaArrayListasGerenciaCodpes($codpes);
            if (!empty($gerentes)) {
                $papel = 'opr';
            }
        }
        return $papel;
    }


    function imprimePost()
    {
        foreach ($_POST as $key => $value) {
            $this->logger->write("POST: '$key' => '$value'");
        }
    }

    function imprimeGet()
    {
        foreach ($_GET as $key => $value) {
            $this->logger->write("GET: '$key' => '$value'");
        }
    }

    function objToJson($obj)
    {
        $obj_keys = array();
        $obj_values = array();
        $obj_combine[] = array();

        //$this->logger->write("tamanho obj: ".sizeof($obj));

        for ($i = 0; $i < count($obj); $i++) {
            //$this->logger->write("registro [$i]: ".json_encode($obj[$i]));
            foreach ($obj[$i] as $key => $val) {
                array_push($obj_keys, $key);
                array_push($obj_values, $val);
                // $this->logger->write("key[$i]: $key => val: $val");
            }
            try {
                $obj_combine[$i] = array_combine($obj_keys, $obj_values);
            } catch (Exception $e) {
                $this->logger->write("Erro na função : array_combine - $e");
            }
        }

        $obj_jsonfy = json_encode($obj_combine);

        return $obj_jsonfy;
    }


    function formataTexto($texto)
    {
        $retorna = str_replace(",", " ", $texto);
        $retorna = $this->remove_accents($retorna);
        return trim(strtolower($retorna));
    }

    function remove_accents($text)
    {
        $trans = array(
            'À' => 'A',
            'Á' => 'A',
            'Â' => 'A',
            'Ã' => 'A',
            'Ä' => 'A',
            'Å' => 'A',
            'Ç' => 'C',
            'È' => 'E',
            'É' => 'E',
            'Ê' => 'E',
            'Ë' => 'E',
            'Ì' => 'I',
            'Í' => 'I',
            'Î' => 'I',
            'Ï' => 'I',
            'Ò' => 'O',
            'Ó' => 'O',
            'Ô' => 'O',
            'Õ' => 'O',
            'Ö' => 'O',
            'Ø' => 'O',
            'Ù' => 'U',
            'Ú' => 'U',
            'Û' => 'U',
            'Ü' => 'U',
            'à' => 'a',
            'á' => 'a',
            'â' => 'a',
            'ã' => 'a',
            'ä' => 'a',
            'å' => 'a',
            'ç' => 'c',
            'è' => 'e',
            'é' => 'e',
            'ê' => 'e',
            'ë' => 'e',
            'ì' => 'i',
            'í' => 'i',
            'î' => 'i',
            'ï' => 'i',
            'ò' => 'o',
            'ó' => 'o',
            'ô' => 'o',
            'õ' => 'o',
            'ö' => 'o',
            'ù' => 'u',
            'ú' => 'u',
            'û' => 'u',
            'ü' => 'u',
            'Ā' => 'A',
            'ā' => 'a',
            'Ă' => 'A',
            'ă' => 'a',
            'Ą' => 'A',
            'ą' => 'a',
            'Ē' => 'E',
            'ē' => 'e',
            'Ĕ' => 'E',
            'ĕ' => 'e',
            'Ė' => 'E',
            'ė' => 'e',
            'Ę' => 'E',
            'ę' => 'e',
            'Ě' => 'E',
            'ě' => 'e',
            'Ĩ' => 'I',
            'ĩ' => 'i',
            'Ī' => 'I',
            'ī' => 'i',
            'Ĭ' => 'I',
            'ĭ' => 'i',
            'Į' => 'I',
            'į' => 'i',
            'İ' => 'I',
            'Ō' => 'O',
            'ō' => 'o',
            'Ŏ' => 'O',
            'ŏ' => 'o',
            'Ő' => 'O',
            'ő' => 'o',
            'Ũ' => 'U',
            'ũ' => 'u',
            'Ū' => 'U',
            'ū' => 'u',
            'Ŭ' => 'U',
            'ŭ' => 'u',
            'Ů' => 'U',
            'ů' => 'u',
            'Ű' => 'U',
            'ű' => 'u',
            'Ų' => 'U',
            'ų' => 'u',
        );
        return strtr($text, $trans);
    }

    function retornaListasPorCodpes($codpes)
    {
        $sql = "SELECT DISTINCT L.name_list 
        FROM sympa.list_table L 
        JOIN sympa.role_table R ON (R.list_admin=L.name_list)
        WHERE L.status_list='open' AND R.codpes=? ORDER BY L.name_list";

        $result = $this->db->exec($sql, array($codpes));

        return $result;
    }

    function retornaListasPorCodema($codema)
    {
        $result = null;
        $sql = "SELECT L.name_list, L.owners_list, R.codpes, R.nompes, R.user_admin, R.role_admin FROM sympa.list_table L 
        JOIN sympa.role_table R ON (R.list_admin=L.name_list)
        WHERE L.status_list='open' AND R.user_admin=? ORDER BY L.name_list";

        try {
            $result = $this->db->exec($sql, array($codema));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }

        return $result;
    }

    function retornaListasAtivas()
    {
        $result = null;
        $sql = "SELECT name_list FROM sympa.list_table WHERE status_list='open' ORDER BY name_list";

        try {
            $result = $this->db->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    public function enviaEmail($from, $to, $subject, $mensagem)
    {
        // o from e o to são arrays com o email e o nome do remetente e destinatário, 
        // respectivamente: $from[0] = email, $from[1] = nome $to[0] = email, $to[1] = nome
        $header = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
        'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
        $header .= "<html lang='pt-br' dir='ltr'>";
        $header .= "<head><meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
        $header .= "<style> body { font-family: Arial, sans-serif; font-size: 14px; color: #333; } </style></head>";
        $envio = 0;
        try {
            $envio = $this->enviaEmail_PHPMailer($from, $to, $subject, $mensagem, $header);
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
        }
        //$this->logger->write("Email enviado? '" . $envio . "'");
        return $envio;
    }

    function papel_lista_usuario($codpes, $lista)
    {

        $sql = "SELECT role_admin FROM sympa.role_table
        WHERE codpes=? AND list_admin=? ORDER BY role_admin DESC";

        $result = $this->db->exec($sql, array($codpes, $lista));

        // $this->logger->write("codpes: $codpes");
        // $this->logger->write("lista: $lista");
        // $this->logger->write("sql: $sql");

        return $result;
    }

    function gerentes_listas()
    {
        // somente os proprietários das listas ativas, para evitar que a consulta traga muitos registros e sobrecarregue a aplicação
        $sql = "SELECT R.list_admin, R.user_admin, R.codpes, R.nompes, R.update_admin 
        FROM sympa.role_table R
        JOIN sympa.list_table L ON (R.list_admin=L.name_list) 
        WHERE R.role_admin='owner' AND L.status_list='open' ORDER BY L.name_list, R.user_admin";

        $result = $this->db->exec($sql);

        //$this->logger->write("sql: $sql");

        return $result;
    }

    function retorna_gerentes_lista($lista)
    {
        $result = null;
        $sql = "SELECT * FROM sympa.role_table
        WHERE list_admin=? ORDER BY role_admin DESC";

        try {
            $result = $this->db->exec($sql, array($lista));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    public function retorna_pessoa_por_codpes($codpes)
    {

        $sql = "SELECT L.nompes, L.codema, L.codpes, L.nomabvset AS setor, L.tipvinext
                FROM replicado.LOCALIZAPESSOA L
                WHERE L.codundclg=3 AND L.sitatl='A' AND L.nomabvset IS NOT NULL
                AND L.codema IS NOT NULL AND L.codpes=?";

        $result = $this->db_r->exec($sql, $codpes);

        return $result;
    }

    public function retorna_pessoa_por_email($codema)
    {

        $sql = "SELECT P.codpes, P.nompes, E.codema, P.tipfnc as setor, P.tipvin as tipvinext
        FROM replicado.EMAILPESSOA E 
        JOIN replicado.VINCULOPESSOAUSP P ON (P.codpes=E.codpes)
        WHERE E.codema =?";

        $result = $this->db_r->exec($sql, $codema);

        return $result;
    }

    public function retorna_lst_pessoas($nome)
    {
        $trecho = "%$nome%";
        $trecho = str_replace(' ', '%', $trecho); // para incluir '%' entre espaços vazios

        $sql = "SELECT L.nompes, L.codema, L.codpes, L.nomabvset AS setor, L.tipvinext
                FROM replicado.LOCALIZAPESSOA L
                WHERE L.codundclg=3 AND L.sitatl='A' AND L.tipvinext<>'Servidor Designado'
                AND L.codema IS NOT NULL AND L.nompes like ? ORDER BY L.nompes LIMIT 50";

        //$this->logger->write("sql: $sql");
        $result = $this->db_r->exec($sql, $trecho);

        return $result;
    }

    function retornaArrayListasGerenciaCodpes($codpes)
    {
        $result = null;
        $array_agr = array();
        // $sql = "SELECT DISTINCT A.list_admin, A.role_admin FROM sympa.admin_table A WHERE A.codpes = ?
        // UNION SELECT DISTINCT R.list_admin, R.role_admin FROM sympa.role_table R WHERE R.codpes = ?";
        $sql = "SELECT DISTINCT L.name_list, R.role_admin 
        FROM sympa.list_table L 
        JOIN sympa.role_table R ON (R.list_admin=L.name_list)
        WHERE L.status_list='open' AND R.codpes=? ORDER BY L.name_list, R.role_admin desc";
        try {
            $result = $this->db->exec($sql, array($codpes));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        if ($result)
            foreach ($result as $row) {
                $array_agr[$row['name_list']][] = $row['role_admin'] == 'owner' ?
                    'proprietário' : 'publicador';
            }
        // $this->logger->write("array_agr:" . json_encode($array_agr));
        // $this->logger->write("array_agr[dev]:" . json_encode($array_agr['dev']));
        return $array_agr;
    }

    function retornaInscritosLista($lista, $pagina = 1, $total_reg = 10)
    {
        $entity = array();
        $pc = "1";
        #Se a página não for especificada a variável "pagina" tomará o valor 1, isso evita de exibir a página 0 de início
        if ($pagina > 1)
            $pc = $pagina;
        #Vamos determinar o valor inicial das buscas limitadas:
        $inicio = $pc - 1;
        $inicio = $inicio * $total_reg;
        #Vamos selecionar os dados e exibir a paginação:

        // $this->logger->write("");
        // $this->logger->write("retornaInscritosLista pagina: $pagina");
        // $this->logger->write("retornaInscritosLista pc: $pc");
        // $this->logger->write("retornaInscritosLista inicio: $inicio");
        // $this->logger->write("retornaInscritosLista total_reg: $total_reg");

        $sql_limite = "SELECT * FROM sympa.subscriber_table WHERE list_subscriber=? ORDER BY nompes, user_subscriber LIMIT $inicio, $total_reg";
        $sql = "SELECT * FROM sympa.subscriber_table WHERE list_subscriber=?";
        $todos = $this->db->exec($sql,  $lista);

        $tr = count($todos); // verifica o número total de registros
        $tp = $tr / $total_reg; // verifica o número total de páginas

        $entity = $this->db->exec($sql_limite, $lista);

        $anterior = $pc - 1;
        $proximo = $pc + 1;

        return array($entity, $anterior, $proximo, $pc, $tp, $tr, $inicio);
    }

    function existeInscritoLista($lista, $codema)
    {
        $result = array();
        $sql = "SELECT * FROM sympa.subscriber_table WHERE list_subscriber=?
        AND user_subscriber=?";
        try {
            $result = $this->db->exec($sql, array($lista, trim($codema)));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function listasUtilizadasHoje()
    {
        $result = array();
        $hoje = date('Y-m-d', strtotime('today'));
        $timestamp = strtotime($hoje);
        // $timestamp = 1691849106; // 02/11/2023, 13:05:05

        $sql = "SELECT action_logs, list_logs AS lista, error_type_logs AS erros, 
        status_logs AS estado, target_email_logs, 
        if(user_email_logs='anonymous', '-', user_email_logs) AS remetente, count(user_email_logs) AS tot
        FROM sympa.logs_table WHERE (action_logs = 'DoMessage' OR action_logs = 'get_bounce') 
        AND error_type_logs<>'rejected_authorization' AND date_logs >= ?
        GROUP BY action_logs, lista, erros, estado, target_email_logs, remetente ORDER BY lista, action_logs";

        //$this->logger->write("sql: $sql");

        try {
            $result = $this->db->exec($sql, $timestamp);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        //var_dump($this->db->log());
        return $result;
    }

    function logEnvioListaSucesso($lista, $ano = 0, $mes = 0)
    {
        $result = array();
        //$hoje = date('Y-m-d', strtotime('today'));
        // $timestamp = strtotime($hoje);
        // $timestamp = 1698941105; // 02/11/2023, 13:05:05
        $ano = $ano == 0 ? date('Y') : $ano;
        $mes = $mes == 0 ? date('m') : $mes;

        $sql = "SELECT if(action_logs='get_bounce', 'rejeitado', 'ok') AS log_envio, 
        from_unixtime(date_logs) AS dtaocor, list_logs AS lista, error_type_logs AS erros, 
        status_logs AS estado, target_email_logs, 
        if(user_email_logs='anonymous', '-', user_email_logs) AS remetente
        FROM sympa.logs_table WHERE action_logs = 'DoMessage'
        AND error_type_logs<>'rejected_authorization' AND status_logs='success' AND list_logs = ?
        AND year(from_unixtime(date_logs))=? AND month(from_unixtime(date_logs))=?";

        // $this->logger->write("sql: $sql");
        // $this->logger->write("lista: $lista, ano: $ano, mes: $mes");

        try {
            $result = $this->db->exec($sql, array($lista, $ano, $mes));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    function logUltimoEnvio($lista)
    {
        $result = array();

        $sql = "SELECT if(action_logs='get_bounce', 'rejeitado', 'ok') AS log_envio, 
        max(from_unixtime(date_logs)) AS dtaocor, list_logs AS lista, '-' AS erros
        , '-' AS estado, '-' AS target_email_logs, '*ÚLTIMO ENVIO*' AS remetente 
        FROM sympa.logs_table WHERE action_logs = 'DoMessage'
        AND error_type_logs<>'rejected_authorization' AND status_logs='success' AND list_logs = ?";
        // $this->logger->write("sql: $sql");
        try {
            $result = $this->db->exec($sql, array($lista));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        if (is_null($result[0]['dtaocor']))
            $result = array();

        return $result;
    }

    function logEnvioListaErro($lista, $ano = 0, $mes = 0, $pagina = 1, $total_reg = 10)
    {
        $entity = array();
        //$hoje = date('Y-m-d', strtotime('today'));
        // $timestamp = strtotime($hoje);
        // $timestamp = 1698941105; // 02/11/2023, 13:05:05
        $ano = $ano == 0 ? date('Y') : $ano;
        $mes = $mes == 0 ? date('m') : $mes;

        #Se a página não for especificada a variável "pagina" tomará o valor 1, isso evita de exibir a página 0 de início
        //if ($pagina > 1)
        $pc = $pagina;
        #Vamos determinar o valor inicial das buscas limitadas:
        $inicio = $pc - 1;
        $inicio = $inicio * $total_reg;
        #Vamos selecionar os dados e exibir a paginação:

        $sql_limite = "SELECT if(action_logs='get_bounce', 'rejeitado pelo destinatário', '-') AS log_envio,
        from_unixtime(date_logs) AS dtaocor, list_logs AS lista, 
        if(error_type_logs='rejected_authorization', 'Não autorizado', error_type_logs) AS erros, 
        status_logs AS estado, target_email_logs, 
        if(user_email_logs='anonymous', '-', user_email_logs) AS remetente
        FROM sympa.logs_table WHERE status_logs='error' AND list_logs = ?
        AND year(from_unixtime(date_logs))=? AND month(from_unixtime(date_logs))=? 
        ORDER BY date_logs DESC LIMIT $inicio, $total_reg";

        $sql = "SELECT if(action_logs='get_bounce', 'rejeitado pelo destinatário', '-') AS log_envio,
        from_unixtime(date_logs) AS dtaocor, list_logs AS lista, 
        if(error_type_logs='rejected_authorization', 'Não autorizado', error_type_logs) AS erros, 
        status_logs AS estado, target_email_logs, 
        if(user_email_logs='anonymous', '-', user_email_logs) AS remetente
        FROM sympa.logs_table WHERE status_logs='error' AND list_logs = ?
        AND year(from_unixtime(date_logs))=? AND month(from_unixtime(date_logs))=?";

        //$this->logger->write("sql: $sql");
        $todos = $this->db->exec($sql,  array($lista, $ano, $mes));

        $tr = count($todos); // verifica o número total de registros
        $tp = $tr / $total_reg; // verifica o número total de páginas
        // $this->logger->write("sql_limite: $sql_limite");
        if ($tr > 0)
            $entity = $this->db->exec($sql_limite, array($lista, $ano, $mes));

        $anterior = $pc - 1;
        $proximo = $pc + 1;

        return array($entity, $anterior, $proximo, $pc, $tp, $tr, $inicio);
    }

    function listasInscrito()
    {
        $result = array();
        $codema = $this->f3->get('email');
        $lst_inscrito = array();
        $owner = array();
        // $this->logger->write("codema: $codema");
        // $codema = 'rveira@usp.br';
        $sql = "SELECT DISTINCT S.list_subscriber, R.user_admin, R.nompes FROM sympa.subscriber_table S
        JOIN sympa.role_table R ON (R.list_admin=S.list_subscriber)
        WHERE S.user_subscriber=? AND R.role_admin = 'owner'
        ORDER BY S.list_subscriber, R.user_admin";

        try {
            $result = $this->db->exec($sql, $codema);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        if ($result) {
            foreach ($result as $res) {
                $owner = array($res['user_admin'], trim($res['nompes']));
                $lst_inscrito[$res['list_subscriber']][] = $owner;
            }
        }


        return $lst_inscrito;
    }

    function enviosRejeitados()
    {
        $result = array();
        $hoje = date('Y-m-d', strtotime('today'));
        $timestamp = strtotime($hoje);
        //$timestamp = 1698941105; // 02/11/2023, 13:05:05

        // função mysql para retornar detetime de timestamp
        //from_unixtime()

        $sql = "SELECT list_logs, user_email_logs, from_unixtime(date_logs) AS dtaocor
        FROM sympa.logs_table WHERE action_logs = 'DoMessage'
        AND error_type_logs='rejected_authorization' AND date_logs >= ? ";

        //$this->logger->write("sql: $sql");

        try {
            $result = $this->db->exec($sql, $timestamp);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        //var_dump($this->db->log());
        return $result;
    }


    function minhasInscricoes($codema)
    {
        $result = array();
        $sql = "SELECT S.comment_subscriber, S.date_subscriber, 
        S.include_sources_subscriber, S.included_subscriber, 
        S.list_subscriber, S.subscribed_subscriber, S.suspend_end_date_subscriber, 
        S.suspend_start_date_subscriber, S.suspend_subscriber,
        S.update_subscriber, S.user_subscriber,  S.codpes, S.nompes, S.codpesalt 
        FROM sympa.subscriber_table S
        JOIN sympa.list_table L ON (L.name_list=S.list_subscriber) 
        WHERE S.user_subscriber = ? AND L.status_list='open' 
        ORDER BY L.name_list";
        try {
            $result = $this->db->exec($sql, array(trim($codema)));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    function criaMensagemParaEnvio($from, $to)
    {
        // $from é um array com o email e o nome do remetente, respectivamente: $from[0] = email, $from[1] = nome
        $subject = 'Notificação de inclusão em lista';
        $msg = '';
        $envio = false;
        $msg = "<p>Prezado $to[1],</p>";
        $msg .= "<p>Seu e-mail ($to[0]) foi incluso na lista de distribuição '" . $from[1] . "'.</p>";
        $msg .= "<p>Por favor inclua este endereço de e-mail (" . $from[0] . ") na sua lista de contatos para evitar que novas mensagens caiam na pasta de mensegem rejeitadas (spam).</p>";
        $msg .= "<p>Cordialmente,</p>";
        $msg .= "<p>" . $this->f3->get('nompes') . "<br>" . $this->f3->get('email') . "</p>";
        $envio = $this->enviaEmail($from, $to, $subject, $msg);

        $this->logger->write("Mensagem da lista '" . $from[1] . "' para " . $to[0] . " : " . $envio == true ? "Enviado" : "NÃO Enviado");

        return $envio;
    }

    function enviaEmail_PHPMailer($from, $to, $subject, $message, $header = '')
    {
        // o from é um array com o email e o nome do remetente, respectivamente: $from[0] = email, $from[1] = nome
        $erro = '';
        $success = false;
        // Crie uma nova instância do PHPMailer
        $mail = new PHPMailer;
        // Configure AS opções do SMTP
        $mail->isSMTP();
        $mail->CharSet = "UTF-8";                          //encoding para caracteres especiais
        $mail->Host       = "adproxy";  //Set the SMTP server to send through
        $mail->Username   = "";         //SMTP username
        $mail->Password   = "";         //SMTP password 
        $mail->SMTPAuth   = false;      //Enable SMTP authentication
        $mail->SMTPAutoTLS = false;
        $mail->SMTPSecure = false;      //$mail->SMTPSecure = 'tls';
        $mail->Port       = 25;  //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

        // Defina os detalhes do email
        // $mail->AltBody = 'Conteúdo do seu email em texto simples';
        // $mail->addAttachment('/caminho/para/anexo/arquivo.pdf');
        $mail->setFrom($from[0], $from[1]);
        $mail->addAddress($to[0], $to[1]);
        // responder para o remetente do email, caso seja uma lista de distribuição da Poli, 
        // responder para o email institucional do remetente da mensagem, caso contrário, 
        // responder para o email do remetente da mensagem
        if (strpos($from[0], '@listas.poli.usp.br')) {
            $mail->addReplyTo($this->f3->get('email'), $this->f3->get('nompes'));
        } else {
            $mail->addReplyTo($from[0], $from[1]);
            // if ($to != 'ricardo.leandro@usp.br')
            //     $mail->addBCC($from[0]); // enviar copia oculta
        }
        // Embute a imagem no e-mail
        $root = dirname(__DIR__, 2); // sobe 2 níveis: controllers -> app -> raiz
        $logo_path = $root . "/app/static/images/malingpoli.png";
        $mail->addEmbeddedImage($logo_path, "logo_cid");

        $body = "<body>
        <div style='text-align:center;border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>
        <a href='http://www.poli.usp.br' target='_blank'>
            <img src='cid:logo_cid' alt='Logo Poli USP'></a>
            </div><br>";

        $mensagem = $header . $body . $message . "<br></body></html>";

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body = $mensagem;
        // opcional para incluir uma versão em texto simples do email,
        // caso o cliente de email do destinatário não suporte HTML
        $mail->AltBody = strip_tags($message);

        // $mail->msgHTML($message); sobscreve a mensagem do corpo do email, por isso, não é utilizado para manter o header e o body formatados
        // Envie o email
        try {
            $success = $mail->send();
        } catch (Exception $e) {
            $erro = $e;
        }

        if (!$success)
            $this->logger->write("Erro no envio do email: " . $to[0] . " - " . $mail->ErrorInfo);
        $envio = $success == true ? "De " . $from[0] . ", enviado para " . $to[0] . " com sucesso!" : "Não enviado para " . $to[0];
        $this->logger->write("envio: [$envio] / $erro");

        return $success;
    }

    function retornaResultadoPesquisaInscrito($lista, $termo)
    {
        $result = array();
        $sql = "SELECT * FROM sympa.subscriber_table WHERE list_subscriber = ?
        AND CONCAT_WS(',', user_subscriber, codpes, nompes) like CONCAT('%', ?, '%')";
        try {
            $result = $this->db->exec($sql, array($lista, trim($termo)));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function retornaQueryLista($lista)
    {
        $result = array();
        $sql = "SELECT * FROM sympa.lists_and_sources WHERE list_subscriber = ?";
        try {
            $result = $this->db->exec($sql, array($lista));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function retornaSiicusp()
    {
        $result = array();
        $sql = "SELECT distinct codpes_or AS codpes, orientador AS nompes, codema_or AS codema
        FROM sympa.projetos_siicusp_2026 ORDER BY orientador";
        try {
            $result = $this->db->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    function retornaSiicuspCodpes($codpes)
    {
        $result = array();
        $sql = "SELECT * FROM sympa.projetos_siicusp_2026
        WHERE codpes_or = ? ORDER BY aluno";
        try {
            $result = $this->db->exec($sql, array($codpes));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function retornaSiicuspCodema($codema)
    {
        $result = array();
        $sql = "SELECT * FROM sympa.projetos_siicusp_2026
        WHERE codema_or = ? ORDER BY aluno";
        try {
            $result = $this->db->exec($sql, array($codema));
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    function retornaListasDesatualizadas($dias = 15)
    {
        // Lista nome da lista da ultima atualização inscritos anterior a X dias
        $result = array();
        $sql = "SELECT list_subscriber, MAX(update_subscriber) AS upd FROM sympa.subscriber_table
        WHERE DATE_SUB(CURDATE(),INTERVAL ? DAY) >= update_subscriber GROUP BY list_subscriber;";
        try {
            $result = $this->db->exec($sql, $dias);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }


    function retornaQueriesListas()
    {
        $result = array();
        $sql = "SELECT * FROM sympa.lists_and_sources ORDER BY list_subscriber";
        try {
            $result = $this->db->exec($sql);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function retornaAtualizacaoInscrito($lista)
    {
        // Lista nome da lista da ultima atualização inscritos anterior a X dias
        $result = array();
        $sql = "SELECT MIN(update_subscriber) AS upd FROM sympa.subscriber_table
        WHERE list_subscriber =  ?";
        try {
            $result = $this->db->exec($sql, $lista);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        return $result;
    }

    function retornaDataUltimoInscrito($lista)
    {
        // Lista nome da lista da ultima atualização inscritos anterior a X dias
        $res = null;
        $result = array();
        $sql = "SELECT max(update_subscriber) AS ultimo FROM sympa.subscriber_table WHERE list_subscriber=?";
        try {
            $result = $this->db->exec($sql, $lista);
        } catch (Exception $e) {
            $this->logger->write("Erro conexão sympa: $e");
        }
        if ($result)
            $res = $result[0]['ultimo'];

        // $this->logger->write("reposta : $lista - $res");
        return $res;
    }

    function atualizarInscritos($lista, $query)
    {
        // $this->logger->write("Lista : $lista");
        // $this->logger->write("Query : $query");
        $result = array();
        $cont = 0;

        $custom_attribute_subscriber = '<?xml version="1.0" encoding="UTF-8" ?><custom_attributes></custom_attributes>';
        $agora = date("Y-m-d H:i:s");
        $codpesalt = $this->f3->get('codpes');
        $sql_rep = "SELECT DISTINCT L.codpes, L.nompes, L.codema FROM $query";
        $select_rep =  $this->db_r->exec($sql_rep);
        // $this->logger->write("sql_rep: $sql_rep");
        // $this->logger->write("total para inserir: " . count($select_rep));
        if ($select_rep) {
            try {
                $this->db->exec("DELETE FROM sympa.subscriber_table WHERE list_subscriber = ?", array($lista));
                // $this->logger->write("apagando membros da lista : $lista");
                foreach ($select_rep as $rep) {
                    $codema = $rep['codema'];
                    $codpes = $rep['codpes'];
                    $nompes = $rep['nompes'];
                    // $this->logger->write("dados -> $codema, $codpes, $nompes");
                    $sql = "INSERT INTO sympa.subscriber_table
                    (bounce_address_subscriber, bounce_score_subscriber, bounce_subscriber,
                    comment_subscriber, custom_attribute_subscriber, date_subscriber,
                    include_sources_subscriber, included_subscriber, list_subscriber,
                    reception_subscriber, robot_subscriber, subscribed_subscriber,
                    suspend_end_date_subscriber, suspend_start_date_subscriber,
                    suspend_subscriber, topics_subscriber, update_subscriber,
                    user_subscriber, visibility_subscriber, codpes, nompes, codpesalt)
                    VALUES (NULL, NULL, NULL, NULL, ?, ?, '', 1, ?, 'mail', 'listas.poli.usp.br',
                    1, NULL, NULL, NULL, NULL, ?, ?, 'noconceal', $codpes, ?, $codpesalt)";
                    try {
                        $result = $this->db->exec($sql, array($custom_attribute_subscriber, $agora, $lista, $agora, $codema, $nompes));
                        $cont++;
                        //$result = $this->db->exec($sql);
                    } catch (Exception $e) {
                        $this->logger->write("Erro ao tentar atualizar [$lista] query: [$sql_rep] - $e");
                        break;
                    }
                }
            } catch (Exception $e) {
                $this->logger->write("Erro não foi possível deletar $lista (subscriber_table): $e");
            }
        } else {
            $this->logger->write("$lista - Não gerou registos: [$sql_rep]");
        }
        $this->logger->write("$lista atualizada: $cont inscritos");

        return $result;
    }

    function atualizarInscritosSiicusp($lista, $siicusp)
    {
        // $this->logger->write("Lista : $lista");
        // $this->logger->write("Query : $query");
        $result = array();
        $cont = 0;

        $custom_attribute_subscriber = '<?xml version="1.0" encoding="UTF-8" ?><custom_attributes></custom_attributes>';
        $agora = date("Y-m-d H:i:s");
        $codpesalt = $this->f3->get('codpes');
        // $this->logger->write("sql_rep: $sql_rep");
        // $this->logger->write("total para inserir: " . count($select_rep));
        if ($siicusp) {
            foreach ($siicusp as $rep) {
                $codema = $rep['codema'];
                $codpes = $rep['codpes'] ?? 0;
                $nompes = $rep['nompes'];
                // $this->logger->write("dados -> $codema, $codpes, $nompes");
                $sql = "INSERT INTO sympa.subscriber_table
                    (bounce_address_subscriber, bounce_score_subscriber, bounce_subscriber,
                    comment_subscriber, custom_attribute_subscriber, date_subscriber,
                    include_sources_subscriber, included_subscriber, list_subscriber,
                    reception_subscriber, robot_subscriber, subscribed_subscriber,
                    suspend_end_date_subscriber, suspend_start_date_subscriber,
                    suspend_subscriber, topics_subscriber, update_subscriber,
                    user_subscriber, visibility_subscriber, codpes, nompes, codpesalt)
                    VALUES (NULL, NULL, NULL, NULL, ?, ?, '', 1, ?, 'mail', 'listas.poli.usp.br',
                    1, NULL, NULL, NULL, NULL, ?, ?, 'noconceal', $codpes, ?, $codpesalt)";
                try {
                    $result = $this->db->exec($sql, array($custom_attribute_subscriber, $agora, $lista, $agora, $codema, $nompes));
                    $cont++;
                    //$result = $this->db->exec($sql);
                } catch (Exception $e) {
                    $this->logger->write("Erro ao tentar atualizar [$lista] volta: [$cont] - $e");
                    break;
                }
            }
        } else {
            $this->logger->write("$lista - Não gerou registos: [$cont]");
        }
        $this->logger->write("$lista atualizada: $cont inscritos");

        return $result;
    }


    function retornaDataCompleta($data_str)
    {
        date_default_timezone_set("America/Sao_Paulo");
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::FULL,
            IntlDateFormatter::NONE,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN
        );
        $data_completa = $formatter->format(strtotime($data_str));
        return $data_completa;
    }

    function retornaDataHorario($data_str, $tipoHora = IntlDateFormatter::NONE)
    {
        date_default_timezone_set("America/Sao_Paulo");
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::LONG, # tipo data (13 de junho de 2024)
            $tipoHora, # tipo tempo (FULL, LONG, MEDIUM, SHORT, NONE)
            'America/Sao_Paulo', # zona do tempo
            IntlDateFormatter::GREGORIAN
        );
        $data_hora = $formatter->format(strtotime($data_str));
        return $data_hora;
    }

    function retornaDataIntervalo($dias)
    {
        $datetime = date_create(date('Y-m-d H:s:i'));
        $intervalo = DateInterval::createFromDateString($dias . ' days');
        $resultado = date_sub($datetime, $intervalo);
        return $resultado;
    }


    function alteracoes_periodo($dias = 7)
    {

        //$inicio = "$ano-$mes-01";
        //$fim = date("Y-m-d", strtotime("$inicio +1 month")); // mês inteiro, considerando variações de dias entre os meses
        $fim = date("Y-m-d 23:59:59"); // até a data atual, para considerar o mês em andamento
        $inicio = date("Y-m-d 00:00:00", strtotime("$fim -$dias days")); // até 7 dias atrás

        $sql = "SELECT CONCAT(CAST(U.nome AS CHAR CHARACTER SET utf8), ' ( ', U.codema, ' ) ', 
        CAST(E.codpesalt AS CHAR CHARACTER SET utf8)) AS nome,
        CONCAT('Regras para [', CAST(E.list_admin AS CHAR CHARACTER SET utf8), ']: ',
        IF(E.role_admin = 'owner', 'Proprietário', 'Publicador')) AS ent,
        date(E.update_admin) AS dta_ocor,
        COUNT(E.id) AS tot, U.codlog
        FROM sympa.user U
        JOIN sympa.role_table E ON E.codpesalt = U.id
        WHERE E.update_admin >= ? AND E.update_admin < ?
        GROUP BY dta_ocor, ent, nome

        UNION ALL
        SELECT CONCAT(CAST(U.nome AS CHAR CHARACTER SET utf8), ' ( ', U.codema, ' ) ', 
        CAST(E.codpesalt AS CHAR CHARACTER SET utf8)) AS nome,
        CONCAT('Inscritos em [', CAST(E.list_subscriber AS CHAR CHARACTER SET utf8), ']') AS ent,
        date(E.date_subscriber) AS dta_ocor,
        COUNT(E.list_subscriber) AS tot, U.codlog
        FROM sympa.user U
        JOIN sympa.subscriber_table E ON E.codpesalt = U.id
        WHERE E.date_subscriber >= ? AND E.date_subscriber < ?
        GROUP BY dta_ocor, ent, nome

        UNION ALL
        SELECT 'Automático' AS nome, 
        CONCAT('Inscritos em  [', E.list_subscriber, ']') AS ent, 
        date(E.date_subscriber) AS dta_ocor,
        COUNT(E.list_subscriber) AS tot, E.codpesalt AS codlog 
        FROM sympa.subscriber_table E 
        WHERE (E.codpesalt IS NULL or E.codpesalt = 0) 
        AND E.date_subscriber >= ? AND E.date_subscriber < ?
        GROUP BY dta_ocor, ent, nome

        UNION ALL
        SELECT CONCAT(E.nome, ' ( ', E.codema, ' ) ', E.id) AS nome,
        CONCAT('Acesso', ' -> ', LPAD(hour(E.dtaalt), 2, 0), ':', LPAD(minute(E.dtaalt), 2, 0),
        ' ( ', E.papel, ' ', IFNULL(E.setor, ''), ' ) ') AS ent,
        date(E.dtaalt) AS dta_ocor,
        COUNT(E.id) AS tot, E.codlog FROM sympa.user E 
        WHERE E.dtaalt >= ? AND E.dtaalt < ?
        GROUP BY dta_ocor, ent, nome
        ORDER BY dta_ocor desc, ent, nome";

        return $this->db->exec($sql, [$inicio, $fim, $inicio, $fim, $inicio, $fim, $inicio, $fim]);
    }
}
