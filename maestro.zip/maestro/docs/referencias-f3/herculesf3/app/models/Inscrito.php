<?php

class Inscrito extends DB\SQL\Mapper
{

    public function  __construct(DB\SQL $db)
    {
        parent::__construct($db, 'subscriber_table'); // nome da tabela no db
    }

    // lista todos usuários
    public function all()
    {
        $this->load();
        return $this->query;
    }

    public function allList($list)
    {
        $this->load(array("list_subscriber=?", $list));
        return $this->query;
    }

    public function getByCodemaLista($codema, $lista)
    {
        $this->load(array('user_subscriber=? AND list_subscriber=?', $codema, $lista));
        return $this->query;
    }

    // exclui usuário pelo id
    public function delete($codema, $lista)
    {
        $this->load(array('user_subscriber=? AND list_subscriber=?', $codema, $lista));
        $this->erase();
    }


    // exclui todos usuários da lista
    public function deleteAll($lista)
    {
        $this->load(array('list_subscriber=?', $lista));
        $this->erase();
    }

    function retornaInscrito($lista, $codema)
    {
        // $sql = "SELECT * FROM sympa.subscriber_table WHERE list_subscriber=?
        // AND user_subscriber=?";
        $this->load(array('list_subscriber=? AND user_subscriber=?',  $lista, $codema));
        return $this->query;
    }
}
