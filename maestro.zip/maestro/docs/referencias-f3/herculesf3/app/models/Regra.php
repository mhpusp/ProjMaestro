<?php

class Regra extends DB\SQL\Mapper
{

    public function  __construct(DB\SQL $db)
    {
        parent::__construct($db, 'role_table'); // nome da tabela no db
    }

    // lista todos usuários
    public function all()
    {
        $this->load();
        return $this->query;
    }

    public function allList($list)
    {
        $this->load(array("list_admin=?", $list));
        return $this->query;
    }

    public function getById($id)
    {
        $this->load(array('id=?', $id));
        return $this->query;
    }

    public function getByCodpes($codpes)
    {
        $this->load(array('codpes=?', strval($codpes)));
        return $this->query;
    }

    public function getByRegraList($regra, $list)
    {
        $this->load(array("role_admin=? AND list_admin=?", $regra, $list));
        return $this->query;
    }

    public function getByEmailRegraList($email, $regra, $list)
    {
        $this->load(array("user_admin=? AND role_admin=? AND list_admin=?", $email, $regra, $list));
        return $this->query;
    }

    // cria novo usuário
    public function add()
    {
        $this->copyFrom('POST');
        $this->save();
    }
    // edita usuário pelo id
    public function edit($id)
    {
        $this->load(array('id=?', $id));
        $this->copyFrom('POST');
        $this->update();
    }
    // exclui usuário pelo id
    public function delete($id)
    {
        $this->load(array('id=?', $id));
        $this->erase();
    }
}
