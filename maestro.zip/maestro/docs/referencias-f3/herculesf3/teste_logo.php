<?php
$host = $_SERVER['HTTP_HOST']; // pega domínio atual (ex: localhost ou www.seusite.com)
$logoUrl = "http://" . $host . "/herculesf3/app/static/images/logo.png";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>teste logo</title>
</head>

<body>

    <div style='text-align:center;border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>
        <a href='http://www.poli.usp.br' target='_blank'>
            <img src="<?php echo $logoUrl; ?>" style='width:100px; height:auto;' alt='Logo Poli USP'></a>
    </div>

</body>

</html>

<!--https://imagens.usp.br/wp-content/uploads/EP-Escrita.jpg-->
<!--https://imagens.usp.br/wp-content/uploads/EP-Circular.jpg-->
<!--{{@APP_URL}}/app/static/images/logo.png-->