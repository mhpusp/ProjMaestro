<?php
$logoPath = __DIR__ . "\app\static\images\logo.png";

echo "Verificando diretório: " .  __DIR__  . "<br>";

if (file_exists($logoPath)) {
    echo "Arquivo encontrado: " . $logoPath;
} else {
    echo "Arquivo NÃO encontrado: " . $logoPath;
}

?>
<div style='text-align:center;border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>
    <a href='http://www.poli.usp.br' target='_blank'>
        <img src=<?php echo $logoPath; ?> style='width:100px; height:auto;'
            alt='Logo Poli USP'></a>
</div>