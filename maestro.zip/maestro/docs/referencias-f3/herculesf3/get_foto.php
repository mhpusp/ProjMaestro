<?php 
require(__DIR__ . '/vendor/econea/nusoap/src/nusoap.php');
require(__DIR__ . '/vendor/uspdev/wsfoto/src/Wsfoto.php');
use Uspdev\Wsfoto;
putenv('WSFOTO_USER=EP');
putenv('WSFOTO_PASS=p0L!*12');

$foto = Wsfoto::obter((int)(trim($_GET['codpes'])));

if(!$foto){
	header('Content-Type: image/png');
        echo file_get_contents(__DIR__ .'/app/static/images/vazio.jpg');
	exit;
}
header('Content-Type: image/png');
echo base64_decode($foto);