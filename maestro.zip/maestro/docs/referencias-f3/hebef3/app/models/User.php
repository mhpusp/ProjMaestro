<?php

class User extends DB\SQL\Mapper
{

    public function  __construct(DB\SQL $db)
    {
        parent::__construct($db, 'user'); // nome da tabela no db
    }

    // lista todos usuários
    public function all()
    {
        $this->load();
        return $this->query;
    }
    // retorna usuário pelo id
    public function getById($id)
    {
        $this->load(array('id=?', $id));
        return $this->query;
    }
    // retorna usuário pelo codlog
    public function getByCodlog($codlog)
    {
        $this->load(array('codlog=?', strval($codlog)));
        return $this->query;
    }
    // retorna usuário pelo papel
    public function getByPapel($papel)
    {
        $this->load(array('papel=?', strval($papel)));
        return $this->query;
    }

    // retorna adm autorizados receber emails
    //array('papel<>? AND receber_emails=?', 'usr', 1)
    public function getByAutorizados()
    {
        $this->load(array('papel<>? AND receber_emails=?', 'usr', 1));
        return $this->query;
    }

    // cria novo usuário
    public function add()
    {
        $this->copyFrom('POST');
        $this->save();
    }
    // edita usuário pelo id
    public function edit($id)
    {
        $this->load(array('id=?', $id));
        $this->copyFrom('POST');
        $this->update();
    }
    // exclui usuário pelo id
    public function delete($id)
    {
        $this->load(array('id=?', $id));
        $this->erase();
    }
    //atualiza dtaalt
    public function atualiza_data($id, $dtaalt)
    {
        if (empty($dtaalt)) {
            return null;
        } else {
            $this->load(array('id=?', $id));
            $this->edit($dtaalt);
        }
    }

    //recebe email
    public function recebe_email($id)
    {
        $recebe = 0;
        $result = $this->load(array('id=?', $id));
        if ($result) {
            $recebe = 1;
            if ($result[0]['receber_emails'] == 0) {
                $recebe = 0;
            }
        }
        return $recebe;
    }

    //print variable codpes
    public function codpes()
    {
        echo $this->id . "\n";
    }
    //print variable codpes
    public function codlog()
    {
        echo $this->codlog . "\n";
    }
}
