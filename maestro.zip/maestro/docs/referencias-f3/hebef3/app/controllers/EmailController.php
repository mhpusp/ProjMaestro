<?php

class EmailController extends Controller
{
    //Sobscreve o beforeroute do Controller para não solicitar autenticação
    function beforeroute($f3, $args)
    {
        $this->parseQuery($args[0]);
        $this->args = $args;

        setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        date_default_timezone_set("America/Sao_Paulo");
        $agora = date("Y-m-d H:i:s");

        $this->logger = new \Log('logs/app-events.log');

        $f3->set('agora', $agora);
    }

    public function enviarEmailEmBloco()
    {
        $mesHoje = date('m');
        $diaHoje = $_GET['dia'] ?? date('d');
        $nomeMes = $this->descricaoMes($mesHoje);
        $nivers = $this->niverMesDia($mesHoje, $diaHoje);
        $subject = "Parabéns pelo seu dia: " . $diaHoje . " " . $nomeMes . "!";
        $ehProducao = $this->ambienteEhProducao();

        // $flag = 0; // 0 - padrão  // 1 - Email fake para kardopoly.
        if (!empty($nivers) && $ehProducao) {
            $this->criando_mensagem($nivers, $subject, $nomeMes, $diaHoje);
            // $tot = count($nivers);
            // $this->logger->write("Aniversariantes hoje: $tot em $diaHoje/$nomeMes");
        } else {
            $msg = "Não há aniversariantes hoje: $diaHoje/$nomeMes";
            $this->logger->write($msg);
            if ($ehProducao) {
                $res = $this->enviaRelatorio('Relatório de envio de felicitações de aniversário', $msg);
                $this->logger->write("Relatório $msg: [$res]");
            }
        }
    }


    function teste()
    {
        $this->f3->set('view', 'nao_autorizado.htm');
        $template = new Template;
        echo $template->render('base.htm');
    }


    function retornaTratamento($sex)
    {
        $tratamento = $sex == 'F' ? 'Prazada' : 'Prezado';
        return $tratamento;
    }

    function startsWith($string, $startString)
    {
        $len = strlen($startString);
        return (substr($string, 0, $len) === $startString);
    }

    function assinaturaDir($codpes_niver)
    {
        $gen = "";
        $assinante = $this->retornaDiretoria($codpes_niver);
        $ass = '';
        $gen = $assinante['sexpes'] == 'F' ? 'a' : '';
        $tituloDiretor = "Prof$gen.";
        $cargoDiretor = "Diretor$gen";
        $cargoVice = "Vice-Diretor$gen";
        $assinatura = $this->startsWith($assinante['nomfnc'], 'D') ? $cargoDiretor : $cargoVice;
        $ass .= "<p align='center'> $tituloDiretor " . $assinante['nompes'] . "<br/>" . $assinatura . ".</p>";

        // $this->logger->write("assinante: ".$assinante['nompes']);
        // $this->logger->write("assinatura: $assinatura");
        // $this->logger->write("ass: $ass");

        return $ass;
    }


    function criando_mensagem($nivers, $subject, $nomeMes, $diaHoje)
    {
        // $this->logger->write("flag: $flag");
        // $flag = 1; // - Email fake para kardopoly

        $tot = count($nivers);
        $to = array();
        $cont = 0;
        $felicitacao = $tot > 1 ? "felicitações" : "felicitação";
        $gen = "o";
        $rel = "<h3>Relatório de envio de $tot $felicitacao de aniversário.</h3>";
        $rel .= "<h4> $diaHoje de $nomeMes.</h4>";
        $rel .= "<ul>";
        // $this->logger->write("");
        foreach ($nivers as $niv) {
            // relatório
            $rel .= "<li>" . $niv['nompes'] . " (" . $niv['idade'] . " anos) - " . $niv['tipvinext'] . "/" . $niv['nomabvset'] . "</li>";

            $gen = $niv['sexpes'] == 'F' ? 'a' : 'o';
            $msg = "<p>Prezad$gen " . $niv['nompes'] . "</p>";
            $msg .= "<p>Em nome da Escola Politécnica, temos a satisfação de cumprimenta-l$gen pela passagem de seu aniversário.</p>";
            $msg .= $this->assinaturaDir($niv['codpes']);

            // $this->logger->write("msg: $msg");
            // $this->logger->write("####");
            // $this->logger->write("");

            // $this->enviaEmail($niv, $subject, $msg, $flag);

            if (gettype($niv) == 'array') {
                $to = array($niv['codema'], $niv['nompes']);     //se arrray
            } else {
                $to = array($niv->codema, $niv->nompes);     //se objeto
            }

            $res = $this->enviaEmail($to, $subject, $msg);
            if ($res) {
                $cont++;
            }
            // $this->logger->write("enviar para: $to - tipo objeto[$cont]: " . gettype($niv));
        }
        $rel .= "</li>";

        //$this->logger->write(strip_tags($rel));

        $res = $this->enviaRelatorio("Relatório de envio de $felicitacao de aniversário", $rel);

        $this->logger->write("Relatório " . strip_tags($rel) . ": " . $res == true ? "Enviado" : "NÃO Enviado");
        $this->logger->write("total na lista de aniversariantes $diaHoje/$nomeMes: " . count($nivers));
        $this->logger->write("total de envios: $cont");
        $this->logger->write("");
    }
}
