<?php

class ServidoresController extends Controller
{
    // funcao antes
    function beforeroute($f3, $args)
    {
        parent::beforeroute($f3, $args);
    }
    // fim funcao antes

    // funcao depois
    function afterroute($f3, $args)
    {
        parent::afterroute($f3, $args);
    }
    // fim funcao depois

    // rota: GET|POST /servidores=ServidoresController->servidores
    function servidores()
    {
        $title = "Servidores";
        $papel = $this->f3->get('papel');
        $params = '';
        $servidores = array();
        $servidoresToJson = null;
        $cabecalho = array();
        $total = 0;

        if (isset($_POST['sexpes'])) {
            $sexpes = $_POST['sexpes'];
            //$tiplis = $_POST['tiplis'];
            $msg = $sexpes == "F" ? "Lista de Servidoras" : "Lista de Servidores";
            $params = $this->criaCriterios();
            //$this->logger->write("Parametros: $params");

            $servidores = $this->retornaListaServidores($params);
            $total = count($servidores);

            if (empty($servidores)) {
                $msg = "Nada encontrado com os parâmetros indicados!";
            } else {
                //$servidoresToJson = $this->objToJson($servidores);
                $servidoresToJson = json_encode($servidores);
                array_push(
                    $cabecalho,
                    'Nr. USP',
                    'Nome',
                    'Sexo',
                    'Vínculo',
                    'Tipo',
                    'Início',
                    'Carreira',
                    'Classificação',
                    'Nível',
                    'Função',
                    'Tipo',
                    'Jornada',
                    'Mérito',
                    'Contrato',
                    'E-mail',
                    'Lotação',
                    'Nascimento'
                );
            }

            // $this->imprimePost();
            // $this->logger->write(" total: $total");
            // $this->logger->write($servidoresToJson);

            $msg_jsonfy = json_encode(
                array('msg' => $msg, 'cabecalho' => $cabecalho, 'servidores' => $servidoresToJson, 'total' => $total)
            );

            echo $msg_jsonfy;
        } else {
            //$this->logger->write("GET");


            if ($papel == 'adm' || $papel == 'opr') {

                $comboTipoVinculoExterno = array();
                $comboAnoIngresso = array();
                $comboSetores = array();
                $comboAreaSetores = array();
                $comboCarreiras = array();
                $comboCategorias = array();
                $comboClassificacoes = array();
                $comboTipoFuncoes = array();
                $comboNomeFuncoes = array();
                $comboJornadas = array();
                $comboNiveis = array();
                $comboCondicoes = array();

                $comboTipoVinculoExterno = $this->retornaTipoVinculoExternoTipvinext();
                $comboAnoIngresso = $this->retornaAnoIngresso();
                $comboSetores = $this->retornaListaSetores();
                $comboAreaSetores = $this->retornaListaAreaSetores();
                $comboCarreiras = $this->retornaCarreirasNomcaa();
                $comboCategorias = $this->retornaCategoriasTipmer();
                $comboClassificacoes = $this->retornaClassificacoesNomabvcla();
                $comboTipoFuncoes = $this->retornaFuncoesTipfnc();
                $comboNomeFuncoes = $this->retornaNomeFuncaoNomabvfnc();
                $comboJornadas = $this->retornaJornadasTipjor();
                $comboNiveis = $this->retornaNiveisNivgrupvm();
                $comboCondicoes = $this->retornaCondicoesTipcon();


                $this->f3->set('comboTipoVinculoExterno', $comboTipoVinculoExterno);
                $this->f3->set('comboAnoIngresso', $comboAnoIngresso);
                $this->f3->set('comboSetores', $comboSetores);
                $this->f3->set('comboAreaSetores', $comboAreaSetores);
                $this->f3->set('comboCarreiras', $comboCarreiras);
                $this->f3->set('comboCategorias', $comboCategorias);
                $this->f3->set('comboClassificacoes', $comboClassificacoes);
                $this->f3->set('comboTipoFuncoes', $comboTipoFuncoes);
                $this->f3->set('comboNomeFuncoes', $comboNomeFuncoes);
                $this->f3->set('comboJornadas', $comboJornadas);
                $this->f3->set('comboNiveis', $comboNiveis);
                $this->f3->set('comboCondicoes', $comboCondicoes);
                $this->f3->set('title', $title);
                $this->f3->set('view', 'servidores.htm');
            } else {
                $this->f3->set('view', 'nao_autorizado.htm');
            }
            $template = new Template;
            echo $template->render('base.htm');
        }
    }

    //rota: GET /servidores_por_idade=ServidoresController->servidoresIdade
    function servidoresIdade()
    {
        $title = "Servidores por ano de nascimento";
        $papel = $this->f3->get('papel');
        $totais = array();
        $lista = array();
        $ano = 0;
        $msg = "Selecione servidores pela idade!";
        $chart_lables = array();
        $chart_values = array();
        $colors = array();

        if ($papel == 'adm' || $papel == 'opr') {
            $totais = $this->retornaTotalPorIdade();
            if (isset($_GET['ano'])) {
                $ano = $_GET['ano'];
                $lista = $this->retornaListaPorIdade($ano);
                $msg = "Servidores nascidos em $ano!";
            }

            $chart_lables = array_column($totais, 'ano');
            $chart_values = array_column($totais, 'total');
            $colors = $this->retornaArrayDeCores(count($totais));
            $pct = $this->retornaArrayDePorcentagens($chart_values);
            $total_func = array_sum($chart_values);
            //$this->logger->write(json_encode($pct));

            $this->f3->set('msg', $msg);
            $this->f3->set('ano', $ano);
            $this->f3->set('totais', $totais);
            $this->f3->set('lista', $lista);
            $this->f3->set('chart_lables', json_encode($chart_lables));
            $this->f3->set('chart_values', json_encode($chart_values));
            $this->f3->set('pct', $pct);
            $this->f3->set('total_func', $total_func);
            $this->f3->set('colors', json_encode($colors));
            $this->f3->set('title', $title);
            $this->f3->set('view', 'servidores_por_idade.htm');
        } else {
            $this->f3->set('view', 'nao_autorizado.htm');
        }
        $template = new Template;
        echo $template->render('base.htm');
    }

    function retornaArrayDeCores($tot)
    {
        $colors = array();
        for ($x = 0; $x < $tot; $x++) {
            if ($x >= 255)
                $x = 0;
            $r = rand($x, 255);
            $g = rand($x, 255);
            $b = rand($x, 255);
            $hex_code = sprintf("#%02x%02x%02x", $r, $g, $b);
            array_push($colors, $hex_code);
        }
        return $colors;
    }

    function retornaArrayDePorcentagens($valores)
    {
        $percent = array();
        $soma = array_sum($valores);

        foreach ($valores as $val) {
            $pct = ($val * 100) / $soma;
            $percent[$val][] = $pct;
        }

        return $percent;
    }

    // rota: GET /aniversariantes=ServidoresController->aniversariantes
    function aniversariantes()
    {
        $title = "Aniversariantes";
        $papel = $this->f3->get('papel');
        $nivers = array();
        $mes = 0;
        $diaHoje = 0;
        $totHoje = 0;

        if ($papel == 'adm' || $papel == 'opr') {
            $this->f3->set('title', $title);

            if (isset($_GET['mes'])) {
                $mes = $_GET['mes'];
                $this->f3->set('mes', $mes);
                $nomeMes = $this->descricaoMes($mes);

                if ($mes == 0) {
                    $mesHoje = date('m');
                    $diaHoje = date('d');
                    $nomeMes = $this->descricaoMes($mesHoje);
                    $nivers = $this->niverMesDia($mesHoje, $diaHoje);
                } else {
                    $nivers = $this->niverMes($mes);
                }
            } else {
                $mesHoje = date('m');
                $diaHoje = date('d');
                $nomeMes = $this->descricaoMes($mesHoje);
                $nivers = $this->niverMesDia($mesHoje, $diaHoje);
                $totHoje = count($nivers);
            }
            //$this->logger->write("nivers: " . json_encode($nivers));

            $this->f3->set('tothoje', $totHoje);
            $this->f3->set('mes', $mes);
            $this->f3->set('nomeMes', $nomeMes);
            $this->f3->set('dia', $diaHoje);
            $this->f3->set('nivers', $nivers);
            $this->f3->set('view', 'aniversariantes.htm');
        } else {
            $this->f3->set('view', 'nao_autorizado.htm');
        }
        $template = new Template;
        echo $template->render('base.htm');
    }

    function exportarXLS()
    {
        $agora_txt = date("YmdHi");
        $ano = $_POST['ano'];
        $entity = array();
        $entity = $this->retornaListaPorIdade($ano);
        $dados = $this->gera_dados_para_xls($entity);
        //header array to rename the field labels and sort/reorder the data array 
        $headers = [
            'codpes' => 'Nr. USP',
            'nompes' => 'Nome',
            'sexpes' => 'Sexo',
            'nomset' => 'Setor',
            'dtainivin' => 'Início',
            'codema' => 'E-mail',
            'nivgrupvm' => 'Nível',
            'nomabvcla' => 'Class.',
            'nomabvfnc' => 'Func.',
            'nomcaa' => 'Car.',
            'tipcon' => 'Conv.',
            'tipfnc' => 'Tipo',
            'tipjor' => 'Jorn.',
            'tipmer' => 'Mer.',
            'tipvin' => 'Vinc.',
            'tipvinext' => 'Tipo Vinc.',
            'dtanas' => 'Data Nasc.',
            'idade' => 'Idade'
        ];
        $excel = \Sheet::instance();
        $excel->renderXLS($dados, $headers, "servidores_nascidos_em_" . $ano . "_$agora_txt.xls");
        //$excel->renderCSV($dados, $headers, "servidores_nascidos_em_" . $ano . "_$agora_txt.csv");

    }


    function gera_dados_para_xls($entity)
    {
        $dado = array();
        $dados = array();

        foreach ($entity as $row) {
            // $this->logger->write("");
            $dado = [
                'codpes' => $row['codpes'],
                'nompes' => $row['nompes'],
                'sexpes' => $row['sexpes'],
                'nomset' => $row['nomset'],
                'dtainivin' => date('d/m/Y', strtotime($row['dtainivin'])),
                'codema' => $row['codema'],
                'nivgrupvm' => $row['nivgrupvm'],
                'nomabvcla' => $row['nomabvcla'],
                'nomabvfnc' => $row['nomabvfnc'],
                'nomcaa' => $row['nomcaa'],
                'tipcon' => $row['tipcon'],
                'tipfnc' => $row['tipfnc'],
                'tipjor' => $row['tipjor'],
                'tipmer' => $row['tipmer'],
                'tipvin' => $row['tipvin'],
                'tipvinext' => $row['tipvinext'],
                'dtanas' => date('d/m/Y', strtotime($row['dtanas'])),
                'idade' => $row['idade']
            ];
            array_push($dados, $dado);
            //$this->logger->write("dado => " . json_encode($dado));
        }


        return $dados;
    }

    function exportarNiverXLS()
    {
        $mes = $_POST['mes'];
        $entity = array();
        $dados = array();
        $nomeMes = strtolower($this->descricaoMes($mes));
        $entity = $this->niverMes($mes);
        // $this->logger->write("mes => $mes");
        // $this->logger->write("nomeMes => $nomeMes");
        // $this->logger->write("entity => " . json_encode($entity[0]));
        if ($entity) {
            $dados = $this->gera_dados_niver_xls($entity);
            //$this->logger->write("dados => " . json_encode($dados[0]));
            //header array to rename the field labels and sort/reorder the data array 
            $headers = [
                'dia' => 'Dia',
                'nompes' => 'Nome',
                'sexpes' => 'Sexo',
                'nomfnc' => 'Função',
                'nomset' => 'Setor',
                'sitatl' => 'Situação',
                'tipvinext' => 'Vínculo',
                'idade' => 'Idade'
            ];
            $excel = \Sheet::instance();
            $excel->renderXLS($dados, $headers, "servidores_nascidos_mes_" . $nomeMes . ".xls");
            // $excel->renderCSV($dados, $headers, "servidores_nascidos_mes_" . $nomeMes . ".csv");
        }
    }

    function gera_dados_niver_xls($entity)
    {
        $dado = array();
        $dados = array();

        foreach ($entity as $row) {
            // $this->logger->write("");
            $dado = [
                'dia' => $row['dia'],
                'nompes' => $row['nompes'],
                'sexpes' => $row['sexpes'],
                'nomfnc' => $row['nomfnc'],
                'nomset' => $row['nomset'],
                'sitatl' => $row['sitatl'] == 'P' ? 'Aposentado' : 'Ativo',
                'tipvinext' => $row['tipvinext'],
                'idade' => $row['idade']
            ];
            array_push($dados, $dado);
            //$this->logger->write("dado => " . json_encode($dado));
        }


        return $dados;
    }


    function niverMes($mes)
    {
        $result = array();

        $sql = "SELECT DAY(P.dtanas) as dia, P.codpes, P.nompes, P.dtanas, P.sexpes, 
        L.sitatl, L.nomfnc,L.codema, L.nomabvset, L.nomset,L.tipvinext, 
        YEAR(now())- YEAR(P.dtanas) as idade FROM replicado.LOCALIZAPESSOA L 
        JOIN replicado.PESSOA P ON (L.codpes=P.codpes) WHERE L.codundclg= 3 
        AND L.tipvinext <> 'Servidor Designado' AND MONTH(P.dtanas) = ?
        AND L.codset>0 order by DAY(P.dtanas), P.nompes";

        $result = $this->db_r->exec($sql, $mes);

        return $result;
    }


    function retornaTipoVinculoExternoTipvinext()
    {
        $sql = "SELECT  DISTINCT L.tipvinext FROM replicado.LOCALIZAPESSOA L 
        WHERE L.codundclg=3 AND L.sitatl='A' AND L.codset is not null
        AND L.tipvinext IS NOT NULL ORDER BY L.tipvinext";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaAnoIngresso()
    {
        $sql = "SELECT DISTINCT year(V.dtainivin) as anoing FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.tipvin='SERVIDOR' AND V.codund=3 AND V.sitatl = 'A' 
        AND V.dtainivin IS NOT NULL ORDER BY year(V.dtainivin) desc";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaListaSetores()
    {
        $sql = "SELECT  S.codset, S.tipset, S.nomabvset, S.nomset, S.nomareatcset FROM replicado.SETOR S 
        WHERE S.codund=3 AND S.codset <> 2523 AND S.dtadtvset is null ORDER BY S.nomset";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaListaAreaSetores()
    {
        $sql = "SELECT DISTINCT S0.codset, S0.nomareatcset, S0.tipset FROM replicado.SETOR S0, 
        replicado.SETOR S1 WHERE S0.codset = S1.codsetspe 
        AND S0.dtadtvset is null AND S1.dtadtvset is null 
        AND S0.codund=3 ORDER BY S0.nomareatcset, S0.tipset";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaArraySetoresPorArea($codset)
    {
        $sql = "SELECT S1.codset FROM replicado.SETOR S0, 
        replicado.SETOR S1 WHERE S0.codset = S1.codsetspe 
        AND S0.codset = ? AND S0.dtadtvset is null";

        $result = $this->db_r->exec($sql, $codset);

        return $result;
    }

    function retornaCarreirasNomcaa()
    {
        $sql = "SELECT DISTINCT V.nomcaa FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' 
        AND V.nomcaa IS NOT NULL ORDER BY V.nomcaa";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaCategoriasTipmer()
    {
        $sql = "SELECT DISTINCT V.tipmer FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.tipmer IS NOT NULL AND V.codund=3 AND V.sitatl = 'A' ORDER BY V.tipmer";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaClassificacoesNomabvcla()
    {
        $sql = "SELECT DISTINCT V.nomabvcla FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' 
        AND V.nomabvcla IS NOT NULL ORDER BY V.nomabvcla";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaFuncoesTipfnc()
    {
        $sql = "SELECT DISTINCT V.tipfnc FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' 
        AND V.tipfnc IS NOT NULL ORDER BY V.tipfnc";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaNomeFuncaoNomabvfnc()
    {
        $sql = "SELECT DISTINCT V.nomabvfnc FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A'
        AND V.nomabvfnc IS NOT NULL ORDER BY V.nomabvfnc";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaJornadasTipjor()
    {
        $sql = "SELECT DISTINCT V.tipjor FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' AND V.tipjor IS NOT NULL ORDER BY V.tipjor";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaNiveisNivgrupvm()
    {
        $sql = "SELECT DISTINCT V.nivgrupvm FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' AND V.nivgrupvm IS NOT NULL ORDER BY V.nivgrupvm";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaCondicoesTipcon()
    {
        $sql = "SELECT DISTINCT V.tipcon FROM replicado.VINCULOPESSOAUSP V 
        WHERE V.codund=3 AND V.sitatl = 'A' 
        AND V.tipcon IS NOT NULL ORDER BY V.tipcon";

        $result = $this->db_r->exec($sql);

        return $result;
    }


    function retornaTotalTipvinext()
    {
        $sql = "SELECT   L.tipvinext, COUNT(L.tipvinext) AS Qtd
        FROM replicado.LOCALIZAPESSOA L 
        JOIN replicado.PESSOA P ON (L.codpes=P.codpes)
        WHERE  L.codundclg=3 AND L.sitatl='A' AND L.tipvin='SERVIDOR'
        GROUP BY  L.tipvinext
        HAVING   COUNT( L.tipvinext) > 1 
        ORDER BY COUNT( L.tipvinext) DESC";

        $result = $this->db_r->exec($sql);

        return $result;
    }


    function retornaTotalAnoDtainivin()
    {
        $sql = "SELECT year(V.dtainivin),
        COUNT(year(V.dtainivin)) AS Qtd
        FROM replicado.LOCALIZAPESSOA L 
        JOIN replicado.VINCULOPESSOAUSP V ON (L.codpes=V.codpes AND L.tipvin=V.tipvin AND L.codundclg=V.codund) 
        WHERE  L.codundclg=3 AND L.sitatl='A' AND V.tipvin='SERVIDOR'
        GROUP BY year(V.dtainivin)
        HAVING   COUNT( year(V.dtainivin)) > 1 
        ORDER BY COUNT( year(V.dtainivin)) DESC, year(V.dtainivin) desc";

        $result = $this->db_r->exec($sql);

        return $result;
    }


    function retornaTotalPorIdade()
    {
        $sql = "SELECT (year(now())-year(P.dtanas)) as idade, year(P.dtanas) AS ano, COUNT(year(P.dtanas)) AS total
        FROM replicado.LOCALIZAPESSOA L 
        JOIN replicado.VINCULOPESSOAUSP V ON (L.codpes=V.codpes AND L.tipvin=V.tipvin AND L.codundclg=V.codund) 
        JOIN replicado.PESSOA P ON (L.codpes=P.codpes)
        WHERE  L.codundclg=3 AND L.sitatl='A' AND V.tipvin='SERVIDOR'
        GROUP BY year(P.dtanas)
        ORDER BY idade, COUNT( year(P.dtanas)) DESC, year(P.dtanas) desc";

        $result = $this->db_r->exec($sql);

        return $result;
    }

    function retornaListaPorIdade($ano)
    {
        $sql = "SELECT L.codpes, L.nompes, P.sexpes, L.nomset, V.dtainivin, L.codema, V.nivgrupvm, 
        V.nomabvcla, V.nomabvfnc, V.nomcaa, V.tipcon, V.tipfnc, V.tipjor, V.tipmer, V.tipvin, 
        L.tipvinext, P.dtanas, (year(now())-year(P.dtanas)) as idade, year(P.dtanas) AS ano
        FROM replicado.LOCALIZAPESSOA L JOIN replicado.VINCULOPESSOAUSP V 
        ON (L.codpes=V.codpes AND L.tipvin=V.tipvin AND L.codundclg=V.codund) 
        JOIN replicado.PESSOA P ON (L.codpes=P.codpes)
        WHERE  L.codundclg=3 AND L.sitatl='A' AND V.tipvin='SERVIDOR' AND year(P.dtanas)=?
        ORDER BY L.nompes";

        $result = $this->db_r->exec($sql, $ano);

        return $result;
    }

    function retornaListaServidores($criterio)
    {
        //"Nr.USP, Nome, Sexo, Vínculo, Tipo, Início, Carreira, Classificação, Nível, Função, Tipo, Jornada, Mérito, Contrato, E-mail, Lotação, Nascimento";

        $sql = "SELECT P.codpes,L.nompes, P.sexpes, V.tipvin, L.tipvinext, 
        DATE_FORMAT(V.dtainivin, '%d/%m/%Y') as datainicio , V.nomcaa,
        V.nomabvcla, V.nivgrupvm, V.nomabvfnc, REPLACE(V.tipfnc,',',' ') as tipfnc, 
        V.tipjor, V.tipmer, V.tipcon, L.codema, 
        concat(REPLACE(L.nomset,',',' '),' (',RTRIM(L.nomabvset),')') as lotacao, 
        DATE_FORMAT(P.dtanas, '%d/%m/%Y') as dtanas 
        FROM replicado.LOCALIZAPESSOA L JOIN replicado.VINCULOPESSOAUSP V 
        ON (L.codpes=V.codpes AND L.tipvin=V.tipvin AND L.codundclg=V.codund) 
        JOIN replicado.PESSOA P ON (L.codpes=P.codpes) WHERE  L.codundclg=3 AND L.sitatl='A' PARAM ORDER BY L.nompes";

        $imprimeSql = str_replace("PARAM", $criterio, $sql);
        // $this->logger->write("");
        // $this->logger->write("criterio: $criterio");
        // $this->logger->write("sql: $imprimeSql");
        // $this->logger->write("");

        $result = array();

        try {
            $result = $this->db_r->exec($imprimeSql);
        } catch (Exception $e) {
            $this->logger->write("Erro na query: $e");
        }


        return $result;
    }

    function criaCriterios()
    {

        $criterio = " ";

        if ($_POST['tipoServidor'] != "T") {
            $criterio .= "AND L.tipvinext='" . $_POST['tipoServidor'] . "' ";
        } else {
            $criterio .= "AND V.tipvin='SERVIDOR' AND L.tipvinext <> 'Servidor Designado' ";
        }
        if ($_POST['sexpes'] != "A") {
            $criterio .= "AND P.sexpes='" . $_POST['sexpes'] . "' ";
        }
        if ($_POST['anoIngresso'] != 0) {
            $criterio .= "AND YEAR(V.dtainivin)=" . $_POST['anoIngresso'] . " ";
        }
        if ($_POST['codigoSetor'] != 0) {
            $criterio .= "AND V.codset=" . $_POST['codigoSetor'] . " ";
        } else {
            // faz uma procura dos codsets da area e faz um loop 
            // para cada codset criando o criterio 'OR'
            if ($_POST['codigoAreaSetor'] != 0) {
                $setores = $this->retornaArraySetoresPorArea($_POST['codigoAreaSetor']);
                // $this->logger->write("setores: " . json_encode($setores));
                // $this->logger->write("setores: " . count($setores));
                $totset = count($setores);
                if ($totset > 1) {
                    $criterio .= "AND (";
                    foreach ($setores as $cod) {
                        $criterio .= "V.codset=" . $cod['codset'] . " OR ";
                    }
                    $criterio .= "V.codset=" . $_POST['codigoAreaSetor']; // acrescentando tambem a area na lista
                    $criterio .= ") ";
                } else {
                    $criterio .= "AND (V.codset=" . $setores[0]['codset'] . " OR V.codset=" . $_POST['codigoAreaSetor'] . ")";
                }
            }
        }
        if ($_POST['carreira'] != "T") {
            $criterio .= "AND V.nomcaa='" . $_POST['carreira'] . "' ";
        }
        if ($_POST['categoria'] != "T") {
            $criterio .= "AND V.tipmer='" . $_POST['categoria'] . "' ";
        }
        if ($_POST['classificacao'] != "T") {
            $criterio .= "AND V.nomabvcla='" . $_POST['classificacao'] . "' ";
        }
        if ($_POST['tipoFuncao'] != "T") {
            $criterio .= "AND V.tipfnc='" . $_POST['tipoFuncao'] . "' ";
        }
        if ($_POST['nomeFuncao'] != "T") {
            $criterio .= "AND V.nomabvfnc='" . $_POST['nomeFuncao'] . "' ";
        }
        if ($_POST['jornada'] != "T") {
            $criterio .= "AND V.tipjor='" . $_POST['jornada'] . "' ";
        }
        if ($_POST['nivel'] != "T") {
            $criterio .= "AND V.nivgrupvm='" . $_POST['nivel'] . "' ";
        }
        if ($_POST['condicao'] != "T") {
            $criterio .= "AND V.tipcon='" . $_POST['condicao'] . "' ";
        }

        // $this->logger->write("");
        // $this->logger->write("criterio: $criterio");
        // $this->logger->write("");
        return $criterio;
    }
}
