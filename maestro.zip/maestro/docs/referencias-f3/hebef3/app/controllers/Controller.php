<?php

use PHPMailer\PHPMailer\PHPMailer;

class Controller
{
    protected $f3;
    protected $db;
    protected $db_r;
    protected $args;
    protected $queryParams;
    protected $uri;
    protected $logger;


    function beforeroute($f3, $args)
    {
        $this->parseQuery($args[0]);
        $this->args = $args;

        //setlocale(LC_ALL, 'pt_BR.UTF8');
        //$data = new DateTime();

        setlocale(LC_ALL, 'pt_BR', 'pt_BR.windows-1252', 'pt_BR.windows-1252', 'portuguese');
        date_default_timezone_set("America/Sao_Paulo");
        $agora = date("Y-m-d H:i:s");

        $this->logger = new \Log('logs/app-events.log');
        //$this->logger->write("");
        //$this->logger->write("####################### Controller $agora");

        $cache_em_minutos = 7200;
        $f3->set('cache_em_minutos', $cache_em_minutos);

        session_cache_expire($cache_em_minutos);
        $cache_expire = session_cache_expire();
        $f3->set('cache_expire', $cache_expire);
        $f3->set('agora', $agora);

        //$this->logger->write("As páginas de sessão em cache expiram após $cache_expire segundos");

        session_start();

        $ehProducao = $this->ambienteEhProducao();

        if ($ehProducao) {

            //COMEÇA AQUI AS MODIFICAÇÕES FEITAS PELO KAIQUE NA PARTE DE LOGIN
            if (array_key_exists("iPlanetDirectoryPro", $_COOKIE)) { //Verifica se o usurário esta logado
                $cookie = str_replace(' ', '+', $_COOKIE['iPlanetDirectoryPro']);
                $url = 'https://app.poli.usp.br/opensso/json/attributes?subjectid=' . $cookie;
                $response =  @file_get_contents($url);
                if ($response) { //Verifica se há resposta da usp em relação ao login
                    $opensso_json = json_decode($response);
                    $this->f3->set('codpes', (int)$opensso_json->codpes);
                    $this->f3->set('email', trim($opensso_json->codema));
                    $this->f3->set('nompes', trim($opensso_json->nompes));
                } else { // Direciona para logar 
                    header("Location: https://app.poli.usp.br/opensso/UI/Login?goto=http:$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
                    exit;
                }
            } else { // Direciona para logar
                header("Location: https://app.poli.usp.br/opensso/UI/Login?goto=http:$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
                exit;
            }
            //ACABA AQUI O TRECHO QUE O KAIQUE INCLUI PARA MODIFCAÇÃO DE LOGIN
        } else {
            // ambiente de desenvolvimento
            $this->f3->set('codpes', 3040414);
            $this->f3->set('email', 'rveira@usp.br');
            $this->f3->set('nompes', 'Ricardo Oliveira');
        }

        $papel = $this->consultaPapelApp($this->f3->get('codpes'));
        $this->f3->set('papel', $papel);

        $data = new DateTime();
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::FULL,
            IntlDateFormatter::SHORT,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN
        );
        $data_completa = $formatter->format($data);
        $this->f3->set('data_completa', $data_completa);
    }


    function afterroute($f3, $args)
    {
        $agora = date_create(date("Y-m-d H:i:s"));
        $user_login_date = date_create($f3->get('ult_login'));
        $diff = date_diff($user_login_date, $agora);
        $dif_dia = intval($diff->format('%d'));
        $dif_hora = intval($diff->format('%h'));
        $dif_min = intval($diff->format('%i'));
        $seg = $diff->format('%s');
        $cache_expire = intval($f3->get('cache_expire'));
        $min_dia = $dif_dia > 0 ? ($dif_dia * 24) * 60 : 0;
        $min_tot_dia = $min_dia > 0 ? ($min_dia + $dif_min) * 60 : $dif_min * 60;
        $min_tot = $dif_hora > 0 ? ($dif_hora * 3600) + $min_tot_dia : $min_tot_dia;

        //$this->logger->write('afterroute Controller logado? ' . $f3->get('codpes'));
        //$this->logger->write('afterroute Controller papel?  ' . $f3->get('papel'));
        //$this->logger->write('host name:                    ' . $f3->get('host_name'));
        //$this->logger->write('hora que loguei:              ' . $user_login_date->format('d-m-Y H:i:s'));
        //$this->logger->write('agora:                        ' . $agora->format('d-m-Y H:i:s'));
        //$this->logger->write("dif:                          $dif_dia - $dif_hora:$dif_min:$seg");

        if (intval($min_tot) > $cache_expire) {
            //$this->logger->write("tempo [$min_tot] é maior que o limite [$cache_expire]");
            unset($_SESSION['codpes']);
            $this->f3->reroute('https://app.poli.usp.br/opensso/UI/Logout');
            exit();
        } else {
            //$this->logger->write('limite em segundos:           ' . $cache_expire);
            //$this->logger->write('segundos passados:            ' . $min_tot);
            //$this->logger->write("segundos restantes:           " . $f3->get('codpes') . " - " . ($cache_expire - $min_tot));
        }
    }


    function __construct()
    {
        $f3 = Base::instance();
        $this->f3 = $f3;

        $db = new DB\SQL(
            $f3->get('db_dsn'),
            $f3->get('db_user'),
            $f3->get('db_pass'),
            array(
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, //exibe possíveis erros do mysql para a aplicação
                \PDO::ATTR_EMULATE_PREPARES => false, // performace
                \PDO::ATTR_STRINGIFY_FETCHES => false // mostra int como int não string
            )
        );
        if ($f3->DEBUG == 0) {
            $db->log(false);
        }
        $this->db = $db;

        $db_r = new DB\SQL(
            $f3->get('db_dsn_r'),
            $f3->get('db_user_r'),
            $f3->get('db_pass_r'),
            array(
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, //exibe possíveis erros do mysql para a aplicação
                \PDO::ATTR_EMULATE_PREPARES => false, // performace
                \PDO::ATTR_STRINGIFY_FETCHES => false // mostra int como int não string
            )
        );
        if ($f3->DEBUG == 0) {
            $db_r->log(false);
        }
        $this->db_r = $db_r;
    }


    protected function parseQuery($uri)
    {
        $url_dns = 'http://localhost';
        $query = parse_url($url_dns . $uri, PHP_URL_QUERY);
        $this->queryParams = array();
        parse_str($query, $this->queryParams);
        foreach ($this->queryParams as $key => $value) {
            $this->queryParams[$key] = explode(',', $value);
        }
        $this->uri = parse_url($url_dns . $uri, PHP_URL_PATH);
    }


    function ambienteEhProducao()
    {
        $ehProducao = false;

        $production_identifiers = [
            'dev.poli.usp.br',
            'app.poli.usp.br',
        ];

        $current_identifier = $_SERVER['HTTP_HOST'];

        if (in_array($current_identifier, $production_identifiers)) {
            $ehProducao = true;
        }
        return $ehProducao;
    }

    public function retorna_periodo_hoje()
    {
        $periodo = 0;
        $per = 1;
        $ano = date("Y");
        $mes = date("m");
        if ($mes > 6) {
            $per = 2;
        }
        $periodo = $ano . $per;
        return $periodo;
    }


    public function retorna_lista_pareceres()
    {
        $parecer_arr = array(
            'AG' => "Aguardando",
            'AQ' => "Arquivado",
            'DF' => "Deferido",
            'DV' => "Desfavorável",
            'FV' => "Favorável",
            'IN' => "Indeferido",
            'NH' => "Não Há",
            'PC' => "Parcial",
        );

        return $parecer_arr;
    }

    public function descricaoMes($mes)
    {
        $nomeMes = "Janeiro";

        switch ($mes) {
            case 1:
                $nomeMes = "Janeiro";
                break;
            case 2:
                $nomeMes = "Fevereiro";
                break;
            case 3:
                $nomeMes = "Março";
                break;
            case 4:
                $nomeMes = "Abril";
                break;
            case 5:
                $nomeMes = "Maio";
                break;
            case 6:
                $nomeMes = "Junho";
                break;
            case 7:
                $nomeMes = "Julho";
                break;
            case 8:
                $nomeMes = "Agosto";
                break;
            case 9:
                $nomeMes = "Setembro";
                break;
            case 10:
                $nomeMes = "Outubro";
                break;
            case 11:
                $nomeMes = "Novembro";
                break;
            case 12:
                $nomeMes = "Dezembro";
                break;
            default:
                $nomeMes = "Janeiro";
        }
        return $nomeMes;
    }

    public function data_em_string($data_s)
    {
        $data = strtotime($data_s);
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::MEDIUM,
            IntlDateFormatter::NONE,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN,
            "dd/MMM/YYYY"
        );
        $agora_str = $formatter->format($data);
        return $agora_str;
    }

    public function consultaPapelApp($codpes)
    {
        $papel = 'usr';

        $sql = "SELECT PA.nome as papel FROM helios.APLICACAO AP, helios.AUTORIZACAO AU, helios.MEMBRO ME, helios.PAPEL PA
        where AP.nome = 'hebe'
        and AP.id = AU.aplicacao_id
        and ME.grupo_id = AU.grupo_id
        and PA.aplicacao_id=AP.id
        and AU.papel_id = PA.id
        and ME.codlog=? order by PA.nome";
        $papel_app = $this->db_r->exec($sql, $codpes);

        //$this->logger->write("papel_app: " . $papel_app[0]['papel']);

        if (empty($papel_app)) {
            $sql_loc = "SELECT DISTINCT AP.nome AS app, PP.nome AS papel, G.nome AS grupo, L.nomabvset, P.nompes AS nome, P.codpes AS codlog
            FROM (((((helios.LOTACAO L JOIN helios.GRUPO G ON ((G.id = L.grupo_id)))
            JOIN replicado.LOCALIZAPESSOA P ON ((L.codset = P.codset))) JOIN
            helios.AUTORIZACAO A ON ((A.grupo_id = G.id))) JOIN helios.APLICACAO AP ON
            ((A.aplicacao_id = AP.id))) JOIN helios.PAPEL PP ON
            ((A.papel_id = PP.id))) WHERE AP.nome='hebe' AND P.codpes = ?";
            $locacao = $this->db_r->exec($sql_loc, $codpes);

            //$this->logger->write("locacao: " . $locacao[0]['papel']);

            if (empty($locacao)) {
                $sql_vin = "SELECT AP.nome AS app, PP.nome AS papel,
                G.nome AS grupo, V.tipvin as vin, P.nompes AS nome, P.codpes AS codlog FROM
                (((((helios.VINCULO V JOIN helios.GRUPO G ON ((G.id = V.grupo_id)))
                JOIN replicado.LOCALIZAPESSOA P ON ((V.tipvin = P.tipvin)))
                JOIN helios.AUTORIZACAO A ON ((A.grupo_id = G.id)))
                JOIN helios.APLICACAO AP ON ((A.aplicacao_id = AP.id)))
                JOIN helios.PAPEL PP ON ((A.papel_id = PP.id)))
                WHERE (AP.nome='hebe' and P.codpes= ?)";
                $vinculo = $this->db_r->exec($sql_vin, $codpes);

                //$this->logger->write("vinculo: " . $vinculo[0]['papel']);

                if (!empty($vinculo)) {
                    $papel = $vinculo[0]['papel'];
                }
            } else {
                $papel = $locacao[0]['papel'];
            }
        } else {
            $papel = $papel_app[0]['papel'];
        }
        return $papel;
    }

    function imprimePost()
    {
        foreach ($_POST as $key => $value) {
            $this->logger->write("POST: '$key' => '$value'");
        }
    }

    function imprimeGet()
    {
        foreach ($_GET as $key => $value) {
            $this->logger->write("GET: '$key' => '$value'");
        }
    }

    function objToJson($obj)
    {
        $obj_keys = array();
        $obj_values = array();
        $obj_combine[] = array();

        //$this->logger->write("tamanho obj: ".sizeof($obj));

        for ($i = 0; $i < count($obj); $i++) {
            //$this->logger->write("registro [$i]: ".json_encode($obj[$i]));
            foreach ($obj[$i] as $key => $val) {
                array_push($obj_keys, $key);
                array_push($obj_values, $val);
                // $this->logger->write("key[$i]: $key => val: $val");
            }
            try {
                $obj_combine[$i] = array_combine($obj_keys, $obj_values);
            } catch (Exception $e) {
                $this->logger->write("Erro na função : array_combine - $e");
            }
        }

        $obj_jsonfy = json_encode($obj_combine);

        return $obj_jsonfy;
    }


    function formataTexto($texto)
    {
        $retorna = str_replace(",", " ", $texto);
        $retorna = $this->remove_accents($retorna);
        return trim(strtolower($retorna));
    }

    function remove_accents($text)
    {
        $trans = array(
            'À' => 'A',
            'Á' => 'A',
            'Â' => 'A',
            'Ã' => 'A',
            'Ä' => 'A',
            'Å' => 'A',
            'Ç' => 'C',
            'È' => 'E',
            'É' => 'E',
            'Ê' => 'E',
            'Ë' => 'E',
            'Ì' => 'I',
            'Í' => 'I',
            'Î' => 'I',
            'Ï' => 'I',
            'Ò' => 'O',
            'Ó' => 'O',
            'Ô' => 'O',
            'Õ' => 'O',
            'Ö' => 'O',
            'Ø' => 'O',
            'Ù' => 'U',
            'Ú' => 'U',
            'Û' => 'U',
            'Ü' => 'U',
            'à' => 'a',
            'á' => 'a',
            'â' => 'a',
            'ã' => 'a',
            'ä' => 'a',
            'å' => 'a',
            'ç' => 'c',
            'è' => 'e',
            'é' => 'e',
            'ê' => 'e',
            'ë' => 'e',
            'ì' => 'i',
            'í' => 'i',
            'î' => 'i',
            'ï' => 'i',
            'ò' => 'o',
            'ó' => 'o',
            'ô' => 'o',
            'õ' => 'o',
            'ö' => 'o',
            'ù' => 'u',
            'ú' => 'u',
            'û' => 'u',
            'ü' => 'u',
            'Ā' => 'A',
            'ā' => 'a',
            'Ă' => 'A',
            'ă' => 'a',
            'Ą' => 'A',
            'ą' => 'a',
            'Ē' => 'E',
            'ē' => 'e',
            'Ĕ' => 'E',
            'ĕ' => 'e',
            'Ė' => 'E',
            'ė' => 'e',
            'Ę' => 'E',
            'ę' => 'e',
            'Ě' => 'E',
            'ě' => 'e',
            'Ĩ' => 'I',
            'ĩ' => 'i',
            'Ī' => 'I',
            'ī' => 'i',
            'Ĭ' => 'I',
            'ĭ' => 'i',
            'Į' => 'I',
            'į' => 'i',
            'İ' => 'I',
            'i',
            'Ō' => 'O',
            'ō' => 'o',
            'Ŏ' => 'O',
            'ŏ' => 'o',
            'Ő' => 'O',
            'ő' => 'o',
            'Ũ' => 'U',
            'ũ' => 'u',
            'Ū' => 'U',
            'ū' => 'u',
            'Ŭ' => 'U',
            'ŭ' => 'u',
            'Ů' => 'U',
            'ů' => 'u',
            'Ű' => 'U',
            'ű' => 'u',
            'Ų' => 'U',
            'ų' => 'u',
        );
        return strtr($text, $trans);
    }

    function niverMesDia($mes, $dia)
    {
        $sql = "SELECT DAY(P.dtanas) as dia, P.codpes, P.nompes, P.dtanas, P.sexpes, L.sitatl, L.nomfnc, 
        L.codema, L.nomabvset, L.nomset, L.tipvinext, YEAR(now())- YEAR(P.dtanas) as idade 
        FROM replicado.LOCALIZAPESSOA L JOIN replicado.PESSOA P ON (L.codpes=P.codpes) 
        WHERE L.codema IS NOT NULL AND L.codundclg= 3 AND  L.codset>0 
        AND L.tipvinext <> 'Servidor Designado' AND MONTH(P.dtanas) = ? AND DAY(P.dtanas)=?";

        $result = $this->db_r->exec($sql, array($mes, $dia));

        return $result;
    }

    function retornaDiretoria($codpesniver)
    {
        $assinante = array();
        $sql = "SELECT P.codpes, P.nompes, P.dtanas, P.sexpes, L.sitatl, L.nomfnc, L.tipvinext, L.tipvin
        FROM replicado.LOCALIZAPESSOA L
        JOIN replicado.PESSOA P ON (P.codpes=L.codpes)
        WHERE L.tipvin='SERVIDOR' AND L.codundclg=3 AND (L.nomfnc like 'Diretor%' or L.nomfnc like 'Vice Dir%') order by L.nomfnc";

        $result = $this->db_r->exec($sql);

        if ($codpesniver == $result[0]['codpes']) {
            $assinante = $result[1];
        } else {
            $assinante = $result[0];
        }

        return $assinante;
    }


    public function enviaEmail($to, $subject, $mensagem)
    {
        $header = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
        'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
        $header .= "<html lang='pt-br' dir='ltr'>";
        $header .= "<head><meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
        $header .= "<style> body { font-family: Arial, sans-serif; font-size: 14px; color: #333; } </style></head>";
        $envio = 0;

        try {
            $envio = $this->enviaEmail_PHPMailer($to, $subject, $mensagem, $header);
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
        }
        //$this->logger->write("Email enviado? '" . $envio . "'");
        return $envio;
    }

    public function enviaRelatorio($subject, $mensagem)
    {

        $to = array("servico.pessoal.poli@usp.br", "Serviço Pessoal Poli/USP");
        $header = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
        'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";
        $header .= "<html lang='pt-br' dir='ltr'>";
        $header .= "<head><meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
        $header .= "<style> body { font-family: Arial, sans-serif; font-size: 14px; color: #333; } </style></head>";

        $envio = 0;

        try {
            $envio = $this->enviaEmail_PHPMailer($to, $subject, $mensagem, $header);
        } catch (Exception $e) {
            $this->logger->write("Exceção: '$e'");
        }
        //$this->logger->write("Relatório: '" . strip_tags($mensagem) . "'");
        return $envio;
    }

    function enviaEmail_PHPMailer($to, $subject, $message, $header)
    {

        $from = array("servico.pessoal.poli@usp.br", "Serviço Pessoal Poli/USP");
        $success = false;
        // Crie uma nova instância do PHPMailer
        $mail = new PHPMailer;
        // Configure as opções do SMTP
        $mail->isSMTP();
        $mail->CharSet = "UTF-8";                          //encoding para caracteres especiais
        $mail->Host       = "adproxy";  //Set the SMTP server to send through
        $mail->Username   = "";         //SMTP username
        $mail->Password   = "";         //SMTP password 
        $mail->SMTPAuth   = false;      //Enable SMTP authentication
        $mail->SMTPAutoTLS = false;
        $mail->SMTPSecure = false;      //$mail->SMTPSecure = 'tls';
        $mail->Port       = 25;  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        // Defina os detalhes do email
        // $mail->AltBody = 'Conteúdo do seu email em texto simples';
        // $mail->addAttachment('/caminho/para/anexo/arquivo.pdf');
        $mail->setFrom($from[0], $from[1]);

        //teste envio email, enviar para mim somente
        if ($this->f3->get('codpes') == 3040414) {
            $mail->addAddress($this->f3->get('email'), $this->f3->get('nompes'));     //Add a recipient
        } else {
            $mail->addAddress($to[0], $to[1]);     //Add a recipient
        }
        $mail->addReplyTo($from[0], "ReplyTo");
        if ($to[0] == 'servico.pessoal.poli@usp.br') {
            $mail->addBCC('ricardo.leandro@usp.br'); // enviar relatório com copia oculta
            $mail->addBCC('informatica.poli@usp.br'); // enviar relatório com copia oculta
        }
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        // Embute a imagem no e-mail
        $root = dirname(__DIR__, 2); // sobe 2 níveis: controllers -> app -> raiz
        $logo_path = $root . "/app/static/images/malingpoli.png";
        $mail->addEmbeddedImage($logo_path, "logo_cid");

        $body = "<body>
        <div style='text-align:center;border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>
        <a href='http://www.poli.usp.br' target='_blank'>
            <img src='cid:logo_cid' alt='Logo Poli USP'></a>
            </div><br>";

        $mensagem = $header . $body . $message . "<br></body></html>";
        $mail->isHTML(true);
        $mail->Body = $mensagem;
        // opcional para incluir uma versão em texto simples do email,
        // caso o cliente de email do destinatário não suporte HTML
        $mail->AltBody = strip_tags($message);

        // Envie o email
        try {
            $success = $mail->send();
        } catch (Exception $e) {
            $this->logger->write("Erro ao enviar email: [" . $e->getMessage() . "]" . $mail->ErrorInfo);
        }
        if (!$success)
            $this->logger->write("Erro no envio para email: " . $to[0] . " - " . "{$mail->ErrorInfo}");
        $envio = $success == true ? "Enviado para " . $to[0] . " com sucesso!" : "Não enviado para " . $to[0];
        $this->logger->write("envio: [$envio]");
        return $success;
    }

    function retornaDataCompleta($data_str)
    {
        date_default_timezone_set("America/Sao_Paulo");
        $formatter = new IntlDateFormatter(
            'pt_BR',
            IntlDateFormatter::FULL,
            IntlDateFormatter::NONE,
            'America/Sao_Paulo',
            IntlDateFormatter::GREGORIAN
        );
        $data_completa = $formatter->format(strtotime($data_str));
        return $data_completa;
    }
}
