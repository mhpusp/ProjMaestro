let prefixo_url = "/hebef3";
moment.locale("pt-br"); // pt-br

// função mensagem
function mensagem(msgs) {
  if (Array.isArray(msgs)) {
    msgs.forEach((mg) => {
      adicionaItemNaLista(mg, "lista_msg");
    });
    $("#jsmessage").show();
  } else {
    $("#jsmessage").text(msgs);
    $("#jsmessage").show();
  }
}

// funcao para adicionar um item na div mensagem quando for um array de menagens
function adicionaItemNaLista(texto, lista) {
  //console.log(texto, lista)
  elem = document.getElementById(lista);
  if (elem) {
    var node = document.createElement("LI"); // Create a <li> node
    var textnode = document.createTextNode(texto); // Create a text node
    node.appendChild(textnode); // Append the text to <li>
    document.getElementById(lista).appendChild(node); // Append <li> to <ul> with id="lista_msg"
  } else {
    $("#jsmessage").text(texto);
    $("#jsmessage").show();
  }
}

function espera_redirect(tempo, url) {
  setTimeout(function () {
    window.location.href = url;
  }, tempo);
}

function formataData(data_str) {
  if (data_str) {
    let [ano, mes, dia] = data_str.split("-");

    if (dia.toString().length == 1) dia = "0" + dia;
    if (mes.toString().length == 1) mes = "0" + mes;

    return dia + "/" + mes + "/" + ano;
  }
}

function formatStrToDate(data_str) {
  if (data_str) {
    let [dia, mes, ano] = data_str.split("/");

    if (dia.toString().length == 1) dia = "0" + dia;
    if (mes.toString().length == 1) mes = "0" + mes;

    return ano + "-" + mes + "-" + dia;
  }
}

function trataString(str) {
  let result = str.replace("{", "");
  result = result.replace("}", "");
  result = result.replaceAll('"', "");
  result = result.replace(":", " -> ");
  return result;
}

function criaTable(lista, tit, cabecalho) {
  return `<h3 class="title">${tit}</h3>
  <table id="tb_principal" class="display table table-striped table-bordered nowrap" style="width: 100%;">
  <thead>
    <tr>
        ${retorna_cabecalho(cabecalho)}
    </tr>
    </thead>
    <tbody>
  ${criaTrTable(lista)}
  </tbody>
  </table>`;
}

function retorna_cabecalho(cab) {
  var retorno = ``;
  for (var i = 0; i < cab.length; i++) {
    retorno += `<th>${cab[i]}</th>`;
  }
  return retorno;
}

function criaTrTable(lista) {
  var retorno = "";
  for (const ind in lista) {
    retorno += `<tr>`;
    //    retorno += `<td><input type="checkbox" id="cb${ind}" value="1" name="selecionado"></td>`;
    // retorno += `<td><input type="checkbox" id="${lista[ind].id}" value="1" name="selecionado"></td>`;
    for (const ind2 in lista[ind]) {
      // console.log(`${ind2} -> ${lista[ind][ind2]}`);
      retorno += `<td>${lista[ind][ind2]}</td>`;
    }
    retorno += `</td>`;
  }
  return retorno;
}

function imprimeObjeto(obj) {
  let objstr = JSON.stringify(obj, null, 4);
  console.log(`objstr: ${objstr}`);
}

function imprimeArray(arr) {
  let txt = "";
  for (let x in arr) {
    txt += arr[x];
    console.log(`arr[${x}]: ${txt}`);
  }
}

function convertToCSV(objArray) {
  var array = typeof objArray != "object" ? JSON.parse(objArray) : objArray;
  var str = "";

  // Forçando o Excel a usar UTF-8 para CSV
  // colocando um BOM (Byte Order Mark) como primeiros caracteres no arquivo.
  // var universalBOM = "\uFEFF";

  for (var i = 0; i < array.length; i++) {
    var line = "\uFEFF";
    for (var index in array[i]) {
      if (line != "\uFEFF") line += ";";

      line += array[i][index];
    }

    str += line + "\r\n";
  }

  return str;
}

function exportCSVFile(headers, items, fileTitle) {
  if (headers) {
    items.unshift(headers);
  }

  // imprimeObjeto(items);

  // Convert Object to JSON
  var jsonObject = JSON.stringify(items);

  var csv = this.convertToCSV(jsonObject);

  var exportedFilenmae = fileTitle + ".csv" || "export.csv";
  // alterado o charset para cp-1252 (windows-1252)
  var blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  if (navigator.msSaveBlob) {
    // IE 10+
    navigator.msSaveBlob(blob, exportedFilenmae);
  } else {
    var link = document.createElement("a");
    if (link.download !== undefined) {
      // feature detection
      // Browsers that support HTML5 download attribute
      var url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", exportedFilenmae);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
}

// função para o dia de hoje
function hoje() {
  let agora = new Date();
  let ano = agora.getFullYear();
  let dia = agora.getDate();
  let mes = agora.getMonth() + 1;
  let hora = agora.getHours();
  let min = agora.getMinutes();
  if (dia.toString().length == 1) dia = "0" + dia;
  if (mes.toString().length == 1) mes = "0" + mes;
  if (hora.toString().length == 1) hora = "0" + hora;
  if (min.toString().length == 1) min = "0" + min;
  return dia + "/" + mes + "/" + ano + " " + hora + ":" + min;
}

// função para o dia de hoje
function nome_arquivo(nome) {
  let agora = new Date();
  let ano = agora.getFullYear();
  let dia = agora.getDate();
  let mes = agora.getMonth() + 1;
  let hora = agora.getHours();
  let min = agora.getMinutes();
  if (dia.toString().length == 1) dia = "0" + dia;
  if (mes.toString().length == 1) mes = "0" + mes;
  if (hora.toString().length == 1) hora = "0" + hora;
  if (min.toString().length == 1) min = "0" + min;
  return nome + "_" + ano + "_" + mes + "_" + dia + "_" + hora + "_" + min;
}

// funçoes carregadas no load
$(document).ready(function () {
  $(".btn_lista").on("click", function () {
    //console.log(`botão selecionado`);
    $(".load").show(); // habilita/deshabilita engrenagem

    let tipoServidorSelecionado = $("#tipo").val();
    let sexpes = $("input[name='sexpes']:checked").val();
    let anoIngressoSelecionado = $("#ano").val();
    let codigoSetorSelecionado = $("#lot").val();
    let codigoAreaSetorSelecionado = $("#alot").val();
    let carreiraSelecionada = $("#car").val();
    let categoriaSelecionada = $("#cat").val();
    let classificacaoSelecionada = $("#cla").val();
    let tipoFuncaoSelecionada = $("#tfun").val();
    let nomeFuncaoSelecionada = $("#fun").val();
    let jornadaSelecionada = $("#jor").val();
    let nivelSelecionado = $("#niv").val();
    let condicaoSelecionada = $("#con").val();
    let tiplis = $("input[name='tiplis']:checked").val();

    const tab_dinamica = document.querySelector("#tab_dinamica");
    tab_dinamica.style.display = "none";

    //let tiplis2 = $("input[name='xls']:checked").val();  // 'on' or 'undefined'
    //console.log(`tipoServidorSelecionado: ${tipoServidorSelecionado}`);
    //console.log(`sexpes: ${sexpes}`);
    //console.log(`anoIngressoSelecionado: ${anoIngressoSelecionado}`);
    //console.log(`codigoSetorSelecionado: ${codigoSetorSelecionado}`);
    //console.log(`codigoAreaSetorSelecionado: ${codigoAreaSetorSelecionado}`);
    //console.log(`carreiraSelecionada: ${carreiraSelecionada}`);
    //console.log(`categoriaSelecionada: ${categoriaSelecionada}`);
    //console.log(`classificacaoSelecionada: ${classificacaoSelecionada}`);
    //console.log(`tipoFuncaoSelecionada: ${tipoFuncaoSelecionada}`);
    //console.log(`nomeFuncaoSelecionada: ${nomeFuncaoSelecionada}`);
    //console.log(`jornadaSelecionada: ${jornadaSelecionada}`);
    //console.log(`nivelSelecionado: ${nivelSelecionado}`);
    //console.log(`condicaoSelecionada: ${condicaoSelecionada}`);
    //console.log(`tiplis: ${tiplis}`);

    req = $.ajax({
      url: `${prefixo_url}/servidores`,
      type: "POST",
      data: {
        tipoServidor: tipoServidorSelecionado,
        sexpes: sexpes,
        anoIngresso: anoIngressoSelecionado,
        codigoSetor: codigoSetorSelecionado,
        codigoAreaSetor: codigoAreaSetorSelecionado,
        carreira: carreiraSelecionada,
        categoria: categoriaSelecionada,
        classificacao: classificacaoSelecionada,
        tipoFuncao: tipoFuncaoSelecionada,
        nomeFuncao: nomeFuncaoSelecionada,
        jornada: jornadaSelecionada,
        nivel: nivelSelecionado,
        condicao: condicaoSelecionada,
      },
    });

    req
      .done(function (data) {
        var jsonData = JSON.parse(data);
        //window.location.href = `${prefixo_url}/servidores?busca=${jsonData.busca}`;
        //console.log(`jsonData.servidores: ${jsonData.servidores}`);
        var lista = JSON.parse(jsonData.servidores);
        var tit = jsonData.msg;
        var cabecalho = jsonData.cabecalho;
        //var tipo = jsonData.tiplis;
        var tot = jsonData.total;

        //console.log(`cabeçalho : ${cabecalho}`);
        //imprimeObjeto(lista[0]);

        if (lista) {
          if (tiplis == "xls") {
            // gera arquivo
            //cria csv de alunos
            var fileTitle = nome_arquivo("servidores"); // nome do arquivo

            //cabecalho
            var headers = {
              codpes: "Nr. USP",
              nompes: "Nome",
              sexpes: "Sexo",
              tipvin: "Vínculo",
              tipvinext: "Tipo",
              datainicio: "Início",
              nomcaa: "Carreira",
              nomabvcla: "Classificação",
              nivgrupvm: "Nível",
              nomabvfnc: "Função",
              tipfnc: "Tipo",
              tipjor: "Jornada",
              tipmer: "Mérito",
              tipcon: "Contrato",
              codema: "E-mail",
              lotacao: "Lotação",
              dtanas: "Nascimento",
            };

            exportCSVFile(headers, lista, fileTitle); // chamando a funcao exportCSVFile() para procesar o JSON e fazer o download
          }

          if (tot > 0) {
            
            //imprimeObjeto(lista);
            // Rotina para excluir registros com codpes não numérico
            lista = lista.filter((objeto) => {
              return typeof objeto.codpes === "number";
            });
            //console.log(`lista: depois do filter`);
            //imprimeObjeto(lista);
            tab_dinamica.innerHTML = criaTable(lista, tit, cabecalho);
            tab_dinamica.style.display = "block";
          } else {
            tab_dinamica.innerHTML = `Não há registros com estes parâmetros!`;
            tab_dinamica.style.display = "block";
          }
          // colocado aqui para reformatar a tabela depois de criada no js
          var datatableInstance = $("#tb_principal").DataTable({
            language: {
              url: "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Portuguese-Brasil.json",
            },
            order: [[1, "asc"]],
          });

          $(".load").toggle(); // habilita/deshabilita engrenagem

          //
        } else {
          tab_dinamica.innerHTML = `Não há registros com estes parâmetros!`;
          tab_dinamica.style.display = "block";
        }

        mensagem(jsonData.msg);
      })
      .fail(function (req, exception) {
        // Our error logic here
        var msg = "";
        if (req.status === 0) {
          msg = "Limite de conexão expirado.\n Logue novamente na aplicação.";
        } else if (req.status == 404) {
          msg = "Página não encontrada. [404]";
        } else if (req.status == 500) {
          msg = "Erro interno do servidor [500].";
        } else if (exception === "parsererror") {
          msg = "Falha em formatar o JSON.";
        } else if (exception === "timeout") {
          msg = "Erro fora do limite do tempo.";
        } else if (exception === "abort") {
          msg = "Solicitação do Ajax abortada.";
        } else {
          msg = "Uncaught Error.\n" + req.responseText;
        }
        mensagem(msg);
        alert(msg);
        espera_redirect(1000, `${prefixo_url}/`);
        //$(".load").toggle();
      }); // fim do ajax com tratamento de erro
  }); // fim do evento btn_lista
});
