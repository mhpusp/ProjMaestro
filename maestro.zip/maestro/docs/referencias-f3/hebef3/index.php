<?php
//Load Composer's autoloader
require(__DIR__ . '/vendor/autoload.php');

$f3 = \Base::instance();

$host_name = gethostname();
$f3->set('host_name', $host_name);


$production_identifiers = [
    'dev.poli.usp.br',
    'app.poli.usp.br',
];

$current_identifier = $_SERVER['HTTP_HOST'] ?? $host_name();

if (in_array($current_identifier, $production_identifiers)) {
    $config_path = __DIR__ . '/config/production.ini';
} else {
    $config_path = __DIR__ . '/config/development.ini';
}

$routes_path = __DIR__ . '/config/routes.ini';

if (file_exists($config_path) === false) {
    die('Falta o arquivo config');
}

if (file_exists($routes_path) === false) {
    die('Falta o arquivo de rotas');
}

$f3->config($config_path);
$f3->config($routes_path, true);

$excel = \Sheet::instance();

$f3->run();
