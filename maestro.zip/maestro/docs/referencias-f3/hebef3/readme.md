Cria arquivo composer.json
======================

{
    "name": "ricardo/f3sheet",
    "authors": [
        {
            "name": "3040414",
            "email": "rveira@usp.br"
        }
    ],
    "require": {"bcosca/fatfree": "3.8",
        "ikkez/f3-sheet":"v0.4.2"
    }
}

    inicializa o composer
        composer init (cria o arquivo composer.json)
    instala dependencias iniciais:
        composer update

    instalando biblioteca do ikkez:
        composer require ikkez/f3-sheet

    desinstalando biblioteca
        composer remove ikkez/f3-mailer


criando um repositório
======================
    crie o repositório no gitpoli
    execute estas linhas no seu projeto:
    git init
    git checkout -b main
    git commit -m "first commit"
    git remote add origin https://git.poli.usp.br/stdev/heliosf3.git
    git push -u origin main


    url para receber o json papeis:
    ===============================

        kardo.poli.usp.br/heliosf3/papel_usuario_app?app=requerimento&codpes=3040414
        dev.poli.usp.br/heliosf3/papel_usuario_app?app=consultapessoa&codpes=7943589
        dev.poli.usp.br/heliosf3/papel_usuario_app?app=libra&codpes=5345272


    Para implementar o PHPMailer em uma aplicação PHP usando o Fat-Free Framework, siga estas etapas:

Instalação do PHPMailer:
Você pode instalar o PHPMailer usando o Composer. Adicione a seguinte linha ao seu arquivo composer.json:

"phpmailer/phpmailer": "~5.2"

Em seguida, execute o comando:
 composer require phpmailer/phpmailer
 
Crie um script PHP (por exemplo, send_email.php) no diretório do seu projeto do Fat-Free Framework.
Configure o PHPMailer com os detalhes do seu servidor SMTP

Lembre-se de substituir os espaços reservados pelos seus próprios detalhes de email e servidor SMTP.
Execute o script usando a interface de linha de comando do PHP ou integre-o à sua aplicação do Fat-Free Framework. Por exemplo, você pode criar um endpoint em sua aplicação que acione o processo de envio de email.
O PHPMailer é uma biblioteca poderosa e flexível para envio de emails em projetos PHP. Com essas configurações, você poderá enviar emails com facilidade usando o SMTP do Gmail ou qualquer outro servidor SMTP de sua escolha.

    <?php
    use PHPMailer\PHPMailer\PHPMailer;

    // Crie uma nova instância do PHPMailer
    $mail = new PHPMailer;

    // Configure as opções do SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->SMTPAuth = true;
    $mail->Username = 'seu_email@gmail.com';
    $mail->Password = 'sua_senha';

    // Defina os detalhes do email
    $mail->setFrom('seu_email@gmail.com', 'Seu Nome');
    $mail->addReplyTo('replyto@seusite.com', 'Seu Nome');
    $mail->addAddress('destinatario@example.com', 'Nome do Destinatário');
    $mail->Subject = 'Assunto do seu email';
    $mail->CharSet = 'UTF-8';
    $mail->msgHTML("<p>Conteúdo do seu email em formato HTML</p>");
    $mail->AltBody = 'Conteúdo do seu email em texto simples';
    $mail->addAttachment('/caminho/para/anexo/arquivo.pdf');

    // Envie o email
    if (!$mail->send()) {
        die("Erro no envio do email: {$mail->ErrorInfo}");
    } else {
        echo 'Email enviado com sucesso';
    }
    ?>

