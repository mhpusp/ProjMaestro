<?php
// php.ini - extension=php_curl.dll
// phpinfo();

// usando o 'CRON' no linux para programar execução 
// # programado para todos os dias as 6
// 0 6 * * * php /var/www/hebef3/curl.php
// # mostando conteudo con crontab
// crontab -l
// crontab -e (caso não exista o arquivo cron, criar)


//$url = $_SERVER['HTTP_HOST'].'/hebef3/email';
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'dev.poli.usp.br';
$url = "http://$host/hebef3/email";

$iniciar = curl_init();

// curl_setopt($iniciar, CURLOPT_URL, "http://kardo.poli.usp.br/hebef3/email");
// curl_setopt($iniciar, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt_array($iniciar, [
    CURLOPT_URL => $url,
    CURLOPT_CUSTOMREQUEST => 'GET'
]);

curl_exec($iniciar);
curl_close($iniciar);
