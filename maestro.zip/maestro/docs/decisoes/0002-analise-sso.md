# 0002 - Analise da implementacao SSO nos exemplos F3

Data: 2026-06-10

## Contexto

Foram analisados os controllers das duas aplicacoes de referencia em `docs/referencias-f3`: `hebef3` e `herculesf3`. A analise focou na integracao com OpenSSO, no uso do cookie institucional para Single Sign On e no que pode ser aproveitado no projeto principal em Slim.

As duas aplicacoes possuem implementacoes muito parecidas. O fluxo de autenticacao fica principalmente em `app/controllers/Controller.php`, enquanto `app/controllers/UserController.php` cuida de registrar ou atualizar dados do usuario local, controlar parte da sessao PHP e executar logout.

## Como o SSO foi implementado

### Fluxo comum nas duas aplicacoes

O `Controller::beforeroute` e executado antes das rotas protegidas e faz quase todo o trabalho de autenticacao:

1. Define locale, timezone e dados auxiliares da requisicao.
2. Configura um tempo de sessao/cache em `cache_em_minutos`.
3. Detecta se esta em producao comparando `HTTP_HOST` com `dev.poli.usp.br` e `app.poli.usp.br`.
4. Em producao, procura o cookie `iPlanetDirectoryPro`.
5. Se o cookie existe, troca espacos por `+` e consulta `https://app.poli.usp.br/opensso/json/attributes?subjectid=<cookie>`.
6. Se o OpenSSO responde, extrai `codpes`, `codema` e `nompes` do JSON e injeta esses valores no contexto F3.
7. Se nao ha cookie ou nao ha resposta valida, redireciona para `https://app.poli.usp.br/opensso/UI/Login`, passando um `goto` com host e URI atuais.
8. Em desenvolvimento, ignora o OpenSSO e injeta um usuario fixo.

Depois disso, cada aplicacao consulta papel/perfil do usuario no banco e disponibiliza informacoes como `papel`, `nome_usr`, `depto` e `data_completa` para os controllers e views.

### Uso do cookie de Single Sign On

O cookie usado para SSO e `iPlanetDirectoryPro`. Ele nao e criado pela aplicacao; ele e esperado como cookie ja emitido pelo OpenSSO no dominio institucional. A aplicacao usa esse cookie como token de sessao externa e valida sua autenticidade indiretamente ao chamar o endpoint `/opensso/json/attributes`.

Esse desenho tem uma vantagem importante: a aplicacao nao tenta interpretar o conteudo do cookie localmente. Ela delega a validacao do token ao proprio OpenSSO e usa apenas os atributos retornados.

Tambem ha manipulacao do cookie da sessao PHP, mas isso e diferente do cookie de SSO. Em `UserController::login`, as aplicacoes leem `session_name()` e renovam o cookie de sessao PHP com `setcookie(...)`. Essa renovacao tenta manter a sessao local viva, mas nao renova necessariamente a sessao do OpenSSO.

### Logout

O logout limpa a sessao local do F3/PHP e redireciona para `https://app.poli.usp.br/opensso/UI/Logout`. Isso e correto conceitualmente porque o logout de SSO precisa encerrar a sessao no provedor, nao apenas na aplicacao.

## Pontos fortes

### Delegacao da autenticacao ao provedor institucional

As aplicacoes nao armazenam senha e nao implementam autenticacao propria. Elas aceitam o cookie `iPlanetDirectoryPro` apenas como identificador de sessao OpenSSO e consultam o endpoint oficial de atributos. Esse e o principal comportamento a preservar.

### Contexto de usuario simples e familiar

O resultado do SSO e normalizado para campos de dominio conhecidos pela equipe: `codpes`, `email`/`codema` e `nompes`. Esse vocabulario deve ser mantido no projeto principal, mesmo que encapsulado em classes mais modernas.

### Redirecionamento automatico para login

Quando o usuario nao esta autenticado, o fluxo redireciona para a tela de login do OpenSSO com um `goto` para voltar a URL original. A experiencia de uso e adequada: o usuario acessa uma pagina protegida, autentica no provedor e retorna para a aplicacao.

### Logout federado

O logout redireciona para `/opensso/UI/Logout`, o que evita a falsa sensacao de sair apenas da aplicacao local enquanto a sessao institucional continua ativa.

### Usuario fake em desenvolvimento

As referencias resolvem o desenvolvimento local sem depender do OpenSSO, injetando um usuario fixo fora de producao. A ideia e boa e deve ser preservada, mas movida para configuracao `.env`, sem codigos pessoais hardcoded em controller.

### Integracao com autorizacao de dominio

A autenticacao nao termina em "usuario logado"; as aplicacoes tambem calculam `papel` a partir de tabelas institucionais e do banco de apoio. Isso mostra que o projeto principal deve separar autenticacao de autorizacao: OpenSSO responde quem e o usuario; a aplicacao decide o que ele pode fazer.

## Pontos fracos

### Autenticacao dentro do controller base

O maior problema e concentrar autenticacao, sessao, ambiente, conexoes de banco, autorizacao, helpers de data, envio de email e consultas de dominio em `Controller.php`. Isso dificulta teste, reuso e evolucao.

No projeto principal, essa responsabilidade deve ficar em middleware e services dedicados, nao em controller.

### Dependencia direta de superglobais

As referencias leem `$_COOKIE`, `$_SERVER`, `$_SESSION` e usam `header()`/`exit` diretamente. Em Slim, isso deve ser substituido por `ServerRequestInterface`, atributos de request e `ResponseInterface`.

### Montagem insegura do `goto`

O redirecionamento para login monta o `goto` com interpolacao direta de `$_SERVER[HTTP_HOST]` e `$_SERVER[REQUEST_URI]`, alem de usar `http:` fixo. Isso traz riscos:

- host header injection se o host nao for validado;
- retorno para URL incorreta atras de proxy ou HTTPS;
- ausencia de `urlencode` no parametro `goto`;
- potencial abertura para redirect malformado.

No Slim, o `goto` deve ser construido com a URL base configurada (`APP_URL`/`APP_BASE_PATH`) e codificado com `rawurlencode`.

### Ambiente detectado por hostname

As referencias consideram producao quando `HTTP_HOST` esta em uma lista fixa. Isso acopla comportamento de seguranca ao dominio de deploy e pode falhar em homologacao, proxy reverso, CLI ou testes.

O projeto principal ja usa `APP_AMBIENTE` em `config/settings.php`. Esse padrao deve ser mantido.

### Uso de `@file_get_contents`

A chamada ao endpoint do OpenSSO usa `@file_get_contents`, sem timeout explicito, sem tratamento de status HTTP, sem logging adequado e suprimindo erros. Uma indisponibilidade do OpenSSO pode virar comportamento dificil de diagnosticar.

No projeto principal, usar cliente HTTP ou `stream_context_create` com timeout curto, tratamento de erro e log estruturado.

### Falta de validacao do JSON retornado

As referencias assumem que o JSON possui `codpes`, `codema` e `nompes`. Nao ha verificacao de `json_last_error`, tipo dos campos, ausencia de atributos ou resposta inesperada.

O projeto principal deve validar explicitamente a resposta antes de criar o usuario autenticado.

### Sessao local confundida com sessao SSO

O codigo renova o cookie da sessao PHP com `setcookie`, mas o valor configurado como `cache_em_minutos = 7200` e tratado de forma ambigua. `session_cache_expire` trabalha em minutos, enquanto `setcookie` espera segundos quando se soma ao `time()`. Alem disso, a sessao local nao deve ser confundida com validade do cookie OpenSSO.

No projeto principal, separar:

- validade do cookie OpenSSO, controlada pelo provedor;
- sessao local da aplicacao, controlada por middleware de sessao;
- cache de dados de usuario, se necessario, com TTL proprio.

### Expiracao baseada em `ult_login`

O `afterroute` compara `ult_login` com a hora atual para decidir se encerra sessao. Esse campo tambem e salvo no cadastro local do usuario, o que mistura auditoria de login, estado de sessao e regra de expiracao.

No projeto principal, a sessao local deve ter timestamps proprios, por exemplo `autenticado_em` e `ultimo_acesso_em`.

### Configuracoes hardcoded

URLs do OpenSSO, hosts de producao e usuario de desenvolvimento ficam no codigo. Isso reduz portabilidade e dificulta testes.

No projeto principal, esses valores devem entrar no `.env.example`:

- `SSO_HABILITADO`;
- `SSO_COOKIE_NAME`;
- `SSO_ATTRIBUTES_URL`;
- `SSO_LOGIN_URL`;
- `SSO_LOGOUT_URL`;
- `SSO_GOTO_BASE_URL`;
- `SSO_TIMEOUT`;
- `DEV_USUARIO_CODPES`;
- `DEV_USUARIO_NOME`;
- `DEV_USUARIO_EMAIL`.

### Pouca protecao nos cookies locais

A renovacao do cookie de sessao PHP usa apenas nome, valor, expira e path. Nao define `secure`, `httponly` ou `samesite`.

No projeto principal, a configuracao de sessao deve definir atributos seguros, especialmente em producao:

- `session.cookie_secure=true`;
- `session.cookie_httponly=true`;
- `session.cookie_samesite=Lax` ou `Strict`, conforme fluxo do OpenSSO permitir.

## O que pode ser aproveitado no projeto principal

### Aproveitar conceitualmente

O projeto principal ja possui um bom ponto de encaixe: `WorkplaceSessionMiddleware` cria hoje uma sessao mockada e injeta `WorkplaceSession` na requisicao. Esse middleware deve evoluir para um middleware real de SSO, mantendo `WorkplaceSession` como contrato interno para controllers e views.

O desenho recomendado e:

1. `OpenSsoMiddleware` le cookies da `ServerRequestInterface`.
2. Se `APP_AMBIENTE=desenvolvimento` e `SSO_HABILITADO=false`, cria usuario de desenvolvimento via `.env`.
3. Se SSO estiver habilitado, procura `iPlanetDirectoryPro` ou o nome configurado.
4. Consulta o endpoint de atributos do OpenSSO.
5. Valida resposta e cria `UsuarioLogado`.
6. Resolve papeis institucionais em um service separado.
7. Injeta `WorkplaceSession` no request.
8. Em caso de falha, retorna redirect PSR-7 para a URL de login.

Assim, controllers continuam simples e nao precisam conhecer OpenSSO, cookie institucional ou detalhes de sessao.

### Manter nomes de dominio

O projeto principal deve mapear os atributos do OpenSSO para nomes que a equipe reconhece:

- `codpes` como identificador institucional principal;
- `nompes` como nome;
- `codema` como email;
- `papel` ou `papeis` como autorizacoes da aplicacao.

Hoje `UsuarioLogado` usa `id`, `nome` e `email`. Isso pode ser mantido, mas vale incluir `codpes` explicitamente ou garantir que `id` represente sempre o `codpes`.

### Reaproveitar a ideia de logout federado

Criar uma rota `/logout` no Slim que:

1. limpa a sessao local da aplicacao;
2. remove dados auxiliares da `WorkplaceSession`;
3. redireciona para `SSO_LOGOUT_URL`;
4. opcionalmente passa retorno para uma pagina publica da aplicacao.

Nao basta limpar `$_SESSION`; o logout deve continuar encerrando a sessao no OpenSSO.

### Reaproveitar login automatico com retorno

O comportamento de voltar para a pagina originalmente acessada e bom. A diferenca e que o projeto principal deve construir o retorno com base em configuracao confiavel, nao em `HTTP_HOST` cru.

Exemplo de regra:

- base confiavel: `APP_URL`;
- path atual: `$request->getUri()->getPath()`;
- query atual: `$request->getUri()->getQuery()`;
- parametro final: `goto=` + `rawurlencode($urlRetorno)`.

### Preservar usuario de desenvolvimento, mas configuravel

O mock atual (`WorkplaceSession::mock`) e util no scaffold. Ele deve continuar existindo para desenvolvimento e testes, mas com dados configuraveis por `.env` e com a mesma forma final de uma sessao real.

Isso evita que controllers precisem saber se o usuario veio de mock, OpenSSO ou outro provedor futuro.

### Integrar com autorizacao existente

O projeto principal ja tem `Autorizador`, `ExigePermissao` e `config/permissoes.php`. A integracao SSO nao deve substituir isso. Ela deve alimentar a identidade; a autorizacao atual continua decidindo acesso por papel e acao.

O fluxo ideal e:

- OpenSSO autentica e fornece identidade;
- `UsuarioRepository`/`PapelRepository` busca papeis internos;
- `WorkplaceSession` carrega usuario e papel ativo;
- `ExigePermissao` usa `Autorizador` para a decisao final.

## Recomendacao de desenho para o Slim

### Componentes sugeridos

- `App\middlewares\OpenSsoMiddleware`: middleware PSR-15 que autentica, redireciona e injeta a sessao institucional.
- `App\services\OpenSsoClient`: cliente do endpoint `/opensso/json/attributes`.
- `App\services\SessaoInstitucionalService`: controla sessao local, timestamps e papel ativo.
- `App\workplace\UsuarioLogado`: incluir `codpes` explicitamente ou documentar que `id` e o `codpes`.
- `App\repositories\UsuarioRepository`: persiste ou atualiza dados locais do usuario quando necessario.
- `App\repositories\PapelRepository`: resolve papeis a partir de `codpes`.
- `config/settings.php`: centraliza URLs e nomes de cookies via `.env`.

### Configuracoes sugeridas

Adicionar ao `.env.example`:

```env
SSO_HABILITADO=false
SSO_COOKIE_NAME=iPlanetDirectoryPro
SSO_ATTRIBUTES_URL=https://app.poli.usp.br/opensso/json/attributes
SSO_LOGIN_URL=https://app.poli.usp.br/opensso/UI/Login
SSO_LOGOUT_URL=https://app.poli.usp.br/opensso/UI/Logout
SSO_TIMEOUT=3

DEV_USUARIO_CODPES=0000000
DEV_USUARIO_NOME="Usuario Desenvolvimento"
DEV_USUARIO_EMAIL=usuario.dev@example.test
DEV_USUARIO_PAPEIS=admin,operador,leitor
```

### Cuidados obrigatorios

- Nao confiar no valor do cookie sem validar no OpenSSO.
- Nao montar `goto` com `HTTP_HOST` sem whitelist ou base configurada.
- Codificar o `goto` com `rawurlencode`.
- Tratar timeout e erro HTTP na consulta ao OpenSSO.
- Validar campos obrigatorios do JSON.
- Logar falhas de SSO sem registrar o valor do cookie.
- Configurar cookies locais com `HttpOnly`, `Secure` e `SameSite`.
- Separar tempo de sessao local de validade do SSO.
- Evitar qualquer `codpes` hardcoded fora de configuracao de desenvolvimento.

## Decisao recomendada

O projeto principal deve aproveitar o comportamento funcional das referencias, mas nao a estrutura tecnica exata.

Devem ser preservados:

- uso do cookie `iPlanetDirectoryPro` como token de SSO emitido pelo OpenSSO;
- validacao do cookie por consulta ao endpoint de atributos;
- normalizacao de `codpes`, `nompes` e `codema`;
- redirecionamento automatico para login;
- logout federado no OpenSSO;
- usuario fake para desenvolvimento.

Devem ser substituidos:

- autenticacao dentro de controller base por middleware PSR-15;
- `$_COOKIE`, `$_SERVER`, `header()` e `exit` por request/response PSR-7;
- `@file_get_contents` por cliente HTTP com timeout e tratamento de erro;
- ambiente por hostname por `APP_AMBIENTE`/`.env`;
- dados hardcoded por configuracao;
- expiracao baseada em `ult_login` por sessao local dedicada.

A melhor adaptacao e transformar o `WorkplaceSessionMiddleware` atual em uma camada de sessao institucional real, alimentada por um `OpenSsoClient`. Assim o projeto principal aproveita a experiencia ja validada nas aplicacoes F3, mas com limites mais seguros, testaveis e alinhados ao Slim.
