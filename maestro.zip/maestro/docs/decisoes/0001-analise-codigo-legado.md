# 0001 - Analise dos exemplos F3 legados

Data: 2026-06-07

## Contexto

Foram analisados os exemplos em `docs/referencias-f3`, especialmente os projetos `hebef3` e `herculesf3`. A amostra mostra aplicacoes Fat-Free Framework com estrutura simples: `index.php`, `config/*.ini`, `config/routes.ini`, `app/controllers`, `app/models`, `app/views` e `app/static`.

O objetivo desta analise e separar o que deve ser preservado por familiaridade da equipe, o que deve ser melhorado no novo scaffold e o que nao deve ser replicado ao migrar o estilo para PHP Slim.

## 1. Padroes que devem ser preservados por familiaridade

### Estrutura de pastas simples

Os dois projetos seguem uma organizacao direta, com baixo custo cognitivo:

- `config/routes.ini` concentra rotas.
- `config/development.ini` e `config/production.ini` concentram configuracao.
- `app/controllers` guarda fluxos HTTP.
- `app/models` guarda classes ligadas a tabelas.
- `app/views` guarda templates HTML.
- `app/static` guarda CSS, JS e imagens.

Esse desenho e familiar e deve influenciar o scaffold Slim, ainda que com ajustes para PSR-4, `public/` e container de dependencias.

### Rotas explicitas e rastreaveis

As rotas usam um formato facil de seguir, como:

- `GET /=UserController->login`
- `GET /perfil=UserController->perfil`
- `GET|POST /servidores=ServidoresController->servidores`
- `GET|POST /ger_lista=ListaController->paginaTab`
- `POST /busca_pessoa=ListaController->buscaPessoa`

O padrao de "verbo + caminho + controller/metodo" deve ser preservado no Slim, mesmo que escrito em PHP. Isso ajuda desenvolvedores a rastrear rapidamente a jornada entre URL, controller e tela.

### Fluxo controller -> view direto

O fluxo mais comum e:

1. Controller executa `beforeroute`.
2. Controller le parametros de `$_GET` ou `$_POST`.
3. Controller consulta banco.
4. Controller popula variaveis no `$f3`.
5. Controller define `view`.
6. Controller renderiza `base.htm`.

Esse fluxo e facil de entender. No Slim, vale preservar a intencao: um metodo de controller deve deixar claro qual tela ou JSON ele retorna, sem exigir navegacao por muitas camadas abstratas.

### Layout unico com includes

Os projetos usam `base.htm` como layout comum, incluindo:

- `partes/header.htm`
- `partes/top.htm`
- `partes/menu.htm`
- `partes/messages.htm`
- a view dinamica via `{{@view}}`
- `partes/foot.htm`

Esse padrao deve ser preservado conceitualmente. No Slim, pode virar Twig com `layout.twig`, `partials/header.twig`, `partials/menu.twig` e `partials/messages.twig`.

### Vocabulario de dominio em portugues

A nomenclatura de dominio usa termos conhecidos pela equipe e pelos sistemas USP/Poli:

- `codpes`
- `nompes`
- `codema`
- `papel`
- `adm`, `opr`, `usr`
- `servidores`
- `aniversariantes`
- `listas`
- `inscritos`
- `regras`
- `gerentes`
- `lotacao`
- `setor`

Esses nomes devem ser preservados quando representarem conceitos de dominio. Trocar tudo por termos genericos em ingles aumentaria o atrito sem ganho tecnico proporcional.

### Telas orientadas a operacao

As views priorizam operacoes concretas: listar servidores, buscar pessoas, gerenciar inscritos, alterar regras, exportar XLS, enviar mala direta. O scaffold novo deve manter esse carater pragmatico, com formularios e acoes explicitas.

### Uso de Bootstrap, DataTables e jQuery em telas administrativas

Os exemplos usam Bootstrap, Bootstrap Icons, jQuery UI, DataTables, Moment e jQuery para montar tabelas e interacoes administrativas. Isso e familiar para a equipe e pode ser mantido inicialmente, desde que os scripts sejam melhor organizados e nao carreguem URLs hardcoded.

## 2. Padroes que devem ser melhorados

### Controller base com responsabilidades demais

`Controller.php` concentra autenticacao OpenSSO, sessao, locale, timezone, criacao de conexoes de banco, autorizacao, formatacao de datas, envio de e-mail, consultas de dominio e helpers diversos.

No Slim, essas responsabilidades devem ser separadas:

- autenticacao em middleware;
- sessao em middleware ou service dedicado;
- autorizacao em policy/service;
- banco em dependencias injetadas;
- e-mail em service;
- consultas em repositories;
- formatacao em helpers pequenos ou filtros de template.

### Acesso a banco disperso

Ha SQL direto em controllers e tambem em metodos utilitarios do controller base. Os models (`User`, `Inscrito`, `Regra`) sao wrappers finos de `DB\SQL\Mapper`, mas boa parte da regra real fica fora deles.

No Slim, o acesso a banco deve ficar em repositories com nomes de dominio, por exemplo:

- `UsuarioRepository`
- `PessoaRepository`
- `ListaRepository`
- `InscritoRepository`
- `RegraRepository`
- `ServidorRepository`

Controllers devem orquestrar, nao carregar SQL grande.

### Entrada HTTP por superglobais

Os exemplos leem diretamente `$_GET`, `$_POST`, `$_COOKIE`, `$_SESSION` e `$_SERVER`. Isso reduz testabilidade e cria acoplamento forte com ambiente global.

No Slim, controllers devem usar `ServerRequestInterface` para query params, parsed body, attributes e cookies. Sessao deve ser encapsulada por service ou middleware.

### Respostas HTTP por `echo`, `header()` e `exit`

Varios fluxos usam `echo json_encode(...)`, `header("Location: ...")`, `exit()` e renderizacao direta dentro do controller.

No Slim, todo metodo deve retornar `ResponseInterface`. JSON, redirect e HTML devem ter helpers padronizados:

- `return $this->view->render($response, '...', $dados);`
- `return $this->json($response, $payload);`
- `return $response->withHeader('Location', $url)->withStatus(302);`

### Autorizacao espalhada

A autorizacao aparece como condicionais locais, por exemplo `if ($papel == 'adm' || $papel == 'opr')` ou `if ($papel == 'adm')`. Esse padrao e compreensivel, mas tende a se espalhar.

No Slim, preservar os papeis `adm`, `opr` e `usr`, mas centralizar as regras em middleware ou policies simples:

- `requireRole('adm')`
- `requireAnyRole(['adm', 'opr'])`
- `canManageLista($usuario, $lista)`

### Configuracao versionada e acoplada ao ambiente

Os arquivos `.ini` incluem DSNs, usuarios e senhas de banco. Tambem ha deteccao de producao por hostname (`dev.poli.usp.br`, `app.poli.usp.br`) em `index.php` e controllers.

No Slim, o scaffold deve usar `.env` para segredos e `config/*.php` para configuracao versionavel sem credenciais. A deteccao de ambiente deve vir de `APP_ENV`, nao de hostname.

### Front-end com URLs hardcoded

Os scripts possuem prefixos como `let prefixo_url = "/hebef3"` e `let prefixo_url = "/herculesf3"`. Isso dificulta deploy com outro path e cria divergencia entre rotas e JS.

No Slim, a URL base deve ser exposta pelo template em um objeto de configuracao JS ou resolvida por helper de rotas.

## 3. Vicios que nao devem entrar no novo scaffold

### SQL por concatenacao

O exemplo mais critico esta no fluxo de servidores: criterios sao montados concatenando valores de `$_POST` em strings SQL e depois substituindo `PARAM` na query. Isso nao deve ser copiado.

Todo filtro vindo de usuario deve usar parametros preparados, whitelist de campos e validacao explicita.

### Classe Deus

O novo scaffold nao deve ter um `Controller` base acumulando autenticacao, banco, e-mail, queries, helpers, formatacao e regras de negocio. Uma classe base pequena pode existir para helpers de resposta, mas nao para concentrar dominio.

### Metodos grandes com muitos caminhos

`ListaController->paginaTab` mistura listagem, detalhe, paginacao, cadastro, exclusao, atualizacao, busca e renderizacao. Esse estilo dificulta teste e evolucao.

No Slim, dividir por acao e intencao:

- `listarListas`
- `exibirLista`
- `buscarPessoa`
- `adicionarInscrito`
- `removerInscrito`
- `adicionarRegra`
- `removerRegra`
- `atualizarInscritos`

### Misturar HTML, JSON e mutacao no mesmo fluxo

Alguns controllers renderizam tela em GET, processam POST, retornam JSON ou renderizam novamente dependendo dos parametros. Isso deve ser evitado.

Rotas de pagina e rotas de API/AJAX devem ser separadas, mesmo que fiquem no mesmo controller.

### Segredos e configuracoes sensiveis no repositorio

O scaffold nao deve versionar usuario, senha, host real de banco, SMTP sensivel ou URLs internas secretas. Usar `.env.example` com placeholders.

### Dependencia de pessoa especifica para operacao administrativa

Ha fluxo administrativo protegido por comparacao direta com um `codpes` especifico. O novo scaffold deve usar autorizacao por papel/permissao, nao por identificador hardcoded em controller.

### Comentarios historicos e codigo morto

Ha muitos comentarios de debug, blocos antigos comentados, mensagens historicas e exemplos soltos dentro dos controllers. Comentarios uteis devem explicar regra de negocio, nao manter historico de tentativa.

### Scripts front-end globais e longos

Os JS montam HTML por template string, fazem AJAX, validam, formatam data, controlam redirecionamento e criam tabelas no mesmo arquivo. O scaffold deve separar por tela ou modulo e padronizar chamadas AJAX.

## 4. Sugestoes para adaptar esse estilo para PHP Slim

### Estrutura sugerida

Manter familiaridade sem copiar acoplamentos:

- `public/index.php`
- `config/routes.php`
- `config/settings.php`
- `config/container.php`
- `app/Controllers`
- `app/Middlewares`
- `app/Repositories`
- `app/Services`
- `app/Views`
- `public/assets`

Se a equipe preferir portugues, usar portugues nos nomes de dominio e manter ingles apenas em termos tecnicos de framework. Exemplo: `ListaController`, `InscritoRepository`, `OpenSsoAuthMiddleware`.

### Rotas Slim com leitura simples

Organizar rotas de forma parecida com o F3:

```php
$app->get('/', [UserController::class, 'login']);
$app->get('/perfil', [UserController::class, 'perfil']);
$app->get('/logout', [UserController::class, 'logout']);
$app->map(['GET', 'POST'], '/ger_lista', [ListaController::class, 'pagina']);
$app->post('/busca_pessoa', [ListaController::class, 'buscarPessoa']);
```

Para rotas protegidas, usar grupos:

```php
$app->group('', function ($group) {
    $group->get('/ger_lista', [ListaController::class, 'pagina']);
    $group->post('/novo_inscrito', [ListaController::class, 'novoInscrito']);
})->add(RoleMiddleware::any(['adm', 'opr']));
```

### Middleware de autenticacao

Criar um `OpenSsoAuthMiddleware` que:

- detecta ambiente por `APP_ENV`;
- em producao valida cookie `iPlanetDirectoryPro`;
- consulta atributos OpenSSO;
- popula um objeto `UsuarioAutenticado`;
- em desenvolvimento usa usuario fake configurado por `.env`;
- redireciona para login sem `header()` manual.

### Middleware ou service de sessao

O controle de sessao, expiracao e logout deve sair do controller. O Slim deve expor um service como `SessaoUsuario`, com metodos claros:

- `iniciar()`
- `registrarLogin($usuario)`
- `expirou()`
- `encerrar()`

### Repositories para banco

Trocar SQL espalhado por classes com metodos nomeados:

- `ServidorRepository::filtrarServidores(FiltroServidor $filtro)`
- `ListaRepository::ativas()`
- `ListaRepository::porGerente($codpes)`
- `InscritoRepository::porLista($lista, $pagina, $limite)`
- `PessoaRepository::buscarPorCodpes($codpes)`
- `PessoaRepository::buscarPorEmail($email)`
- `PessoaRepository::buscarPorNome($nome)`

Isso preserva a leitura por dominio e melhora testes.

### DTOs ou arrays validados para filtros

O scaffold nao precisa comecar com uma arquitetura pesada, mas deve ter validacao central para entradas importantes:

- `FiltroServidor`
- `BuscaPessoaRequest`
- `NovoInscritoRequest`
- `NovaRegraRequest`

Se DTO parecer complexo para a equipe, usar funcoes de normalizacao bem nomeadas no controller ou service, mas nunca concatenar entrada diretamente em SQL.

### Templates

Usar Twig ou PHP templates simples. O importante e manter:

- layout base;
- partials para header, menu, mensagens e footer;
- variaveis de view explicitas;
- helper para assets e rotas;
- mensagens flash padronizadas.

Exemplo conceitual:

- `app/Views/layouts/base.twig`
- `app/Views/partials/header.twig`
- `app/Views/partials/menu.twig`
- `app/Views/listas/gerencia.twig`
- `app/Views/usuarios/perfil.twig`

### JSON e AJAX

Separar endpoints AJAX em rotas `POST` especificas e retornar sempre um envelope previsivel:

```json
{
  "ok": true,
  "mensagem": "...",
  "dados": {}
}
```

Em erro:

```json
{
  "ok": false,
  "mensagem": "...",
  "erros": []
}
```

### Autorizacao

Preservar os papeis existentes:

- `adm`: administrador amplo;
- `opr`: operador ou gerente;
- `usr`: usuario comum.

Mas definir regras em um unico lugar. Controllers devem chamar algo legivel, como `canManageLista`, em vez de repetir consultas e condicionais.

### Estilo geral recomendado

O scaffold deve ser moderno, mas nao excessivamente abstrato:

- nomes de dominio em portugues quando fizer sentido;
- controllers curtos;
- repositories explicitos;
- services apenas quando houver regra de negocio real;
- middlewares para cross-cutting concerns;
- sem heranca pesada;
- sem camadas genericas que escondam SQL simples demais.

## 5. Riscos de manutencao para desenvolvedores com baixa familiaridade com arquitetura moderna

### Risco de scaffold moderno demais

Se o Slim vier com muitas camadas, factories, interfaces para tudo, namespaces profundos e padroes abstratos, a equipe pode perder a rastreabilidade que hoje existe. O resultado provavel seria manutencao por copia e cola, contornando a arquitetura.

Mitigacao: manter rotas, controllers e repositories com nomes obvios e exemplos completos.

### Risco de copiar o F3 literalmente

Se o scaffold copiar o estilo atual sem ajustes, herdara os principais problemas:

- SQL inseguro;
- controllers muito grandes;
- baixa testabilidade;
- dependencia de superglobais;
- autorizacao espalhada;
- configuracao sensivel versionada;
- dificuldade de trocar autenticacao ou banco.

Mitigacao: preservar familiaridade visual e de nomenclatura, mas alterar os limites tecnicos.

### Risco de inseguranca por desconhecimento de PSR-7

Desenvolvedores acostumados com `echo`, `header()` e `$_POST` podem ter dificuldade com request/response imutavel do Slim.

Mitigacao: criar exemplos de controller padrao para HTML, JSON e redirect. Esses exemplos devem ser copiados nos novos casos.

### Risco de duplicacao de regras

Se autorizacao e consulta de papel nao forem centralizadas desde o inicio, cada tela pode recriar sua propria regra. Isso ja aparece nos exemplos com condicionais locais.

Mitigacao: criar `AuthService`, `UsuarioAutenticado` e `AuthorizationService` simples antes das primeiras telas.

### Risco de repositories virarem novo "Controller.php"

Ao mover SQL para repositories, existe risco de criar repositories enormes com qualquer consulta do sistema.

Mitigacao: dividir por agregado de dominio e manter metodos pequenos. Se uma consulta serve a uma tela especifica, nomear isso claramente.

### Risco de dificuldade em depurar

O F3 atual permite debugar olhando controller e `logs/app-events.log`. Em Slim, se logs, erros e respostas nao forem padronizados, a equipe pode sentir que o sistema ficou opaco.

Mitigacao: configurar logging desde o scaffold, com mensagens consistentes por rota, usuario, acao e erro.

### Risco de migracao parcial confusa

Durante transicao, pode haver mistura de rotas estilo pagina, endpoints AJAX e services novos. Se cada tela seguir um padrao diferente, o scaffold deixara de cumprir seu papel.

Mitigacao: documentar exemplos oficiais no proprio scaffold:

- pagina HTML protegida;
- endpoint JSON;
- formulario POST com redirect;
- consulta paginada;
- exportacao de arquivo;
- envio de e-mail;
- autorizacao por papel.

## Decisao recomendada

O novo scaffold Slim deve preservar a simplicidade operacional dos exemplos F3: rotas explicitas, controllers reconheciveis, templates com layout comum, vocabulario em portugues e fluxo facil de seguir.

Ao mesmo tempo, deve corrigir os pontos de maior risco: superglobais, SQL concatenado, segredos versionados, controller base excessivo, autorizacao espalhada e mistura de HTML/JSON/mutacao no mesmo metodo.

A melhor direcao e uma arquitetura moderada: Slim com PSR-7, container simples, middlewares claros, repositories por dominio e templates familiares. O objetivo nao e introduzir arquitetura moderna como fim em si, mas reduzir riscos mantendo a equipe produtiva.
