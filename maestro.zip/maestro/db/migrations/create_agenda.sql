-- Migration converted to MySQL-compatible DDL
USE maestro;
-- 1. Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    nusp VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(150) NOT NULL,
    criado_em TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Tabela de Funções / Níveis de Permissão
CREATE TABLE IF NOT EXISTS funcoes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE,
    descricao VARCHAR(255) NULL,
    criado_em TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Tabela de Junção: Usuários <-> Funções (Relacionamento N:N)
CREATE TABLE IF NOT EXISTS usuario_funcoes (
    usuario_id BIGINT UNSIGNED NOT NULL,
    funcao_id BIGINT UNSIGNED NOT NULL,
    atribuido_em TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, funcao_id),
    CONSTRAINT fk_usuario_funcoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_usuario_funcoes_funcao FOREIGN KEY (funcao_id) REFERENCES funcoes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Tabela de Agenda de Notificações / Atividades
-- Note: `processos.id` is VARCHAR(191) in existing schema; we reference it accordingly.
CREATE TABLE IF NOT EXISTS agenda (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    processo_id VARCHAR(191) NULL,
    instancia_id BIGINT UNSIGNED NULL,
    instancia_elemento_id BIGINT UNSIGNED NULL,
    tipo_agenda ENUM('Tarefa', 'Notificação', 'Mensagem') NOT NULL,
    tipo_node VARCHAR(150) NOT NULL,
    assunto VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    cor VARCHAR(7) DEFAULT '#E0FFFF',
    data_notificacao DATETIME NOT NULL,
    data_fim DATETIME NULL,
    lida TINYINT(1) NOT NULL DEFAULT 0,
    concluido TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_agenda_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_agenda_processo FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE SET NULL,
    CONSTRAINT fk_agenda_instancia FOREIGN KEY (instancia_id) REFERENCES processo_instancias(id) ON DELETE SET NULL,
    CONSTRAINT fk_agenda_instancia_elemento FOREIGN KEY (instancia_elemento_id) REFERENCES instancia_elementos(id) ON DELETE SET NULL,
    CONSTRAINT chk_agenda_cor CHECK (cor IS NULL OR cor REGEXP '^#[0-9A-Fa-f]{6}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- ÍNDICES DE PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_usuario_funcoes_funcao ON usuario_funcoes (funcao_id);

CREATE INDEX IF NOT EXISTS idx_agenda_usuario_datas ON agenda (usuario_id, data_notificacao, data_fim);

CREATE INDEX IF NOT EXISTS idx_agenda_usuario_concluida ON agenda (usuario_id, concluida, data_notificacao);

CREATE INDEX IF NOT EXISTS idx_agenda_processo_elemento ON agenda (processo_id, instancia_elemento_id);

CREATE INDEX IF NOT EXISTS idx_agenda_usuario_lida ON agenda (usuario_id, lida);