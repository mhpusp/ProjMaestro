-- Migration: create_maestro.sql
-- Creates database `maestro` and tables for process definitions, instances and instance elements

CREATE DATABASE IF NOT EXISTS maestro CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
USE maestro;

-- Table: processos (Mantém o cadastro de processos e suas versões)
CREATE TABLE IF NOT EXISTS processos (
  id VARCHAR(191) NOT NULL PRIMARY KEY,
  processo_pai_id VARCHAR(191) NULL,
  nome VARCHAR(255) NOT NULL,
  descricao TEXT NULL,
  versao INT UNSIGNED NOT NULL DEFAULT 1,
  arquivo VARCHAR(255) NULL, --Nome do arquivo json do processo
  status TINYINT(1) NOT NULL DEFAULT 0, --Versão corrente ativa 
  dono_processo VARCHAR(15) NOT NULL,
  lista_subprocessos JSON NULL, --Nomes arquivsos dos subprocessos
  raias_participantes JSON NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_processos_pai FOREIGN KEY (processo_pai_id) REFERENCES processos(id) ON DELETE RESTRICT,
  INDEX idx_processos_nome (nome),
  INDEX idx_processos_pai (processo_pai_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: processo_instancias (Mantém as instâncias de processos em execução)
CREATE TABLE IF NOT EXISTS processo_instancias (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  processo_id VARCHAR(191) NOT NULL,
  concluido TINYINT(1) NOT NULL DEFAULT 0,
  dados_form JSON NULL,
  raias_participantes JSON NULL,
  criado_por VARCHAR(30) NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (processo_id) REFERENCES processos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: instancia_elementos (Mantém os elementos de cada instância de processo em execução)
CREATE TABLE IF NOT EXISTS instancia_elementos (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  instancia_id BIGINT UNSIGNED NOT NULL,
  elemento_id VARCHAR(191) NOT NULL,
  tipo VARCHAR(64) NULL,
  nome_raia VARCHAR(255) NULL,
  participante VARCHAR(30) NULL,
  nome VARCHAR(255) NULL,
  descricao TEXT NULL,
  arquivo VARCHAR(255) NULL,
  pergunta TEXT NULL,
  respostas JSON NULL,
  evento JSON NULL,
  volta JSON NULL,
  libera JSON NULL,
  concluido TINYINT(1) NOT NULL DEFAULT 0,
  origem VARCHAR(191) NULL,
  destino VARCHAR(191) NULL,
  dados_form JSON NULL,
  criado_por VARCHAR(30) NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (instancia_id) REFERENCES processo_instancias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Indexes to speed lookups
CREATE INDEX IF NOT EXISTS idx_instancia_processo ON processo_instancias(processo_id);
CREATE INDEX IF NOT EXISTS idx_instancia_current_element ON processo_instancias(current_element_id);
CREATE INDEX IF NOT EXISTS idx_elemento_instancia ON instancia_elementos(instancia_id);

-- End of migration
