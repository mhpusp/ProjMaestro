-- Migration: add process versioning and parent relationship to existing databases.
USE maestro;

ALTER TABLE processos
  MODIFY versao INT UNSIGNED NOT NULL DEFAULT 1;

ALTER TABLE processos
  ADD COLUMN processo_pai_id VARCHAR(191) NULL AFTER id;

ALTER TABLE processos
  ADD INDEX idx_processos_nome (nome),
  ADD INDEX idx_processos_pai (processo_pai_id),
  ADD CONSTRAINT fk_processos_pai
    FOREIGN KEY (processo_pai_id) REFERENCES processos(id) ON DELETE RESTRICT;