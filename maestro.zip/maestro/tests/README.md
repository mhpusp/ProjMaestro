# Testes

Este diretorio fica reservado para os testes automatizados do scaffold.

A primeira versao mantem a estrutura pronta, sem escolher uma ferramenta de testes antes da equipe validar o padrao inicial.
